/// <mls fileReference="_102034_/l1/server/layer_2_controllers/contracts.ts" enhancement="_blank" />
import type { IDataRuntime } from '/_102034_/l1/server/layer_1_external/data/runtime.js';
import type { ICacheRuntime } from '/_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory.js';
import type { MdmFacade } from '/_102034_/l1/mdm/layer_3_usecases/mdmFacade.js';
import type { ConnectionContext } from '/_102034_/l1/server/layer_1_external/connections/catalogs/types.js';

/**
 * What a route that serves an operation of a connection receives, next to the input: which operation, who the call is about
 * (`context`, where the person is the only person) and the idempotency key. Only a `message` request (a server-side caller)
 * can carry it; over `http` it is discarded.
 */
export interface BffConnectionMeta {
  connectionId: string;
  operationId: string;
  context: ConnectionContext;
  idempotencyKey?: string;
}

export interface BffRequestTelemetryEvent {
  eventType: string;
  label: string;
  durationMs?: number | null;
  metadata?: Record<string, unknown> | null;
  recordedAt: string;
}

export interface BffRequest {
  routine: string;
  params: unknown;
  meta?: {
    requestId?: string;
    /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
    userId?: string;
    authToken?: string;
    /**
     * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
     * usefully — the http transport overwrites them from the JWKS-verified token, and every other
     * identity field of this meta is discarded on that transport. This is the only channel through which
     * a request may tell execBff who it is.
     */
    verifiedUserId?: string;
    verifiedEmail?: string;
    /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
    verifiedAuthorities?: string[];
    traceId?: string;
    source?: 'http' | 'message' | 'test';
    /**
     * "Done through the assistant". Read ONLY when `source` is `message` (a server-side caller) and only the value
     * `nora`; over `http` it is discarded like every other identity claim.
     */
    via?: 'nora';
    /**
     * Who the author is, when it is not a person: `agent` is a virtual employee acting in its own name (its id is `userId`).
     * Read ONLY when `source` is `message`; over `http` it is discarded like every other identity claim.
     */
    actorType?: 'agent';
    /**
     * With `actorType: 'agent'`: the member of the agent in the mdm (its id and name), put in `sessionContext.person` so the domain fields
     * that say who did it carry the member. Read ONLY when `source` is `message`; over `http` it is discarded.
     */
    agentMdmId?: string;
    agentName?: string;
    /** A call that arrives through a connection (`/exec/connection`). Read ONLY when `source` is `message`. */
    connection?: BffConnectionMeta;
    actorId?: string;
    actorScope?: string[];
    activeCompanyId?: string;
    activeUnitId?: string;
    workspaceId?: string;
    telemetry?: BffRequestTelemetryEvent[];
  };
}

export type ShellMode = 'spa' | 'pwa';
export type DeviceKind = 'desktop' | 'mobile';
export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';

export interface FrontendRegionVisibility {
  header: boolean;
  aside: boolean;
  content: boolean;
}

export interface FrontendAppLayout {
  regions: {
    desktop: FrontendRegionVisibility;
    mobile: FrontendRegionVisibility;
  };
  asideMode: {
    desktop: FrontendAsideMode;
    mobile: FrontendAsideMode;
  };
  asideSize?: {
    desktopWidthPx?: number;
    drawerWidthPx?: number;
  };
}

export interface FrontendRegionRendererRegistration {
  entrypoint: string;
  tag: string;
}

export type FrontendRegionName = 'header' | 'aside' | 'content';

export interface FrontendDynamicRegionConfig {
  renderer: FrontendRegionRendererRegistration;
  widthPx?: number;
  source?: string;
  switchWithoutRouteReload?: boolean;
  props?: Record<string, unknown>;
  brand?: Record<string, unknown>;
  component?: string;
  appsMenuSource?: string;
  [key: string]: unknown;
}

export interface FrontendShellRegionProfiles {
  activeProfile: string;
  switchWithoutRouteReload?: boolean;
  profiles: Record<string, FrontendDynamicRegionConfig>;
}

export interface FrontendClientShellConfig {
  mode: ShellMode;
  activeProfile?: string;
  runtimeControls?: Record<string, string>;
  regions: {
    header?: FrontendShellRegionProfiles;
    aside?: FrontendShellRegionProfiles;
  };
}

export type FrontendRouteMatchMode = 'exact' | 'prefix';

export interface FrontendRouteRegistration {
  path: string;
  entrypoint: string;
  tag: string;
  title: string;
  aliases?: string[];
  loadingKey?: string;
  preload?: boolean;
  matchMode?: FrontendRouteMatchMode;
}

export interface FrontendModuleShellPreferences {
  layout?: Partial<FrontendAppLayout>;
}

export interface FrontendNavigationItem {
  id: string;
  label: string;
  href: string;
  description?: string;
  /** Optional Lucide icon name. Absent when the config item has none. */
  icon?: string;
}

export interface BffError {
  code: string;
  message: string;
  details?: unknown;
}

export interface BffResponse<TData = unknown> {
  ok: boolean;
  data: TData | null;
  error: BffError | null;
  telemetryReceived?: number;
}

export interface ILogger {
  info(message: string, data?: unknown): void;
  error(message: string, data?: unknown): void;
}

export interface IClock {
  nowIso(): string;
}

export interface IIdGenerator {
  newId(): string;
}

export interface RequestBusinessContext {
  activeCompanyId?: string;
  activeUnitId?: string;
}

export interface RequestActorSession {
  actorId?: string;
  scope?: string[];
}

export interface RequestCurrentWorkspace {
  workspaceId?: string;
}

export interface RequestProjectContext {
  projectId?: string;
  domain?: string;
  port?: number;
  databaseName?: string;
  environment?: string;
  studioEnabled?: boolean;
}

export interface RequestOrganizationContext {
  countryCode: string;
  currency?: string;
  timezone?: string;
}

/**
 * Typed projection of the signed-in Person onto the session — public contract, not the MDM document.
 * Resolved from the login row of `mdm_tag` for a verified e-mail; absent when the e-mail has no login.
 * The monitor test runner (`source: 'test'`) sets it from the sandbox fixture's seeded Person, with
 * `email` '' when that fixture declares no login (a simulated identity, never an invented e-mail).
 */
export interface PlatformSessionPerson {
  mdmId: string;
  email: string;
  name: string;
}

export interface CollabAuthInviteClient {
  createInvite(input: {
    orgId: string;
    email: string;
    apiKey: string;
    moduleId: string;
    actorId: string;
  }): Promise<{ token: string; expiresAt: string; teamIds?: string[] }>;
}

export interface RequestSessionContext {
  /** The Company the session acts for, resolved by the platform for the organization; it is not the signed-in Person. */
  activeCompanyId?: string;
  activeUnitId?: string;
  actorId?: string;
  actorScope?: string[];
  workspaceId?: string;
  /** Set by `execBff` for a `message` request that carries `via: 'nora'`; never from `http`. The workflow advance marks the history with it. */
  via?: 'nora';
  /** Typed projection of the Person: set when `mdm.identity.findByLogin` resolves the verified e-mail, or by the monitor runner from its sandbox fixture. */
  person?: PlatformSessionPerson;
  businessContext: RequestBusinessContext;
  actorSession: RequestActorSession;
  currentWorkspace: RequestCurrentWorkspace;
  project: RequestProjectContext;
}

export interface RequestContext {
  data: IDataRuntime;
  mdm: MdmFacade;
  cache: ICacheRuntime;
  /** Test/override seam for collab-auth invites. Production uses COLLAB_AUTH_* env. */
  collabAuthInvite?: CollabAuthInviteClient;
  log: ILogger;
  clock: IClock;
  idGenerator: IIdGenerator;
  sessionContext: RequestSessionContext;
  /**
   * Caller module of this BFF (`ordenServicio2`). Absent on platform/test callers.
   * `organization` is the super module: unfiltered MDM reads and writes.
   */
  moduleId?: string;
  /** Installation/org locale — never derived from UI language. */
  organization: RequestOrganizationContext;
  // Disposable runtime (test sandbox): the execution is not real traffic, so execBff
  // keeps it out of the monitor execution log and telemetry.
  sandbox?: boolean;
  requestMeta?: {
    requestId?: string;
    /**
     * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
     * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
     */
    userId?: string;
    traceId?: string;
    source?: 'http' | 'message' | 'test';
    /** `agent` when a virtual employee acts in its own name (set only for a `message` request); the audit trail records it. */
    actorType?: 'user' | 'agent' | 'system';
    /** The connection call that caused this request, when one did (set only for a `message` request). */
    connection?: BffConnectionMeta;
  };
}

export interface IRequestEnvelope {
  request: BffRequest;
  ctx: RequestContext;
}

export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;

// Self-describing route exported by a hexagonal http controller, so the runtime can discover
// routes by enumerating the module's controllers folder (no generated router file).
export interface ControllerRoute {
  key: string;
  handler: BffHandler;
}

export interface ModuleBffRegistration {
  projectId: string;
  moduleId: string;
  frontendBasePath: string;
  frontendEntrypoint: string;
  loadRouter: () => Promise<Map<string, BffHandler>>;
  backendControllers?: string;
}

export interface FrontendAppRegistration {
  projectId: string;
  appId: string;
  basePath: string;
  indexHtmlPath: string;
  assetRoots: string[];
  routePatterns: string[];
  shellMode: ShellMode;
  languages?: string[];
  designSystems?: string[];
  routes: FrontendRouteRegistration[];
  headerRenderer?: FrontendRegionRendererRegistration;
  asideRenderer?: FrontendRegionRendererRegistration;
  layout: FrontendAppLayout;
  device?: DeviceKind;
  pageTitle?: string;
  navigation?: FrontendNavigationItem[];
  moduleLinks?: FrontendNavigationItem[];
  clientShell?: FrontendClientShellConfig;
  /** Same-origin favicon href injected into the served HTML (`<link rel="icon">`). */
  faviconHref?: string;
}

export interface RoutineResolution {
  moduleId: string;
  routineName: string;
  registration: ModuleBffRegistration;
}

export class AppError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly details?: unknown;

  public constructor(
    code: string,
    message: string,
    statusCode = 400,
    details?: unknown,
  ) {
    super(message);
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
  }
}

export function ok<TData>(data: TData): BffResponse<TData> {
  return {
    ok: true,
    data,
    error: null,
  };
}

export function fail(error: AppError): BffResponse {
  return {
    ok: false,
    data: null,
    error: {
      code: error.code,
      message: error.message,
      details: error.details,
    },
  };
}

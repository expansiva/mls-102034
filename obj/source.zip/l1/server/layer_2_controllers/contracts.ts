/// <mls fileReference="_102034_/l1/server/layer_2_controllers/contracts.ts" enhancement="_blank" />
import type { IDataRuntime } from '/_102034_/l1/server/layer_1_external/data/runtime.js';
import type { MdmFacade } from '/_102034_/l1/mdm/layer_3_usecases/mdmFacade.js';

export interface BffRequestTelemetryEvent {
  eventType: string;
  label: string;
  durationMs?: number | null;
  metadata?: Record<string, unknown> | null;
  recordedAt: string;
}

export interface BffRequest {
  routine: string;
  params: unknown;
  meta?: {
    requestId?: string;
    /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
    userId?: string;
    authToken?: string;
    /**
     * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
     * usefully — the http transport overwrites them from the JWKS-verified token, and every other
     * identity field of this meta is discarded on that transport. This is the only channel through which
     * a request may tell execBff who it is.
     */
    verifiedUserId?: string;
    verifiedEmail?: string;
    /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
    verifiedAuthorities?: string[];
    traceId?: string;
    source?: 'http' | 'message' | 'test';
    actorId?: string;
    actorScope?: string[];
    activeCompanyId?: string;
    activeUnitId?: string;
    workspaceId?: string;
    telemetry?: BffRequestTelemetryEvent[];
  };
}

export type ShellMode = 'spa' | 'pwa';
export type DeviceKind = 'desktop' | 'mobile';
export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';

export interface FrontendRegionVisibility {
  header: boolean;
  aside: boolean;
  content: boolean;
}

export interface FrontendAppLayout {
  regions: {
    desktop: FrontendRegionVisibility;
    mobile: FrontendRegionVisibility;
  };
  asideMode: {
    desktop: FrontendAsideMode;
    mobile: FrontendAsideMode;
  };
  asideSize?: {
    desktopWidthPx?: number;
    drawerWidthPx?: number;
  };
}

export interface FrontendRegionRendererRegistration {
  entrypoint: string;
  tag: string;
}

export type FrontendRegionName = 'header' | 'aside' | 'content';

export interface FrontendDynamicRegionConfig {
  renderer: FrontendRegionRendererRegistration;
  widthPx?: number;
  source?: string;
  switchWithoutRouteReload?: boolean;
  props?: Record<string, unknown>;
  brand?: Record<string, unknown>;
  component?: string;
  appsMenuSource?: string;
  [key: string]: unknown;
}

export interface FrontendShellRegionProfiles {
  activeProfile: string;
  switchWithoutRouteReload?: boolean;
  profiles: Record<string, FrontendDynamicRegionConfig>;
}

export interface FrontendClientShellConfig {
  mode: ShellMode;
  activeProfile?: string;
  runtimeControls?: Record<string, string>;
  regions: {
    header?: FrontendShellRegionProfiles;
    aside?: FrontendShellRegionProfiles;
  };
}

export type FrontendRouteMatchMode = 'exact' | 'prefix';

export interface FrontendRouteRegistration {
  path: string;
  entrypoint: string;
  tag: string;
  title: string;
  aliases?: string[];
  loadingKey?: string;
  preload?: boolean;
  matchMode?: FrontendRouteMatchMode;
}

export interface FrontendModuleShellPreferences {
  layout?: Partial<FrontendAppLayout>;
}

export interface FrontendNavigationItem {
  id: string;
  label: string;
  href: string;
  description?: string;
}

export interface BffError {
  code: string;
  message: string;
  details?: unknown;
}

export interface BffResponse<TData = unknown> {
  ok: boolean;
  data: TData | null;
  error: BffError | null;
  telemetryReceived?: number;
}

export interface ILogger {
  info(message: string, data?: unknown): void;
  error(message: string, data?: unknown): void;
}

export interface IClock {
  nowIso(): string;
}

export interface IIdGenerator {
  newId(): string;
}

export interface RequestBusinessContext {
  activeCompanyId?: string;
  activeUnitId?: string;
}

export interface RequestActorSession {
  actorId?: string;
  scope?: string[];
}

export interface RequestCurrentWorkspace {
  workspaceId?: string;
}

export interface RequestProjectContext {
  projectId?: string;
  domain?: string;
  port?: number;
  databaseName?: string;
  environment?: string;
  studioEnabled?: boolean;
}

export interface RequestOrganizationContext {
  countryCode: string;
  currency?: string;
  timezone?: string;
}

export interface RequestSessionContext {
  activeCompanyId?: string;
  activeUnitId?: string;
  actorId?: string;
  actorScope?: string[];
  workspaceId?: string;
  businessContext: RequestBusinessContext;
  actorSession: RequestActorSession;
  currentWorkspace: RequestCurrentWorkspace;
  project: RequestProjectContext;
}

export interface RequestContext {
  data: IDataRuntime;
  mdm: MdmFacade;
  log: ILogger;
  clock: IClock;
  idGenerator: IIdGenerator;
  sessionContext: RequestSessionContext;
  /**
   * Caller module of this BFF (`ordenServicio2`). Absent on platform/test callers.
   * `organization` is the super module: unfiltered MDM reads and writes.
   */
  moduleId?: string;
  /** Installation/org locale — never derived from UI language. */
  organization: RequestOrganizationContext;
  // Disposable runtime (test sandbox): the execution is not real traffic, so execBff
  // keeps it out of the monitor execution log and telemetry.
  sandbox?: boolean;
  requestMeta?: {
    requestId?: string;
    /**
     * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
     * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
     */
    userId?: string;
    traceId?: string;
    source?: 'http' | 'message' | 'test';
  };
}

export interface IRequestEnvelope {
  request: BffRequest;
  ctx: RequestContext;
}

export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;

// Self-describing route exported by a hexagonal http controller, so the runtime can discover
// routes by enumerating the module's controllers folder (no generated router file).
export interface ControllerRoute {
  key: string;
  handler: BffHandler;
}

export interface ModuleBffRegistration {
  projectId: string;
  moduleId: string;
  frontendBasePath: string;
  frontendEntrypoint: string;
  loadRouter: () => Promise<Map<string, BffHandler>>;
}

export interface FrontendAppRegistration {
  projectId: string;
  appId: string;
  basePath: string;
  indexHtmlPath: string;
  assetRoots: string[];
  routePatterns: string[];
  shellMode: ShellMode;
  languages?: string[];
  designSystems?: string[];
  routes: FrontendRouteRegistration[];
  headerRenderer?: FrontendRegionRendererRegistration;
  asideRenderer?: FrontendRegionRendererRegistration;
  layout: FrontendAppLayout;
  device?: DeviceKind;
  pageTitle?: string;
  navigation?: FrontendNavigationItem[];
  moduleLinks?: FrontendNavigationItem[];
  clientShell?: FrontendClientShellConfig;
  /** Same-origin favicon href injected into the served HTML (`<link rel="icon">`). */
  faviconHref?: string;
}

export interface RoutineResolution {
  moduleId: string;
  routineName: string;
  registration: ModuleBffRegistration;
}

export class AppError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly details?: unknown;

  public constructor(
    code: string,
    message: string,
    statusCode = 400,
    details?: unknown,
  ) {
    super(message);
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
  }
}

export function ok<TData>(data: TData): BffResponse<TData> {
  return {
    ok: true,
    data,
    error: null,
  };
}

export function fail(error: AppError): BffResponse {
  return {
    ok: false,
    data: null,
    error: {
      code: error.code,
      message: error.message,
      details: error.details,
    },
  };
}

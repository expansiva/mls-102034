import { ensureEnvFileLoaded } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { msgProxyTarget, serviceIdentityHeaders } from '/_102034_/l1/server/layer_1_external/transport/http/msgProxy.js';
import { moduleHeaders as moduleCredentialHeaders, postEnvelope } from '/_102034_/l1/server/layer_1_external/collabMessages/transport.js';
import type {
  AgentIntentModuleAdvance,
  RequestAddMessage,
  RequestAddUserInThread,
  RequestApplyIntents,
  RequestEnsureModuleThread,
  RequestGetModuleTask,
  RequestGetTaskUpdate,
  RequestLinkModulePerson,
  RequestListModuleTasks,
  RequestModuleLlmStep,
  RequestOpenModuleTask,
  RequestResolveModulePeople,
  ResponseAddMessage,
  ResponseAddUserInThread,
  ResponseApplyIntents,
  ResponseBase,
  ResponseEnsureModuleThread,
  ResponseGetModuleTask,
  ResponseGetTaskUpdate,
  ResponseLinkModulePerson,
  ResponseListModuleTasks,
  ResponseModuleLlmStep,
  ResponseOpenModuleTask,
  ResponseResolveModulePeople,
} from '/_102036_/l2/shared/interfaces.js';

const DEFAULT_TIMEOUT_MS = 10_000;

const NOT_CONFIGURED = 'collab-messages service is not configured';

type ActionName =
  | 'ensureModuleThread'
  | 'openModuleTask'
  | 'getModuleTask'
  | 'listModuleTasks'
  | 'requestModuleLlmStep'
  | 'applyIntents'
  | 'getTaskUpdate'
  | 'addMessage'
  | 'addUserInThread'
  | 'linkModulePerson'
  | 'resolveModulePeople';

/**
 * Actions whose collab-messages schema has no body `userId` (additionalProperties: false rejects it).
 * Contract: collab-messages src/layer_2_controllers/moduleTasks.ts (open/get/list schemas) and
 * src/local.ts `bindAppActingUser` — on the app path the acting user travels only in `x-user-id`.
 */
const ACTIONS_WITHOUT_BODY_USER_ID: ReadonlySet<ActionName> = new Set<ActionName>([
  'openModuleTask',
  'getModuleTask',
  'listModuleTasks',
  // rt209: the schema of requestModuleLlmStep (moduleTasks.ts RequestModuleLlmStepSchema) has no userId either.
  'requestModuleLlmStep',
]);

function bodyOf(action: ActionName, input: object, userId: string): Record<string, unknown> {
  const body: Record<string, unknown> = { ...input, action, userId };
  if (ACTIONS_WITHOUT_BODY_USER_ID.has(action)) delete body.userId;
  return body;
}

export type MessagesCallResult<T> = {
  httpStatus: number;
  body: ResponseBase & Partial<T> & { code?: string };
};

export type ServerMessagesClientOptions = {
  env?: NodeJS.ProcessEnv;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
  /** Server-resolved application id. Module calls read its private credential; common calls ignore it. */
  projectId?: string;
};

export type ServerMessagesClient = {
  ensureModuleThread(
    asUserId: string,
    input: Omit<RequestEnsureModuleThread, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseEnsureModuleThread>>;
  openModuleTask(
    asUserId: string,
    input: Omit<RequestOpenModuleTask, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseOpenModuleTask>>;
  getModuleTask(
    asUserId: string,
    input: Omit<RequestGetModuleTask, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseGetModuleTask>>;
  listModuleTasks(
    asUserId: string,
    input: Omit<RequestListModuleTasks, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseListModuleTasks>>;
  advanceModuleTask(
    asUserId: string,
    intent: AgentIntentModuleAdvance,
  ): Promise<MessagesCallResult<ResponseApplyIntents>>;
  requestModuleLlmStep(
    asUserId: string,
    input: Omit<RequestModuleLlmStep, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseModuleLlmStep>>;
  applyIntents(
    asUserId: string,
    input: Omit<RequestApplyIntents, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseApplyIntents>>;
  getTaskUpdate(
    asUserId: string,
    input: Omit<RequestGetTaskUpdate, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseGetTaskUpdate>>;
  addMessage(
    asUserId: string,
    input: Omit<RequestAddMessage, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseAddMessage>>;
  addUserInThread(
    asUserId: string,
    input: Omit<RequestAddUserInThread, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseAddUserInThread>>;
  linkModulePerson(
    asUserId: string,
    input: Omit<RequestLinkModulePerson, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseLinkModulePerson>>;
  resolveModulePeople(
    asUserId: string,
    input: Omit<RequestResolveModulePeople, 'action' | 'userId'>,
  ): Promise<MessagesCallResult<ResponseResolveModulePeople>>;
};

function timeoutMsOf(timeoutMs: number | undefined): number {
  if (timeoutMs === undefined) return DEFAULT_TIMEOUT_MS;
  if (!Number.isInteger(timeoutMs) || timeoutMs <= 0) {
    throw new AppError('MSG_SERVICE_NOT_CONFIGURED', NOT_CONFIGURED, 503);
  }
  return timeoutMs;
}

function callerUserId(asUserId: string): string {
  const userId = asUserId.trim();
  if (!userId || /[\r\n]/u.test(asUserId) || /[\r\n]/u.test(userId)) {
    throw new AppError('MSG_SERVICE_NOT_CONFIGURED', NOT_CONFIGURED, 503);
  }
  return userId;
}

function localError(code: string, statusCode: number, message: string): AppError {
  return new AppError(code, message, statusCode);
}

type CallAuth = 'common' | 'module';

const MODULE_INTENT_UNSUPPORTED = 'Module intent is not accepted on this call.';

function isModuleIntentType(type: unknown): boolean {
  return type === 'module-advance' || type === 'module-progress';
}

function containsModuleIntent(intents: unknown): boolean {
  if (!Array.isArray(intents)) return false;
  return intents.some((item) => {
    if (item === null || typeof item !== 'object') return false;
    return isModuleIntentType((item as { type?: unknown }).type);
  });
}

export function createServerMessagesClient(options: ServerMessagesClientOptions = {}): ServerMessagesClient {
  const timeoutMs = timeoutMsOf(options.timeoutMs);
  const fetchImpl = options.fetchImpl ?? fetch;
  if (options.env === undefined) ensureEnvFileLoaded();
  const source = options.env ?? process.env;
  const capturedEnv: NodeJS.ProcessEnv = {
    MSG_PROXY_TARGET: source.MSG_PROXY_TARGET,
    MSG_PROXY_TOKEN: source.MSG_PROXY_TOKEN,
    MSG_PROXY_ORG_ID: source.MSG_PROXY_ORG_ID,
  };

  function moduleHeaders(asUserId: string, boundProject: string): Record<string, string> {
    return moduleCredentialHeaders(options.projectId, boundProject, asUserId);
  }

  function commonHeaders(action: ActionName, userId: string): Record<string, string> {
    const identity = serviceIdentityHeaders({ ...capturedEnv, MSG_PROXY_USER_ID: userId });
    if (!('inject' in identity) || identity.inject === null) {
      throw localError('MSG_SERVICE_NOT_CONFIGURED', 503, `${NOT_CONFIGURED} (${action})`);
    }
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      authorization: identity.inject.authorization,
      'x-user-id': identity.inject['x-user-id'],
    };
    if (identity.inject['x-org-id']) headers['x-org-id'] = identity.inject['x-org-id'];
    return headers;
  }

  async function call<T>(
    action: ActionName,
    asUserId: string,
    input: object,
    auth: CallAuth,
    boundProject?: string,
  ): Promise<MessagesCallResult<T>> {
    const userId = callerUserId(asUserId);
    const headers = auth === 'module' ? moduleHeaders(userId, boundProject ?? '') : commonHeaders(action, userId);

    return postEnvelope({
      fetchImpl,
      url: `${msgProxyTarget(capturedEnv)}/msg`,
      headers,
      body: JSON.stringify(bodyOf(action, input, userId)),
      timeoutMs,
      label: action,
    }) as Promise<MessagesCallResult<T>>;
  }

  return {
    ensureModuleThread: (asUserId, input) => call('ensureModuleThread', asUserId, input, 'module', input.project),
    openModuleTask: (asUserId, input) => call('openModuleTask', asUserId, input, 'module', input.ref.project),
    getModuleTask: (asUserId, input) => call('getModuleTask', asUserId, input, 'module', input.ref.project),
    listModuleTasks: (asUserId, input) => call('listModuleTasks', asUserId, input, 'module', input.project),
    requestModuleLlmStep: (asUserId, input) => call('requestModuleLlmStep', asUserId, input, 'module', input.ref.project),
    advanceModuleTask: async (asUserId, intent) => {
      if (intent.type !== 'module-advance') {
        throw localError('MSG_MODULE_INTENT_UNSUPPORTED', 400, MODULE_INTENT_UNSUPPORTED);
      }
      return call('applyIntents', asUserId, { intents: [intent] }, 'module', options.projectId);
    },
    applyIntents: async (asUserId, input) => {
      if (containsModuleIntent(input.intents)) {
        throw localError('MSG_MODULE_INTENT_UNSUPPORTED', 400, MODULE_INTENT_UNSUPPORTED);
      }
      return call('applyIntents', asUserId, input, 'common');
    },
    getTaskUpdate: (asUserId, input) => call('getTaskUpdate', asUserId, input, 'common'),
    addMessage: (asUserId, input) => call('addMessage', asUserId, input, 'common'),
    addUserInThread: (asUserId, input) => call('addUserInThread', asUserId, input, 'common'),
    linkModulePerson: (asUserId, input) => call('linkModulePerson', asUserId, input, 'module', options.projectId),
    resolveModulePeople: (asUserId, input) => call('resolveModulePeople', asUserId, input, 'module', options.projectId),
  };
}

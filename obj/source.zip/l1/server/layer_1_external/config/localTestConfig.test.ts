/// <mls fileReference="_102034_/l1/server/layer_1_external/config/localTestConfig.test.ts" enhancement="_blank" />
import assert from 'node:assert/strict';
import { chmodSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import {
  LocalTestConfigError,
  assertLocalTestProxyTarget,
  getLocalTestConfig,
  loadLocalTestConfig,
  lookupLocalTestPersona,
  resetLocalTestConfigCache,
  type LocalTestConfigDeps,
} from '/_102034_/l1/server/layer_1_external/config/localTestConfig.js';

const PROJECT = '102047';
const PORT = 2047;
const KEY = 'k'.repeat(32);

function manifest(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    schema: 1,
    scope: 'lima',
    projectId: PROJECT,
    organizationKey: 'org-bench',
    companyMdmId: 'company-1',
    cmTarget: 'http://127.0.0.1:8180',
    cmOrgId: `runtime-test:${PROJECT}`,
    storagePrefix: 'desenv_',
    allowedOrigins: [`http://localhost:${PORT}`, `http://127.0.0.1:${PORT}`],
    cookieKey: KEY,
    personas: {
      responsavel: {
        email: `responsavel.${PROJECT}@runtime.test`,
        name: 'Responsavel',
        sub: `local-test:${PROJECT}:responsavel`,
        personMdmId: 'person-responsavel',
        cmUserId: 'cm-responsavel',
      },
      membro: {
        email: `membro.${PROJECT}@runtime.test`,
        name: 'Membro',
        sub: `local-test:${PROJECT}:membro`,
        personMdmId: 'person-membro',
        cmUserId: 'cm-membro',
      },
    },
    ...overrides,
  };
}

function deps(text: string, mode: { declared: boolean; mode: string } = { declared: true, mode: 'development' }): LocalTestConfigDeps & { reads: number } {
  const bag = {
    reads: 0,
    readText() {
      bag.reads += 1;
      return text;
    },
    fileMode: () => 0o600,
    defaultProjectId: () => PROJECT,
    projectMode: () => mode,
  };
  return bag;
}

function enabledEnv(file = '/etc/collab/local-tests/102047.json'): NodeJS.ProcessEnv {
  return { LOCAL_TEST_SESSION_ENABLED: 'true', LOCAL_TEST_SESSIONS_FILE: file };
}

test('flag off does not read the manifest', () => {
  const sources = deps('{');
  const state = loadLocalTestConfig({ LOCAL_TEST_SESSIONS_FILE: '/etc/collab/local-tests/102047.json' }, sources);
  assert.deepEqual(state, { enabled: false });
  assert.equal(sources.reads, 0);
  assert.equal(lookupLocalTestPersona({ alias: 'responsavel' }, state), null);
  assert.throws(() => assertLocalTestProxyTarget('http://127.0.0.1:8180', state), /disabled/u);
});

test('two profiles resolve by alias, email and sub, not by id', () => {
  const state = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(manifest())));
  assert.equal(state.enabled, true);
  if (!state.enabled) return;
  const byAlias = lookupLocalTestPersona({ alias: 'membro' }, state);
  const byEmail = lookupLocalTestPersona({ email: `responsavel.${PROJECT}@runtime.test` }, state);
  const bySub = lookupLocalTestPersona({ sub: `local-test:${PROJECT}:membro` }, state);
  assert.equal(byAlias?.cmUserId, 'cm-membro');
  assert.equal(byEmail?.sub, `local-test:${PROJECT}:responsavel`);
  assert.equal(bySub?.email, `membro.${PROJECT}@runtime.test`);
  assert.equal(lookupLocalTestPersona({ email: byAlias!.email, sub: 'other-sub' }, state), null);
  assert.equal(lookupLocalTestPersona({}, state), null);
  assertLocalTestProxyTarget('http://127.0.0.1:8180/', state);
  assert.throws(() => assertLocalTestProxyTarget('http://127.0.0.1:8181', state), /refused/u);
  assert.throws(() => assertLocalTestProxyTarget('http://10.0.0.8:8180', state), /refused/u);
});

function withAuthorities(responsavel: unknown, membro?: unknown): Record<string, unknown> {
  const base = manifest();
  const personas = base.personas as Record<string, Record<string, unknown>>;
  const next = { responsavel: { ...personas.responsavel }, membro: { ...personas.membro } };
  if (responsavel !== undefined) next.responsavel.authorities = responsavel;
  if (membro !== undefined) next.membro.authorities = membro;
  return { ...base, personas: next };
}

test('persona authorities: a list is kept, absent means none, a bad item or a repeat fails closed', () => {
  const withList = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(withAuthorities(['modA:actor', 'modB:other'], []))));
  assert.equal(withList.enabled, true);
  if (!withList.enabled) return;
  assert.deepEqual(withList.personas.responsavel.authorities, ['modA:actor', 'modB:other']);
  assert.deepEqual(withList.personas.membro.authorities, []);
  const old = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(manifest())));
  if (!old.enabled) return;
  assert.deepEqual(old.personas.responsavel.authorities, []);
  assert.deepEqual(old.personas.membro.authorities, []);
  for (const bad of [['actor'], ['modA:'], [':actor'], ['modA:actor:x'], ['modA:actor', 'modA:actor'], [7], 'modA:actor', null]) {
    assert.throws(
      () => loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(withAuthorities(bad)))),
      (error: LocalTestConfigError) => error.message === 'local test session manifest is invalid',
    );
  }
});

function withThird(extra: Record<string, unknown> = {}): Record<string, unknown> {
  const base = manifest();
  const personas = base.personas as Record<string, unknown>;
  return {
    ...base,
    personas: {
      ...personas,
      semPapel: {
        email: `semPapel.${PROJECT}@runtime.test`,
        name: 'Sem papel',
        sub: `local-test:${PROJECT}:semPapel`,
        personMdmId: 'person-semPapel',
        cmUserId: 'cm-semPapel',
        ...extra,
      },
    },
  };
}

test('semPapel is optional: a manifest of two and of three people are valid, and the third is validated like the others', () => {
  const two = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(manifest())));
  assert.equal(two.enabled, true);
  if (!two.enabled) return;
  assert.equal(two.personas.semPapel, undefined);
  assert.equal(lookupLocalTestPersona({ alias: 'semPapel' }, two), null);

  const three = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(withThird())));
  assert.equal(three.enabled, true);
  if (!three.enabled) return;
  assert.deepEqual(three.personas.semPapel?.authorities, []);
  assert.equal(lookupLocalTestPersona({ alias: 'semPapel' }, three)?.cmUserId, 'cm-semPapel');
  assert.equal(lookupLocalTestPersona({ sub: `local-test:${PROJECT}:semPapel` }, three)?.alias, 'semPapel');

  const withList = loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(withThird({ authorities: ['modA:actor'] }))));
  if (withList.enabled) assert.deepEqual(withList.personas.semPapel?.authorities, ['modA:actor']);

  const invalid = [
    withThird({ authorities: ['actor'] }),
    withThird({ authorities: ['modA:actor', 'modA:actor'] }),
    withThird({ cmUserId: 'cm-membro' }),
    withThird({ email: 'semPapel@example.com' }),
    { ...withThird(), personas: { ...(withThird().personas as Record<string, unknown>), outro: {} } },
  ];
  for (const bad of invalid) {
    assert.throws(
      () => loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(bad))),
      (error: LocalTestConfigError) => error.message === 'local test session manifest is invalid',
    );
  }
});

test('noAlpha: absent means false, a boolean is kept, anything else invalidates the manifest', () => {
  const read = (extra: Record<string, unknown>) => loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(manifest(extra))));
  const absent = read({});
  assert.equal(absent.enabled && absent.noAlpha, false);
  const off = read({ noAlpha: false });
  assert.equal(off.enabled && off.noAlpha, false);
  const on = read({ noAlpha: true });
  assert.equal(on.enabled && on.noAlpha, true);
  for (const bad of ['true', 1, null, [], {}]) {
    assert.throws(
      () => read({ noAlpha: bad }),
      (error: LocalTestConfigError) => error.message === 'local test session manifest is invalid',
    );
  }
});

test('missing file, relative path, bad mode, project and origin fail closed without secrets', () => {
  assert.throws(
    () => loadLocalTestConfig({ LOCAL_TEST_SESSION_ENABLED: 'true' }, deps('{}')),
    (error: LocalTestConfigError) => error.message.includes('absolute') && !error.message.includes(KEY),
  );

  const relative = deps(JSON.stringify(manifest()));
  assert.throws(() => loadLocalTestConfig(enabledEnv('local-tests/102047.json'), relative), /absolute/u);
  assert.equal(relative.reads, 0);

  const missing = deps(JSON.stringify(manifest()), { declared: true, mode: 'development' });
  missing.fileMode = () => {
    throw new Error('ENOENT secret-body');
  };
  assert.throws(
    () => loadLocalTestConfig(enabledEnv(), missing),
    (error: LocalTestConfigError) => !error.message.includes('secret-body') && !error.message.includes(KEY),
  );
  assert.equal(missing.reads, 0);

  for (const mode of [
    { declared: true, mode: 'production' },
    { declared: true, mode: 'homologation' },
    { declared: false, mode: 'presentation' },
  ]) {
    const sources = deps(JSON.stringify(manifest()), mode);
    assert.throws(() => loadLocalTestConfig(enabledEnv(), sources), /declared development or presentation/u);
    assert.equal(sources.reads, 0);
  }

  const cases: Record<string, unknown>[] = [
    { projectId: '102099' },
    { scope: 'remote' },
    { schema: 2 },
    { cmTarget: 'http://example.com:8180' },
    { storagePrefix: 'prod_' },
    { cookieKey: 'short' },
    { allowedOrigins: ['http://localhost:80'] },
    { allowedOrigins: [`http://localhost:${PORT}/app`] },
    { allowedOrigins: [`http://user:pw@localhost:${PORT}`] },
    { allowedOrigins: ['http://*.localhost:2047'] },
    { allowedOrigins: [`https://localhost:${PORT}`] },
    { personas: { ...manifest().personas as object, extra: {} } },
  ];
  for (const override of cases) {
    assert.throws(
      () => loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(manifest(override)))),
      (error: LocalTestConfigError) => !error.message.includes(KEY) && !error.message.includes('user:pw'),
    );
  }

  const shared = manifest();
  const personas = shared.personas as { membro: { sub: string } };
  personas.membro.sub = `local-test:${PROJECT}:responsavel`;
  assert.throws(() => loadLocalTestConfig(enabledEnv(), deps(JSON.stringify(shared))), /invalid|match/u);
});

test('presentation is accepted only when declared, and the cache ignores a later file edit', () => {
  const dir = mkdtempSync(join(tmpdir(), 'rt86-s1-'));
  const file = join(dir, '102047.json');
  writeFileSync(file, JSON.stringify(manifest()));
  chmodSync(file, 0o600);
  const sources = deps('', { declared: true, mode: 'presentation' });
  delete sources.readText;
  delete sources.fileMode;
  const env = enabledEnv(file);
  const first = loadLocalTestConfig(env, sources);
  assert.equal(first.enabled, true);

  resetLocalTestConfigCache();
  const cached = deps('', { declared: true, mode: 'presentation' });
  delete cached.readText;
  delete cached.fileMode;
  assert.equal(getLocalTestConfig(env, cached).enabled, true);
  writeFileSync(file, '{');
  chmodSync(file, 0o600);
  assert.equal(getLocalTestConfig(env, cached).enabled, true);
  resetLocalTestConfigCache();
  assert.throws(() => getLocalTestConfig(env, cached), LocalTestConfigError);
  resetLocalTestConfigCache();
});

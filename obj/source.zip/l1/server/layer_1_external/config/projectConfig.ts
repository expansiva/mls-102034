/// <mls fileReference="_102034_/l1/server/layer_1_external/config/projectConfig.ts" enhancement="_blank" />
import { existsSync, readFileSync } from 'node:fs';
import { extname, join, dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import type {
  ProjectConfigRecord,
  ProjectType,
  ProjectsConfig,
} from '/_102029_/l2/runtimeConfigTypes.js';

// Config types are shared, master-agnostic contracts hosted by 102029 (they are also
// used by the publish composers). Re-exported here to keep this module's public API.
export type {
  ProjectClientShellConfig,
  ProjectConfigRecord,
  ProjectDynamicRegionConfig,
  ProjectFrontendPageConfig,
  ProjectModuleConfig,
  ProjectModuleFrontendConfig,
  ProjectModuleFrontendEntrypoint,
  ProjectNavigationEntry,
  ProjectPersistenceModuleConfig,
  ProjectRegionRendererConfig,
  ProjectShellRegionProfiles,
  ProjectType,
  ProjectsConfig,
} from '/_102029_/l2/runtimeConfigTypes.js';

let cachedConfig: ProjectsConfig | null = null;

function normalizeProjectType(project: ProjectConfigRecord): ProjectType {
  if (project.type) {
    return project.type;
  }

  switch (project.role) {
    case 'frontend_base':
      return 'master frontend';
    case 'server_core':
      return 'master backend';
    case 'client_project':
      return 'client';
    default:
      return 'lib';
  }
}

function validateProjectsConfig(config: ProjectsConfig) {
  const projects = Object.entries(config.projects);
  const clients = projects.filter(([, project]) => project.type === 'client');
  const masterFrontends = projects.filter(([, project]) => project.type === 'master frontend');
  const masterBackends = projects.filter(([, project]) => project.type === 'master backend');

  if (clients.length !== 1) {
    throw new Error(`Workspace must declare exactly 1 project of type "client". Found ${clients.length}.`);
  }

  if (masterFrontends.length === 0) {
    throw new Error('Workspace must declare at least 1 project of type "master frontend".');
  }

  if (masterBackends.length === 0) {
    throw new Error('Workspace must declare at least 1 project of type "master backend".');
  }

  if (!config.projects[config.defaultProjectId]) {
    throw new Error(`defaultProjectId "${config.defaultProjectId}" is not declared in projects/config.json.`);
  }
}

function normalizeProjectsConfig(config: ProjectsConfig): ProjectsConfig {
  const normalizedProjects = Object.fromEntries(
    Object.entries(config.projects).map(([projectId, project]) => [
      projectId,
      {
        ...project,
        type: normalizeProjectType(project),
      },
    ]),
  ) as ProjectsConfig['projects'];

  const normalizedConfig: ProjectsConfig = {
    ...config,
    projects: normalizedProjects,
  };
  // Old config.json may still carry `publication`; drop it in memory, no warning.
  delete (normalizedConfig as { publication?: unknown }).publication;

  validateProjectsConfig(normalizedConfig);
  return normalizedConfig;
}

/**
 * `existsSync` for a default location that this process may not be allowed to read (a Deno child only reads its own
 * base): a denied check (`NotCapable`, `EACCES`) counts as absent, with one log line. Any other error still throws.
 */
export function existsSyncOrDenied(path: string): boolean {
  try {
    return existsSync(path);
  } catch (error) {
    const name = (error as Error).name;
    const code = (error as NodeJS.ErrnoException).code;
    if (name === 'NotCapable' || name === 'PermissionDenied' || code === 'EACCES' || code === 'EPERM') {
      if (!loggedDeniedPaths.has(path)) {
        loggedDeniedPaths.add(path);
        console.warn(`[cbe] cannot check ${path} (${name}${code ? ` ${code}` : ''}): treated as absent; set CBE_PROJECTS_DIR`);
      }
      return false;
    }
    throw error;
  }
}

const loggedDeniedPaths = new Set<string>();

function isProjectsConfigFile(configPath: string) {
  if (!existsSyncOrDenied(configPath)) {
    return false;
  }

  try {
    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Partial<ProjectsConfig>;
    return typeof config.defaultProjectId === 'string' && !!config.projects && typeof config.projects === 'object';
  } catch {
    return false;
  }
}

function findProjectsDir(startDir = process.cwd()) {
  let current = resolve(startDir);

  while (true) {
    const cwdProjectsConfig = resolve(current, 'config.json');
    if (isProjectsConfigFile(cwdProjectsConfig)) {
      return current;
    }

    const nestedProjectsConfig = resolve(current, 'projects', 'config.json');
    if (isProjectsConfigFile(nestedProjectsConfig)) {
      return resolve(current, 'projects');
    }

    const parent = dirname(current);
    if (parent === current) {
      return resolve(startDir);
    }
    current = parent;
  }
}

function getProjectsDir() {
  return findProjectsDir();
}

export function projectsConfigExists() {
  return existsSync(resolve(getProjectsDir(), 'config.json'));
}

function normalizeVirtualPath(relativePath: string) {
  return relativePath.replace(/^\.\//u, '').replace(/^\/+/u, '');
}

function resolveProjectSourcePath(relativePath: string): string | null {
  const normalized = normalizeVirtualPath(relativePath);
  const match = normalized.match(/^_(\d+)_\/(.*)$/u);
  if (!match) {
    return null;
  }

  const [, projectId, rest] = match;
  const base = resolve(getProjectsDir(), `mls-${projectId}`, rest);
  const candidates = [base];
  if (extname(base) === '.js') {
    candidates.push(`${base.slice(0, -3)}.ts`, `${base.slice(0, -3)}.tsx`);
  }
  if (!extname(base)) {
    candidates.push(base, `${base}.ts`, `${base}.tsx`, join(base, 'index.ts'), join(base, 'index.tsx'));
  }
  return candidates.find((candidate) => existsSync(candidate)) ?? null;
}

function withSourceFallback(distPath: string, relativePath: string) {
  if (existsSync(distPath)) {
    return distPath;
  }

  return resolveProjectSourcePath(relativePath) ?? distPath;
}

export function readProjectsConfig(): ProjectsConfig {
  if (cachedConfig) {
    return cachedConfig;
  }

  const configPath = resolve(getProjectsDir(), 'config.json');
  if (!existsSync(configPath)) {
    throw new Error(`projects/config.json not found at ${configPath}`);
  }

  cachedConfig = normalizeProjectsConfig(JSON.parse(readFileSync(configPath, 'utf8')) as ProjectsConfig);
  return cachedConfig;
}

export function resetProjectsConfigCache() {
  cachedConfig = null;
}

export function resolveProjectsPath(relativePath: string) {
  return resolve(getProjectsDir(), relativePath);
}

export function resolveProjectDistPath(relativePath: string) {
  const normalized = normalizeVirtualPath(relativePath);
  const match = normalized.match(/^_(\d+)_\/(.*)$/u);
  if (!match) {
    return withSourceFallback(
      resolve(getProjectsDir(), 'dist', 'local', normalized),
      normalized,
    );
  }

  const [, projectId, rest] = match;
  return withSourceFallback(
    resolve(getProjectsDir(), 'dist', 'local', `_${projectId}_`, rest),
    normalized,
  );
}

/** Browser statics (Lit, shells, css, l3). One name — not a publication target. */
const WEB_DIST_DIR = 'web';

export function resolveWebDistPath(relativePath = '.') {
  const normalized = normalizeVirtualPath(relativePath);
  if (!normalized || normalized === '.') {
    return resolve(getProjectsDir(), 'dist', WEB_DIST_DIR);
  }
  return resolve(getProjectsDir(), 'dist', WEB_DIST_DIR, normalized);
}

export function resolveProjectModuleImportUrl(relativePath: string) {
  return pathToFileURL(resolveProjectDistPath(relativePath)).href;
}

/// <mls fileReference="_102034_/l1/server/layer_1_external/frontend/appRegistry.ts" enhancement="_blank" />
import { dirname } from 'node:path';
import type {
  DeviceKind,
  FrontendAppLayout,
  FrontendAppRegistration,
  FrontendClientShellConfig,
  FrontendDynamicRegionConfig,
  FrontendModuleShellPreferences,
  FrontendRegionRendererRegistration,
  FrontendRouteRegistration,
} from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type {
  ProjectClientShellConfig,
  ProjectConfigRecord,
  ProjectDynamicRegionConfig,
  ProjectModuleConfig,
} from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import {
  readProjectsConfig,
  resolveProjectModuleImportUrl,
  resolveWebDistPath,
} from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import { resolveAppFaviconHref } from '/_102034_/l1/server/layer_1_external/frontend/faviconHtml.js';

interface LoadedModuleUiDefinition {
  pageTitle?: string;
  device?: DeviceKind;
  navigation?: FrontendAppRegistration['navigation'];
  routes: FrontendRouteRegistration[];
  headerRenderer?: FrontendAppRegistration['headerRenderer'];
  asideRenderer?: FrontendAppRegistration['asideRenderer'];
}

const moduleDefinitionCache = new Map<string, Promise<LoadedModuleUiDefinition | undefined>>();
let cachedAppsPromise: Promise<FrontendAppRegistration[]> | null = null;
let faviconChoiceLogged = false;

function toPublicImportPath(importPath: string) {
  return importPath.startsWith('./') ? `/${importPath.slice(2)}` : importPath;
}

function createDefaultLayout(): FrontendAppLayout {
  return {
    regions: {
      desktop: {
        header: true,
        aside: true,
        content: true,
      },
      mobile: {
        header: true,
        aside: true,
        content: true,
      },
    },
    asideMode: {
      desktop: 'inline',
      mobile: 'drawer',
    },
    asideSize: {
      desktopWidthPx: 280,
      drawerWidthPx: 320,
    },
  };
}

function mergeLayoutPreferences(preferences?: FrontendModuleShellPreferences): FrontendAppLayout {
  const defaults = createDefaultLayout();
  return {
    regions: {
      desktop: {
        ...defaults.regions.desktop,
        ...(preferences?.layout?.regions?.desktop ?? {}),
      },
      mobile: {
        ...defaults.regions.mobile,
        ...(preferences?.layout?.regions?.mobile ?? {}),
      },
    },
    asideMode: {
      ...defaults.asideMode,
      ...(preferences?.layout?.asideMode ?? {}),
    },
    asideSize: {
      ...defaults.asideSize,
      ...(preferences?.layout?.asideSize ?? {}),
    },
  };
}

function normalizeRendererConfig(renderer?: { entrypoint: string; tag: string }) {
  if (!renderer?.entrypoint || !renderer.tag) {
    return undefined;
  }
  return {
    entrypoint: toPublicImportPath(renderer.entrypoint),
    tag: renderer.tag,
  };
}

function normalizeRoutes(routes: FrontendRouteRegistration[] | undefined) {
  return (routes ?? []).map((route) => ({
    ...route,
    entrypoint: toPublicImportPath(route.entrypoint),
  }));
}

function normalizeProjectPageEntrypoint(projectId: string, source: string) {
  const normalizedSource = source
    .replace(/^\.\//u, '')
    .replace(/^\/+/u, '')
    .replace(/\.tsx?$/u, '.js');

  return toPublicImportPath(`./_${projectId}_/${normalizedSource}`);
}

function buildRoutesFromModuleConfig(projectId: string, moduleConfig: ProjectModuleConfig) {
  const pages = moduleConfig.frontend?.pages ?? [];
  const navigationById = new Map((moduleConfig.navigation ?? []).map((item) => [item.id, item]));

  return pages.map((page, index): FrontendRouteRegistration => {
    const navigation = navigationById.get(page.pageId);
    const aliases = index === 0 ? [moduleConfig.basePath, `${moduleConfig.basePath}/index.html`] : undefined;
    return {
      path: page.route,
      entrypoint: normalizeProjectPageEntrypoint(projectId, page.source),
      tag: page.componentTag,
      title: page.title ?? navigation?.label ?? page.pageId,
      aliases,
    };
  });
}

function normalizeDynamicRegionConfig(regionConfig?: ProjectDynamicRegionConfig): FrontendDynamicRegionConfig | undefined {
  if (!regionConfig?.renderer?.entrypoint || !regionConfig.renderer.tag) {
    return undefined;
  }

  return {
    ...regionConfig,
    renderer: {
      entrypoint: toPublicImportPath(regionConfig.renderer.entrypoint),
      tag: regionConfig.renderer.tag,
    },
  };
}

function normalizeClientShell(clientShell?: ProjectClientShellConfig): FrontendClientShellConfig | undefined {
  if (!clientShell?.regions) {
    return undefined;
  }

  const headerProfiles = clientShell.regions.header
    ? Object.fromEntries(
        Object.entries(clientShell.regions.header.profiles ?? {})
          .map(([profileName, profileConfig]) => [profileName, normalizeDynamicRegionConfig(profileConfig)] as const)
          .filter(([, profileConfig]) => Boolean(profileConfig)),
      ) as Record<string, FrontendDynamicRegionConfig>
    : undefined;

  const asideProfiles = clientShell.regions.aside
    ? Object.fromEntries(
        Object.entries(clientShell.regions.aside.profiles ?? {})
          .map(([profileName, profileConfig]) => [profileName, normalizeDynamicRegionConfig(profileConfig)] as const)
          .filter(([, profileConfig]) => Boolean(profileConfig)),
      ) as Record<string, FrontendDynamicRegionConfig>
    : undefined;

  return {
    ...clientShell,
    regions: {
      header: clientShell.regions.header
        ? {
            ...clientShell.regions.header,
            profiles: headerProfiles ?? {},
          }
        : undefined,
      aside: clientShell.regions.aside
        ? {
            ...clientShell.regions.aside,
            profiles: asideProfiles ?? {},
          }
        : undefined,
    },
  };
}

function getActiveRegionRenderer(
  clientShell: FrontendClientShellConfig | undefined,
  region: 'header' | 'aside',
): FrontendRegionRendererRegistration | undefined {
  const regionProfiles = clientShell?.regions[region];
  if (!regionProfiles?.activeProfile) {
    return undefined;
  }

  return regionProfiles.profiles[regionProfiles.activeProfile]?.renderer;
}

function applyClientShellLayout(layout: FrontendAppLayout, clientShell?: FrontendClientShellConfig): FrontendAppLayout {
  const activeAsideProfile = clientShell?.regions.aside?.profiles[clientShell.regions.aside.activeProfile];
  const widthPx = activeAsideProfile?.widthPx;
  if (typeof widthPx !== 'number' || widthPx <= 0) {
    return layout;
  }

  return {
    ...layout,
    asideSize: {
      ...layout.asideSize,
      desktopWidthPx: widthPx,
      drawerWidthPx: widthPx,
    },
  };
}

async function loadModuleDefinition(
  projectId: string,
  moduleId: string,
): Promise<LoadedModuleUiDefinition | undefined> {
  const cacheKey = `${projectId}:${moduleId}`;
  const cached = moduleDefinitionCache.get(cacheKey);
  if (cached) {
    return cached;
  }

  const pending = (async () => {
    try {
      const moduleUrl = resolveProjectModuleImportUrl(`./_${projectId}_/l2/${moduleId}/module.js`);
      const mod = await import(moduleUrl) as {
        moduleShellPreferences?: FrontendModuleShellPreferences;
        moduleFrontendDefinition?: LoadedModuleUiDefinition;
      };
      if (!mod.moduleFrontendDefinition?.routes?.length) {
        return undefined;
      }

      return {
        ...mod.moduleFrontendDefinition,
        routes: normalizeRoutes(mod.moduleFrontendDefinition.routes),
        headerRenderer: normalizeRendererConfig(mod.moduleFrontendDefinition.headerRenderer),
        asideRenderer: normalizeRendererConfig(mod.moduleFrontendDefinition.asideRenderer),
        device: mod.moduleFrontendDefinition.device ?? 'desktop',
        navigation: mod.moduleFrontendDefinition.navigation ?? [],
      };
    } catch {
      return undefined;
    }
  })();

  moduleDefinitionCache.set(cacheKey, pending);
  return pending;
}

async function loadModuleShellPreferences(
  projectId: string,
  moduleId: string,
): Promise<FrontendModuleShellPreferences | undefined> {
  try {
    const moduleUrl = resolveProjectModuleImportUrl(`./_${projectId}_/l2/${moduleId}/module.js`);
    const mod = await import(moduleUrl) as { moduleShellPreferences?: FrontendModuleShellPreferences };
    return mod.moduleShellPreferences;
  } catch {
    return undefined;
  }
}

function collectRoutePatterns(routes: FrontendRouteRegistration[]) {
  return [...new Set(routes.flatMap((route) => [route.path, ...(route.aliases ?? [])]))];
}

/** Resolve the HTML shell for a module. Names the missing key instead of throwing
 *  `Cannot read properties of undefined (reading 'spa')` — that silent shape is what
 *  left pm2 green with nothing listening. */
export function requireShellTemplate(
  shellTemplates: { spa?: string; pwa?: string } | undefined,
  shellMode: string,
): string {
  const templatePath = shellTemplates?.[shellMode as 'spa' | 'pwa'];
  if (typeof templatePath !== 'string' || templatePath.length === 0) {
    throw new Error(
      `config.shellTemplates.${shellMode} is required (missing from client config.json); frontend registry cannot mount`,
    );
  }
  return templatePath;
}

async function getConfiguredFrontendApps(): Promise<FrontendAppRegistration[]> {
  const config = readProjectsConfig();
  const sharedAssetRoots = Object.keys(config.projects).map((projectId) =>
    resolveWebDistPath(`./_${projectId}_/l2`),
  );

  const configuredProjects = Object.entries(config.projects) as Array<[string, ProjectConfigRecord]>;
  const maybeApps: Array<FrontendAppRegistration | null> = await Promise.all(configuredProjects.flatMap(([projectId, project]) =>
    (project.modules ?? []).map(async (moduleConfig) => {
      const [moduleDefinition, modulePreferences] = await Promise.all([
        loadModuleDefinition(projectId, moduleConfig.moduleId),
        loadModuleShellPreferences(projectId, moduleConfig.moduleId),
      ]);
      const configRoutes = buildRoutesFromModuleConfig(projectId, moduleConfig);
      const routes = configRoutes.length > 0 ? configRoutes : moduleDefinition?.routes ?? [];
      if (routes.length === 0) {
        return null;
      }
      const clientShell = project.type === 'client' ? normalizeClientShell(config.clientShell) : undefined;
      const layout = applyClientShellLayout(mergeLayoutPreferences(modulePreferences), clientShell);
      const favicon = resolveAppFaviconHref(config.favicon);
      if (!faviconChoiceLogged) {
        console.info(`[favicon] ${favicon.href} (${favicon.source})`);
        faviconChoiceLogged = true;
      }

      const app: FrontendAppRegistration = {
        projectId,
        appId: moduleConfig.moduleId,
        basePath: moduleConfig.basePath,
        indexHtmlPath: resolveWebDistPath(requireShellTemplate(config.shellTemplates, moduleConfig.shellMode)),
        assetRoots: sharedAssetRoots,
        routePatterns: collectRoutePatterns(routes),
        shellMode: moduleConfig.shellMode,
        languages: moduleConfig.languages ?? [],
        designSystems: moduleConfig.designSystems ?? [],
        routes,
        headerRenderer: getActiveRegionRenderer(clientShell, 'header') ?? moduleDefinition?.headerRenderer,
        asideRenderer: getActiveRegionRenderer(clientShell, 'aside') ?? moduleDefinition?.asideRenderer,
        layout,
        device: moduleDefinition?.device ?? 'desktop',
        pageTitle: moduleDefinition?.pageTitle ?? moduleConfig.moduleId,
        navigation: moduleConfig.navigation ?? moduleDefinition?.navigation ?? [],
        clientShell,
        faviconHref: favicon.href,
      };

      return app;
    })));

  const apps = maybeApps.filter((app): app is FrontendAppRegistration => app !== null);

  return apps.map((app) => ({
    ...app,
    moduleLinks: apps
      .filter((candidate) => candidate.basePath !== app.basePath)
      .map((candidate) => ({
        id: candidate.appId,
        label: candidate.pageTitle ?? candidate.appId,
        href: candidate.basePath,
        description: `Open ${candidate.pageTitle ?? candidate.appId}`,
      })),
  }));
}

export async function getFrontendAppRegistrations() {
  if (!cachedAppsPromise) {
    cachedAppsPromise = getConfiguredFrontendApps();
  }
  return cachedAppsPromise;
}

export async function getFrontendAppByBasePath(urlPath: string) {
  const apps = await getFrontendAppRegistrations();
  return apps.find((app) => urlPath === app.basePath || urlPath.startsWith(`${app.basePath}/`));
}

export function getAppPublicRootDir(app: FrontendAppRegistration) {
  return dirname(app.indexHtmlPath);
}

/**
 * Directories that back this app's own `/{basePath}/...` asset URLs, tried after the shell root.
 *
 * Exactly ONE root: the module's own l3 asset dir (`_<project>_/l3/<moduleId>`). That makes
 * `/cafeFlow/assets/seed/MenuItem/x.webp` resolve to `_<project>_/l3/cafeFlow/assets/seed/...` — the
 * exact path the seed generator writes into `imageUrl` — and keeps it module-scoped, so two modules can
 * hold same-named assets without colliding. Before this, no root was consulted at all and a seed image
 * answered 200 with the SPA shell instead of its bytes.
 *
 * Deliberately NOT including `app.assetRoots` (every project's published l2): those files are already
 * reachable at `/_<project>_/l2/...` via tryReadProjectAsset, and mirroring them under every app's
 * basePath would add a second path to the same bytes for no benefit.
 */
export function getAppAssetRootDirs(app: FrontendAppRegistration): string[] {
  return [resolveWebDistPath(`./_${app.projectId}_/l3/${app.appId}`)];
}

/// <mls fileReference="_102034_/l1/server/layer_1_external/persistence/registry.ts" enhancement="_blank" />
import { readdirSync } from 'node:fs';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { readProjectsConfig, resolveProjectDistPath, resolveProjectModuleImportUrl, } from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import { resolveDynamoTableName, resolvePostgresTableName, resolveRepositoryName, usesDynamo, usesPostgres, } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { sha256Hex } from '/_102029_/l2/webCrypto.js';
const registryCache = new Map();
function getPersistenceModuleRegistrations() {
    const config = readProjectsConfig();
    return Object.entries(config.projects).flatMap(([projectId, project]) => (project.persistenceModules ?? []).map((moduleConfig) => ({
        projectId,
        moduleId: moduleConfig.moduleId,
        persistenceEntrypoint: moduleConfig.persistenceEntrypoint,
        tableDefsDir: moduleConfig.tableDefsDir,
    })));
}
function isTableDefinition(value) {
    return !!value
        && typeof value === 'object'
        && typeof value.moduleId === 'string'
        && typeof value.tableName === 'string'
        && Array.isArray(value.columns);
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function readString(value) {
    return typeof value === 'string' && value.length > 0 ? value : undefined;
}
function readStringArray(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
}
function normalizePostgresType(value) {
    const normalized = readString(value)?.toLowerCase();
    switch (normalized) {
        case 'uuid':
            return 'UUID';
        case 'text':
            return 'TEXT';
        case 'int':
        case 'integer':
            return 'INTEGER';
        case 'decimal':
        case 'numeric':
            return 'NUMERIC';
        case 'timestamptz':
            return 'TIMESTAMPTZ';
        case 'bool':
        case 'boolean':
            return 'BOOLEAN';
        case 'json':
        case 'jsonb':
            return 'JSONB';
        default:
            return normalized?.toUpperCase() ?? 'TEXT';
    }
}
function normalizeDefaultSql(value) {
    if (typeof value === 'number' && Number.isFinite(value)) {
        return String(value);
    }
    if (typeof value === 'boolean') {
        return value ? 'TRUE' : 'FALSE';
    }
    if (typeof value === 'string') {
        return `'${value.replace(/'/gu, "''")}'`;
    }
    return undefined;
}
function normalizePlannerTableDefinition(value) {
    if (!isRecord(value)) {
        return null;
    }
    const moduleId = readString(value.moduleId);
    const tableName = readString(value.tableName);
    const rawColumns = Array.isArray(value.columns) ? value.columns.filter(isRecord) : [];
    if (!moduleId || !tableName || rawColumns.length === 0) {
        return null;
    }
    const columns = [];
    for (const column of rawColumns) {
        const name = readString(column.name);
        if (!name) {
            continue;
        }
        const normalizedColumn = {
            name,
            postgresType: normalizePostgresType(column.type),
        };
        if (typeof column.nullable === 'boolean') {
            normalizedColumn.nullable = column.nullable;
        }
        const defaultSql = normalizeDefaultSql(column.default);
        if (defaultSql) {
            normalizedColumn.defaultSql = defaultSql;
        }
        const description = readString(column.description);
        if (description) {
            normalizedColumn.description = description;
        }
        columns.push(normalizedColumn);
    }
    const explicitPrimaryKey = readStringArray(value.primaryKey);
    const primaryKey = explicitPrimaryKey.length > 0
        ? explicitPrimaryKey
        : rawColumns
            .filter((column) => column.primaryKey === true)
            .map((column) => readString(column.name))
            .filter((name) => !!name);
    const indexes = Array.isArray(value.indexes)
        ? value.indexes
            .filter(isRecord)
            .map((index) => ({
            name: readString(index.indexName) ?? readString(index.name) ?? `idx_${tableName}`,
            columns: readStringArray(index.columns),
        }))
            .filter((index) => index.columns.length > 0)
        : undefined;
    return {
        moduleId,
        repositoryName: readString(value.tableId),
        tableName,
        purpose: 'transacao',
        description: readString(value.purpose) ?? readString(value.title) ?? tableName,
        backupHot: false,
        storageProfile: 'postgres',
        writeMode: 'sync',
        columns,
        primaryKey,
        indexes,
        version: 1,
    };
}
function normalizeTableDefinition(value) {
    if (isTableDefinition(value)) {
        return value;
    }
    if (!isRecord(value)) {
        return null;
    }
    const data = isRecord(value.data) ? value.data : null;
    return normalizePlannerTableDefinition(data?.tableDefinition);
}
function isTableSeedRows(value) {
    return !!value
        && typeof value === 'object'
        && typeof value.seedFor === 'string'
        && Array.isArray(value.rows);
}
// Hexagonal model: discover every TableDefinition-shaped export across the module's table-def
// adapters. TableSeedRows-shaped exports are collected globally and merged after every persistence
// module is loaded, so a client module can seed 102034-owned MDM tables without owning them.
async function discoverTableDefinitions(tableDefsDir) {
    const dir = resolveProjectDistPath(tableDefsDir);
    const definitions = [];
    const seeds = [];
    const files = readdirSync(dir).filter((file) => (file.endsWith('.js') || file.endsWith('.ts')) && !file.endsWith('.d.ts'));
    for (const file of files) {
        const moduleUrl = resolveProjectModuleImportUrl(`${tableDefsDir.replace(/\/$/u, '')}/${file}`);
        const mod = await import(moduleUrl);
        const seenExports = new Set();
        for (const value of Object.values(mod)) {
            if (isRecord(value)) {
                if (seenExports.has(value)) {
                    continue;
                }
                seenExports.add(value);
            }
            const definition = normalizeTableDefinition(value);
            if (definition) {
                definitions.push(definition);
            }
            else if (isTableSeedRows(value)) {
                seeds.push(value);
            }
        }
    }
    return { definitions, seeds, seedSource: tableDefsDir };
}
async function importTableDefinitions(registration) {
    if (registration.tableDefsDir) {
        return discoverTableDefinitions(registration.tableDefsDir);
    }
    if (!registration.persistenceEntrypoint) {
        throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Persistence module must declare persistenceEntrypoint or tableDefsDir', 500, registration);
    }
    const moduleUrl = resolveProjectModuleImportUrl(registration.persistenceEntrypoint);
    const mod = await import(moduleUrl);
    const seeds = Object.values(mod).filter(isTableSeedRows);
    const directExport = mod.tableDefinitions;
    if (Array.isArray(directExport)) {
        return {
            definitions: directExport
                .map(normalizeTableDefinition)
                .filter((definition) => definition !== null),
            seeds,
            seedSource: registration.persistenceEntrypoint,
        };
    }
    if (typeof mod.getTableDefinitions === 'function') {
        const loaded = await mod.getTableDefinitions();
        if (Array.isArray(loaded)) {
            return { definitions: loaded, seeds, seedSource: registration.persistenceEntrypoint };
        }
    }
    throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Persistence manifest must export tableDefinitions', 500, registration);
}
function applySeedRows(definitions, seeds) {
    for (const { seed, source } of seeds) {
        const def = definitions.find((d) => d.repositoryName === seed.seedFor || d.tableName === seed.seedFor);
        if (def) {
            def.seedRows = [...(def.seedRows ?? []), ...seed.rows];
        }
        else {
            console.warn(`[persistence] seed target not found in ${source}: ${seed.seedFor}`);
        }
    }
}
function validateDefinition(definition, registration, env) {
    if (definition.moduleId !== registration.moduleId) {
        throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Persistence definition moduleId mismatch', 500, {
            expectedModuleId: registration.moduleId,
            receivedModuleId: definition.moduleId,
            tableName: definition.tableName,
        });
    }
    if (definition.columns.length === 0) {
        throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Persistence definition must declare columns', 500, {
            moduleId: definition.moduleId,
            tableName: definition.tableName,
        });
    }
    if (definition.primaryKey.length === 0 && definition.storageProfile !== 'dynamoOnly') {
        throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Postgres-backed tables must declare a primary key', 500, {
            moduleId: definition.moduleId,
            tableName: definition.tableName,
        });
    }
    if (usesDynamo(definition) && !resolveDynamoTableName(definition, env)) {
        throw new AppError('PERSISTENCE_MANIFEST_INVALID', 'Dynamo-backed tables must declare a DynamoDB table name', 500, {
            moduleId: definition.moduleId,
            tableName: definition.tableName,
        });
    }
}
function validateResolvedDefinitions(definitions) {
    const seenTableNames = new Map();
    const seenRepositoryNames = new Map();
    const seenDynamoNames = new Map();
    for (const definition of definitions) {
        const tableKey = definition.tableName;
        const previousTable = seenTableNames.get(tableKey);
        if (previousTable) {
            throw new AppError('PERSISTENCE_MANIFEST_DUPLICATE', 'Duplicate table name found in persistence registry', 500, { current: definition, previous: previousTable });
        }
        seenTableNames.set(tableKey, definition);
        const repositoryKey = definition.repositoryName;
        const previousRepository = seenRepositoryNames.get(repositoryKey);
        if (previousRepository) {
            throw new AppError('PERSISTENCE_MANIFEST_DUPLICATE', 'Duplicate repository name found in persistence registry', 500, { current: definition, previous: previousRepository });
        }
        seenRepositoryNames.set(repositoryKey, definition);
        if (usesDynamo(definition) && definition.dynamoResolvedTableName) {
            const previousDynamo = seenDynamoNames.get(definition.dynamoResolvedTableName);
            if (previousDynamo) {
                throw new AppError('PERSISTENCE_MANIFEST_DUPLICATE', 'Duplicate DynamoDB table name found in persistence registry', 500, { current: definition, previous: previousDynamo });
            }
            seenDynamoNames.set(definition.dynamoResolvedTableName, definition);
        }
    }
}
export async function loadResolvedTableDefinitions(env) {
    const cached = registryCache.get(env.appEnv);
    if (cached) {
        return cached;
    }
    const pending = (async () => {
        const registrations = getPersistenceModuleRegistrations();
        const imported = await Promise.all(registrations.map(async (registration) => {
            const loaded = await importTableDefinitions(registration);
            const definitions = loaded.definitions.map((definition) => {
                validateDefinition(definition, registration, env);
                return {
                    ...definition,
                    tableName: resolvePostgresTableName(definition, env),
                    projectId: registration.projectId,
                    repositoryName: resolveRepositoryName(definition),
                    dynamoResolvedTableName: resolveDynamoTableName(definition, env),
                };
            });
            return {
                definitions,
                seeds: loaded.seeds.map((seed) => ({ seed, source: loaded.seedSource })),
            };
        }));
        const flattened = imported.flatMap((item) => item.definitions).sort((left, right) => `${left.projectId}:${left.moduleId}:${left.tableName}`.localeCompare(`${right.projectId}:${right.moduleId}:${right.tableName}`));
        applySeedRows(flattened, imported.flatMap((item) => item.seeds));
        validateResolvedDefinitions(flattened);
        return flattened;
    })();
    registryCache.set(env.appEnv, pending);
    return pending;
}
export function resetResolvedTableDefinitionsCache() {
    registryCache.clear();
}
export async function loadResolvedPostgresTableDefinitions(env) {
    const definitions = await loadResolvedTableDefinitions(env);
    return definitions.filter((definition) => usesPostgres(definition));
}
export async function loadResolvedDynamoTableDefinitions(env) {
    const definitions = await loadResolvedTableDefinitions(env);
    return definitions.filter((definition) => usesDynamo(definition));
}
export async function buildSchemaSnapshot(env) {
    const definitions = await loadResolvedTableDefinitions(env);
    const tables = definitions.map((definition) => ({
        projectId: definition.projectId,
        moduleId: definition.moduleId,
        repositoryName: definition.repositoryName,
        tableName: definition.tableName,
        storageProfile: definition.storageProfile,
        backupHot: definition.backupHot,
        dynamoTableName: definition.dynamoResolvedTableName,
        version: definition.version,
    }));
    const hash = await sha256Hex(JSON.stringify(tables));
    const appliedAt = new Date().toISOString();
    return {
        id: `registry:${hash}`,
        hash,
        appliedAt,
        tables,
    };
}
export async function loadViewDefinitions() {
    const registrations = getPersistenceModuleRegistrations();
    const results = await Promise.all(registrations.map(async (registration) => {
        if (!registration.persistenceEntrypoint) {
            return [];
        }
        const moduleUrl = resolveProjectModuleImportUrl(registration.persistenceEntrypoint);
        const mod = await import(moduleUrl);
        const exported = mod.viewDefinitions;
        if (!Array.isArray(exported)) {
            return [];
        }
        return exported;
    }));
    return results.flat();
}
export async function findResolvedTableDefinition(repositoryNameOrTableName, env) {
    const definitions = await loadResolvedTableDefinitions(env);
    const definition = definitions.find((entry) => entry.repositoryName === repositoryNameOrTableName ||
        entry.tableName === repositoryNameOrTableName);
    if (!definition) {
        throw new AppError('PERSISTENCE_TABLE_NOT_FOUND', 'Persistence table is not registered', 404, { repositoryNameOrTableName });
    }
    return definition;
}

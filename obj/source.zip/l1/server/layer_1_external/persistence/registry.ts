/// <mls fileReference="_102034_/l1/server/layer_1_external/persistence/registry.ts" enhancement="_blank" />
import { readdirSync } from 'node:fs';
import { AppError, type RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import {
  readProjectsConfig,
  resolveProjectDistPath,
  resolveProjectModuleImportUrl,
  type ProjectPersistenceModuleConfig,
} from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import type {
  ResolvedTableDefinition,
  SchemaSnapshot,
  SeedExportOrigin,
  TableDefinition,
  TableSeedRows,
  ViewDefinition,
} from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { assertInitialSeed, readSeedPurpose } from '/_102034_/l1/server/layer_1_external/persistence/seedPolicy.js';
import {
  applyProjectTableNamespace,
  isClientProjectType,
  logicalTableNameFromEmitted,
  matchesTableLookup,
  resolveDynamoTableName,
  resolvePostgresTableName,
  resolveRepositoryName,
  usesDynamo,
  usesPostgres,
} from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import type { AppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { sha256Hex } from '/_102029_/l2/webCrypto.js';

interface PersistenceModuleRegistration {
  projectId: string;
  projectType?: string;
  moduleId: string;
  persistenceEntrypoint?: string;
  tableDefsDir?: string;
}

interface ImportedSeed {
  seed: TableSeedRows;
  source: string;
  projectId: string;
  moduleId: string;
}

interface ImportedPersistenceDefinitions {
  definitions: TableDefinition[];
  seeds: TableSeedRows[];
  seedSource: string;
}

const registryCache = new Map<AppEnv['appEnv'], Promise<ResolvedTableDefinition[]>>();

function getPersistenceModuleRegistrations(): PersistenceModuleRegistration[] {
  const config = readProjectsConfig();
  return Object.entries(config.projects).flatMap(([projectId, project]) =>
    (project.persistenceModules ?? []).map((moduleConfig: ProjectPersistenceModuleConfig) => ({
      projectId,
      projectType: project.type,
      moduleId: moduleConfig.moduleId,
      persistenceEntrypoint: moduleConfig.persistenceEntrypoint,
      tableDefsDir: moduleConfig.tableDefsDir,
    })),
  );
}

function isTableDefinition(value: unknown): value is TableDefinition {
  return !!value
    && typeof value === 'object'
    && typeof (value as TableDefinition).moduleId === 'string'
    && typeof (value as TableDefinition).tableName === 'string'
    && Array.isArray((value as TableDefinition).columns);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function readString(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function readStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
}

function normalizePostgresType(value: unknown) {
  const normalized = readString(value)?.toLowerCase();
  switch (normalized) {
    case 'uuid':
      return 'UUID';
    case 'text':
      return 'TEXT';
    case 'int':
    case 'integer':
      return 'INTEGER';
    case 'decimal':
    case 'numeric':
      return 'NUMERIC';
    case 'timestamptz':
      return 'TIMESTAMPTZ';
    case 'bool':
    case 'boolean':
      return 'BOOLEAN';
    case 'json':
    case 'jsonb':
      return 'JSONB';
    default:
      return normalized?.toUpperCase() ?? 'TEXT';
  }
}

function normalizeDefaultSql(value: unknown): string | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return String(value);
  }
  if (typeof value === 'boolean') {
    return value ? 'TRUE' : 'FALSE';
  }
  if (typeof value === 'string') {
    return `'${value.replace(/'/gu, "''")}'`;
  }
  return undefined;
}

function normalizePlannerTableDefinition(value: unknown): TableDefinition | null {
  if (!isRecord(value)) {
    return null;
  }

  const moduleId = readString(value.moduleId);
  const tableName = readString(value.tableName);
  const rawColumns = Array.isArray(value.columns) ? value.columns.filter(isRecord) : [];
  if (!moduleId || !tableName || rawColumns.length === 0) {
    return null;
  }

  const columns: TableDefinition['columns'] = [];
  for (const column of rawColumns) {
    const name = readString(column.name);
    if (!name) {
      continue;
    }
    const normalizedColumn: TableDefinition['columns'][number] = {
      name,
      postgresType: normalizePostgresType(column.type),
    };
    if (typeof column.nullable === 'boolean') {
      normalizedColumn.nullable = column.nullable;
    }
    const defaultSql = normalizeDefaultSql(column.default);
    if (defaultSql) {
      normalizedColumn.defaultSql = defaultSql;
    }
    const description = readString(column.description);
    if (description) {
      normalizedColumn.description = description;
    }
    columns.push(normalizedColumn);
  }

  const explicitPrimaryKey = readStringArray(value.primaryKey);
  const primaryKey = explicitPrimaryKey.length > 0
    ? explicitPrimaryKey
    : rawColumns
      .filter((column) => column.primaryKey === true)
      .map((column) => readString(column.name))
      .filter((name): name is string => !!name);

  const indexes = Array.isArray(value.indexes)
    ? value.indexes
      .filter(isRecord)
      .map((index) => ({
        name: readString(index.indexName) ?? readString(index.name) ?? `idx_${tableName}`,
        columns: readStringArray(index.columns),
      }))
      .filter((index) => index.columns.length > 0)
    : undefined;

  return {
    moduleId,
    repositoryName: readString(value.tableId),
    tableName,
    purpose: 'transacao',
    description: readString(value.purpose) ?? readString(value.title) ?? tableName,
    backupHot: false,
    storageProfile: 'postgres',
    writeMode: 'sync',
    columns,
    primaryKey,
    indexes,
    version: 1,
  };
}

function normalizeTableDefinition(value: unknown): TableDefinition | null {
  if (isTableDefinition(value)) {
    return value;
  }
  if (!isRecord(value)) {
    return null;
  }

  const data = isRecord(value.data) ? value.data : null;
  return normalizePlannerTableDefinition(data?.tableDefinition);
}

function isTableSeedRows(value: unknown): value is TableSeedRows {
  return !!value
    && typeof value === 'object'
    && typeof (value as TableSeedRows).seedFor === 'string'
    && Array.isArray((value as TableSeedRows).rows);
}

function acceptSeedExport(value: unknown, source: string): TableSeedRows | null {
  if (!isTableSeedRows(value)) {
    return null;
  }
  readSeedPurpose(value.purpose, { source, seedFor: value.seedFor });
  return value;
}

/**
 * Files of a table-defs folder that are imported. `.defs.*` is kept (those are the definitions); a test file is never
 * imported by the app, because it runs its own top-level code inside the server.
 */
export function selectTableDefinitionFiles(entries: readonly string[]): string[] {
  return entries.filter((file) =>
    (file.endsWith('.js') || file.endsWith('.ts')) && !file.endsWith('.d.ts') && !/\.test\.(js|ts)$/u.test(file));
}

// Hexagonal model: discover every TableDefinition-shaped export across the module's table-def
// adapters. TableSeedRows-shaped exports are collected globally and merged after every persistence
// module is loaded, so a client module can seed 102034-owned MDM tables without owning them.
async function discoverTableDefinitions(tableDefsDir: string): Promise<ImportedPersistenceDefinitions> {
  const dir = resolveProjectDistPath(tableDefsDir);
  const definitions: TableDefinition[] = [];
  const seeds: TableSeedRows[] = [];
  const files = selectTableDefinitionFiles(readdirSync(dir));
  for (const file of files) {
    const moduleUrl = resolveProjectModuleImportUrl(`${tableDefsDir.replace(/\/$/u, '')}/${file}`);
    const mod = await import(moduleUrl);
    const seenExports = new Set<unknown>();
    for (const value of Object.values(mod)) {
      if (isRecord(value)) {
        if (seenExports.has(value)) {
          continue;
        }
        seenExports.add(value);
      }
      const definition = normalizeTableDefinition(value);
      if (definition) {
        definitions.push(definition);
      } else {
        const seed = acceptSeedExport(value, moduleUrl);
        if (seed) {
          seeds.push(seed);
        }
      }
    }
  }
  return { definitions, seeds, seedSource: tableDefsDir };
}

async function importTableDefinitions(
  registration: PersistenceModuleRegistration,
): Promise<ImportedPersistenceDefinitions> {
  if (registration.tableDefsDir) {
    return discoverTableDefinitions(registration.tableDefsDir);
  }
  if (!registration.persistenceEntrypoint) {
    throw new AppError(
      'PERSISTENCE_MANIFEST_INVALID',
      'Persistence module must declare persistenceEntrypoint or tableDefsDir',
      500,
      registration,
    );
  }
  const moduleUrl = resolveProjectModuleImportUrl(registration.persistenceEntrypoint);
  const mod = await import(moduleUrl);
  const seeds = Object.values(mod).flatMap((value) => {
    const seed = acceptSeedExport(value, moduleUrl);
    return seed ? [seed] : [];
  });
  const directExport = mod.tableDefinitions;
  if (Array.isArray(directExport)) {
    return {
      definitions: directExport
        .map(normalizeTableDefinition)
        .filter((definition): definition is TableDefinition => definition !== null),
      seeds,
      seedSource: registration.persistenceEntrypoint,
    };
  }

  if (typeof mod.getTableDefinitions === 'function') {
    const loaded = await mod.getTableDefinitions();
    if (Array.isArray(loaded)) {
      return { definitions: loaded as TableDefinition[], seeds, seedSource: registration.persistenceEntrypoint };
    }
  }

  throw new AppError(
    'PERSISTENCE_MANIFEST_INVALID',
    'Persistence manifest must export tableDefinitions',
    500,
    registration,
  );
}

function rememberSeedOrigin(definition: ResolvedTableDefinition, origin: SeedExportOrigin) {
  definition.seedOrigins = [...(definition.seedOrigins ?? []), origin];
}

function applySeedRows(
  definitions: ResolvedTableDefinition[],
  seeds: ImportedSeed[],
) {
  for (const imported of seeds) {
    const { seed, source, projectId, moduleId } = imported;
    const purpose = readSeedPurpose(seed.purpose, { source, seedFor: seed.seedFor });
    const origin: SeedExportOrigin = {
      purpose,
      source,
      projectId,
      moduleId,
      seedFor: seed.seedFor,
    };
    if (purpose === 'initial') {
      // Same logical name may exist in another module. Initial binds only to the exporter's table.
      const matches = definitions.filter((definition) =>
        definition.projectId === projectId
        && definition.moduleId === moduleId
        && matchesTableLookup(definition, seed.seedFor));
      if (matches.length !== 1) {
        throw new AppError(
          'PERSISTENCE_SEED_INVALID',
          matches.length === 0
            ? `initial seed target not found in ${source}: ${seed.seedFor}`
            : `initial seed target is ambiguous in ${source}: ${seed.seedFor}`,
          500,
          { ...origin, matchCount: matches.length },
        );
      }
      const def = matches[0];
      assertInitialSeed(def, seed.rows, origin);
      def.initialSeedRows = [...(def.initialSeedRows ?? []), ...seed.rows];
      rememberSeedOrigin(def, origin);
      continue;
    }
    // Test and legacy exports keep the global lookup so a client module can still seed MDM tables.
    const def = definitions.find((definition) => matchesTableLookup(definition, seed.seedFor));
    if (def) {
      def.seedRows = [...(def.seedRows ?? []), ...seed.rows];
      rememberSeedOrigin(def, origin);
    } else {
      console.warn(`[persistence] seed target not found in ${source}: ${seed.seedFor}`);
    }
  }
}

function validateDefinition(
  definition: TableDefinition,
  registration: PersistenceModuleRegistration,
  env: Pick<AppEnv, 'appEnv'>,
) {
  if (definition.moduleId !== registration.moduleId) {
    throw new AppError(
      'PERSISTENCE_MANIFEST_INVALID',
      'Persistence definition moduleId mismatch',
      500,
      {
        expectedModuleId: registration.moduleId,
        receivedModuleId: definition.moduleId,
        tableName: definition.tableName,
      },
    );
  }

  if (definition.columns.length === 0) {
    throw new AppError(
      'PERSISTENCE_MANIFEST_INVALID',
      'Persistence definition must declare columns',
      500,
      {
        moduleId: definition.moduleId,
        tableName: definition.tableName,
      },
    );
  }

  if (definition.primaryKey.length === 0 && definition.storageProfile !== 'dynamoOnly') {
    throw new AppError(
      'PERSISTENCE_MANIFEST_INVALID',
      'Postgres-backed tables must declare a primary key',
      500,
      {
        moduleId: definition.moduleId,
        tableName: definition.tableName,
      },
    );
  }

  if (usesDynamo(definition) && !resolveDynamoTableName(definition, env)) {
    throw new AppError(
      'PERSISTENCE_MANIFEST_INVALID',
      'Dynamo-backed tables must declare a DynamoDB table name',
      500,
      {
        moduleId: definition.moduleId,
        tableName: definition.tableName,
      },
    );
  }
}

function validateResolvedDefinitions(definitions: ResolvedTableDefinition[]) {
  const seenTableNames = new Map<string, ResolvedTableDefinition>();
  const seenRepositoryNames = new Map<string, ResolvedTableDefinition>();
  const seenDynamoNames = new Map<string, ResolvedTableDefinition>();

  for (const definition of definitions) {
    const tableKey = definition.tableName;
    const previousTable = seenTableNames.get(tableKey);
    if (previousTable) {
      throw new AppError(
        'PERSISTENCE_MANIFEST_DUPLICATE',
        'Duplicate table name found in persistence registry',
        500,
        { current: definition, previous: previousTable },
      );
    }
    seenTableNames.set(tableKey, definition);

    const repositoryKey = definition.repositoryName;
    const previousRepository = seenRepositoryNames.get(repositoryKey);
    if (previousRepository) {
      throw new AppError(
        'PERSISTENCE_MANIFEST_DUPLICATE',
        'Duplicate repository name found in persistence registry',
        500,
        { current: definition, previous: previousRepository },
      );
    }
    seenRepositoryNames.set(repositoryKey, definition);

    if (usesDynamo(definition) && definition.dynamoResolvedTableName) {
      const previousDynamo = seenDynamoNames.get(definition.dynamoResolvedTableName);
      if (previousDynamo) {
        throw new AppError(
          'PERSISTENCE_MANIFEST_DUPLICATE',
          'Duplicate DynamoDB table name found in persistence registry',
          500,
          { current: definition, previous: previousDynamo },
        );
      }
      seenDynamoNames.set(definition.dynamoResolvedTableName, definition);
    }
  }
}

export async function loadResolvedTableDefinitions(
  env: Pick<AppEnv, 'appEnv'>,
): Promise<ResolvedTableDefinition[]> {
  const cached = registryCache.get(env.appEnv);
  if (cached) {
    return cached;
  }

  const pending = (async () => {
    const registrations = getPersistenceModuleRegistrations();
    const imported = await Promise.all(registrations.map(async (registration) => {
      const loaded = await importTableDefinitions(registration);
      const definitions = loaded.definitions.map((definition): ResolvedTableDefinition => {
        validateDefinition(definition, registration, env);
        const emittedName = resolvePostgresTableName(definition, env);
        const logicalTableName = isClientProjectType(registration.projectType)
          ? logicalTableNameFromEmitted(emittedName, definition.moduleId)
          : emittedName;
        const dynamoBaseName = resolveDynamoTableName(definition, env);
        return {
          ...definition,
          logicalTableName,
          tableName: applyProjectTableNamespace(emittedName, registration.projectId, registration.projectType),
          projectId: registration.projectId,
          repositoryName: resolveRepositoryName(definition),
          // Index names live in ONE flat namespace per Postgres schema (unlike columns, which are
          // per-table) — without this, two client projects sharing a database whose tables both
          // declare an index with the same literal name (e.g. "idx_<table>_status", a common
          // generated pattern) collide with 42P07 "relation already exists" the moment the second
          // one's CREATE INDEX runs. Namespacing it the same way tableName already is fixes that.
          indexes: definition.indexes?.map((index) => ({
            ...index,
            name: applyProjectTableNamespace(index.name, registration.projectId, registration.projectType),
          })),
          dynamoResolvedTableName: dynamoBaseName
            ? applyProjectTableNamespace(dynamoBaseName, registration.projectId, registration.projectType)
            : null,
        };
      });
      return {
        definitions,
        seeds: loaded.seeds.map((seed): ImportedSeed => ({
          seed,
          source: loaded.seedSource,
          projectId: registration.projectId,
          moduleId: registration.moduleId,
        })),
      };
    }));

    const flattened = imported.flatMap((item) => item.definitions).sort((left, right) =>
      `${left.projectId}:${left.moduleId}:${left.tableName}`.localeCompare(
        `${right.projectId}:${right.moduleId}:${right.tableName}`,
      ),
    );
    applySeedRows(flattened, imported.flatMap((item) => item.seeds));
    validateResolvedDefinitions(flattened);
    return flattened;
  })();

  registryCache.set(env.appEnv, pending);
  return pending;
}

export function resetResolvedTableDefinitionsCache() {
  registryCache.clear();
}

export async function loadResolvedPostgresTableDefinitions(
  env: Pick<AppEnv, 'appEnv'>,
): Promise<ResolvedTableDefinition[]> {
  const definitions = await loadResolvedTableDefinitions(env);
  return definitions.filter((definition) => usesPostgres(definition));
}

export async function loadResolvedDynamoTableDefinitions(
  env: Pick<AppEnv, 'appEnv'>,
): Promise<ResolvedTableDefinition[]> {
  const definitions = await loadResolvedTableDefinitions(env);
  return definitions.filter((definition) => usesDynamo(definition));
}

/** Snapshot row used for the schema hash. Columns in; seedRows out — a seed-only edit must not rebuild. */
export function toSchemaSnapshotTable(definition: ResolvedTableDefinition): SchemaSnapshot['tables'][number] {
  return {
    projectId: definition.projectId,
    moduleId: definition.moduleId,
    repositoryName: definition.repositoryName,
    tableName: definition.tableName,
    storageProfile: definition.storageProfile,
    backupHot: definition.backupHot,
    dynamoTableName: definition.dynamoResolvedTableName,
    version: definition.version,
    columns: definition.columns.map((column) => ({
      name: column.name,
      postgresType: column.postgresType,
      nullable: column.nullable === true,
      defaultSql: column.defaultSql ?? null,
    })),
  };
}

export async function buildSchemaSnapshot(
  env: Pick<AppEnv, 'appEnv'>,
): Promise<SchemaSnapshot> {
  const definitions = await loadResolvedTableDefinitions(env);
  const tables = definitions.map(toSchemaSnapshotTable);
  const hash = await sha256Hex(JSON.stringify(tables));
  const appliedAt = new Date().toISOString();

  return {
    id: `registry:${hash}`,
    hash,
    appliedAt,
    tables,
  };
}

export async function loadViewDefinitions(): Promise<ViewDefinition[]> {
  const registrations = getPersistenceModuleRegistrations();
  const results = await Promise.all(registrations.map(async (registration) => {
    if (!registration.persistenceEntrypoint) {
      return [] as ViewDefinition[];
    }
    const moduleUrl = resolveProjectModuleImportUrl(registration.persistenceEntrypoint);
    const mod = await import(moduleUrl);
    const exported = mod.viewDefinitions;
    if (!Array.isArray(exported)) {
      return [] as ViewDefinition[];
    }
    return exported as ViewDefinition[];
  }));
  return results.flat();
}

export async function findResolvedTableDefinition(
  repositoryNameOrTableName: string,
  env: Pick<AppEnv, 'appEnv'>,
): Promise<ResolvedTableDefinition> {
  const definitions = await loadResolvedTableDefinitions(env);
  const definition = definitions.find((entry) => matchesTableLookup(entry, repositoryNameOrTableName));
  if (!definition) {
    throw new AppError(
      'PERSISTENCE_TABLE_NOT_FOUND',
      'Persistence table is not registered',
      404,
      { repositoryNameOrTableName },
    );
  }
  return definition;
}

/**
 * A module that wants to be woken up exports `onTick` from its persistence file, next to
 * `tableDefinitions` and `viewDefinitions`. The platform only lends the clock: what the module does
 * with the minute — which occurrences it owes, where it records them — is the module's business.
 */
export type ModuleTickHandler = (ctx: RequestContext, now: Date) => Promise<void> | void;

export interface ModuleTickRegistration {
  moduleId: string;
  onTick: ModuleTickHandler;
}

/**
 * Collects `onTick` the same way `loadViewDefinitions` collects `viewDefinitions` — with one
 * difference on purpose: a module whose import throws is warned about and skipped instead of
 * rejecting the whole load. `loadViewDefinitions` above has no such isolation; the tick runs every
 * minute forever, so one broken module must not silence every other module's clock.
 */
export async function loadModuleTickHandlers(): Promise<ModuleTickRegistration[]> {
  const handlers: ModuleTickRegistration[] = [];
  const seen = new Set<string>();
  for (const registration of getPersistenceModuleRegistrations()) {
    if (!registration.persistenceEntrypoint) {
      continue;
    }
    try {
      const moduleUrl = resolveProjectModuleImportUrl(registration.persistenceEntrypoint);
      const mod: unknown = await import(moduleUrl);
      const onTick = isRecord(mod) ? mod.onTick : undefined;
      if (typeof onTick !== 'function') {
        continue;
      }
      if (seen.has(registration.moduleId)) {
        console.warn(`[tick] duplicate onTick for module ${registration.moduleId}; the first one wins`);
        continue;
      }
      seen.add(registration.moduleId);
      handlers.push({ moduleId: registration.moduleId, onTick: onTick as ModuleTickHandler });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.warn(`[tick] module ${registration.moduleId} was skipped, its persistence failed to load: ${message}`);
    }
  }
  return handlers;
}

import { getSharedPgPool } from '/_102034_/l1/server/layer_1_external/data/postgres/pg.js';
import { usesPostgres } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { buildSchemaSnapshot, loadResolvedTableDefinitions, loadViewDefinitions, } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { ensureRegisteredDynamoTables, writeSchemaSnapshotLog, } from '/_102034_/l1/server/layer_1_external/persistence/dynamoAdmin.js';
function quoteIdentifier(identifier) {
    return `"${identifier.replaceAll('"', '""')}"`;
}
function renderIndexColumn(column) {
    if (typeof column === 'string') {
        return quoteIdentifier(column);
    }
    return `${quoteIdentifier(column.name)} ${(column.direction ?? 'asc').toUpperCase()}`;
}
function buildCreateTableSql(definition) {
    const columnsSql = definition.columns.map((column) => {
        const notNullSql = column.nullable ? '' : ' NOT NULL';
        const defaultSql = column.defaultSql ? ` DEFAULT ${column.defaultSql}` : '';
        return `${quoteIdentifier(column.name)} ${column.postgresType}${notNullSql}${defaultSql}`;
    });
    const primaryKeySql = definition.primaryKey.length > 0
        ? `, PRIMARY KEY (${definition.primaryKey.map((column) => quoteIdentifier(column)).join(', ')})`
        : '';
    const unloggedSql = definition.postgres?.unlogged ? 'UNLOGGED ' : '';
    return `CREATE ${unloggedSql}TABLE ${quoteIdentifier(definition.tableName)} (${columnsSql.join(', ')}${primaryKeySql})`;
}
function buildCreateIndexSql(definition) {
    return (definition.indexes ?? []).map((index) => `CREATE ${index.unique ? 'UNIQUE ' : ''}INDEX ${quoteIdentifier(index.name)}
     ON ${quoteIdentifier(definition.tableName)} (${index.columns.map((column) => renderIndexColumn(column)).join(', ')})`);
}
async function ensureTimescaleAvailable(pool) {
    const existing = await pool.query("SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'timescaledb') AS exists");
    if (existing.rows[0]?.exists) {
        return true;
    }
    try {
        await pool.query('CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE');
        return true;
    }
    catch {
        console.warn('[bootstrapSchema] TimescaleDB extension not available — hypertables will be created as regular tables');
        return false;
    }
}
async function rebuildPostgresSchema(env, definitions, snapshotId) {
    const pool = getSharedPgPool(env);
    const hasTimescale = definitions.some((d) => d.timescale?.hypertable);
    const timescaleAvailable = hasTimescale ? await ensureTimescaleAvailable(pool) : false;
    // Surgical cleanup instead of DROP SCHEMA public CASCADE: dropping the schema would
    // CASCADE-drop the timescaledb extension (its functions live in public) and the app
    // role cannot re-create it (superuser-only, see vmInitialSetup.sh). Drop only the
    // user objects; the extension and its catalogs survive the rebuild.
    // Continuous aggregates first: they show up in pg_views but Timescale requires
    // DROP MATERIALIZED VIEW for them.
    const droppedCaggs = new Set();
    if (timescaleAvailable) {
        try {
            const caggs = await pool.query("SELECT view_name FROM timescaledb_information.continuous_aggregates WHERE view_schema = 'public'");
            for (const row of caggs.rows) {
                await pool.query(`DROP MATERIALIZED VIEW IF EXISTS ${quoteIdentifier(row.view_name)} CASCADE`);
                droppedCaggs.add(row.view_name);
            }
        }
        catch (error) {
            console.warn('[bootstrapSchema] continuous aggregate cleanup skipped:', error instanceof Error ? error.message : error);
        }
    }
    const existingViews = await pool.query("SELECT viewname FROM pg_views WHERE schemaname = 'public'");
    for (const row of existingViews.rows) {
        if (droppedCaggs.has(row.viewname))
            continue;
        try {
            await pool.query(`DROP VIEW IF EXISTS ${quoteIdentifier(row.viewname)} CASCADE`);
        }
        catch (error) {
            // 0A000: a continuous aggregate not listed by the info view — retry the right way.
            await pool.query(`DROP MATERIALIZED VIEW IF EXISTS ${quoteIdentifier(row.viewname)} CASCADE`);
        }
    }
    const existingMatViews = await pool.query("SELECT matviewname FROM pg_matviews WHERE schemaname = 'public'");
    for (const row of existingMatViews.rows) {
        await pool.query(`DROP MATERIALIZED VIEW IF EXISTS ${quoteIdentifier(row.matviewname)} CASCADE`);
    }
    const existingTables = await pool.query("SELECT tablename FROM pg_tables WHERE schemaname = 'public'");
    for (const row of existingTables.rows) {
        await pool.query(`DROP TABLE IF EXISTS ${quoteIdentifier(row.tablename)} CASCADE`);
    }
    const orderedDefinitions = [...definitions]
        .filter((definition) => usesPostgres(definition))
        .sort((left, right) => {
        if (left.tableName === '_schema_migrations') {
            return -1;
        }
        if (right.tableName === '_schema_migrations') {
            return 1;
        }
        return left.tableName.localeCompare(right.tableName);
    });
    for (const definition of orderedDefinitions) {
        await pool.query(buildCreateTableSql(definition));
    }
    for (const definition of orderedDefinitions) {
        for (const indexSql of buildCreateIndexSql(definition)) {
            await pool.query(indexSql);
        }
    }
    if (timescaleAvailable) {
        for (const definition of orderedDefinitions.filter((d) => d.timescale?.hypertable)) {
            const { timeColumn, chunkTimeInterval } = definition.timescale.hypertable;
            const intervalPart = chunkTimeInterval ? `, chunk_time_interval => INTERVAL '${chunkTimeInterval}'` : '';
            // Explicit casts: extended-protocol params arrive as "unknown" and Postgres does
            // not resolve create_hypertable(regclass, name, ...) with named notation otherwise.
            // Non-fatal: the table already exists as a regular table at this point; a Timescale
            // failure must not abort the whole migration/publish.
            try {
                await pool.query(`SELECT create_hypertable($1::regclass, $2::name, if_not_exists => TRUE${intervalPart})`, [definition.tableName, timeColumn]);
            }
            catch (error) {
                console.warn(`[bootstrapSchema] create_hypertable failed for "${definition.tableName}" — kept as regular table:`, error instanceof Error ? error.message : error);
            }
        }
    }
    // Mechanical seed: the schema was just rebuilt (DROP SCHEMA above), so every table is
    // empty — apply the definitions' seedRows. Non-fatal: bad seed data must not block a release.
    for (const definition of orderedDefinitions.filter((d) => d.seedRows?.length)) {
        try {
            for (const row of definition.seedRows) {
                const columns = definition.columns.map((c) => c.name).filter((name) => row[name] !== undefined);
                if (columns.length === 0)
                    continue;
                const placeholders = columns.map((_, index) => `$${index + 1}`);
                const values = columns.map((name) => {
                    const value = row[name];
                    return value !== null && typeof value === 'object' ? JSON.stringify(value) : value;
                });
                await pool.query(`INSERT INTO ${quoteIdentifier(definition.tableName)} (${columns.map(quoteIdentifier).join(', ')}) VALUES (${placeholders.join(', ')})`, values);
            }
            console.info(`[bootstrapSchema] seeded ${definition.seedRows.length} row(s) into "${definition.tableName}"`);
        }
        catch (error) {
            console.warn(`[bootstrapSchema] seed failed for "${definition.tableName}":`, error instanceof Error ? error.message : error);
        }
    }
    await pool.query('INSERT INTO "_schema_migrations" ("id") VALUES ($1)', [snapshotId]);
    return timescaleAvailable;
}
const TIMESCALE_STATEMENT_PATTERN = /timescaledb|time_bucket|create_hypertable|continuous aggregate|add_retention_policy|add_compression_policy/iu;
async function applyViewDefinitions(pool, input) {
    const viewDefs = await loadViewDefinitions();
    for (const view of viewDefs) {
        for (const statement of view.statements) {
            if (!input.timescaleAvailable && TIMESCALE_STATEMENT_PATTERN.test(statement)) {
                console.warn(`[bootstrapSchema] Skipped TimescaleDB view statement for ${view.viewName}`);
                continue;
            }
            // Non-fatal: a broken view must not block the migration/publish.
            try {
                await pool.query(statement);
            }
            catch (error) {
                console.warn(`[bootstrapSchema] view statement failed for ${view.viewName}:`, error instanceof Error ? error.message : error);
            }
        }
    }
}
export async function bootstrapSchema(env, input) {
    if (env.runtimeMode === 'memory') {
        console.info('[bootstrapSchema] Skipped — memory mode');
        return { snapshotId: 'memory', postgresTableCount: 0, dynamoTableCount: 0 };
    }
    const definitions = await loadResolvedTableDefinitions(env);
    const snapshot = await buildSchemaSnapshot(env);
    const timescaleAvailable = await rebuildPostgresSchema(env, definitions, snapshot.id);
    const pool = getSharedPgPool(env);
    await applyViewDefinitions(pool, { timescaleAvailable });
    let dynamoTableCount = 0;
    if (input?.ensureDynamo !== false) {
        await ensureRegisteredDynamoTables(env);
        dynamoTableCount = definitions.filter((definition) => definition.dynamoResolvedTableName).length;
    }
    if (input?.recordSnapshotLog) {
        await writeSchemaSnapshotLog(env, snapshot);
    }
    return {
        snapshotId: snapshot.id,
        postgresTableCount: definitions.filter((definition) => usesPostgres(definition)).length,
        dynamoTableCount,
    };
}

/// <mls fileReference="_102034_/l1/server/layer_1_external/cbe/cbeTypes.ts" enhancement="_blank" />
// Minimal contracts mirrored from the central cbe (collab back-end) /exec API.
// Only the login-related subset runs on the runtime VM — administration
// actions (org management, invites, project settings, user creation) stay on
// the central cbe / sites.collab.codes. Field names must stay compatible with
// the cfe (mls) frontend library, which consumes this payload unchanged.
export const CBE_HTTP_OK = 200;
export const CBE_HTTP_BAD_REQUEST = 400;
export const CBE_HTTP_NOT_FOUND = 404;
export const CBE_HTTP_NOT_MODIFIED = 304;
export const CBE_HTTP_SERVER_ERROR = 500;

/// <mls fileReference="_102034_/l1/server/layer_1_external/cbe/cbeTypes.ts" enhancement="_blank" />
// Minimal contracts mirrored from the central cbe (collab back-end) /exec API.
// Only the login-related subset runs on the runtime VM — administration
// actions (org management, invites, project settings, user creation) stay on
// the central cbe / sites.collab.codes. Field names must stay compatible with
// the cfe (mls) frontend library, which consumes this payload unchanged.

export const CBE_HTTP_OK = 200;
export const CBE_HTTP_BAD_REQUEST = 400;
export const CBE_HTTP_UNAUTHORIZED = 401;
export const CBE_HTTP_NOT_FOUND = 404;
export const CBE_HTTP_NOT_MODIFIED = 304;
export const CBE_HTTP_SERVER_ERROR = 500;

export interface CbeProjectsLastModified {
  project: number;
  lastModified: string;
}

export interface CbeRequestBase {
  action: string;
}

export interface CbeRequestLogin extends CbeRequestBase {
  action: 'login';
  queryString?: string;
  baseProject?: number;
  actualProject?: number;
  projectsLastModified?: CbeProjectsLastModified[];
}

// Sent by the cfe's collab-auth callback handler (handleCollabAuthCallback):
// the tokens arrive in the URL fragment and are handed to the server, which
// verifies and stores them as httpOnly cookies — JS never keeps them.
export interface CbeRequestAuthSession extends CbeRequestBase {
  action: 'authSession';
  access_token?: string;
  refresh_token?: string;
}

// ── Source I/O (VM storage driver, mls-102033 l2/cbe/driverVm.ts) ───────────
// The login only delivers compiled js; these actions serve the .ts SOURCES the
// studio editor and the agents read and write.

export interface CbeSourceFile {
  /** `l<level>/<folder>/<shortName><extension>` — same key the login's filesInfo uses. */
  shortPath: string;
  content: string;
  /** utf8 for text, base64 for binary (l3 assets). */
  encoding: 'utf8' | 'base64';
}

export interface CbeRequestGetContents extends CbeRequestBase {
  action: 'getContents';
  project?: number;
  shortPaths?: string[];
}

export interface CbeRequestSetContents extends CbeRequestBase {
  action: 'setContents';
  project?: number;
  files?: CbeSourceFile[];
  deletes?: string[];
  /** The studio's save comment — becomes the message of the commit cbeGitCommit makes. */
  comments?: string | null;
}

export interface CbeRequestLoadFilesInfo extends CbeRequestBase {
  action: 'loadFilesInfo';
  project?: number;
}

// ── File history (read-only; served from the project's git repo on the VM) ──
// Field names mirror mls.stor.IHistory, except `date` — the cfe interface calls
// it `data`, which the driver renames on the way out rather than spreading the
// typo through the server.

export interface CbeHistoryEntry {
  /** Commit sha; opaque to the cfe, handed back verbatim to getHistoryContent. */
  ref: string;
  authorName: string;
  /** ISO-8601 author date. */
  date: string;
  message: string;
  additions: number;
  deletions: number;
}

export interface CbeRequestGetHistory extends CbeRequestBase {
  action: 'getHistory';
  project?: number;
  shortPath?: string;
}

export interface CbeRequestGetHistoryContent extends CbeRequestBase {
  action: 'getHistoryContent';
  project?: number;
  shortPath?: string;
  ref?: string;
}

export interface CbePrjSourcesFile {
  shortPath: string;
  versionRef?: string;
  Length?: number;
  update_at?: string;
  /** gzip+base64 of the compiled js content (same encoding the central cbe uses). */
  jsContent?: string;
}

export interface CbePrjSourcesInfo {
  filesInfo: CbePrjSourcesFile[];
  importsMap: string;
  indexModules: string;
}

export interface CbePrjSettings {
  id: number;
  name: string;
  owner: string;
  value: string;
  created_at: string;
  archived_at: string;
  repository_lastModified: string;
  userAuth: 'public' | 'private';
  prj_dependencies: number[];
  /** gzip+base64 of CbePrjSourcesInfo — only present when newer than the frontend copy. */
  files?: string;
}

export interface CbeOrgInfo {
  key: string;
  value: string;
  sett: {
    name: string;
    created_at: string;
    description: string;
    projects: CbePrjSettings[];
    users: string[];
    teams: { name: string; auth: string; usrIndex: number[] }[];
  };
  VersionNumber: number;
}

export interface CbeResponseBase {
  statusCode: number;
  msg: string;
  error?: string;
}

export interface CbeResponseLogin extends CbeResponseBase {
  services: unknown[];
  orgs: { [org: string]: CbeOrgInfo };
  inits: { [widget: string]: string };
  providers: string[];
  avatar_url: string;
  baseProject: number;
  alertMessage: string;
  errorMessage: string;
}

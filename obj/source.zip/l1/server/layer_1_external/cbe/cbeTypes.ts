/// <mls fileReference="_102034_/l1/server/layer_1_external/cbe/cbeTypes.ts" enhancement="_blank" />
// Minimal contracts mirrored from the central cbe (collab back-end) /exec API.
// Only the login-related subset runs on the runtime VM — administration
// actions (org management, invites, project settings, user creation) stay on
// the central cbe / sites.collab.codes. Field names must stay compatible with
// the cfe (mls) frontend library, which consumes this payload unchanged.

export const CBE_HTTP_OK = 200;
export const CBE_HTTP_BAD_REQUEST = 400;
export const CBE_HTTP_UNAUTHORIZED = 401;
export const CBE_HTTP_FORBIDDEN = 403;
export const CBE_HTTP_NOT_FOUND = 404;
export const CBE_HTTP_NOT_MODIFIED = 304;
export const CBE_HTTP_SERVER_ERROR = 500;

export interface CbeProjectsLastModified {
  project: number;
  lastModified: string;
}

export interface CbeRequestBase {
  action: string;
}

export interface CbeRequestLogin extends CbeRequestBase {
  action: 'login';
  queryString?: string;
  baseProject?: number;
  actualProject?: number;
  projectsLastModified?: CbeProjectsLastModified[];
}

// Sent by the cfe's collab-auth callback handler (handleCollabAuthCallback):
// the tokens arrive in the URL fragment and are handed to the server, which
// verifies and stores them as httpOnly cookies — JS never keeps them.
export interface CbeRequestAuthSession extends CbeRequestBase {
  action: 'authSession';
  access_token?: string;
  refresh_token?: string;
  org_id?: string;
}

// ── Source I/O (VM storage driver, mls-102033 l2/cbe/driverVm.ts) ───────────
// The login only delivers compiled js; these actions serve the .ts SOURCES the
// studio editor and the agents read and write.

export interface CbeSourceFile {
  /** `l<level>/<folder>/<shortName><extension>` — same key the login's filesInfo uses. */
  shortPath: string;
  content: string;
  /** utf8 for text, base64 for binary (l3 assets). */
  encoding: 'utf8' | 'base64';
}

export interface CbeRequestGetContents extends CbeRequestBase {
  action: 'getContents';
  project?: number;
  shortPaths?: string[];
  /**
   * A commit (7..40 hex chars). With it, each `shortPath` is read as it was in that commit, in the same tree
   * `getHistoryContent` reads (the draft's when the draft header is present), in ONE git process for the whole
   * request. The answer has the usual shape (`files[]` with `shortPath`, `content`, `encoding`): a file that did not
   * exist in the commit, or a path the project boundary rejects, is simply left out of the list, as without `ref`.
   * An invalid `ref`, an unknown commit or more than 500 `shortPaths` is a 400, never an empty list. Without `ref`
   * nothing changes.
   */
  ref?: string;
}

/** How the text of a file written by `setContents` is encoded: text, base64 bytes, or base64 of a gzip (rt189). */
export type CbeSourceEncoding = 'utf8' | 'base64' | 'gzip-base64';

/** A file that travels inside the request. No `encoding` means utf8. The decoded size is at most 64 MB. */
export interface CbeSourceFileContent {
  shortPath: string;
  content: string;
  encoding?: CbeSourceEncoding;
}

/**
 * A file that travels in parts (`setContentsPart`): `uploadId` names the parts, `encoding` says how the joined text is
 * decoded and `sha256` (hex) is the hash of the FINAL bytes, checked before anything is written.
 */
export interface CbeSourceFileUpload {
  shortPath: string;
  uploadId: string;
  encoding: CbeSourceEncoding;
  sha256: string;
}

export type CbeSourceFileInput = CbeSourceFileContent | CbeSourceFileUpload;

/**
 * One part of a big file. `uploadId` is a UUID made by the client; `data` is a piece of the final string (text,
 * base64 or gzip-base64), at most 3 MB; `index` runs from 0 to `total - 1` and `total` is at most 64. Sending a part
 * again overwrites it. Answer: `{ statusCode: 200, received }`.
 */
export interface CbeRequestSetContentsPart extends CbeRequestBase {
  action: 'setContentsPart';
  project?: number;
  uploadId?: string;
  index?: number;
  total?: number;
  data?: string;
}

export interface CbeRequestSetContents extends CbeRequestBase {
  action: 'setContents';
  project?: number;
  files?: CbeSourceFileInput[];
  deletes?: string[];
  /** The studio's save comment — becomes the message of the commit cbeGitCommit makes. */
  comments?: string | null;
}

export interface CbeRequestLoadFilesInfo extends CbeRequestBase {
  action: 'loadFilesInfo';
  project?: number;
}

// ── File history (read-only; served from the project's git repo on the VM) ──
// Field names mirror mls.stor.IHistory, except `date` — the cfe interface calls
// it `data`, which the driver renames on the way out rather than spreading the
// typo through the server.

export interface CbeHistoryEntry {
  /** Commit sha; opaque to the cfe, handed back verbatim to getHistoryContent. */
  ref: string;
  authorName: string;
  /** ISO-8601 author date. */
  date: string;
  message: string;
  additions: number;
  deletions: number;
}

export interface CbeRequestGetHistory extends CbeRequestBase {
  action: 'getHistory';
  project?: number;
  shortPath?: string;
}

export interface CbeRequestGetHistoryContent extends CbeRequestBase {
  action: 'getHistoryContent';
  project?: number;
  shortPath?: string;
  ref?: string;
}

// ── Draft promote (merge onto main), discard, list, diff ────────────────────
// `draft` is the slug (`team-102047`), never a raw git ref.

export interface CbeRequestPromote extends CbeRequestBase {
  action: 'promote';
  project?: number;
  draft?: string;
  /** `production` merges now. `homolog` is reserved and answers NOT_YET. */
  target?: string;
  /** Becomes the merge subject: `promote <branch>: <comment>`. */
  comment?: string;
}

export interface CbeRequestDiscardDraft extends CbeRequestBase {
  action: 'discardDraft';
  project?: number;
  draft?: string;
}

export interface CbeRequestDraftResetDatabase extends CbeRequestBase {
  action: 'draftResetDatabase';
  project?: number;
  draft?: string;
}

/** Current draft data source: `source`, and `at`/`by` when a person last set it. */
export interface CbeRequestDraftDataSource extends CbeRequestBase {
  action: 'draftDataSource';
  project?: number;
  draft?: string;
}

/** Switch the draft data source to `copy`. No `modules` copies every business module. */
export interface CbeRequestDraftCopy extends CbeRequestBase {
  action: 'draftCopy';
  project?: number;
  draft?: string;
  modules?: string[];
  withRegistry?: boolean;
}

/** Point the draft at the app database through the read-only role. */
export interface CbeRequestDraftReadonly extends CbeRequestBase {
  action: 'draftReadonly';
  project?: number;
  draft?: string;
}

/** Point the draft at the same database as the published app. */
export interface CbeRequestDraftSame extends CbeRequestBase {
  action: 'draftSame';
  project?: number;
  draft?: string;
}

export interface CbeRequestDraftRestorePaths extends CbeRequestBase {
  action: 'draftRestorePaths';
  project?: number;
  draft?: string;
  /** `main`, or a 40-hex commit that is an ancestor of the draft branch. */
  ref?: string;
  paths?: string[];
}

export interface CbeRequestDraftSync extends CbeRequestBase {
  action: 'draftSync';
  project?: number;
  draft?: string;
}

export interface CbeRequestListDrafts extends CbeRequestBase {
  action: 'listDrafts';
  project?: number;
}

export interface CbeRequestDraftDiff extends CbeRequestBase {
  action: 'draftDiff';
  project?: number;
  draft?: string;
  shortPath?: string;
}

export interface CbePrjSourcesFile {
  shortPath: string;
  versionRef?: string;
  Length?: number;
  update_at?: string;
  /** gzip+base64 of the compiled js content (same encoding the central cbe uses). */
  jsContent?: string;
}

export interface CbePrjSourcesInfo {
  filesInfo: CbePrjSourcesFile[];
  importsMap: string;
  indexModules: string;
}

export interface CbePrjSettings {
  id: number;
  name: string;
  owner: string;
  value: string;
  created_at: string;
  archived_at: string;
  repository_lastModified: string;
  userAuth: 'public' | 'private';
  prj_dependencies: number[];
  /** gzip+base64 of CbePrjSourcesInfo — only present when newer than the frontend copy. */
  files?: string;
}

export interface CbeOrgInfo {
  key: string;
  value: string;
  sett: {
    name: string;
    created_at: string;
    description: string;
    projects: CbePrjSettings[];
    users: string[];
    teams: { name: string; auth: string; usrIndex: number[] }[];
  };
  VersionNumber: number;
}

export interface CbeResponseBase {
  statusCode: number;
  msg: string;
  error?: string;
}

export interface CbeResponseLogin extends CbeResponseBase {
  services: unknown[];
  orgs: { [org: string]: CbeOrgInfo };
  inits: { [widget: string]: string };
  providers: string[];
  avatar_url: string;
  baseProject: number;
  alertMessage: string;
  errorMessage: string;
}

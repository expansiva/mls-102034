/// <mls fileReference="_102034_/l1/server/layer_1_external/cbe/cbeRoutes.ts" enhancement="_blank" />
// Fastify wiring for the cbe-compatible endpoints on the runtime VM:
//   POST /exec               -> action dispatcher (login/authSession/authLogout; admin actions stay central)
//   GET  /exec/logout        -> navigation logout (clears cookies, 303 to /)
//   GET  /libs/*             -> mls lib assets (disk cache + remote origin)
//   GET  /monaco/*           -> monaco editor assets (disk cache + remote origin)
//   GET  /mlsServiceWorker.js
// Kept apart from the app/BFF routes on purpose — everything cbe-related lives
// in this folder so it can later move to a release-packaged module untouched.

import { closeSync, openSync, readFileSync, rmSync, writeFileSync, writeSync } from 'node:fs';
import { join } from 'node:path';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { Pool } from 'pg';
import { executeCbeLogin, readProjectFile } from '/_102034_/l1/server/layer_1_external/cbe/cbeLogin.js';
import { getProjectsBaseDir } from '/_102034_/l1/server/layer_1_external/cbe/cbeCompiledLocal.js';
import { getCbeStaticFile, logCbeStaticConfig } from '/_102034_/l1/server/layer_1_external/cbe/cbeStaticFiles.js';
import {
  activeOrganizationId,
  availableOrganizations,
  isJwtAuthEnabled,
  parseCookies,
  resolveJwtSession,
  selectOrganization,
  verifyAccessToken,
  type JwtSession,
} from '/_102034_/l1/server/layer_1_external/cbe/cbeAuthJwt.js';
import { listSources, readSources, writeDecodedSources } from '/_102034_/l1/server/layer_1_external/cbe/cbeSources.js';
import { decodeSourceInputs, partProblem, removeUploads, storePart, sweepExpiredUploads } from '/_102034_/l1/server/layer_1_external/cbe/cbeUploads.js';
import { EXEC_ROUTE_OPTIONS } from '/_102034_/l1/server/layer_1_external/cbe/cbeExecLimit.js';
import { CANDIDATE_BODY_LIMIT, candidateActionAllowed, candidateHubMode, candidateHubOrgId, candidateIdentity, candidateLocalCaller, candidateOrigin, proxyCandidateRequest } from '/_102034_/l1/server/layer_1_external/cbe/cbeCandidateProxy.js';
import { handleCandidateRevision } from '/_102034_/l1/server/layer_1_external/candidate/candidateStore.js';
import { ensureCandidateSchema, PostgresCandidatePersistence } from '/_102034_/l1/server/layer_1_external/candidate/candidatePostgres.js';
import { isAlphaAllAuthorities } from '/_102034_/l1/server/layer_1_external/config/alphaAuthorities.js';
import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { localTestSessionFromHeaders } from '/_102034_/l1/server/layer_1_external/auth/localTestSession.js';
import { getLocalTestConfig } from '/_102034_/l1/server/layer_1_external/config/localTestConfig.js';
import { expiredLocalTestCookie } from '/_102034_/l1/server/layer_1_external/transport/http/localTestSessionHttp.js';
import { parseDatabaseUrl, readProjectMode, resolveDatabaseUrl } from '/_102034_/l1/server/layer_1_external/config/projectMode.js';
import { getSharedPgPool } from '/_102034_/l1/server/layer_1_external/data/postgres/pg.js';
import { isAcceptableRef, MAX_REF_PATHS, readContentsAtRef, readHistory, readHistoryContent } from '/_102034_/l1/server/layer_1_external/cbe/cbeGit.js';
import { isRebuildInProgress, isRebuildOnSaveEnabled, scheduleRebuildOnSave } from '/_102034_/l1/server/layer_1_external/cbe/cbeRebuildOnSave.js';
import { authorFromSession, commitSavedSources } from '/_102034_/l1/server/layer_1_external/cbe/cbeGitCommit.js';
import { discardDraft, draftDiff, fastForwardDraft, listDrafts, mergeMainIntoDraft, promoteDraft, restoreDraftPaths } from '/_102034_/l1/server/layer_1_external/cbe/cbeGitPromote.js';
import { draftSlugForUser, parseDraftSlug, readDraftOwner, requestDraftValue, resolveRequestDraft, resolveWriteDraft, writeDraftOwner, type RequestDraft } from '/_102034_/l1/server/layer_1_external/cbe/cbeDraft.js';
import { draftChildDatabaseUrls, draftDatabaseUrl, draftDirOf, draftSharedText, ensureDevProcess, ensureDevReaper, readDevLogTail, restartDevProcess, stopDevProcess, waitForDevReady, type DevProcessInfo, type DraftSharedLang } from '/_102034_/l1/server/layer_1_external/cbe/cbeDevProcess.js';
import { sharedDraftSchemaMessage, sharedDraftSchemaModules } from '/_102034_/l1/server/layer_1_external/persistence/schemaBootstrap.js';
import {
  appendDraftDataLog,
  canDraftData,
  draftDataLang,
  readDraftData,
  writeDraftData,
  type DraftDataAction,
  type DraftDataLogEntry,
} from '/_102034_/l1/server/layer_1_external/cbe/draftDataSource.js';
import { awaitDraftPrepare, desenvIo, handleDesenvEnter, handleDesenvExit, handleDraftEnter, runDraftEnter, warmPersonDraftOnLogin } from '/_102034_/l1/server/layer_1_external/cbe/cbeDesenv.js';
import { draftCopyText, isDraftCopyModuleId, performDraftCopy, type PerformDraftCopyInput, type PerformDraftCopyResult } from '/_102034_/l1/server/layer_1_external/cbe/draftCopy.js';
import { forgetDraftLoginCopy } from '/_102034_/l1/server/layer_1_external/cbe/draftLoginCopy.js';
import { getRunningRelease } from '/_102034_/l1/server/layer_1_external/cbe/cbeRelease.js';
import {
  CBE_HTTP_BAD_REQUEST,
  CBE_HTTP_FORBIDDEN,
  CBE_HTTP_NOT_FOUND,
  CBE_HTTP_NOT_MODIFIED,
  CBE_HTTP_OK,
  CBE_HTTP_SERVER_ERROR,
  CBE_HTTP_UNAUTHORIZED,
  type CbeRequestAuthSession,
  type CbeRequestBase,
  type CbeRequestDiscardDraft,
  type CbeRequestDraftCopy,
  type CbeRequestDraftDataSource,
  type CbeRequestDraftReadonly,
  type CbeRequestDraftResetDatabase,
  type CbeRequestDraftSame,
  type CbeRequestDraftRestorePaths,
  type CbeRequestDraftDiff,
  type CbeRequestDraftSync,
  type CbeRequestGetContents,
  type CbeRequestGetHistory,
  type CbeRequestGetHistoryContent,
  type CbeRequestListDrafts,
  type CbeRequestLoadFilesInfo,
  type CbeRequestLogin,
  type CbeRequestPromote,
  type CbeRequestSetContents,
  type CbeRequestSetContentsPart,
} from '/_102034_/l1/server/layer_1_external/cbe/cbeTypes.js';
import { handleProviderToken } from '/_102034_/l1/server/layer_1_external/cbe/cbeProviderToken.js';

// Bump on every change to the cbe module. Exposed via the x-cbe-version
// response header and the {action:'ping'} probe so a deploy can be verified:
//   curl -s localhost:3000/exec -H 'Content-Type: application/json' -d '{"action":"ping"}'
export const CBE_MODULE_VERSION = '1.8.11';

// /libs/<14-digit stamp>/ and /monaco/<stamp>/ are immutable for a year: the
// stamp is the version, so the bytes at that path do not change. Any other
// static path stays no-cache and revalidates with the ETag (304 when unchanged).
const STATIC_CACHE_CONTROL = 'no-cache';
const VERSIONED_STATIC_CACHE_CONTROL = 'public, max-age=31536000, immutable';
const VERSIONED_STATIC_PATH = /^\/(?:libs|monaco)\/\d{14}\//;

function staticCacheControl(rawUrl: string): string {
  const path = rawUrl.split('?')[0] ?? '';
  return VERSIONED_STATIC_PATH.test(path) ? VERSIONED_STATIC_CACHE_CONTROL : STATIC_CACHE_CONTROL;
}

const THIRTY_DAYS_MS = 1000 * 60 * 60 * 24 * 30;

function clearedAuthCookies(): string[] {
  return [
    sessionCookie('cauth', '', { httpOnly: true, expire: true }),
    sessionCookie('crefresh', '', { httpOnly: true, expire: true }),
    sessionCookie('loginUser', 'anonymous'),
  ];
}

/** Cookies of a completed logout: expire cauth/crefresh/loginMsg, loginUser=anonymous. */
export function logoutCookies(): string[] {
  return [
    ...clearedAuthCookies(),
    sessionCookie('loginMsg', '', { httpOnly: true, expire: true }),
  ];
}

const LOGOUT_REVOKE_MS = 2000;

function authBaseUrl(): string {
  return (process.env.COLLAB_AUTH_BASE_URL ?? 'https://auth.collab.codes').replace(/\/$/u, '');
}

export async function revokeCrefresh(
  refreshToken: string | undefined,
  fetchImpl: typeof fetch = fetch,
): Promise<void> {
  const token = refreshToken?.trim();
  if (!token) return;
  try {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), LOGOUT_REVOKE_MS);
    try {
      const res = await fetchImpl(`${authBaseUrl()}/auth/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: token }),
        signal: ac.signal,
      });
      if (!res.ok) console.warn(`[cbe] logout revoke failed: collab-auth answered ${res.status}`);
    } finally {
      clearTimeout(timer);
    }
  } catch (err) {
    console.warn(`[cbe] logout revoke failed: ${(err as Error).message}`);
  }
}

async function completeLogout(
  request: FastifyRequest,
  reply: FastifyReply,
  mode: 'redirect' | 'json',
  fetchImpl: typeof fetch = fetch,
): Promise<void> {
  const session = await resolveSession(request);
  const who = session.email ?? session.testUser ?? 'anonymous';
  console.info(`[cbe] logout (${who})`);
  const cookies = parseCookies(request.headers.cookie as string | undefined);
  await revokeCrefresh(cookies.crefresh, fetchImpl);
  const setCookies = logoutCookies();
  try {
    const state = getLocalTestConfig();
    if (state.enabled) {
      setCookies.push(expiredLocalTestCookie(state.projectId, request.protocol === 'https'));
    }
  } catch {
    console.warn('[cbe] local test session config failed during logout');
    const projectId = readAppEnv().projectId;
    if (projectId) setCookies.push(expiredLocalTestCookie(projectId, request.protocol === 'https'));
  }
  reply.header('set-cookie', setCookies);
  reply.header('Cache-Control', 'no-store');
  if (mode === 'redirect') {
    reply.code(303).header('Location', '/').send();
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok' });
}

function sessionCookie(name: string, value: string, options: { httpOnly?: boolean; maxAgeMs?: number; expire?: boolean } = {}): string {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/'];
  parts.push(options.httpOnly ? 'SameSite=Strict' : 'SameSite=Lax');
  if (options.httpOnly) parts.push('HttpOnly');
  if (options.expire) parts.push(`Expires=${new Date(0).toUTCString()}`);
  else if (options.maxAgeMs) parts.push(`Expires=${new Date(Date.now() + options.maxAgeMs).toUTCString()}`);
  return parts.join('; ');
}

// ── Session resolution ──────────────────────────────────────────────────────
// Order: collab-auth JWT (cauth cookie, validated offline via JWKS) wins; the
// .env test user (CBE_TEST_LOGIN_USER) is the localhost/test fallback; else
// anonymous. Mirrors the central cbe where perfil.user comes from the JWT.
async function resolveSession(request: FastifyRequest): Promise<JwtSession & { testUser?: string }> {
  const cookies = parseCookies(request.headers.cookie as string | undefined);
  const session = await resolveJwtSession(cookies.cauth ?? '', cookies.crefresh ?? '');
  if (session.email) return session;
  const testUser = process.env.CBE_TEST_LOGIN_USER;
  return testUser ? { testUser } : {};
}

/**
 * The person behind a request: the JWT email wins; otherwise the signed local-test persona
 * (the lima bench, where there is no JWT). A disabled bench or a bad cookie gives no person.
 * Tests replace this so a save can name a person without a signed JWT.
 */
export const sessionHooks = {
  emailOf: async (request: FastifyRequest): Promise<string | undefined> => {
    const session = await resolveSession(request);
    if (session.email) return session.email;
    const local = localTestSessionFromHeaders(requestHeaderRecord(request.headers));
    return local.kind === 'ok' ? local.claims.email : undefined;
  },
};

/** Route tests replace these. Alpha on releases every draft-data action; otherwise the JWT list is checked. */
export const draftDataHooks = {
  alphaOn: (): boolean => isAlphaAllAuthorities(),
  authoritiesOf: async (_request: FastifyRequest): Promise<readonly string[]> => [],
};

function headerString(value: string | string[] | undefined): string {
  return Array.isArray(value) ? value[0] ?? '' : value ?? '';
}

function requestHeaderRecord(headers: FastifyRequest['headers']): Record<string, string | string[] | undefined> {
  const record: Record<string, string | string[] | undefined> = {};
  for (const [key, value] of Object.entries(headers)) {
    if (typeof value === 'string' || Array.isArray(value) || value === undefined) record[key] = value;
  }
  return record;
}

let candidateSchemaStarted = false;
let hubStore: PostgresCandidatePersistence | undefined;

function hubCandidateStore(): PostgresCandidatePersistence {
  if (!hubStore) hubStore = new PostgresCandidatePersistence(getSharedPgPool(readAppEnv()));
  return hubStore;
}

async function handleCandidateProxy(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  const body = request.body as unknown;
  if (!candidateActionAllowed(body)) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, status: 'error', msg: 'candidate.invalid_action' });
    return;
  }
  const cookies = parseCookies(request.headers.cookie as string | undefined);
  const session = await resolveSession(request);
  // CBE_TEST_LOGIN_USER is never sufficient, in either mode.
  if (candidateHubMode() === 'local') {
    const identity = candidateIdentity({
      email: session.email,
      authorization: headerString(request.headers.authorization),
      userId: headerString(request.headers['x-user-id']),
      orgId: headerString(request.headers['x-org-id']),
      serviceToken: process.env.COLLAB_SERVICE_TOKEN,
    });
    const caller = candidateLocalCaller(identity, session, process.env);
    if (!caller) {
      reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, status: 'error', msg: 'candidate.unauthorized' });
      return;
    }
    if (identity.kind === 'jwt' && session.newAccessToken) {
      reply.header('set-cookie', [sessionCookie('cauth', session.newAccessToken, { httpOnly: true, maxAgeMs: THIRTY_DAYS_MS })]);
    }
    try {
      const hubOrgId = candidateHubOrgId(
        readProjectFile(Number(process.env.COLLAB_PROJECT_ID))?.org.orgId ?? null,
        process.env,
      );
      const result = await handleCandidateRevision(
        caller,
        body as Parameters<typeof handleCandidateRevision>[1],
        hubOrgId,
        hubCandidateStore(),
      );
      reply.code(result.statusCode).header('Content-Type', 'application/json; charset=utf-8').header('Cache-Control', 'no-store').send(result);
    } catch (err) {
      console.error('[cbe:candidate] local hub failed:', (err as Error).message);
      reply.code(503).send({ statusCode: 503, status: 'error', msg: 'candidate.transport_unavailable' });
    }
    return;
  }
  // Forward a verified JWT as cauth, or the lima desenv identity from MSG_PROXY_*.
  // Never copy the inbound Authorization.
  if (session.email && session.newAccessToken) {
    reply.header('set-cookie', [sessionCookie('cauth', session.newAccessToken, { httpOnly: true, maxAgeMs: THIRTY_DAYS_MS })]);
  }
  const verifiedToken = session.email ? (session.newAccessToken ?? cookies.cauth ?? '') : '';
  try {
    const result = await proxyCandidateRequest(body, verifiedToken, fetch, process.env);
    reply.code(result.statusCode).header('Content-Type', result.contentType).header('Cache-Control', 'no-store').send(result.body);
  } catch (err) {
    console.error('[cbe:candidate] central transport failed:', (err as Error).message);
    reply.code(503).send({ statusCode: 503, status: 'error', msg: 'candidate.transport_unavailable' });
  }
}

// Studio sources require a JWT session on real domains (102045.collabcodes.com
// etc.); localhost/dev needs none. CBE_REQUIRE_LOGIN=always|never overrides
// the host-based default. The production APP (BFF) is never gated by this —
// only the cbe login's sources/orgs delivery.
function requiresLogin(request: FastifyRequest): boolean {
  const override = process.env.CBE_REQUIRE_LOGIN;
  if (override === 'always') return true;
  if (override === 'never') return false;
  const host = String(request.headers.host ?? '').split(':')[0].toLowerCase();
  return !(host === 'localhost' || host === '127.0.0.1' || host === '::1' || host.endsWith('.local') || host === '');
}

// Cookies for the login response. The cfe frontend gates its UI on the
// JS-readable `loginUser`; cauth/crefresh stay httpOnly (set by authSession).
function buildLoginCookies(session: JwtSession & { testUser?: string }): string[] {
  if (session.email) {
    const cookies = [sessionCookie('loginUser', session.email)];
    if (session.newAccessToken) {
      cookies.push(sessionCookie('cauth', session.newAccessToken, { httpOnly: true, maxAgeMs: THIRTY_DAYS_MS }));
    }
    return cookies;
  }

  if (session.testUser) {
    console.warn(`[cbe] TEST session active (CBE_TEST_LOGIN_USER=${session.testUser}) — do not use in production`);
    const cookies = [sessionCookie('loginUser', session.testUser)];
    const cauth = process.env.CBE_TEST_CAUTH;
    if (cauth) cookies.push(sessionCookie('cauth', cauth, { httpOnly: true }));
    const loginMsg = process.env.CBE_TEST_LOGIN_MSG;
    if (loginMsg) cookies.push(sessionCookie('loginMsg', loginMsg, { httpOnly: true }));
    return cookies;
  }

  return [sessionCookie('loginUser', 'anonymous')];
}

// authSession: establish the JWT session from the collab-auth callback tokens
// (the cfe posts them from the URL fragment). Verify before trusting — a bad
// token must never set a session cookie. Same contract as the central cbe.
async function handleAuthSession(body: CbeRequestAuthSession, reply: FastifyReply): Promise<void> {
  if (!isJwtAuthEnabled()) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'JWT auth disabled (AUTH_JWT_ENABLED=false)' });
    return;
  }
  const accessToken = (body.access_token ?? '').trim();
  const refreshToken = (body.refresh_token ?? '').trim();
  if (!accessToken) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'missing access_token' });
    return;
  }

  try {
    const claims = await verifyAccessToken(accessToken);
    const currentOrg = activeOrganizationId(claims);
    const requestedOrg = typeof body.org_id === 'string' ? body.org_id.trim() : '';
    if (!currentOrg && !requestedOrg) {
      reply.code(409).header('set-cookie', clearedAuthCookies()).send({
        statusCode: 409,
        code: 'ORG_SELECTION_REQUIRED',
        msg: 'Select an organization for this session',
        orgs: availableOrganizations(claims),
      });
      return;
    }
    const selectedToken = requestedOrg
      ? await selectOrganization(accessToken, claims, requestedOrg)
      : accessToken;
    if (!selectedToken) {
      reply.code(CBE_HTTP_UNAUTHORIZED).header('set-cookie', clearedAuthCookies()).send({ statusCode: CBE_HTTP_UNAUTHORIZED, code: 'ORG_SELECTION_DENIED', msg: 'Organization selection was not authorized' });
      return;
    }
    const selectedClaims = requestedOrg ? await verifyAccessToken(selectedToken) : claims;
    const cookies = [
      sessionCookie('cauth', selectedToken, { httpOnly: true, maxAgeMs: THIRTY_DAYS_MS }),
      // loginUser here too, so the UI unlocks without waiting for the next login call.
      sessionCookie('loginUser', selectedClaims.email),
    ];
    if (refreshToken) cookies.push(sessionCookie('crefresh', refreshToken, { httpOnly: true, maxAgeMs: THIRTY_DAYS_MS }));
    console.info('[cbe] /exec action:authSession -> organization session established');
    reply.code(CBE_HTTP_OK).header('set-cookie', cookies).send({ statusCode: CBE_HTTP_OK, msg: 'ok' });
  } catch (err) {
    console.info(`[cbe] /exec action:authSession invalid token: ${(err as Error).message}`);
    reply.code(CBE_HTTP_UNAUTHORIZED).header('set-cookie', clearedAuthCookies()).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'invalid access token' });
  }
}

async function handleAuthLogout(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  await completeLogout(request, reply, 'json');
}

async function handleExecLogout(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  await completeLogout(request, reply, 'redirect');
}

// ── Source I/O (VM storage driver) ──────────────────────────────────────────
// Same gate as the login's sources delivery: on a real domain a JWT session is
// required. Writing is stricter — it changes files on the VM's disk, so an
// unauthenticated caller is refused even where reading would be allowed.
async function isSourceRequestAllowed(request: FastifyRequest): Promise<boolean> {
  if (!requiresLogin(request)) return true;
  const session = await resolveSession(request);
  return Boolean(session.email);
}

function readProjectId(body: { project?: number }): number | null {
  const project = Number(body.project);
  return Number.isInteger(project) && project > 0 ? project : null;
}

function draftBody(draft: RequestDraft | null): { slug: string; branch: string } | null {
  return draft ? { slug: draft.slug, branch: draft.branch } : null;
}

async function handleGetContents(request: FastifyRequest, body: CbeRequestGetContents, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project || !Array.isArray(body.shortPaths)) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project or shortPaths' });
    return;
  }
  const draft = await resolveRequestDraft(request.headers, getProjectsBaseDir(), project);
  if (body.ref !== undefined) {
    // A batch at a commit (rt188): one git process for the whole list. A bad ref is a 400, not an empty list, so an
    // error never looks like "no files".
    if (!isAcceptableRef(body.ref) || body.shortPaths.length > MAX_REF_PATHS) {
      const msg = isAcceptableRef(body.ref) ? `too many shortPaths for a ref request (max ${MAX_REF_PATHS})` : 'invalid ref';
      reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg });
      return;
    }
    const atRef = readContentsAtRef(project, body.shortPaths, body.ref, draft?.sourceRoot);
    if (atRef === null) {
      reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid ref' });
      return;
    }
    reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', files: atRef, draft: draftBody(draft) });
    return;
  }
  const files = readSources(project, body.shortPaths, draft?.sourceRoot);
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', files, draft: draftBody(draft) });
}

/** Route tests replace these so a draft save does not spawn Deno. */
export const draftDevHooks = {
  restartDevProcess,
  ensureDevReaper,
  stopDevProcess,
  ensureDevProcess,
  waitForDevReady,
};

/** Route tests replace this so a draft action does not wait on a real prepare. */
export const draftPrepareHooks = {
  awaitDraftPrepare,
};

/** Route tests replace `perform` so a copy does not open Postgres. */
export const draftCopyHooks: { perform: (input: PerformDraftCopyInput) => Promise<PerformDraftCopyResult> } = {
  perform: performDraftCopy,
};

/** Route tests replace these so a promote or draftSync does not touch git. */
export const draftSyncHooks = {
  fastForwardDraft,
  mergeMainIntoDraft,
};

function scheduleDraftDevRestart(base: string, slug: string, clientProjectId: number): void {
  try {
    void draftDevHooks.restartDevProcess({
      base,
      slug,
      clientProjectId,
    }).catch((err: unknown) => {
      console.error(`[cbe] draft ${slug}: dev restart failed: ${(err as Error).message}`);
    });
  } catch (err) {
    console.error(`[cbe] draft ${slug}: dev restart failed: ${(err as Error).message}`);
  }
}

async function handleSetContents(request: FastifyRequest, body: CbeRequestSetContents, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project' });
    return;
  }
  const base = getProjectsBaseDir();
  const marked = requestDraftValue(request.headers);
  let headers = request.headers;
  // No mark: the signed-in person. team-<project> stays the fallback when nobody is identified (rt153).
  if (marked === undefined || marked === '') {
    const email = await sessionHooks.emailOf(request);
    if (email) {
      const person = draftSlugForUser(email);
      await writeDraftOwner(base, person.slug, email);
      headers = { ...request.headers, 'x-collab-draft': person.slug };
    }
  }
  const draft = await resolveWriteDraft(headers, base, project);
  // Big files (rt189): compressed ones are decoded and the ones in parts are assembled and checked HERE, before the first
  // write; a bad one is a 400 with the reason and nothing is written, not even the other files of the request.
  const decoded = decodeSourceInputs(Array.isArray(body.files) ? body.files : [], { base, project, scope: draft.slug });
  // After the decode, so an expired upload is reported as expired and only then removed.
  sweepExpiredUploads(base, project);
  if (!decoded.ok) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: decoded.msg });
    return;
  }
  const rc = writeDecodedSources(project, decoded.files, body.deletes ?? [], { sourceRoot: draft.sourceRoot });
  if (!rc.ok) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: rc.msg ?? 'invalid request' });
    return;
  }
  removeUploads(base, project, draft.slug, decoded.uploadIds);
  // Commit so getHistory and versionRef see this write. Awaited, never fatal —
  // the files are already on disk. `sourceRoot` is the draft worktree.
  const session = await resolveSession(request);
  const commit = await commitSavedSources(project, rc.paths, {
    comments: body.comments ?? undefined,
    author: authorFromSession(session.email ?? session.testUser),
    sourceRoot: draft.sourceRoot,
  });
  if (commit.status === 'failed') {
    console.warn(`[cbe] setContents project ${project}: commit failed (save kept, versionRef will not move): ${commit.msg}`);
  } else if (commit.status === 'committed') {
    console.info(`[cbe] setContents project ${project}: committed ${commit.ref?.slice(0, 8)}`);
  }
  // setContents never rebuilds the release. A draft dev process restarts only when l1 changes.
  console.info(`[cbe] draft ${draft.slug}: no release rebuild`);
  draftDevHooks.ensureDevReaper(base);
  const files = body.files ?? [];
  const deletes = body.deletes ?? [];
  const l1Changed = files.some((file) => file.shortPath.startsWith('l1/'))
    || deletes.some((shortPath) => shortPath.startsWith('l1/'));
  // l2/l3 are served from the Studio cache; only an l1 change needs a new dev process.
  if (!l1Changed) {
    console.info(`[cbe] draft ${draft.slug}: l2/l3 only, no restart`);
  } else {
    // Fire-and-forget: the save responds before the debounced restart. A rejection
    // (or a sync throw from an invalid slug) is logged and never fails this handler.
    try {
      void draftDevHooks.restartDevProcess({
        base,
        slug: draft.slug,
        clientProjectId: project,
      }).catch((err: unknown) => {
        console.error(`[cbe] draft ${draft.slug}: dev restart failed: ${(err as Error).message}`);
      });
    } catch (err) {
      console.error(`[cbe] draft ${draft.slug}: dev restart failed: ${(err as Error).message}`);
    }
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', commit, draft: draftBody(draft) });
}

/**
 * The draft a write goes to, as a slug only (no worktree is made): the one setContents will choose with the same inputs,
 * so the parts of a big file wait where the setContents that joins them will look.
 */
async function writeTargetSlug(request: FastifyRequest, project: number): Promise<string> {
  const marked = requestDraftValue(request.headers);
  const parsed = parseDraftSlug(marked);
  if (parsed) return parsed.slug;
  if (marked === undefined || marked === '') {
    const email = await sessionHooks.emailOf(request);
    if (email) return draftSlugForUser(email).slug;
  }
  return `team-${project}`;
}

// One part of a big file (rt189). Same access rule and same draft choice as setContents; nothing is written to the
// project tree, only to the uploads folder.
async function handleSetContentsPart(request: FastifyRequest, body: CbeRequestSetContentsPart, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project' });
    return;
  }
  const problem = partProblem(body);
  if (problem) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: problem });
    return;
  }
  const base = getProjectsBaseDir();
  sweepExpiredUploads(base, project);
  const stored = storePart(base, project, await writeTargetSlug(request, project), body as { uploadId: string; index: number; total: number; data: string });
  if (!stored.ok) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: stored.msg });
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', received: stored.received });
}

async function handleLoadFilesInfo(request: FastifyRequest, body: CbeRequestLoadFilesInfo, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project' });
    return;
  }
  const draft = await resolveRequestDraft(request.headers, getProjectsBaseDir(), project);
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', filesInfo: listSources(project, draft?.sourceRoot), draft: draftBody(draft) });
}

// History is source code: the same session gate the read actions use applies.
async function handleGetHistory(request: FastifyRequest, body: CbeRequestGetHistory, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project || typeof body.shortPath !== 'string') {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project or shortPath' });
    return;
  }
  const draft = await resolveRequestDraft(request.headers, getProjectsBaseDir(), project);
  // A project without .git, an untracked file or a rejected path all mean "no
  // history" — an empty list, not an error: the studio must degrade quietly.
  reply.code(CBE_HTTP_OK).send({
    statusCode: CBE_HTTP_OK,
    msg: 'ok',
    history: readHistory(project, body.shortPath, draft?.sourceRoot),
    draft: draftBody(draft),
  });
}

async function handleGetHistoryContent(request: FastifyRequest, body: CbeRequestGetHistoryContent, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return;
  }
  const project = readProjectId(body);
  if (!project || typeof body.shortPath !== 'string' || typeof body.ref !== 'string') {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project, shortPath or ref' });
    return;
  }
  const draft = await resolveRequestDraft(request.headers, getProjectsBaseDir(), project);
  // An unacceptable ref (the UI's 'local' sentinel, anything non-hex) comes back
  // as null content, not 400: the diff panel asks for it on an ordinary click.
  const content = readHistoryContent(project, body.shortPath, body.ref, draft?.sourceRoot);
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, msg: 'ok', content, draft: draftBody(draft) });
}

// GET /cbe/source?project=<id>&path=<shortPath> — the file as the VM has it.
//
// This is what the editor's "View on repository" opens here: on the VM the
// repository IS the VM, and DriverIOBase.getUrl is SYNCHRONOUS, so the driver
// can only return a url it can build client-side — a same-origin one. Reads the
// tree through readSources, so it shows exactly what getContents serves, and
// goes through the same session gate and the same path boundary as /exec.
async function handleSourceView(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).type('text/plain; charset=utf-8').send('login required');
    return;
  }
  const query = request.query as { project?: string; path?: string };
  const project = Number(query.project);
  if (!Number.isInteger(project) || project <= 0 || typeof query.path !== 'string' || !query.path) {
    reply.code(CBE_HTTP_BAD_REQUEST).type('text/plain; charset=utf-8').send('invalid project or path');
    return;
  }
  const draft = await resolveRequestDraft(request.headers, getProjectsBaseDir(), project);

  // readSources drops a rejected path and a missing file alike — both are "not
  // here" to a reader, and telling them apart would report on the file system.
  const [file] = readSources(project, [query.path], draft?.sourceRoot);
  if (!file) {
    reply.code(CBE_HTTP_NOT_FOUND).type('text/plain; charset=utf-8').send('not found');
    return;
  }
  if (file.encoding === 'base64') {
    // An l3 asset: hand it over as bytes instead of showing base64 as if it were the file.
    reply.code(CBE_HTTP_OK).type('application/octet-stream').send(Buffer.from(file.content, 'base64'));
    return;
  }
  // text/plain so the browser shows the source instead of downloading it.
  reply.code(CBE_HTTP_OK).type('text/plain; charset=utf-8').send(file.content);
}

/** Publish claim shared by both pm2 workers. Alive until the rebuild lock appears, or 30s. */
interface PromoteInFlight {
  project: number;
  draft: string;
  startedAt: string;
}

/** Written when a claim expires and the rebuild never started. `ping` returns it. */
interface LastPromote {
  status: 'rebuild-not-started';
  project: number;
  draft: string;
  at: string;
}

const PROMOTE_IN_FLIGHT_FILE = '.promote-in-flight.json';
const LAST_PROMOTE_FILE = '.last-promote.json';
const PROMOTE_IN_FLIGHT_MS = 30_000;

function buildPromoteInFlight(project: number, draft: string, startedAt: string): PromoteInFlight {
  return { project, draft, startedAt };
}

function buildLastPromote(project: number, draft: string, at: string): LastPromote {
  return { status: 'rebuild-not-started', project, draft, at };
}

/** Route tests replace these so a promote does not start a release build. */
export const promoteRouteHooks = {
  scheduleRebuildOnSave,
  isRebuildInProgress,
  isRebuildOnSaveEnabled,
  promoteStateDir: (): string => getProjectsBaseDir(),
  now: (): number => Date.now(),
};

interface DraftDbDrop {
  dropDatabase(adminUrl: string, name: string): Promise<void>;
}

const DRAFT_DATABASE_NAME = /^[a-z0-9_]+$/u;

/** Route tests replace `dropDatabase` so a draft reset does not open Postgres. */
export const draftDbHooks: DraftDbDrop = {
  dropDatabase: dropDraftDatabase,
};

async function dropDraftDatabase(adminUrl: string, name: string): Promise<void> {
  if (!DRAFT_DATABASE_NAME.test(name)) {
    console.error(`[cbe] reset draft database: invalid database name`);
    throw new Error('invalid database name');
  }
  const admin = new Pool({ connectionString: adminUrl });
  try {
    await admin.query(`DROP DATABASE IF EXISTS "${name}" WITH (FORCE)`);
  } finally {
    try {
      await admin.end();
    } catch (err) {
      console.error(`[cbe] reset draft database: closing admin connection failed: ${(err as Error).message}`);
    }
  }
}

async function discardDraftDatabase(
  slug: string,
  projectId: number,
): Promise<{ databaseDropped: true } | { databaseDropped: false; cause: string }> {
  const testUrl = process.env.DATABASE_URL_TEST;
  if (!testUrl) {
    const cause = 'DATABASE_URL_TEST is not set';
    console.error(`[cbe] reset draft database ${slug}: ${cause}`);
    return { databaseDropped: false, cause };
  }
  let parsed: { database: string; adminUrl: string } | null;
  try {
    parsed = parseDatabaseUrl(draftDatabaseUrl(testUrl, slug, projectId));
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] reset draft database ${slug}: ${cause}`);
    return { databaseDropped: false, cause };
  }
  if (!parsed) {
    const cause = 'invalid database url';
    console.error(`[cbe] reset draft database ${slug}: ${cause}`);
    return { databaseDropped: false, cause };
  }
  try {
    await draftDbHooks.dropDatabase(parsed.adminUrl, parsed.database);
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] reset draft database ${slug}: drop database ${parsed.database} failed: ${cause}`);
    return { databaseDropped: false, cause };
  }
  return { databaseDropped: true };
}

function promoteInFlightPath(): string {
  return join(promoteRouteHooks.promoteStateDir(), PROMOTE_IN_FLIGHT_FILE);
}

function lastPromotePath(): string {
  return join(promoteRouteHooks.promoteStateDir(), LAST_PROMOTE_FILE);
}

function isPromoteInFlight(value: Partial<PromoteInFlight> | null): value is PromoteInFlight {
  return !!value
    && Number.isInteger(value.project)
    && typeof value.draft === 'string'
    && typeof value.startedAt === 'string'
    && Number.isFinite(Date.parse(value.startedAt));
}

/** `null` when the file is absent. `'corrupt'` when it is there but unusable. */
function readPromoteFile(): PromoteInFlight | null | 'corrupt' {
  const path = promoteInFlightPath();
  let raw: string;
  try {
    raw = readFileSync(path, 'utf8');
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return null;
    console.warn(`[cbe] promote in-flight unreadable: ${(err as Error).message}`);
    return 'corrupt';
  }
  try {
    const value = JSON.parse(raw) as Partial<PromoteInFlight>;
    if (!isPromoteInFlight(value)) {
      console.warn('[cbe] promote in-flight file has an invalid shape');
      return 'corrupt';
    }
    return value;
  } catch (err) {
    console.warn(`[cbe] promote in-flight file is not json: ${(err as Error).message}`);
    return 'corrupt';
  }
}

/**
 * The claim the panel should show, or null. Reading is what retires it:
 * a rebuild in progress takes over, and 30s without one records `lastPromote`.
 */
function readLivePromote(): PromoteInFlight | null {
  const record = readPromoteFile();
  if (record === null) return null;
  if (record === 'corrupt') {
    rmSync(promoteInFlightPath(), { force: true });
    return null;
  }
  if (promoteRouteHooks.isRebuildInProgress()) {
    rmSync(promoteInFlightPath(), { force: true });
    return null;
  }
  if (promoteRouteHooks.now() - Date.parse(record.startedAt) >= PROMOTE_IN_FLIGHT_MS) {
    const last = buildLastPromote(record.project, record.draft, new Date(promoteRouteHooks.now()).toISOString());
    rmSync(promoteInFlightPath(), { force: true });
    try {
      writeFileSync(lastPromotePath(), JSON.stringify(last));
    } catch (err) {
      console.warn(`[cbe] could not record last promote: ${(err as Error).message}`);
    }
    return null;
  }
  return record;
}

function readLastPromote(): LastPromote | null {
  const path = lastPromotePath();
  let raw: string;
  try {
    raw = readFileSync(path, 'utf8');
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') {
      console.warn(`[cbe] last promote unreadable: ${(err as Error).message}`);
    }
    return null;
  }
  try {
    const value = JSON.parse(raw) as Partial<LastPromote>;
    if (value.status !== 'rebuild-not-started' || !Number.isInteger(value.project) || typeof value.draft !== 'string' || typeof value.at !== 'string') {
      console.warn('[cbe] last promote file has an invalid shape — removing it');
      rmSync(path, { force: true });
      return null;
    }
    return value as LastPromote;
  } catch (err) {
    console.warn(`[cbe] last promote file is not json — removing it: ${(err as Error).message}`);
    rmSync(path, { force: true });
    return null;
  }
}

function tryClaimPromote(record: PromoteInFlight): 'ok' | 'eexist' | 'error' {
  let fd: number;
  try {
    fd = openSync(promoteInFlightPath(), 'wx');
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'EEXIST') return 'eexist';
    console.warn(`[cbe] promote project ${record.project}: claim failed: ${(err as Error).message}`);
    return 'error';
  }
  try {
    writeSync(fd, JSON.stringify(record));
  } catch (err) {
    console.warn(`[cbe] promote project ${record.project}: claim write failed: ${(err as Error).message}`);
    closeSync(fd);
    rmSync(promoteInFlightPath(), { force: true });
    return 'error';
  }
  closeSync(fd);
  return 'ok';
}

/** Drops the file only when it is still the claim this request created. */
function releaseClaim(record: PromoteInFlight): void {
  const current = readPromoteFile();
  if (current === null) return;
  if (current === 'corrupt' || current.project !== record.project || current.draft !== record.draft || current.startedAt !== record.startedAt) {
    console.warn(`[cbe] promote project ${record.project}: in-flight file is not this claim — leaving it`);
    return;
  }
  rmSync(promoteInFlightPath(), { force: true });
}

function replyPromoteBlocked(reply: FastifyReply, code: 'REBUILD_BUSY' | 'PROMOTE_IN_PROGRESS'): void {
  reply.code(409).send({ statusCode: 409, code });
}

/** `true` once this request owns the file. One retry when the file on disk has expired. */
function claimPromote(record: PromoteInFlight, reply: FastifyReply): boolean {
  const first = takePromoteClaim(record, reply);
  if (first !== 'retry') return first === 'ok';
  const second = takePromoteClaim(record, reply);
  if (second === 'retry') {
    console.warn(`[cbe] promote project ${record.project}: in-flight file still blocked after one retry`);
    replyPromoteBlocked(reply, 'PROMOTE_IN_PROGRESS');
    return false;
  }
  return second === 'ok';
}

function takePromoteClaim(record: PromoteInFlight, reply: FastifyReply): 'ok' | 'retry' | 'rejected' {
  const attempt = tryClaimPromote(record);
  if (attempt === 'ok') return 'ok';
  if (attempt === 'error') {
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'PROMOTE_CLAIM_FAILED' });
    return 'rejected';
  }
  const live = readLivePromote();
  if (live) {
    console.warn(`[cbe] promote project ${record.project}: another promote is in flight for ${live.project}/${live.draft}`);
    replyPromoteBlocked(reply, 'PROMOTE_IN_PROGRESS');
    return 'rejected';
  }
  if (promoteRouteHooks.isRebuildInProgress()) {
    console.warn(`[cbe] promote project ${record.project}: rebuild took the in-flight promote`);
    replyPromoteBlocked(reply, 'REBUILD_BUSY');
    return 'rejected';
  }
  return 'retry';
}

async function requireSourceProject(
  request: FastifyRequest,
  body: { project?: number },
  reply: FastifyReply,
): Promise<number | null> {
  if (!await isSourceRequestAllowed(request)) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'login required' });
    return null;
  }
  const project = readProjectId(body);
  if (!project) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid project' });
    return null;
  }
  return project;
}

function replyGitFailure(
  reply: FastifyReply,
  result: { status: number; code: string; files?: string[] },
): void {
  reply.code(result.status).send({
    statusCode: result.status,
    code: result.code,
    ...('files' in result ? { files: result.files } : {}),
  });
}

async function handlePromote(request: FastifyRequest, body: CbeRequestPromote, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;

  if (body.target !== 'production') {
    const code = body.target === 'homolog' ? 'NOT_YET' : 'BAD_TARGET';
    console.warn(`[cbe] promote project ${project}: rejected target ${String(body.target)} (${code})`);
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code });
    return;
  }

  // Before any git: a rebuild already running must not start a second release.
  if (promoteRouteHooks.isRebuildInProgress()) {
    console.warn(`[cbe] promote project ${project}: rebuild in progress`);
    replyPromoteBlocked(reply, 'REBUILD_BUSY');
    return;
  }

  const session = await resolveSession(request);
  const slug = typeof body.draft === 'string' ? body.draft : '';
  if (await refuseNotDraftOwner(request, getProjectsBaseDir(), slug, reply)) return;
  const comment = typeof body.comment === 'string' ? body.comment : '';
  const claim = buildPromoteInFlight(project, slug, new Date(promoteRouteHooks.now()).toISOString());
  if (!claimPromote(claim, reply)) return;

  let result;
  try {
    result = await promoteDraft({
      base: getProjectsBaseDir(),
      projectId: project,
      slug,
      author: authorFromSession(session.email),
      comment,
    });
  } catch (err) {
    releaseClaim(claim);
    throw err;
  }
  if (result.status !== 'merged') releaseClaim(claim);

  if (result.status === 'merged') {
    promoteRouteHooks.scheduleRebuildOnSave(project);
    const base = getProjectsBaseDir();
    let draftSync = 'failed';
    try {
      const synced = await draftSyncHooks.fastForwardDraft({
        base,
        projectId: project,
        slug,
      });
      draftSync = typeof synced.status === 'number' ? synced.code : synced.status;
      if (synced.status === 'fast_forwarded') scheduleDraftDevRestart(base, slug, project);
    } catch (err) {
      console.error(`[cbe] promote project ${project}: draft sync failed: ${(err as Error).message}`);
    }
    reply.code(CBE_HTTP_OK).send({
      statusCode: CBE_HTTP_OK,
      status: 'merged',
      ref: result.ref,
      // 'disabled': nothing was scheduled (the module logs why), so the client must not wait 10 minutes for a release.
      release: promoteRouteHooks.isRebuildOnSaveEnabled() ? 'scheduled' : 'disabled',
      draftSync,
    });
    return;
  }
  if (typeof result.status === 'number') {
    replyGitFailure(reply, result);
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: result.status });
}

/**
 * A `user-*` draft belongs to one person: another session gets 400 `draft.not_owner` and nothing runs.
 * `team-*` drafts stay open to everyone. Returns true when the call was refused (reply already sent).
 */
async function refuseNotDraftOwner(request: FastifyRequest, base: string, slug: string, reply: FastifyReply): Promise<boolean> {
  const parsed = parseDraftSlug(slug);
  if (!parsed || !parsed.slug.startsWith('user-')) return false;
  const email = (await sessionHooks.emailOf(request) ?? '').trim().toLowerCase();
  const owner = (await readDraftOwner(base, parsed.slug) ?? '').trim().toLowerCase();
  if (email !== '' && owner === email) return false;
  reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'NOT_OWNER', msg: 'draft.not_owner' });
  return true;
}

async function handleDiscardDraft(request: FastifyRequest, body: CbeRequestDiscardDraft, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, slug, reply)) return;
  const result = await discardDraft({ base, projectId: project, slug });
  if (typeof result.status === 'number') {
    replyGitFailure(reply, result);
    return;
  }
  try {
    draftDevHooks.stopDevProcess(base, slug);
  } catch (err) {
    console.error(`[cbe] discard draft ${slug}: stop dev process failed: ${(err as Error).message}`);
  }
  try {
    draftDevHooks.ensureDevProcess({ base, slug, clientProjectId: project });
  } catch (err) {
    console.error(`[cbe] discard draft ${slug}: ensure dev process failed: ${(err as Error).message}`);
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: 'discarded' });
}

async function draftActor(request: FastifyRequest, slug: string): Promise<string> {
  const by = (await sessionHooks.emailOf(request) ?? '').trim();
  if (!by) console.error(`[cbe] draft data ${slug}: session has no email`);
  return by;
}

/** True when the reply was already sent (403). */
async function refuseDraftData(request: FastifyRequest, action: DraftDataAction, reply: FastifyReply): Promise<boolean> {
  const decision = canDraftData(
    action,
    await draftDataHooks.authoritiesOf(request),
    { alphaAllAuthorities: draftDataHooks.alphaOn() },
    draftDataLang(headerString(request.headers['accept-language'])),
  );
  if (decision.allowed) return false;
  reply.code(CBE_HTTP_FORBIDDEN).send({ statusCode: decision.statusCode, code: decision.code, msg: decision.msg });
  return true;
}

function recordDraftData(base: string, slug: string, entry: DraftDataLogEntry): void {
  appendDraftDataLog(draftDirOf(base, slug), entry);
}

function draftSourceOption(
  action: DraftDataAction,
  authorities: readonly string[],
  alphaAllAuthorities: boolean,
  lang: ReturnType<typeof draftDataLang>,
  configured: () => boolean,
): { ok: boolean; reason?: string } {
  const decision = canDraftData(action, authorities, { alphaAllAuthorities }, lang);
  if (!decision.allowed) return { ok: false, reason: decision.msg };
  if (!configured()) return { ok: false, reason: draftSharedText('notConfigured', lang) };
  return { ok: true };
}

async function handleDraftDataSource(request: FastifyRequest, body: CbeRequestDraftDataSource, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, slug, reply)) return;
  if (await refuseDraftData(request, 'view', reply)) return;
  const parsed = parseDraftSlug(slug);
  if (!parsed) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'BAD_DRAFT', msg: 'draft.bad_slug' });
    return;
  }
  const lang = draftDataLang(headerString(request.headers['accept-language']));
  try {
    const state = readDraftData(draftDirOf(base, parsed.slug), lang);
    const authorities = await draftDataHooks.authoritiesOf(request);
    const alpha = draftDataHooks.alphaOn();
    reply.code(CBE_HTTP_OK).send({
      statusCode: CBE_HTTP_OK,
      source: state.source,
      at: state.at,
      by: state.by,
      ...(state.modules ? { modules: state.modules } : {}),
      ...(state.withRegistry !== undefined ? { withRegistry: state.withRegistry } : {}),
      options: {
        seed: draftSourceOption('reset', authorities, alpha, lang, () => true),
        copy: draftSourceOption('copy', authorities, alpha, lang, () => true),
        readonly: draftSourceOption('readonly', authorities, alpha, lang, () => sharedSourceConfigured('readonly')),
        same: draftSourceOption('sameDatabase', authorities, alpha, lang, () => sharedSourceConfigured('same')),
      },
    });
  } catch (err) {
    const cause = err instanceof Error ? err.message : String(err);
    console.error(`[cbe] draft data ${slug}: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA_UNREADABLE', msg: cause, cause });
  }
}

async function handleDraftResetDatabase(
  request: FastifyRequest,
  body: CbeRequestDraftResetDatabase,
  reply: FastifyReply,
): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, slug, reply)) return;
  if (await refuseDraftData(request, 'reset', reply)) return;
  // A login or draftEnter that is still preparing this draft would start the child right after the stop.
  await draftPrepareHooks.awaitDraftPrepare(slug);
  const by = await draftActor(request, slug);
  try {
    draftDevHooks.stopDevProcess(base, slug);
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] reset draft database ${slug}: stop dev process failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, cause });
    return;
  }
  const drop = await discardDraftDatabase(slug, project);
  if (drop.databaseDropped && !writeDraftSeed(base, slug, by)) {
    const lang = draftDataLang(headerString(request.headers['accept-language']));
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: draftSharedText('notStarted', lang) });
    return;
  }
  let started: DevProcessInfo | null = null;
  try {
    started = draftDevHooks.ensureDevProcess({ base, slug, clientProjectId: project });
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] reset draft database ${slug}: ensure dev process failed: ${cause}`);
    const reported = drop.databaseDropped ? cause : drop.cause;
    if (drop.databaseDropped) {
      try {
        recordDraftData(base, slug, {
          at: new Date().toISOString(),
          by,
          action: 'reset',
          result: 'failed',
          source: 'seed',
          cause: reported,
        });
      } catch (recordErr) {
        console.error(`[cbe] reset draft database ${slug}: record seed failed: ${(recordErr as Error).message}`);
      }
    }
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, cause: reported });
    return;
  }
  if (!drop.databaseDropped) {
    try {
      recordDraftData(base, slug, {
        at: new Date().toISOString(),
        by,
        action: 'reset',
        result: 'failed',
        cause: drop.cause,
      });
    } catch (recordErr) {
      console.error(`[cbe] reset draft database ${slug}: record failed reset: ${(recordErr as Error).message}`);
    }
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, cause: drop.cause });
    return;
  }
  const database = started?.database;
  if (!database) {
    const cause = 'database name missing';
    console.error(`[cbe] reset draft database ${slug}: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, cause });
    return;
  }
  try {
    recordDraftData(base, slug, { at: new Date().toISOString(), by, action: 'reset', result: 'ok', source: 'seed' });
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] reset draft database ${slug}: record seed failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, cause });
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: 'reset', database });
}

function writeDraftSeed(base: string, slug: string, by: string): boolean {
  try {
    const at = new Date().toISOString();
    writeDraftData(draftDirOf(base, slug), { source: 'seed', at, by });
    forgetDraftLoginCopy(draftDirOf(base, slug));
    return true;
  } catch (err) {
    console.error(`[cbe] draft data ${slug}: could not record seed: ${(err as Error).message}`);
    return false;
  }
}

/** Spawns the child. On failure the reply is already sent. */
function startDraftChild(
  base: string,
  slug: string,
  project: number,
  reply: FastifyReply,
): DevProcessInfo | null {
  try {
    return draftDevHooks.ensureDevProcess({ base, slug, clientProjectId: project });
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] draft data ${slug}: start failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: cause });
    return null;
  }
}

/** Starts the child and waits until it answers. On failure the reply is already sent. */
async function bootDraftChild(
  base: string,
  slug: string,
  project: number,
  lang: DraftSharedLang,
  reply: FastifyReply,
): Promise<{ database: string } | null> {
  const info = startDraftChild(base, slug, project, reply);
  if (!info) return null;
  if (!info.database) {
    const cause = 'database name missing';
    console.error(`[cbe] draft data ${slug}: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: cause });
    return null;
  }
  const ready = await draftDevHooks.waitForDevReady(info.port, { expect: { projectId: project, slug } });
  if (ready) return { database: info.database };
  const tail = readDevLogTail(base, slug);
  const modules = sharedDraftSchemaModules(tail);
  const msg = modules ? sharedDraftSchemaMessage(modules, lang) : draftSharedText('notStarted', lang);
  console.error(`[cbe] draft data ${slug}: child did not start\n${tail}`);
  reply.code(CBE_HTTP_SERVER_ERROR).send({
    statusCode: CBE_HTTP_SERVER_ERROR,
    code: modules ? 'DRAFT_SCHEMA_DIFF' : 'DRAFT_NOT_READY',
    msg,
    ...(modules ? { modules } : {}),
  });
  return null;
}

function sharedSourceConfigured(source: 'readonly' | 'same'): boolean {
  try {
    draftChildDatabaseUrls({
      source,
      draftUrl: process.env.DATABASE_URL_TEST ?? '',
      parentUrl: process.env.DATABASE_URL_TEST ?? '',
      readonlyUrl: process.env.DATABASE_URL_READONLY,
    });
    return true;
  } catch (err) {
    console.error(`[cbe] draft data ${source}: ${(err as Error).message}`);
    return false;
  }
}

async function handleDraftSharedSource(
  request: FastifyRequest,
  body: CbeRequestDraftReadonly | CbeRequestDraftSame,
  source: 'readonly' | 'same',
  reply: FastifyReply,
): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, slug, reply)) return;
  const action = source === 'readonly' ? 'readonly' : 'sameDatabase';
  if (await refuseDraftData(request, action, reply)) return;
  const parsed = parseDraftSlug(slug);
  const lang = draftDataLang(headerString(request.headers['accept-language']));
  if (!parsed) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'BAD_DRAFT', msg: 'draft.bad_slug' });
    return;
  }
  if (!sharedSourceConfigured(source)) {
    reply.code(CBE_HTTP_SERVER_ERROR).send({
      statusCode: CBE_HTTP_SERVER_ERROR,
      code: 'DRAFT_DATA_UNCONFIGURED',
      msg: draftSharedText('notConfigured', lang),
    });
    return;
  }
  await draftPrepareHooks.awaitDraftPrepare(parsed.slug);
  const by = await draftActor(request, parsed.slug);
  const at = new Date().toISOString();
  try {
    draftDevHooks.stopDevProcess(base, parsed.slug);
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] draft data ${parsed.slug}: stop failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: cause });
    return;
  }
  try {
    writeDraftData(draftDirOf(base, parsed.slug), { source, at, by });
    forgetDraftLoginCopy(draftDirOf(base, parsed.slug));
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] draft data ${parsed.slug}: record ${source} failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: cause });
    return;
  }
  const started = await bootDraftChild(base, parsed.slug, project, lang, reply);
  if (!started) {
    try {
      recordDraftData(base, parsed.slug, { at, by, action, result: 'failed', source, cause: 'child did not start' });
    } catch (recordErr) {
      console.error(`[cbe] draft data ${parsed.slug}: record failed ${source}: ${(recordErr as Error).message}`);
    }
    return;
  }
  try {
    recordDraftData(base, parsed.slug, { at, by, action, result: 'ok', source });
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] draft data ${parsed.slug}: record ${source} failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: cause });
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: source, source, at, by });
}

function draftCopyModules(body: CbeRequestDraftCopy): { modules?: string[]; withRegistry?: boolean } | 'invalid' {
  if (body.withRegistry !== undefined && typeof body.withRegistry !== 'boolean') return 'invalid';
  if (body.modules === undefined) return body.withRegistry === undefined ? {} : 'invalid';
  if (!Array.isArray(body.modules) || body.modules.length === 0) return 'invalid';
  const modules: string[] = [];
  for (const moduleId of body.modules) {
    if (typeof moduleId !== 'string' || !isDraftCopyModuleId(moduleId) || modules.includes(moduleId)) return 'invalid';
    modules.push(moduleId);
  }
  return { modules, withRegistry: body.withRegistry === true };
}

async function handleDraftCopy(request: FastifyRequest, body: CbeRequestDraftCopy, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, slug, reply)) return;
  if (await refuseDraftData(request, 'copy', reply)) return;
  const parsed = parseDraftSlug(slug);
  if (!parsed) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'BAD_DRAFT', msg: 'draft.bad_slug' });
    return;
  }
  const selection = draftCopyModules(body);
  const lang = draftDataLang(headerString(request.headers['accept-language']));
  if (selection === 'invalid') {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'BAD_MODULES', msg: draftCopyText('badModules', lang) });
    return;
  }
  let leavingShared = false;
  try {
    const current = readDraftData(draftDirOf(base, parsed.slug), lang);
    leavingShared = current.source === 'readonly' || current.source === 'same';
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] copy draft database ${parsed.slug}: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA_UNREADABLE', msg: cause });
    return;
  }
  const testUrl = process.env.DATABASE_URL_TEST;
  let sourceUrl = '';
  let target: { database: string; adminUrl: string } | null = null;
  let targetUrl = '';
  try {
    sourceUrl = resolveDatabaseUrl(readProjectMode(project));
    if (!testUrl) throw new Error('DATABASE_URL_TEST is not set');
    targetUrl = draftDatabaseUrl(testUrl, parsed.slug, project);
    target = parseDatabaseUrl(targetUrl);
    if (!target) throw new Error('invalid database url');
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] copy draft database ${parsed.slug}: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({
      statusCode: CBE_HTTP_SERVER_ERROR,
      code: 'DRAFT_COPY',
      msg: draftCopyText('notConfigured', lang),
    });
    return;
  }
  // A login or draftEnter that is still preparing this draft would start the child right after the stop.
  await draftPrepareHooks.awaitDraftPrepare(parsed.slug);
  const by = await draftActor(request, parsed.slug);
  try {
    draftDevHooks.stopDevProcess(base, parsed.slug);
  } catch (err) {
    const cause = (err as Error).message || String(err);
    console.error(`[cbe] copy draft database ${parsed.slug}: stop dev process failed: ${cause}`);
    reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_COPY', msg: draftCopyText('failed', lang), cause });
    return;
  }
  if (leavingShared) {
    if (!writeDraftSeed(base, parsed.slug, by)) {
      reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_DATA', msg: draftSharedText('notStarted', lang) });
      return;
    }
    const recreated = await bootDraftChild(base, parsed.slug, project, lang, reply);
    if (!recreated) return;
    try {
      draftDevHooks.stopDevProcess(base, parsed.slug);
    } catch (err) {
      const cause = (err as Error).message || String(err);
      console.error(`[cbe] copy draft database ${parsed.slug}: stop after recreate failed: ${cause}`);
      reply.code(CBE_HTTP_SERVER_ERROR).send({ statusCode: CBE_HTTP_SERVER_ERROR, code: 'DRAFT_COPY', msg: draftCopyText('failed', lang), cause });
      return;
    }
  }
  const result = await draftCopyHooks.perform({
    sourceUrl,
    targetUrl,
    projectId: project,
    ...(selection.modules ? { modules: selection.modules } : {}),
    ...(selection.withRegistry !== undefined ? { withRegistry: selection.withRegistry } : {}),
    draftDir: draftDirOf(base, parsed.slug),
    by,
    lang,
    adminUrl: target.adminUrl,
    database: target.database,
    dropDatabase: (adminUrl, database) => draftDbHooks.dropDatabase(adminUrl, database),
    start: () => {
      draftDevHooks.ensureDevProcess({ base, slug: parsed.slug, clientProjectId: project });
    },
  });
  if (!result.ok) {
    reply.code(CBE_HTTP_SERVER_ERROR).send({
      statusCode: CBE_HTTP_SERVER_ERROR,
      code: 'DRAFT_COPY',
      msg: result.msg,
      ...(result.table ? { table: result.table } : {}),
      ...(result.seeded ? { source: 'seed' } : {}),
    });
    return;
  }
  reply.code(CBE_HTTP_OK).send({
    statusCode: CBE_HTTP_OK,
    status: 'copied',
    source: 'copy',
    tables: result.tables,
    database: target.database,
  });
}

async function handleDraftRestorePaths(request: FastifyRequest, body: CbeRequestDraftRestorePaths, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const parsed = parseDraftSlug(slug);
  if (!parsed) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, code: 'BAD_DRAFT', msg: 'draft.bad_slug' });
    return;
  }
  const base = getProjectsBaseDir();
  if (await refuseNotDraftOwner(request, base, parsed.slug, reply)) return;
  await awaitDraftPrepare(parsed.slug);
  const session = await resolveSession(request);
  const result = await restoreDraftPaths({
    base,
    projectId: project,
    slug,
    ref: typeof body.ref === 'string' ? body.ref : '',
    paths: Array.isArray(body.paths) ? body.paths : [],
    author: authorFromSession(session.email ?? (await sessionHooks.emailOf(request)) ?? session.testUser),
  });
  if (typeof result.status === 'number') {
    reply.code(result.status).send({ statusCode: result.status, code: result.code, msg: result.msg });
    return;
  }
  if (result.status === 'restored' && result.restartDev) scheduleDraftDevRestart(base, slug, project);
  reply.code(CBE_HTTP_OK).send({
    statusCode: CBE_HTTP_OK,
    status: result.status,
    paths: result.status === 'restored' ? result.paths : undefined,
    head: result.head,
  });
}

async function handleDraftSync(request: FastifyRequest, body: CbeRequestDraftSync, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const slug = typeof body.draft === 'string' ? body.draft : '';
  const session = await resolveSession(request);
  const base = getProjectsBaseDir();
  const result = await draftSyncHooks.mergeMainIntoDraft({
    base,
    projectId: project,
    slug,
    author: authorFromSession(session.email),
  });
  if (typeof result.status === 'number') {
    replyGitFailure(reply, result);
    return;
  }
  if (result.status === 'fast_forwarded' || result.status === 'merged') {
    scheduleDraftDevRestart(base, slug, project);
    reply.code(CBE_HTTP_OK).send({
      statusCode: CBE_HTTP_OK,
      status: result.status,
      ref: result.ref,
    });
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: result.status });
}

async function handleDraftEnterAction(request: FastifyRequest, body: object, reply: FastifyReply): Promise<void> {
  const fields = body as { project?: unknown; draft?: unknown };
  if (fields.draft !== 'user') {
    await handleDraftEnter(request, body, reply);
    return;
  }
  const email = await sessionHooks.emailOf(request);
  if (!email) {
    reply.code(CBE_HTTP_UNAUTHORIZED).send({ statusCode: CBE_HTTP_UNAUTHORIZED, msg: 'draft.session_required' });
    return;
  }
  const person = draftSlugForUser(email);
  const result = await runDraftEnter({
    allowed: await desenvIo.isAllowed(request),
    draft: person.slug,
    project: fields.project,
  });
  if (result.status === CBE_HTTP_OK) {
    await writeDraftOwner(desenvIo.getProjectsBaseDir(), person.slug, email);
  }
  reply.code(result.status);
  reply.send(result.body);
}

async function handleListDrafts(request: FastifyRequest, body: CbeRequestListDrafts, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const result = await listDrafts({ base: getProjectsBaseDir(), projectId: project });
  if (typeof result.status === 'number') {
    replyGitFailure(reply, result);
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: 'listed', drafts: result.drafts });
}

async function handleDraftDiff(request: FastifyRequest, body: CbeRequestDraftDiff, reply: FastifyReply): Promise<void> {
  const project = await requireSourceProject(request, body, reply);
  if (!project) return;
  const askNames = (body as CbeRequestDraftDiff & { names?: boolean }).names === true;
  const result = await draftDiff({
    base: getProjectsBaseDir(),
    projectId: project,
    slug: typeof body.draft === 'string' ? body.draft : '',
    shortPath: typeof body.shortPath === 'string' ? body.shortPath : undefined,
    names: askNames,
  });
  if (typeof result.status === 'number') {
    replyGitFailure(reply, result);
    return;
  }
  if (result.status === 'files') {
    reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: 'files', head: result.head, main: result.main, files: result.files });
    return;
  }
  reply.code(CBE_HTTP_OK).send({ statusCode: CBE_HTTP_OK, status: 'diff', text: result.text });
}

async function handleExec(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  const body = request.body as CbeRequestBase | undefined;
  if (!body || typeof body !== 'object' || Array.isArray(body) || !body.action) {
    reply.code(CBE_HTTP_BAD_REQUEST).send({ statusCode: CBE_HTTP_BAD_REQUEST, msg: 'invalid body, no action' });
    return;
  }

  reply.header('x-cbe-version', CBE_MODULE_VERSION);
  try {
    switch (body.action) {
      case 'ping':
        // Enough for a browser to tell whether the save it just made is live:
        // `release` is the identity of THIS worker (stable while it runs), `pid`
        // says which of the two cluster workers answered, and `rebuilding` is read
        // from disk on the spot. A release id that changed means a new release is
        // being served; unchanged after rebuilding goes false means the build failed.
        // `promoting` is the publish in flight (the file, so both workers agree), or null.
        // `lastPromote` is set when that claim expired and the rebuild never started.
        reply.code(CBE_HTTP_OK).send({
          statusCode: CBE_HTTP_OK,
          msg: 'pong',
          version: CBE_MODULE_VERSION,
          pid: process.pid,
          release: getRunningRelease(),
          rebuilding: isRebuildInProgress(),
          promoting: readLivePromote(),
          lastPromote: readLastPromote(),
        });
        return;
      case 'authSession':
        await handleAuthSession(body as CbeRequestAuthSession, reply);
        return;
      case 'authLogout':
        await handleAuthLogout(request, reply);
        return;
      case 'getContents':
        await handleGetContents(request, body as CbeRequestGetContents, reply);
        return;
      case 'setContents':
        await handleSetContents(request, body as CbeRequestSetContents, reply);
        return;
      case 'setContentsPart':
        await handleSetContentsPart(request, body as CbeRequestSetContentsPart, reply);
        return;
      case 'loadFilesInfo':
        await handleLoadFilesInfo(request, body as CbeRequestLoadFilesInfo, reply);
        return;
      case 'getHistory':
        await handleGetHistory(request, body as CbeRequestGetHistory, reply);
        return;
      case 'getHistoryContent':
        await handleGetHistoryContent(request, body as CbeRequestGetHistoryContent, reply);
        return;
      case 'promote':
        await handlePromote(request, body as CbeRequestPromote, reply);
        return;
      case 'discardDraft':
        await handleDiscardDraft(request, body as CbeRequestDiscardDraft, reply);
        return;
      case 'draftDataSource':
        await handleDraftDataSource(request, body as CbeRequestDraftDataSource, reply);
        return;
      case 'draftResetDatabase':
        await handleDraftResetDatabase(request, body as CbeRequestDraftResetDatabase, reply);
        return;
      case 'draftCopy':
        await handleDraftCopy(request, body as CbeRequestDraftCopy, reply);
        return;
      case 'draftReadonly':
        await handleDraftSharedSource(request, body as CbeRequestDraftReadonly, 'readonly', reply);
        return;
      case 'draftSame':
        await handleDraftSharedSource(request, body as CbeRequestDraftSame, 'same', reply);
        return;
      case 'draftRestorePaths':
        await handleDraftRestorePaths(request, body as CbeRequestDraftRestorePaths, reply);
        return;
      case 'listDrafts':
        await handleListDrafts(request, body as CbeRequestListDrafts, reply);
        return;
      case 'draftDiff':
        await handleDraftDiff(request, body as CbeRequestDraftDiff, reply);
        return;
      case 'draftSync':
        await handleDraftSync(request, body as CbeRequestDraftSync, reply);
        return;
      case 'draftEnter':
        await handleDraftEnterAction(request, body, reply);
        return;
      case 'providerToken': {
        const session = await resolveSession(request);
        await handleProviderToken(request, body, reply, session);
        return;
      }
      case 'login': {
        const start = Date.now();
        const session = await resolveSession(request);
        const mustLogin = requiresLogin(request);
        // A verified JWT stays on the existing path. Otherwise a valid local-test
        // cookie names the person; a rejected cookie is anonymous and must not
        // fall through to CBE_TEST_LOGIN_USER (that user writes a fake cauth).
        const localTest = session.email ? undefined : localTestSessionFromHeaders(requestHeaderRecord(request.headers));
        const localOk = localTest?.kind === 'ok' ? localTest : undefined;
        const testUser = localTest?.kind === 'reject' ? undefined : session.testUser;
        // The .env test user is a localhost convenience — on a real domain
        // ONLY a valid collab-auth JWT authenticates.
        const authenticated = Boolean(session.email || (!mustLogin && testUser));
        if (mustLogin && !authenticated) {
          // Real domain without a JWT session: answer the login shape the cfe
          // expects, but with NO orgs/sources — the studio stays locked until
          // authSession establishes the collab-auth JWT. The app itself keeps
          // working (BFF routes are not part of /exec).
          console.info('[cbe] /exec action:login -> anonymous denied (login required on this host)');
          reply.header('set-cookie', [sessionCookie('loginUser', 'anonymous')]);
          reply.code(CBE_HTTP_OK).header('Content-Type', 'text/json; charset=utf-8').send({
            statusCode: CBE_HTTP_OK,
            msg: 'login required',
            services: [], orgs: {}, inits: {}, providers: [],
            avatar_url: '', baseProject: (body as CbeRequestLogin).baseProject ?? 0,
            alertMessage: '', errorMessage: 'Login required on this domain.',
          });
          return;
        }
        if (localOk) {
          const email = localOk.claims.email;
          warmPersonDraftOnLogin(request.headers, email);
          const rc = executeCbeLogin(body as CbeRequestLogin, email, session.picture);
          console.info(`[cbe] /exec action:login (${email}) -> ${rc.statusCode} in ${Date.now() - start}ms`);
          reply.header('set-cookie', [
            sessionCookie('loginUser', email),
            sessionCookie('cauth', '', { httpOnly: true, expire: true }),
            sessionCookie('loginMsg', '', { httpOnly: true, expire: true }),
          ]);
          reply
            .code(rc.statusCode)
            .header('Content-Type', 'text/json; charset=utf-8')
            .header('Cache-Control', 'no-cache')
            .send(rc);
          return;
        }
        const loginSession = session.email ? session : { ...session, testUser };
        warmPersonDraftOnLogin(request.headers, session.email ?? testUser);
        const rc = executeCbeLogin(body as CbeRequestLogin, session.email ?? testUser, session.picture);
        console.info(`[cbe] /exec action:login (${session.email ?? testUser ?? 'anonymous'}) -> ${rc.statusCode} in ${Date.now() - start}ms`);
        reply.header('set-cookie', buildLoginCookies(loginSession));
        reply
          .code(rc.statusCode)
          .header('Content-Type', 'text/json; charset=utf-8')
          .header('Cache-Control', 'no-cache')
          .send(rc);
        return;
      }
      default:
        console.info(`[cbe] /exec unsupported action: ${body.action}`);
        reply.code(CBE_HTTP_BAD_REQUEST).send({
          statusCode: CBE_HTTP_BAD_REQUEST,
          msg: `action "${body.action}" is not handled by the runtime cbe module (only login/authSession/authLogout and the source I/O actions run on the VM)`,
        });
        return;
    }
  } catch (err) {
    console.error('[cbe] /exec error:', err);
    reply.code(CBE_HTTP_SERVER_ERROR).send({
      statusCode: CBE_HTTP_SERVER_ERROR,
      msg: `Abend: ${(err as Error).message || String(err)}`,
    });
  }
}

async function handleStatic(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  const clientETag = (request.headers['if-none-match'] as string | undefined) ?? '';
  const rc = await getCbeStaticFile(request.raw.url ?? '', clientETag);

  if (rc.statusCode === CBE_HTTP_NOT_MODIFIED) {
    reply
      .code(CBE_HTTP_NOT_MODIFIED)
      .header('Cache-Control', staticCacheControl(request.raw.url ?? ''))
      .header('ETag', `"${rc.eTag}"`)
      .send();
    return;
  }
  if (rc.statusCode !== CBE_HTTP_OK || !rc.content) {
    reply.code(rc.statusCode).send({ statusCode: rc.statusCode, msg: rc.msg ?? 'error' });
    return;
  }

  reply
    .code(CBE_HTTP_OK)
    .header('Content-Type', rc.contentType ?? 'application/octet-stream')
    .header('Cache-Control', staticCacheControl(request.raw.url ?? ''))
    .header('ETag', `"${rc.eTag}"`)
    .send(rc.content);
}

export function registerCbeRoutes(app: FastifyInstance): void {
  desenvIo.isAllowed = isSourceRequestAllowed;
  app.post('/exec', EXEC_ROUTE_OPTIONS, handleExec);
  app.get('/exec/logout', handleExecLogout);
  app.post('/exec/candidate', { bodyLimit: CANDIDATE_BODY_LIMIT }, handleCandidateProxy);
  app.get('/desenv/sair', handleDesenvExit);
  app.get('/desenv', handleDesenvEnter);
  app.get('/cbe/source', handleSourceView);
  app.get('/libs/*', handleStatic);
  app.get('/monaco/*', handleStatic);
  app.get('/mlsServiceWorker.js', handleStatic);
  console.info(`[cbe] v${CBE_MODULE_VERSION} routes registered: POST /exec (login/authSession/authLogout/getContents/setContents/loadFilesInfo/getHistory/getHistoryContent/promote/discardDraft/draftDataSource/draftResetDatabase/draftCopy/draftReadonly/draftSame/draftRestorePaths/listDrafts/draftDiff/draftSync), GET /exec/logout, POST /exec/candidate, GET /desenv, GET /desenv/sair, GET /cbe/source, GET /libs/*, GET /monaco/*, GET /mlsServiceWorker.js`);
  if (candidateHubMode() === 'local') {
    if (!candidateSchemaStarted) {
      candidateSchemaStarted = true;
      void ensureCandidateSchema(getSharedPgPool(readAppEnv())).catch((err) => {
        console.error('[cbe:candidate] schema ensure failed:', (err as Error).message);
      });
    }
    console.info('[cbe] candidate: local hub');
  } else {
    try {
      console.info(`[cbe] candidate: forward to ${candidateOrigin()}`);
    } catch (err) {
      console.info(`[cbe] candidate: ${(err as Error).message}`);
    }
  }
  logCbeStaticConfig();
  console.info(`[cbe] projects base: ${getProjectsBaseDir()} | jwtAuth: ${isJwtAuthEnabled() ? 'enabled' : 'DISABLED'}${process.env.CBE_TEST_LOGIN_USER ? ` | TEST user: ${process.env.CBE_TEST_LOGIN_USER}` : ''}`);
}

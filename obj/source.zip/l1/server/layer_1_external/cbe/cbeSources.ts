/// <mls fileReference="_102034_/l1/server/layer_1_external/cbe/cbeSources.ts" enhancement="_blank" />
// Source file I/O for the VM storage driver (mls-102033 l2/cbe/driverVm.ts).
// The login payload only carries COMPILED js, so every read of a .ts source —
// opening a file in the studio editor, an agent reading or writing code — lands
// here through the cbe /exec actions getContents/setContents/loadFilesInfo.
//
// Reads and writes hit the project TREE (<base>/mls-<id>/l<level>/...), not
// obj/source.zip: the tree is what the publish syncs, what a write must change,
// and what buildProjectsObj compiles — so read-after-write stays consistent.

import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, resolve, sep } from 'node:path';
import { getProjectFilesInfo, resolveProjectSourcePath } from '/_102034_/l1/server/layer_1_external/cbe/cbeCompiledLocal.js';
import { decodeSourceInputs, type DecodedSourceFile } from '/_102034_/l1/server/layer_1_external/cbe/cbeUploads.js';
import type { CbePrjSourcesFile, CbeSourceFile, CbeSourceFileContent } from '/_102034_/l1/server/layer_1_external/cbe/cbeTypes.js';

/** Levels the platform defines (l1..l7); l0 has no level folder. */
const MAX_LEVEL = 7;
const SHORT_PATH_PATTERN = new RegExp(`^(l[1-${MAX_LEVEL}]/)?[^/].*$`, 'u');

/**
 * Absolute path of a source file, or null when the shortPath is not acceptable.
 *
 * The shortPath comes from the BROWSER and becomes a write target on the VM's
 * disk, so this is a security boundary, not a formality: the resolved path must
 * stay inside <base>/mls-<id>/. Rejects traversal ('..'), absolute paths,
 * backslashes and NUL bytes.
 *
 * SHORT_PATH_PATTERN is shape, not a level filter: it only requires that what
 * follows an `l<n>/` prefix is non-empty. 'l0/x.ts' and 'l8/x.ts' are accepted
 * and read as an ordinary folder named l0 / l8 inside the project — contained,
 * which is what matters here. What proves containment is the resolved-path
 * check below, not the pattern. The same rules apply when `sourceRoot`
 * replaces `<base>/mls-<id>` (a draft worktree; it must be absolute).
 */
export function resolveSourcePath(projectId: number, shortPath: string, sourceRoot?: string): string | null {
  if (!Number.isInteger(projectId) || projectId <= 0) return null;
  if (sourceRoot !== undefined && !isAbsolute(sourceRoot)) {
    console.warn(`[cbe] sourceRoot is not absolute: "${sourceRoot}" (project ${projectId})`);
    return null;
  }
  if (typeof shortPath !== 'string' || shortPath.length === 0) return null;
  if (shortPath.includes('\0') || shortPath.includes('\\')) return null;
  if (shortPath.startsWith('/') || /^[A-Za-z]:/u.test(shortPath)) return null;
  if (shortPath.split('/').some((segment) => segment === '..' || segment === '.')) return null;
  if (!SHORT_PATH_PATTERN.test(shortPath)) return null;

  const projectRoot = resolve(resolveProjectSourcePath(projectId, '.', sourceRoot));
  const target = resolve(projectRoot, shortPath);
  // Containment check on the resolved paths — the only one that actually proves it.
  if (target !== projectRoot && !target.startsWith(projectRoot + sep)) return null;
  return target;
}

const TEXT_SOURCE_PATTERN = /\.(ts|tsx|js|json|less|css|html|md|txt|svg|sql|yml|yaml)$/u;

/** The one text/binary rule of the source actions: text by extension (utf8), anything else base64. */
export function sourceFileFromBytes(shortPath: string, bytes: Buffer): CbeSourceFile {
  return TEXT_SOURCE_PATTERN.test(shortPath)
    ? { shortPath, content: bytes.toString('utf8'), encoding: 'utf8' }
    : { shortPath, content: bytes.toString('base64'), encoding: 'base64' };
}

/** Reads the requested sources; a file that is not there comes back as null content. */
export function readSources(projectId: number, shortPaths: string[], sourceRoot?: string): CbeSourceFile[] {
  const rc: CbeSourceFile[] = [];
  for (const shortPath of shortPaths) {
    const path = resolveSourcePath(projectId, shortPath, sourceRoot);
    if (!path) {
      console.warn(`[cbe] getContents: rejected shortPath "${shortPath}" (project ${projectId})`);
      continue;
    }
    if (!existsSync(path) || !statSync(path).isFile()) continue;
    rc.push(sourceFileFromBytes(shortPath, readFileSync(path)));
  }
  return rc;
}

/**
 * Writes the given sources and removes the deleted ones. All-or-nothing is NOT
 * attempted (no transaction on a plain FS): a rejected path aborts the whole
 * call BEFORE any write, so a bad request never leaves a half-applied state.
 *
 * `paths` reports every shortPath actually touched (written and removed), which
 * is what cbeGitCommit commits — the caller never has to re-derive it.
 */
export function writeSources(
  projectId: number,
  files: CbeSourceFileContent[],
  deletes: string[],
  options: { sourceRoot?: string } = {},
): { ok: boolean; msg?: string; paths: string[] } {
  const decoded = decodeSourceInputs(files, { base: '', project: projectId, scope: '' });
  if (!decoded.ok) return { ok: false, msg: decoded.msg, paths: [] };
  return writeDecodedSources(projectId, decoded.files, deletes, options);
}

/**
 * The write half of `writeSources`, for files already decoded and checked (uploads assembled by the route): validates
 * every path first, then writes, so a rejected path leaves nothing written.
 */
export function writeDecodedSources(
  projectId: number,
  files: DecodedSourceFile[],
  deletes: string[],
  options: { sourceRoot?: string } = {},
): { ok: boolean; msg?: string; paths: string[] } {
  const { sourceRoot } = options;
  const writes: { path: string; content: Buffer }[] = [];
  for (const file of files) {
    const path = resolveSourcePath(projectId, file.shortPath, sourceRoot);
    if (!path) return { ok: false, msg: `rejected shortPath: ${file.shortPath}`, paths: [] };
    writes.push({ path, content: file.bytes });
  }

  const removals: string[] = [];
  for (const shortPath of deletes) {
    const path = resolveSourcePath(projectId, shortPath, sourceRoot);
    if (!path) return { ok: false, msg: `rejected shortPath: ${shortPath}`, paths: [] };
    removals.push(path);
  }

  for (const write of writes) {
    mkdirSync(dirname(write.path), { recursive: true });
    writeFileSync(write.path, write.content);
  }
  for (const path of removals) {
    if (existsSync(path)) rmSync(path, { force: true });
  }
  console.info(`[cbe] setContents project ${projectId}: ${writes.length} written, ${removals.length} removed`);
  return { ok: true, paths: [...files.map((file) => file.shortPath), ...deletes] };
}

/** l1–l7 of a draft worktree. l0 stays on the production index (it is not project source). */
const DRAFT_LEVEL_PATH = /^l[1-7]\//u;

/**
 * The project's file index. Without sourceRoot, the compiled.zip list the login ships.
 * With sourceRoot, l1–l7 come from that draft worktree (`git ls-files`) and l0 from the production index, without jsContent.
 * Git failure logs and returns the production index.
 */
export function listSources(projectId: number, sourceRoot?: string): CbePrjSourcesFile[] {
  if (sourceRoot === undefined) return getProjectFilesInfo(projectId);
  try {
    const raw = execFileSync('git', ['ls-files', '-s', '-z'], { cwd: sourceRoot, encoding: 'utf8' });
    const files: CbePrjSourcesFile[] = [];
    for (const entry of raw.split('\0')) {
      if (!entry) continue;
      const tab = entry.indexOf('\t');
      if (tab < 0) continue;
      const shortPath = entry.slice(tab + 1);
      if (!DRAFT_LEVEL_PATH.test(shortPath)) continue;
      const versionRef = entry.slice(0, tab).split(' ')[1];
      if (!versionRef) continue;
      const info = statSync(resolve(sourceRoot, shortPath));
      files.push({
        shortPath,
        versionRef,
        Length: info.size,
        update_at: info.mtime.toISOString(),
      });
    }
    for (const file of getProjectFilesInfo(projectId)) {
      if (!file.shortPath.startsWith('l0/')) continue;
      files.push({ shortPath: file.shortPath, versionRef: file.versionRef, Length: file.Length, update_at: file.update_at });
    }
    return files;
  } catch (err) {
    console.error(`[cbe] loadFilesInfo draft ${sourceRoot}: ${(err as Error).message}`);
    return getProjectFilesInfo(projectId);
  }
}

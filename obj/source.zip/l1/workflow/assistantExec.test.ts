/// <mls fileReference="_102034_/l1/workflow/assistantExec.test.ts" enhancement="_blank"/>
import assert from 'node:assert/strict';
import test from 'node:test';
import { AppError, type BffRequest, type BffResponse, type RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { createMemoryDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.js';
import { createRequestContext } from '/_102034_/l1/server/layer_2_controllers/execBff.js';
import { getMdmKv, putMdmKv, reserveMdmKv } from '/_102034_/l1/mdm/layer_3_usecases/kvUsecases.js';
import { createAssistantCatalogSource, ASSISTANT_CATALOG_SCHEMA, type AssistantCatalogItem } from '/_102034_/l1/workflow/assistantCatalog.js';
import { execAssistantAction, mapBffResult, type AssistantAgentAccess, type AssistantExecDeps, type AssistantExecInput } from '/_102034_/l1/workflow/assistantExec.js';
import type { AssistantOnBehalfOf } from '/_102034_/l1/workflow/assistantActivities.js';
import { createGeneratedRoute } from '/_102034_/testing/connections/generatedRoute.js';

function item(actionId: string, kind: 'cmd' | 'qry', actors: string[], assistant: 'included' | 'excluded' = 'included'): AssistantCatalogItem {
  return { route: `modA.page.${actionId}`, routes: [`modA.page.${actionId}`], kind, actionId, title: actionId, actors, assistant };
}

const CATALOG = {
  schemaVersion: ASSISTANT_CATALOG_SCHEMA, module: 'modA', lookups: [], entities: [], issues: [],
  commands: [
    { ...item('modA.accept', 'cmd', ['boss']), risk: 'sensitive', inputs: [{ path: 'id', role: 'ref' }, { path: 'version', role: 'version' }] },
    { ...item('modA.note', 'cmd', ['boss']), risk: 'write', inputs: [{ path: 'id', role: 'ref' }, { path: 'details.rev', role: 'version' }] },
    { ...item('modA.create', 'cmd', ['boss']), risk: 'write', inputs: [{ path: 'details.title', role: 'value' }] },
  ],
  queries: [item('modA.list', 'qry', ['boss', 'worker']), item('modA.hidden', 'qry', ['boss'], 'excluded')],
};

interface Calls { requests: BffRequest[] }

function setup(answer: (request: BffRequest) => { response: BffResponse; statusCode: number } | Promise<{ response: BffResponse; statusCode: number }> = () => ({ response: { ok: true, data: { rows: 2 }, error: null }, statusCode: 200 }), extra: Partial<AssistantExecDeps> = {}): { ctx: RequestContext; deps: AssistantExecDeps; calls: Calls } {
  const ctx = createRequestContext(createMemoryDataRuntime());
  const calls: Calls = { requests: [] };
  const deps: AssistantExecDeps = {
    projectId: '102047',
    modules: [{ moduleId: 'modA' }, { moduleId: 'modB' }],
    identities: { toMdmId: async (_c, cmUserId) => { if (cmUserId === 'cm-1') return 'person-1'; if (cmUserId === 'cm-2') return 'person-2'; throw new AppError('WORKFLOW_IDENTITY_UNLINKED', 'u', 409); } },
    withAlpha: async (meta) => meta,
    catalogs: createAssistantCatalogSource({ projectId: '102047', releaseId: () => 'r1', importCatalog: async (moduleId) => (moduleId === 'modA' ? CATALOG : undefined) }),
    agentMemberOf: async (_c, agentId) => ({ mdmId: `member-of-${agentId}`, name: `Agent ${agentId}`, active: true }),
    loginEmailOf: async (_c, id) => (id === 'person-1' ? 'ana@example.test' : id === 'person-2' ? 'bia@example.test' : null),
    execMessage: async (request) => { calls.requests.push(request); return answer(request); },
    kv: { reserve: reserveMdmKv, put: putMdmKv },
    ...extra,
  };
  return { ctx, deps, calls };
}

type PersonExec = Omit<AssistantExecInput, 'onBehalfOf'> & { onBehalfOf: AssistantOnBehalfOf };
const input = (over: Partial<PersonExec> = {}, authorities = ['modA:worker']): PersonExec => ({
  onBehalfOf: { cmUserId: 'cm-1', authorities, snapshotAt: '2026-11-13T10:00:00.000Z', via: 'nora' },
  actionId: 'modA.list', input: { page: 1 }, commandId: 'cmd-1', ...over,
});

test('a query runs as the person, with the login e-mail and the module authorities, and answers done', async () => {
  const { ctx, deps, calls } = setup();
  const result = await execAssistantAction(ctx, deps, input({}, ['modA:worker', 'modB:other']));
  assert.deepEqual(result, { outcome: 'done', data: { rows: 2 } });
  assert.equal(calls.requests.length, 1);
  assert.deepEqual(calls.requests[0], {
    routine: 'modA.page.modA.list',
    params: { page: 1 },
    meta: { requestId: 'cmd-1', verifiedEmail: 'ana@example.test', userId: 'ana@example.test', actorScope: ['modA:worker'], verifiedAuthorities: ['modA:worker'], via: 'nora' },
  });
  const kept = (await getMdmKv(ctx, { key: 'assistant:cmd-1' }))?.value as Record<string, unknown>;
  assert.equal(kept.state, 'done');
  assert.equal(kept.outcome, 'done');
});

test('repeating the commandId returns the kept result and the operation runs once', async () => {
  const { ctx, deps, calls } = setup();
  const first = await execAssistantAction(ctx, deps, input());
  const again = await execAssistantAction(ctx, deps, input());
  assert.deepEqual(again, first);
  assert.equal(calls.requests.length, 1);
});

test('two requests at once with one commandId run the operation once', async () => {
  let release: () => void = () => {};
  const gate = new Promise<void>((resolve) => { release = resolve; });
  const { ctx, deps, calls } = setup(async () => { await gate; return { response: { ok: true, data: { n: 1 }, error: null }, statusCode: 200 }; });
  const a = execAssistantAction(ctx, deps, input());
  const b = execAssistantAction(ctx, deps, input());
  await new Promise((resolve) => setImmediate(resolve));
  release();
  const [first, second] = await Promise.all([a, b]);
  assert.equal(calls.requests.length, 1);
  assert.equal([first, second].filter((result) => result.outcome === 'done').length, 1);
  const other = [first, second].find((result) => result.outcome !== 'done')!;
  assert.equal(other.outcome, 'unavailable');
  assert.equal(other.error?.code, 'ASSISTANT_COMMAND_UNRESOLVED');
});

test('a command runs once as the person, and a sensitive one is treated exactly like a write', async () => {
  const { ctx, deps, calls } = setup(() => ({ response: { ok: true, data: { id: 'x', version: 4 }, error: null }, statusCode: 200 }));
  const sensitive = await execAssistantAction(ctx, deps, input({ actionId: 'modA.accept', input: { id: 'x', version: 3 }, commandId: 'c-sensitive' }, ['modA:boss']));
  const write = await execAssistantAction(ctx, deps, input({ actionId: 'modA.create', input: { details: { title: 't' } }, commandId: 'c-write' }, ['modA:boss']));
  assert.deepEqual(sensitive, { outcome: 'done', data: { id: 'x', version: 4 } });
  assert.deepEqual(write, sensitive);
  assert.equal(calls.requests.length, 2);
  assert.deepEqual(calls.requests[0].meta, { requestId: 'c-sensitive', verifiedEmail: 'ana@example.test', userId: 'ana@example.test', actorScope: ['modA:boss'], verifiedAuthorities: ['modA:boss'], via: 'nora' });
  assert.deepEqual(calls.requests[0].params, { id: 'x', version: 3 });
  const again = await execAssistantAction(ctx, deps, input({ actionId: 'modA.accept', input: { id: 'x', version: 3 }, commandId: 'c-sensitive' }, ['modA:boss']));
  assert.deepEqual(again, sensitive);
  assert.equal(calls.requests.length, 2);
});

test('expectVersion goes into the field the catalog marks as the version; the caller input is not changed', async () => {
  const { ctx, deps, calls } = setup();
  const original = { id: 'x' };
  await execAssistantAction(ctx, deps, input({ actionId: 'modA.accept', input: original, expectVersion: 7, commandId: 'v1' }, ['modA:boss']));
  assert.deepEqual(calls.requests[0].params, { id: 'x', version: 7 });
  assert.deepEqual(original, { id: 'x' });
  await execAssistantAction(ctx, deps, input({ actionId: 'modA.note', input: { id: 'x', details: { keep: 1 } }, expectVersion: 2, commandId: 'v2' }, ['modA:boss']));
  assert.deepEqual(calls.requests[1].params, { id: 'x', details: { keep: 1, rev: 2 } });
  await execAssistantAction(ctx, deps, input({ actionId: 'modA.note', input: { id: 'x' }, expectVersion: 3, commandId: 'v3' }, ['modA:boss']));
  assert.deepEqual(calls.requests[2].params, { id: 'x', details: { rev: 3 } });
});

test('expectVersion for an action with no version field, or with an input that is not an object, is invalid_input and nothing is kept', async () => {
  const { ctx, deps, calls } = setup();
  const noField = await execAssistantAction(ctx, deps, input({ actionId: 'modA.create', input: { details: {} }, expectVersion: 1, commandId: 'n1' }, ['modA:boss']));
  assert.equal(noField.outcome, 'invalid_input');
  assert.equal(noField.error?.code, 'ASSISTANT_NO_VERSION_FIELD');
  const notObject = await execAssistantAction(ctx, deps, input({ actionId: 'modA.accept', input: 'text', expectVersion: 1, commandId: 'n2' }, ['modA:boss']));
  assert.equal(notObject.error?.code, 'ASSISTANT_INPUT_NOT_OBJECT');
  const clash = await execAssistantAction(ctx, deps, input({ actionId: 'modA.note', input: { details: 'text' }, expectVersion: 1, commandId: 'n3' }, ['modA:boss']));
  assert.equal(clash.error?.code, 'ASSISTANT_INPUT_NOT_OBJECT');
  assert.equal(calls.requests.length, 0);
  assert.equal(await getMdmKv(ctx, { key: 'assistant:n1' }), null);
});

test('a stale expectVersion answers stale_version, and a 422 of the module rule answers refused_rule with its code', async () => {
  const stale = setup(() => ({ response: { ok: false, data: null, error: { code: 'VERSION_CONFLICT', message: 'changed' } }, statusCode: 409 }));
  const old = await execAssistantAction(stale.ctx, stale.deps, input({ actionId: 'modA.accept', input: { id: 'x' }, expectVersion: 1 }, ['modA:boss']));
  assert.deepEqual(old, { outcome: 'stale_version', error: { code: 'VERSION_CONFLICT', message: 'changed' } });
  const rule = setup(() => ({ response: { ok: false, data: null, error: { code: 'COMPRADOR_FORA_DA_LISTA', message: 'escolha da lista' } }, statusCode: 422 }));
  const refused = await execAssistantAction(rule.ctx, rule.deps, input({ actionId: 'modA.create', input: { details: {} } }, ['modA:boss']));
  assert.deepEqual(refused, { outcome: 'refused_rule', error: { code: 'COMPRADOR_FORA_DA_LISTA', message: 'escolha da lista' } });
  assert.equal(rule.calls.requests.length, 1);
});

test('a command without authority and alpha off is forbidden and does not run', async () => {
  const { ctx, deps, calls } = setup();
  const result = await execAssistantAction(ctx, deps, input({ actionId: 'modA.accept', input: { id: 'x' } }, ['modA:worker']));
  assert.equal(result.outcome, 'forbidden');
  assert.deepEqual(result.error?.required, ['boss']);
  assert.equal(calls.requests.length, 0);
});

test('without authority in the module and alpha off it is forbidden with the required actors; alpha on lets it through', async () => {
  const { ctx, deps, calls } = setup();
  const denied = await execAssistantAction(ctx, deps, input({}, ['modB:worker']));
  assert.equal(denied.outcome, 'forbidden');
  assert.deepEqual(denied.error?.required, ['boss', 'worker']);
  assert.equal(calls.requests.length, 0);
  assert.equal(await getMdmKv(ctx, { key: 'assistant:cmd-1' }), null);
  const alpha = setup(undefined, { withAlpha: async (meta, moduleId) => ({ ...meta, verifiedAuthorities: [...(meta?.verifiedAuthorities ?? []), `${moduleId}:worker`] }) });
  assert.equal((await execAssistantAction(alpha.ctx, alpha.deps, input({}, []))).outcome, 'done');
});

test('a person without a link is no_person; an unknown, excluded or catalog-less action is invalid_input or unavailable', async () => {
  const { ctx, deps } = setup();
  assert.deepEqual(await execAssistantAction(ctx, deps, { ...input(), onBehalfOf: { ...input().onBehalfOf, cmUserId: 'cm-unknown' } }), { outcome: 'no_person' });
  assert.equal((await execAssistantAction(ctx, deps, input({ actionId: 'modA.nothing' }))).error?.code, 'ASSISTANT_CATALOG_UNAVAILABLE');
  const only = setup(undefined, { modules: [{ moduleId: 'modA' }] });
  assert.equal((await execAssistantAction(only.ctx, only.deps, input({ actionId: 'modA.nothing' }))).error?.code, 'ASSISTANT_ACTION_UNKNOWN');
  assert.equal((await execAssistantAction(only.ctx, only.deps, input({ actionId: 'modA.hidden' }, ['modA:boss']))).error?.code, 'ASSISTANT_ACTION_EXCLUDED');
  const noLogin = setup(undefined, { modules: [{ moduleId: 'modA' }], loginEmailOf: async () => null });
  assert.deepEqual(await execAssistantAction(noLogin.ctx, noLogin.deps, input()), { outcome: 'no_person' });
});

test('the module answers map to the contract: forbidden, not_found, invalid_input, stale_version, refused_rule, unavailable', () => {
  const fail = (code: string, message: string): BffResponse => ({ ok: false, data: null, error: { code, message } });
  const actors = { actors: ['boss'] };
  assert.equal(mapBffResult(fail('FORBIDDEN_ACTOR', 'no'), 403, actors).outcome, 'forbidden');
  assert.deepEqual(mapBffResult(fail('FORBIDDEN_ACTOR', 'no'), 403, actors).error?.required, ['boss']);
  assert.equal(mapBffResult(fail('NOT_FOUND', 'x'), 404, actors).outcome, 'not_found');
  assert.equal(mapBffResult(fail('ROUTINE_NOT_FOUND', 'x'), 404, actors).outcome, 'unavailable');
  assert.equal(mapBffResult(fail('MODULE_NOT_REGISTERED', 'x'), 404, actors).outcome, 'unavailable');
  assert.equal(mapBffResult(fail('VALIDATION_ERROR', 'x'), 400, actors).outcome, 'invalid_input');
  assert.equal(mapBffResult(fail('INVALID_INPUT', 'x'), 422, actors).outcome, 'invalid_input');
  assert.equal(mapBffResult(fail('SOME_CODE', 'x'), 400, actors).outcome, 'invalid_input');
  assert.equal(mapBffResult(fail('CONCURRENCY_CONFLICT', 'x'), 409, actors).outcome, 'stale_version');
  assert.equal(mapBffResult(fail('VERSION_CONFLICT', 'x'), 409, actors).outcome, 'stale_version');
  assert.equal(mapBffResult(fail('COMPRADOR_FORA_DA_LISTA', 'x'), 422, actors).outcome, 'refused_rule');
  assert.equal(mapBffResult(fail('SOLICITACAO_FECHADA', 'x'), 409, actors).outcome, 'refused_rule');
  const rule = mapBffResult(fail('SOLICITACAO_FECHADA', 'a regra do módulo'), 409, actors);
  assert.deepEqual(rule, { outcome: 'refused_rule', error: { code: 'SOLICITACAO_FECHADA', message: 'a regra do módulo' } });
  const down = mapBffResult(fail('INTERNAL_ERROR', 'secret stack detail'), 500, actors);
  assert.equal(down.outcome, 'unavailable');
  assert.equal(JSON.stringify(down).includes('secret'), false);
});

test('a rule that refuses is kept and returned as refused_rule with the module code; a throw is unavailable and not run again', async () => {
  const refuse = setup(() => ({ response: { ok: false, data: null, error: { code: 'REGRA_X', message: 'não pode' } }, statusCode: 409 }));
  const refused = await execAssistantAction(refuse.ctx, refuse.deps, input());
  assert.deepEqual(refused, { outcome: 'refused_rule', error: { code: 'REGRA_X', message: 'não pode' } });
  assert.deepEqual(await execAssistantAction(refuse.ctx, refuse.deps, input()), refused);
  assert.equal(refuse.calls.requests.length, 1);
  const boom = setup(() => { throw new Error('secret boom'); });
  const down = await execAssistantAction(boom.ctx, boom.deps, input());
  assert.equal(down.outcome, 'unavailable');
  assert.equal(JSON.stringify(down).includes('secret'), false);
  await execAssistantAction(boom.ctx, boom.deps, input());
  assert.equal(boom.calls.requests.length, 1);
});

test('a commandId used by another person or for another action is not answered with that result', async () => {
  const { ctx, deps, calls } = setup();
  await execAssistantAction(ctx, deps, input());
  const other = await execAssistantAction(ctx, deps, { ...input(), onBehalfOf: { ...input().onBehalfOf, cmUserId: 'cm-2' } });
  assert.equal(other.error?.code, 'ASSISTANT_COMMAND_ID_REUSED');
  const sameKeyOtherAction = await execAssistantAction(ctx, deps, input({ actionId: 'modA.hidden' }, ['modA:boss']));
  assert.notEqual(sameKeyOtherAction.outcome, 'done');
  assert.equal(calls.requests.length, 1);
});

test('only the value nora is sent as via; anything else the caller wrote is not passed on', async () => {
  const { ctx, deps, calls } = setup();
  await execAssistantAction(ctx, deps, { ...input(), commandId: 'via-1', onBehalfOf: { ...input().onBehalfOf, via: 'other' } });
  assert.equal('via' in (calls.requests[0].meta ?? {}), false);
});

// ---- an agent acting in its own name ----

const agentInput = (over: Partial<AssistantExecInput> = {}, behalf: { agentId: string; requestedBy?: string } = { agentId: 'agent-1', requestedBy: 'cm-boss' }): AssistantExecInput => ({
  onBehalfOf: { ...behalf, via: 'agent' },
  actionId: 'modA.create', input: { details: { title: 'x' } }, commandId: 'agent-cmd-1', ...over,
});

function agentAccess(allowed: readonly string[] | 'no_module' | 'unavailable', asked: unknown[] = []): AssistantAgentAccess {
  return {
    async allowedActions(request) {
      asked.push(request);
      if (allowed === 'no_module') return { ok: false, code: 'no_module', message: 'no module serves the description of the agent' };
      if (allowed === 'unavailable') return { ok: false, code: 'unavailable', message: 'x' };
      return { ok: true, allowed };
    },
  };
}

test('an agent with the tool ON runs it as itself: its id, the agent type and its member, no login person, and only the actors of THAT action', async () => {
  const asked: unknown[] = [];
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create'], asked) });
  const result = await execAssistantAction(ctx, deps, agentInput());
  assert.equal(result.outcome, 'done');
  assert.deepEqual(asked, [{ agentId: 'agent-1', requestedBy: 'cm-boss' }]);
  assert.deepEqual(calls.requests[0], {
    routine: 'modA.page.modA.create',
    params: { details: { title: 'x' } },
    meta: { requestId: 'agent-cmd-1', userId: 'agent-1', actorId: 'agent-1', actorType: 'agent', agentMdmId: 'member-of-agent-1', agentName: 'Agent agent-1', actorScope: ['modA:boss'], verifiedAuthorities: ['modA:boss'] },
  });
  assert.equal('verifiedEmail' in (calls.requests[0].meta ?? {}), false, 'no person is the caller');
  assert.equal('via' in (calls.requests[0].meta ?? {}), false);
  const kept = (await getMdmKv(ctx, { key: 'assistant:agent-cmd-1' }))?.value as Record<string, unknown>;
  assert.equal(kept.agentId, 'agent-1');
  assert.equal('personMdmId' in kept, false);
});

test('a tool that is not ON for the agent is forbidden, and nothing runs', async () => {
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.list']) });
  const result = await execAssistantAction(ctx, deps, agentInput());
  assert.equal(result.outcome, 'forbidden');
  assert.equal(result.error?.code, 'ASSISTANT_AGENT_TOOL_OFF');
  assert.equal(calls.requests.length, 0);
});

test('with no module that answers for the agent, or no way to ask, it is forbidden and says so; an unavailable module is unavailable', async () => {
  for (const extra of [{ agent: agentAccess('no_module') }, {}]) {
    const { ctx, deps, calls } = setup(undefined, extra);
    const result = await execAssistantAction(ctx, deps, agentInput());
    assert.equal(result.outcome, 'forbidden');
    assert.equal(result.error?.code, 'ASSISTANT_AGENT_NO_MODULE');
    assert.equal(calls.requests.length, 0);
  }
  const down = setup(undefined, { agent: agentAccess('unavailable') });
  assert.equal((await execAssistantAction(down.ctx, down.deps, agentInput())).outcome, 'unavailable');
});

test('the roles of whoever called the agent authorize nothing: a person who could run the action does not lend it', async () => {
  // cm-1 is a person with the boss role of modA; the agent is called by them and still has the tool OFF.
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess([]) });
  const result = await execAssistantAction(ctx, deps, agentInput({}, { agentId: 'agent-1', requestedBy: 'cm-1' }));
  assert.equal(result.outcome, 'forbidden');
  assert.equal(calls.requests.length, 0);
  // and the actors it runs with are the action's own, never the person's authorities
  const on = setup(undefined, { agent: agentAccess(['modA.list']) });
  await execAssistantAction(on.ctx, on.deps, agentInput({ actionId: 'modA.list', input: { page: 1 } }, { agentId: 'agent-1', requestedBy: 'cm-1' }));
  assert.deepEqual(on.calls.requests[0].meta?.actorScope, ['modA:boss', 'modA:worker']);
});

test('the commandId of an agent is taken once: a repeat returns the first answer; another agent or another action with the same key is refused', async () => {
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create', 'modA.list']) });
  const first = await execAssistantAction(ctx, deps, agentInput());
  const again = await execAssistantAction(ctx, deps, agentInput());
  assert.deepEqual(again, first);
  assert.equal(calls.requests.length, 1);
  const otherAgent = await execAssistantAction(ctx, deps, agentInput({}, { agentId: 'agent-2' }));
  assert.equal(otherAgent.error?.code, 'ASSISTANT_COMMAND_ID_REUSED');
  const otherAction = await execAssistantAction(ctx, deps, agentInput({ actionId: 'modA.list' }));
  assert.equal(otherAction.error?.code, 'ASSISTANT_COMMAND_ID_REUSED');
  const person = await execAssistantAction(ctx, deps, { ...input(), commandId: 'agent-cmd-1' });
  assert.equal(person.error?.code, 'ASSISTANT_COMMAND_ID_REUSED', 'a person cannot take the key of an agent');
  assert.equal(calls.requests.length, 1);
});

test('the person path does not change: the same request as before, with the nora via and no agent type', async () => {
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create']) });
  await execAssistantAction(ctx, deps, input());
  const meta = calls.requests[0].meta ?? {};
  assert.equal(meta.actorType, undefined);
  assert.equal(meta.via, 'nora');
  assert.equal(meta.verifiedEmail, 'ana@example.test');
});

// ---- the route confirms what the engine did (rt238) ----

test('the same authorities go in actorScope and in verifiedAuthorities, for the person and for the agent', async () => {
  const person = setup();
  await execAssistantAction(person.ctx, person.deps, input({}, ['modA:worker', 'modA:boss']));
  assert.deepEqual(person.calls.requests[0].meta?.verifiedAuthorities, person.calls.requests[0].meta?.actorScope);
  const agent = setup(undefined, { agent: agentAccess(['modA.create']) });
  await execAssistantAction(agent.ctx, agent.deps, agentInput());
  assert.deepEqual(agent.calls.requests[0].meta?.verifiedAuthorities, ['modA:boss']);
  assert.deepEqual(agent.calls.requests[0].meta?.verifiedAuthorities, agent.calls.requests[0].meta?.actorScope);
});

test('a route that lists the actor lets the person and the agent through; one that does not list it refuses with 403, and the answer is forbidden FROM THE ROUTE', async () => {
  // modA.create is for `boss`. The route (as the generator emits it) lists `boss`:
  const listed = createGeneratedRoute(['boss']);
  const person = setup((request) => listed(request));
  assert.equal((await execAssistantAction(person.ctx, person.deps, input({ actionId: 'modA.create', input: { details: { title: 't' } } }, ['modA:boss']))).outcome, 'done');
  const agent = setup((request) => listed(request), { agent: agentAccess(['modA.create']) });
  assert.equal((await execAssistantAction(agent.ctx, agent.deps, agentInput())).outcome, 'done');

  // a route that lists only another actor: the engine's own check passes (boss holds it), the route says 403
  const unlisted = createGeneratedRoute(['someoneElse']);
  const refusedPerson = setup((request) => unlisted(request));
  const byPerson = await execAssistantAction(refusedPerson.ctx, refusedPerson.deps, input({ actionId: 'modA.create', input: { details: { title: 't' } } }, ['modA:boss']));
  assert.equal(byPerson.outcome, 'forbidden');
  assert.equal(refusedPerson.calls.requests.length, 1, 'the route was reached and refused it');
  const refusedAgent = setup((request) => unlisted(request), { agent: agentAccess(['modA.create']) });
  const byAgent = await execAssistantAction(refusedAgent.ctx, refusedAgent.deps, agentInput());
  assert.equal(byAgent.outcome, 'forbidden');
  assert.equal(refusedAgent.calls.requests.length, 1);
});

test('an agent that is not a member yet is no_person with its own code, before the commandId is taken, so the repeat with a new commandId runs', async () => {
  let member: { mdmId: string; name: string; active: boolean } | null = null;
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create']), agentMemberOf: async () => member });
  const first = await execAssistantAction(ctx, deps, agentInput());
  assert.deepEqual(first, { outcome: 'no_person', error: { code: 'ASSISTANT_AGENT_NO_MEMBER', message: 'The agent is not a member of the organization in this app yet.' } });
  assert.equal(calls.requests.length, 0);
  assert.equal(await getMdmKv(ctx, { key: 'assistant:agent-cmd-1' }), null, 'the commandId was not taken');
  member = { mdmId: 'member-1', name: 'Ana', active: true };
  const again = await execAssistantAction(ctx, deps, agentInput());
  assert.equal(again.outcome, 'done');
  assert.equal(calls.requests[0].meta?.agentMdmId, 'member-1');
  assert.equal(calls.requests[0].meta?.agentName, 'Ana');
});

test('an agent whose member is inactive is forbidden, and nothing runs', async () => {
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create']), agentMemberOf: async () => ({ mdmId: 'member-1', name: 'Ana', active: false }) });
  const result = await execAssistantAction(ctx, deps, agentInput());
  assert.equal(result.outcome, 'forbidden');
  assert.equal(result.error?.code, 'ASSISTANT_AGENT_INACTIVE');
  assert.equal(calls.requests.length, 0);
});

test('a failure reading the member of the agent is unavailable, and nothing runs', async () => {
  const { ctx, deps, calls } = setup(undefined, { agent: agentAccess(['modA.create']), agentMemberOf: async () => { throw new Error('down'); } });
  const result = await execAssistantAction(ctx, deps, agentInput());
  assert.equal(result.outcome, 'unavailable');
  assert.equal(calls.requests.length, 0);
});

test('the person path (and the Nora) carries no member of an agent', async () => {
  const { ctx, deps, calls } = setup();
  await execAssistantAction(ctx, deps, input());
  assert.equal('agentMdmId' in (calls.requests[0].meta ?? {}), false);
  assert.equal('actorType' in (calls.requests[0].meta ?? {}), false);
});

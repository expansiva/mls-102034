/// <mls fileReference="_102034_/l1/monitor/layer_2_controllers/router.ts" enhancement="_blank" />
import { ok, type BffHandler } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import {
  monitorArchitectureLoadHandler,
  monitorDynamodbLoadHandler,
  monitorDynamodbTableDetailsHandler,
  monitorDynamodbTableInspectHandler,
  monitorHomeLoadHandler,
  monitorPostgresLoadHandler,
  monitorPostgresTableDetailsHandler,
  monitorPostgresTableInspectHandler,
  monitorGetStatisticsSeriesHandler,
  monitorGetStatisticsSnapshotHandler,
} from '/_102034_/l1/monitor/layer_2_controllers/monitorGetStatistics.js';
import { monitorAbendLoadHandler, monitorClientErrorsLoadHandler } from '/_102034_/l1/monitor/layer_2_controllers/abendHandlers.js';
import { monitorProcessLoadHandler } from '/_102034_/l1/monitor/layer_2_controllers/processHealthHandlers.js';
import { monitorAppsMenuHandler, monitorConfigLoadHandler } from '/_102034_/l1/monitor/layer_2_controllers/configHandlers.js';
import { monitorOperationsSummaryHandler } from '/_102034_/l1/monitor/layer_2_controllers/operationsHandlers.js';
import { monitorRequestTraceLoadHandler } from '/_102034_/l1/monitor/layer_2_controllers/traceHandlers.js';
import {
  monitorLogsTailHandler,
  monitorReleasesActivateHandler,
  monitorReleasesListHandler,
} from '/_102034_/l1/monitor/layer_2_controllers/releaseHandlers.js';
import {
  monitorTestsListHandler,
  monitorTestsResultsHandler,
  monitorTestsRunHandler,
} from '/_102034_/l1/monitor/layer_2_controllers/testsHandlers.js';

export function createMonitorRouter(): Map<string, BffHandler> {
  return new Map<string, BffHandler>([
    ['monitor.home.load', monitorHomeLoadHandler],
    ['monitor.architecture.load', monitorArchitectureLoadHandler],
    ['monitor.postgres.load', monitorPostgresLoadHandler],
    ['monitor.dynamodb.load', monitorDynamodbLoadHandler],
    ['monitor.postgresTable.inspect', monitorPostgresTableInspectHandler],
    ['monitor.postgresTable.details', monitorPostgresTableDetailsHandler],
    ['monitor.dynamodbTable.inspect', monitorDynamodbTableInspectHandler],
    ['monitor.dynamodbTable.details', monitorDynamodbTableDetailsHandler],
    ['monitor.monitorGetStatistics.getSnapshot', monitorGetStatisticsSnapshotHandler],
    ['monitor.monitorGetStatistics.getSeries', monitorGetStatisticsSeriesHandler],
    ['monitor.abend.load', monitorAbendLoadHandler],
    ['monitor.clientErrors.load', monitorClientErrorsLoadHandler],
    ['monitor.process.load', monitorProcessLoadHandler],
    ['monitor.config.load', monitorConfigLoadHandler],
    ['monitor.appsMenu.load', monitorAppsMenuHandler],
    ['monitor.operations.summary', monitorOperationsSummaryHandler],
    ['monitor.requestTrace.load', monitorRequestTraceLoadHandler],
    ['monitor.telemetry.flush', async () => ok(null)],
    // Release management + logs (ADMIN ONLY once auth exists).
    ['monitor.releases.list', monitorReleasesListHandler],
    ['monitor.releases.activate', monitorReleasesActivateHandler],
    ['monitor.logs.tail', monitorLogsTailHandler],
    // Generated BFF tests (devenv). run is gated to development inside the usecase.
    ['monitor.tests.list', monitorTestsListHandler],
    ['monitor.tests.run', monitorTestsRunHandler],
    ['monitor.tests.results', monitorTestsResultsHandler],
  ]);
}

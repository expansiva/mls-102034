/// <mls fileReference="_102034_/l1/monitor/layer_3_usecases/testsUsecases.ts" enhancement="_blank" />
// Item 2c — devenv BFF test runner.
// Discovers the generated page11 `<page>.test.ts` files from config.json (modules[].frontend.pageTests),
// then runs each declarative case through the SAME real pipeline the HTTP transport uses (execBff:
// resolve routine -> controller -> usecase -> adapter), with source='test'. Nothing is faked, so the
// composition root, tables and seeds are all exercised together.
//
// Isolation & environment:
// - `runPageTests` only executes when TESTS_ENABLED is on (default: appEnv === 'development'), else
//   403 TESTS_DISABLED. `list`/`results` run everywhere (history/inspection).
// - EVERY run gets its OWN disposable in-memory runtime — never the process singleton. Tables and
//   mdm are rebuilt from the seed rows on first access and thrown away with the run, so the run is
//   deterministic and cannot touch data anyone else is using: production Postgres on a VM, or the
//   store behind a developer's live preview in devenv. That is also why the mutating cases need no
//   transaction/rollback (the memory runtime has no real rollback anyway). `skipMutating` still
//   reports them as 'skipped' when the caller does not want them executed at all.
// - `<seedRef>` params with a known fieldRef (`Petition.petitionId`) resolve only from that entity:
//   seed-row anchors first (and named `seedIds` when the seeds module exports them), then values
//   harvested from a read of that entity. An unqualified `petitionId` harvested from another
//   entity is not "the petition". Files generated without paramFieldRefs still resolve by fieldId
//   then wire name. Missing stays unresolved — never invent an id.
// - `<seedValue>` is the field on that entity's seeded row; `<seedSpare>` is a leftover from the
//   module's `seedSpares` export (create commands). Same entity discipline. Missing stays
//   unresolved — never invent a value.
// - A case that could not verify what it claims is reported 'inconclusive', never 'pass': a
//   seed marker that never resolved, or a `<command>.<field>.required` case rejected on another
//   field. `failed` is reserved for the backend actually misbehaving.
// - `expect.shape: 'paginated'` checks the collection the case declares in `expect.itemsKey`
//   (`{ menuItems: [...] }`); absent, it falls back to `items` so files generated before the key
//   existed keep working.
//
// Results are captured directly from execBff's return value and kept in a small in-memory ring (the
// execution log/series store only keeps aggregates and Postgres monitor storage is optional in devenv).

import { AppError, type BffRequest, type BffResponse, type PlatformSessionPerson, type RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { IDataRuntime } from '/_102034_/l1/server/layer_1_external/data/runtime.js';
import { MDM_LOGIN_NAMESPACE } from '/_102034_/l1/mdm/layer_3_usecases/identityUsecases.js';
import { ensureOrganizationIdentity } from '/_102034_/l1/mdm/layer_3_usecases/organizationBootstrap.js';
import { readOnboardingConfig, resolveOrganizationBinding, type OrganizationBinding } from '/_102034_/l1/server/layer_1_external/config/onboardingConfig.js';
import type { MdmDocumentRecord, MdmEntityIndexRecord } from '/_102034_/l1/mdm/module.js';
import { createRequestContext, execBff } from '/_102034_/l1/server/layer_2_controllers/execBff.js';
import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { hasDeclaredProjectMode, readProjectMode } from '/_102034_/l1/server/layer_1_external/config/projectMode.js';
import { createMemoryDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.js';
import { readProjectsConfig, resolveProjectModuleImportUrl } from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import { loadResolvedTableDefinitions } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { selectEligibleSeedRows, type SeedModeInput, type SeedPolicyTable } from '/_102034_/l1/server/layer_1_external/persistence/seedPolicy.js';
import { createUuidV7 } from '/_102029_/l2/uuidv7.js';
import type { M1HandlerStage } from '/_102021_/l2/agentMaterializeL1/core/registry.js';
import {
  M1_CATALOG_EXPORT,
  parseCatalog,
  type M1CaseRunner,
  type M1Scenario,
  type M1ScenarioCase,
  type M1ScenarioCatalog,
} from '/_102021_/l2/agentMaterializeL1/testing/catalog.js';
import {
  classifyCase,
  type M1Broken,
  type M1Observation,
  type M1Verdict,
} from '/_102021_/l2/agentMaterializeL1/testing/verify.js';

const SEED_REF_MARKER = '<seedRef>';
const SEED_VALUE_MARKER = '<seedValue>';
const SEED_SPARE_MARKER = '<seedSpare>';
const MAX_STORED_RUNS = 50;

// ---- Shapes read from the (untrusted) generated client file — validated at runtime, never imported. ----

type TestShape = 'object' | 'array' | 'paginated';

// A paginated envelope names its collection after the entity (`{ menuItems: [...] }`), so the case
// declares the key. Absent -> 'items', which is what the files generated before this existed assume.
const DEFAULT_ITEMS_KEY = 'items';

interface PageTestCase {
  id: string;
  routine: string;
  params: Record<string, unknown>;
  /**
   * Ontology fieldRef of each seed-marker param (`Task.taskId`), keyed by the input's wire name.
   * The harvest pool is filled from response field names (usually the fieldId); matching by
   * inputId alone misses `taskTaskId` vs `taskId`. Optional: files generated before this existed
   * keep resolving by name only.
   */
  paramFieldRefs?: Record<string, string>;
  expect: { ok: boolean; errorCode?: string; minItems?: number; shape?: TestShape; itemsKey?: string };
  mutating: boolean;
  /**
   * A failure that is already understood and owned by a named wave of work (e.g. 'mdm-rebuild'). The case
   * still RUNS and still reports what happened: it is counted apart from `failed`, so a suite can be green
   * with knowns instead of red with noise, and the day it passes the run says so — which is how the wave
   * gets proved in production instead of on someone's word.
   */
  expectedFail?: string;
}

interface PageTestsFile {
  moduleName: string;
  page: string;
  variant: string;
  // The l4 actor this page is scoped to (the workspace's declared actor). When present, the run executes
  // the page's cases AS that actor: routes that read the id from the session (a field worker seeing the
  // tasks assigned to them) are otherwise unrunnable headless. Optional for back-compat: an older
  // generated file without it runs with no actor session, exactly as before.
  actor?: string;
  cases: PageTestCase[];
}

interface DiscoveredTestFile {
  projectId: string;
  moduleId: string;
  path: string;
  tests: PageTestsFile | null;
  loadError?: string;
}

// 'inconclusive' = the case could not verify what it claims (a <seedRef> param never resolved, or a
// `<command>.<field>.required` case was rejected on a different field). It is NOT an app defect —
// keeping it out of `failed` is what makes the failed count mean "the backend misbehaved".
// 'moduleOnly' = the catalog declared `runner: 'module'`: the case belongs to the L1 node adapter
// (compilation, usecase called directly), not to `execBff`. The monitor reports it and does not run
// it — never a pass (nothing was verified here) and never a fail (nothing misbehaved).
export type TestCaseStatus = 'pass' | 'fail' | 'inconclusive' | 'skipped' | 'knownFail' | 'expectedRed' | 'blocked' | 'moduleOnly';

export interface TestCaseResult {
  module: string;
  page: string;
  id: string;
  routine: string;
  status: TestCaseStatus;
  ok: boolean;
  statusCode: number;
  durationMs: number;
  errorCode: string | null;
  errorMessage: string | null;
  reason: string;
  /** Handler stage the producer classified (`structure` | `implement`). Catalog cases only. */
  stage?: string;
  /** Catalog `source`: who wrote the expectation. Not a screen-authored label. */
  expectationSource?: string;
  /** Catalog `expectation` text. */
  expectation?: string;
}

export interface TestRunSummary {
  runId: string;
  traceId: string;
  startedAt: string;
  finishedAt: string;
  /** ProjectMode from l5/project.json — not the server APP_ENV. */
  appEnv: string;
  /** Where `appEnv` was read from, so a VM with APP_ENV=production is not mistaken for the project mode. */
  appEnvSource: string;
  /** Server deployment (`APP_ENV`): development | staging | production. */
  serverAppEnv: string;
  scope: { moduleId?: string; page?: string };
  total: number;
  passed: number;
  failed: number;
  /** Failures a case declared as already-owned work (`expectedFail`): known, not new. */
  knownFail: number;
  /** Catalog verdict `expectedRed` (structure stub). Not a pass and not a new failure. */
  expectedRed: number;
  /** Catalog cases with `runner: 'module'`: reported, not executed by the monitor. Not a pass, not a failure. */
  moduleOnly: number;
  blocked: number;
  inconclusive: number;
  skipped: number;
  /** No registered frontend pageTests and no backend.scenarioCatalog in scope. Never a green empty run. */
  untested: boolean;
  untestedReason: string;
  cases: TestCaseResult[];
}

export interface TestListResult {
  appEnv: string;
  appEnvSource: string;
  serverAppEnv: string;
  executionEnabled: boolean;
  modules: Array<{
    moduleId: string;
    projectId: string;
    /** page21/page31 share page11's BFF contract; cases are generated once. */
    variantPolicy: string;
    untestedPages: Array<{ page: string; reason: string }>;
    pages: Array<{
      page: string;
      variant: string;
      path: string;
      loadError?: string;
      cases: Array<{ id: string; routine: string; mutating: boolean; expect: PageTestCase['expect'] }>;
    }>;
  }>;
  recentRuns: TestRunSummary[];
}

export const PAGE11_VARIANT_POLICY = 'page21/page31 share page11\'s contract; cases are generated once for page11.';

export function untestedPageEntries(configuredPageIds: string[], testedPageIds: Iterable<string>): Array<{ page: string; reason: string }> {
  const tested = new Set(testedPageIds);
  return configuredPageIds.filter(page => page && !tested.has(page)).sort().map(page => ({
    page,
    reason: 'no generated .test.ts — inspect pages should emit a <seedRef> case; skip only when the owning entity has no seed',
  }));
}

// ---- In-memory history (net-new state; everything else reuses existing runtime infra). ----

const recentRuns: TestRunSummary[] = [];

function storeRun(run: TestRunSummary): void {
  recentRuns.unshift(run);
  if (recentRuns.length > MAX_STORED_RUNS) recentRuns.length = MAX_STORED_RUNS;
}

export function getRecentRuns(filter: { moduleId?: string; page?: string; runId?: string } = {}, limit = 20): TestRunSummary[] {
  return recentRuns
    .filter(run => (!filter.runId || run.runId === filter.runId))
    .filter(run => (!filter.moduleId || run.scope.moduleId === filter.moduleId || run.cases.some(c => c.module === filter.moduleId)))
    .filter(run => (!filter.page || run.scope.page === filter.page || run.cases.some(c => c.page === filter.page)))
    .slice(0, limit);
}

// ---- Discovery ----

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function coercePageTestsFile(raw: unknown): PageTestsFile | null {
  if (!isRecord(raw)) return null;
  const moduleName = typeof raw.moduleName === 'string' ? raw.moduleName : '';
  const page = typeof raw.page === 'string' ? raw.page : '';
  const variant = typeof raw.variant === 'string' ? raw.variant : 'page11';
  if (!moduleName || !page || !Array.isArray(raw.cases)) return null;
  const cases: PageTestCase[] = [];
  for (const item of raw.cases) {
    if (!isRecord(item)) continue;
    const id = typeof item.id === 'string' ? item.id : '';
    const routine = typeof item.routine === 'string' ? item.routine : '';
    if (!id || !routine) continue;
    const expectRaw = isRecord(item.expect) ? item.expect : {};
    const paramFieldRefs = coerceParamFieldRefs(item.paramFieldRefs);
    cases.push({
      id,
      routine,
      params: isRecord(item.params) ? { ...item.params } : {},
      expect: {
        ok: expectRaw.ok === true,
        errorCode: typeof expectRaw.errorCode === 'string' ? expectRaw.errorCode : undefined,
        minItems: typeof expectRaw.minItems === 'number' ? expectRaw.minItems : undefined,
        shape: expectRaw.shape === 'object' || expectRaw.shape === 'array' || expectRaw.shape === 'paginated' ? expectRaw.shape : undefined,
        itemsKey: typeof expectRaw.itemsKey === 'string' && expectRaw.itemsKey.trim() ? expectRaw.itemsKey.trim() : undefined,
      },
      mutating: item.mutating === true,
      ...(typeof item.expectedFail === 'string' && item.expectedFail.trim() ? { expectedFail: item.expectedFail.trim() } : {}),
      ...(paramFieldRefs ? { paramFieldRefs } : {}),
    });
  }
  // Optional: the page's l4 actor. Absent in files generated before actor-scoped runs existed.
  const actor = typeof raw.actor === 'string' && raw.actor.trim() ? raw.actor.trim() : undefined;
  return { moduleName, page, variant, ...(actor ? { actor } : {}), cases };
}

async function discoverTestFiles(filter: { moduleId?: string; page?: string } = {}): Promise<DiscoveredTestFile[]> {
  const config = readProjectsConfig();
  const files: DiscoveredTestFile[] = [];
  for (const [projectId, project] of Object.entries(config.projects)) {
    for (const moduleConfig of project.modules ?? []) {
      if (filter.moduleId && moduleConfig.moduleId !== filter.moduleId) continue;
      const backendPageTests = Array.isArray(moduleConfig.backend?.pageTests)
        ? (moduleConfig.backend.pageTests as unknown[]).filter((item): item is string => typeof item === 'string')
        : [];
      for (const path of [...(moduleConfig.frontend?.pageTests ?? []), ...backendPageTests]) {
        let tests: PageTestsFile | null = null;
        let loadError: string | undefined;
        try {
          const imported = await import(resolveProjectModuleImportUrl(path)) as { pageTests?: unknown };
          tests = coercePageTestsFile(imported.pageTests);
          if (!tests) loadError = 'file did not export a valid pageTests object';
        } catch (error) {
          loadError = error instanceof Error ? error.message : String(error);
        }
        if (filter.page && tests && tests.page !== filter.page) continue;
        files.push({ projectId, moduleId: moduleConfig.moduleId, path, tests, loadError });
      }
    }
  }
  return files;
}

interface DiscoveredCatalog {
  projectId: string;
  moduleId: string;
  path: string;
  catalog: M1ScenarioCatalog | null;
  broken: M1Broken;
  loadError?: string;
}

function scenarioCatalogPath(backend: Record<string, unknown> | undefined): string {
  const value = backend?.scenarioCatalog;
  return typeof value === 'string' ? value.trim() : '';
}

function brokenFromImport(error: unknown): M1Broken {
  const name = error instanceof Error ? error.name : '';
  const message = error instanceof Error ? error.message : String(error);
  if (name === 'SyntaxError' || /transform|compile|unexpected token/iu.test(message)) return 'compile';
  return 'import';
}

function stageOfHandler(handlerId: string): M1HandlerStage {
  return handlerId.startsWith('implement.') ? 'implement' : 'structure';
}

/** Params the catalog case can state without reading a route contract. Omitted names come from preconditions. */
export function paramsForCatalogCase(item: M1ScenarioCase): Record<string, unknown> {
  const omitted = new Set(item.preconditions.flatMap(entry => {
    const match = /^([A-Za-z][A-Za-z0-9]*) omitted$/u.exec(entry);
    return match ? [match[1]] : [];
  }));
  const params: Record<string, unknown> = {};
  const row = item.synthetic[0];
  if (row) {
    for (const [key, value] of Object.entries(row)) {
      if (!omitted.has(key)) params[key] = value;
    }
  }
  if (item.actorId && !omitted.has('actorId')) params.actorId = item.actorId;
  return params;
}

// The producer (mls-102021/l2/agentMaterializeL1/testing/) reads `fields` as dotted paths, container
// AND leaf both present (`obligations.test.ts:119`), with array rows contributing their field paths
// WITHOUT an index segment (`oracle.test.ts:76`: `rows`, `rows.dockAt`, never `rows.0.dockAt`). The
// response is generated-app output — untrusted — hence the depth/count caps below: never throw, just
// stop and return what was gathered so far.
const FIELD_PATHS_MAX_DEPTH = 6;
const FIELD_PATHS_MAX_COUNT = 500;

/** Pure. See module comment above `FIELD_PATHS_MAX_DEPTH` for the path format this feeds. */
export function fieldPathsOf(data: unknown): string[] {
  const out = new Set<string>();
  collectFieldPaths(data, '', 0, out);
  return Array.from(out).sort();
}

function collectFieldPaths(value: unknown, prefix: string, depth: number, out: Set<string>): void {
  if (out.size >= FIELD_PATHS_MAX_COUNT) return;
  if (Array.isArray(value)) {
    // No index segment: every row folds into the same prefix (a root array -> row paths, no prefix).
    for (const item of value) {
      if (out.size >= FIELD_PATHS_MAX_COUNT) return;
      collectFieldPaths(item, prefix, depth, out);
    }
    return;
  }
  if (!isRecord(value)) return; // primitive/null leaf: nothing to add here, caller already added its own path
  for (const [key, child] of Object.entries(value)) {
    if (out.size >= FIELD_PATHS_MAX_COUNT) return;
    const pathDepth = depth + 1;
    if (pathDepth > FIELD_PATHS_MAX_DEPTH) continue; // beyond the depth cap: not added, not descended into
    const path = prefix ? `${prefix}.${key}` : key;
    out.add(path);
    collectFieldPaths(child, path, pathDepth, out);
  }
}

export function observationFromExec(
  caseId: string,
  durationMs: number,
  exec: { response: BffResponse; statusCode: number } | null,
  patch: { broken?: M1Broken; thrown?: boolean; actorField?: string | null } = {},
): M1Observation {
  const response = exec?.response;
  const details = response?.error?.details;
  const ruleId = isRecord(details) && typeof details.ruleId === 'string' ? details.ruleId : null;
  const actorField = patch.actorField ?? null;
  return {
    caseId,
    durationMs,
    broken: patch.broken ?? 'none',
    thrown: patch.thrown === true,
    skipped: false,
    inconclusive: false,
    blocked: false,
    blockOwner: '',
    ok: response?.ok === true,
    status: exec?.statusCode ?? 0,
    errorCode: response?.error?.code ?? null,
    ruleId,
    fields: fieldPathsOf(response?.data),
    rowActorIds: actorIdsIn(response?.data, actorField),
    reason: response?.error?.message ?? '',
  };
}

function actorIdsIn(data: unknown, actorField: string | null): string[] {
  if (!actorField) return [];
  const rows = Array.isArray(data) ? data : isRecord(data) ? [data] : [];
  return rows.flatMap(row => (isRecord(row) && typeof row[actorField] === 'string' ? [row[actorField]] : []));
}

/** Producer owns the verdict. expectedRed is only the structure stub (caseId + USECASE_NOT_IMPLEMENTED + 501). */
export function verdictForCatalogCase(
  stage: M1HandlerStage,
  item: M1ScenarioCase,
  observation: M1Observation | undefined,
): { verdict: M1Verdict; detail: string } {
  const evidence = classifyCase(stage, item, observation);
  return { verdict: evidence.verdict, detail: evidence.detail };
}

function statusFromVerdict(verdict: M1Verdict): TestCaseStatus {
  if (verdict === 'passed') return 'pass';
  if (verdict === 'failed') return 'fail';
  return verdict;
}

// ---- Catalog v1.1: who runs the case, and who it says it is. ----
//
// Both fields are ADDITIVE. A v1 catalog carries neither, and the defaults below are exactly what the
// monitor did before v1.1 existed: every case is a route, executed with `source: 'test'` and no
// authorities. That is what keeps a v1 catalog read as it is read today.

/** Absent `runner` means 'route' — the v1 behaviour, where every case went through execBff. */
function runnerOf(item: M1ScenarioCase): M1CaseRunner {
  return item.runner ?? 'route';
}

// Absent `caller` means today's caller: the monitor speaking as itself (`source: 'test'`, no
// authorities). Only a v1.1 route case declares one.
//
// WHY DECLARING `source: 'http'` HERE OPENS NOTHING (design decision of x1_05, measured 26/09):
// the generated controller's `authorize()` reads `request.meta.source` and
// `request.meta.verifiedAuthorities` — not `ctx.sessionContext.actorScope` — and it is not behind
// `ctx.sandbox`, so the declared caller is how a case represents itself. The two guards that a
// forged `source` could have bypassed are BOTH behind `!ctx.sandbox`: `refuseTestWrite`
// (execBff.ts:172) and the central actor gate (execBff.ts:184). This runner always builds its
// context with `sandbox: true`, so neither applies to it today, with `source: 'test'` — changing the
// declared source changes nothing about them. And the monitor calls `execBff` in process, never over
// the HTTP transport, so nothing here depends on how that transport stamps meta.
interface ResolvedCaller {
  source: 'http' | 'message' | 'test';
  authorities: string[];
}

const DEFAULT_CALLER: ResolvedCaller = { source: 'test', authorities: [] };

function callerOf(item: M1ScenarioCase): ResolvedCaller {
  return item.caller ? { source: item.caller.source, authorities: item.caller.authorities } : DEFAULT_CALLER;
}

const UNTESTED_REASON = 'não testado: no frontend.pageTests and no backend.scenarioCatalog in scope';

export function emptyRunCoverage(registered: number): { untested: boolean; untestedReason: string } {
  return registered === 0
    ? { untested: true, untestedReason: UNTESTED_REASON }
    : { untested: false, untestedReason: '' };
}

async function discoverBackendCatalogs(filter: { moduleId?: string } = {}): Promise<DiscoveredCatalog[]> {
  const config = readProjectsConfig();
  const found: DiscoveredCatalog[] = [];
  for (const [projectId, project] of Object.entries(config.projects)) {
    for (const moduleConfig of project.modules ?? []) {
      if (filter.moduleId && moduleConfig.moduleId !== filter.moduleId) continue;
      const path = scenarioCatalogPath(moduleConfig.backend);
      if (!path) continue;
      let catalog: M1ScenarioCatalog | null = null;
      let loadError: string | undefined;
      let broken: M1Broken = 'none';
      try {
        const imported = await import(resolveProjectModuleImportUrl(path)) as Record<string, unknown>;
        const parsed = parseCatalog(JSON.stringify(imported[M1_CATALOG_EXPORT] ?? null));
        if (!parsed.catalog) {
          broken = 'import';
          loadError = parsed.issues.join('; ') || `file did not export a valid ${M1_CATALOG_EXPORT}`;
        } else {
          catalog = parsed.catalog;
        }
      } catch (error) {
        broken = brokenFromImport(error);
        loadError = error instanceof Error ? error.message : String(error);
      }
      found.push({ projectId, moduleId: moduleConfig.moduleId, path, catalog, broken, loadError });
    }
  }
  return found;
}

function catalogPages(file: DiscoveredCatalog): TestListResult['modules'][number]['pages'] {
  if (!file.catalog) {
    return [{
      page: 'backend',
      variant: 'scenarioCatalog',
      path: file.path,
      loadError: file.loadError,
      cases: [],
    }];
  }
  return file.catalog.scenarios.map((scenario: M1Scenario) => ({
    page: scenario.scenarioId,
    variant: scenario.handlerId,
    path: file.path,
    cases: scenario.cases.map(item => ({
      id: item.caseId,
      routine: item.routine,
      mutating: item.mutating,
      expect: {
        ok: item.expect.ok,
        errorCode: item.expect.errorCode ?? undefined,
      },
    })),
  }));
}

/** ProjectMode from l5/project.json wins over APP_ENV. The test report prints both so they cannot be confused. */
export function reportAppEnv(projectId?: string): { appEnv: string; appEnvSource: string; serverAppEnv: string } {
  const appEnv = readProjectMode(projectId);
  return {
    appEnv,
    appEnvSource: hasDeclaredProjectMode(projectId) ? 'l5/project.json' : 'default',
    serverAppEnv: readAppEnv().appEnv,
  };
}

// ---- list ----

export async function listPageTests(): Promise<TestListResult> {
  const env = readAppEnv();
  const files = await discoverTestFiles();
  const catalogs = await discoverBackendCatalogs();
  const byModule = new Map<string, TestListResult['modules'][number]>();
  for (const file of files) {
    let entry = byModule.get(file.moduleId);
    if (!entry) {
      entry = { moduleId: file.moduleId, projectId: file.projectId, variantPolicy: PAGE11_VARIANT_POLICY, untestedPages: [], pages: [] };
      byModule.set(file.moduleId, entry);
    }
    entry.pages.push({
      page: file.tests?.page ?? file.path,
      variant: file.tests?.variant ?? 'page11',
      path: file.path,
      loadError: file.loadError,
      cases: (file.tests?.cases ?? []).map(c => ({ id: c.id, routine: c.routine, mutating: c.mutating, expect: c.expect })),
    });
  }
  for (const catalogFile of catalogs) {
    let entry = byModule.get(catalogFile.moduleId);
    if (!entry) {
      entry = { moduleId: catalogFile.moduleId, projectId: catalogFile.projectId, variantPolicy: PAGE11_VARIANT_POLICY, untestedPages: [], pages: [] };
      byModule.set(catalogFile.moduleId, entry);
    }
    entry.pages.push(...catalogPages(catalogFile));
  }
  const reported = reportAppEnv(files[0]?.projectId ?? catalogs[0]?.projectId ?? env.projectId);
  const config = readProjectsConfig();
  for (const [projectId, project] of Object.entries(config.projects)) {
    for (const moduleConfig of project.modules ?? []) {
      const moduleId = moduleConfig.moduleId;
      if (!moduleId) continue;
      let entry = byModule.get(moduleId);
      if (!entry) {
        entry = { moduleId, projectId, variantPolicy: PAGE11_VARIANT_POLICY, untestedPages: [], pages: [] };
        byModule.set(moduleId, entry);
      }
      const frontendPages = (moduleConfig.frontend as { pages?: Array<{ pageId?: string; id?: string }> } | undefined)?.pages ?? [];
      const configured = frontendPages.map(page => page.pageId || page.id || '').filter(Boolean);
      const tested = entry.pages.map(page => page.page);
      entry.untestedPages = untestedPageEntries(configured, tested);
      const registered = catalogs.filter(file => file.moduleId === moduleId);
      for (const catalogFile of registered) {
        if (catalogFile.catalog && catalogFile.catalog.scenarios.length === 0) {
          entry.untestedPages.push({ page: 'backend', reason: 'não testado: backend.scenarioCatalog has no scenarios' });
        }
      }
    }
  }
  return {
    appEnv: reported.appEnv,
    appEnvSource: reported.appEnvSource,
    serverAppEnv: reported.serverAppEnv,
    // Every run is a disposable in-memory sandbox (runPageTests), so execution is always available.
    executionEnabled: true,
    modules: [...byModule.values()],
    recentRuns: getRecentRuns({}, 10),
  };
}

// ---- run ----

function describeShape(data: unknown): string {
  if (Array.isArray(data)) return 'array';
  if (data === null || data === undefined) return String(data);
  return typeof data === 'object' ? 'object' : typeof data;
}

// Item 5 drift guard: the actual response shape must match the shape the FE contract declares.
// Returns '' when compatible, else a failure reason (object×array, or paginated missing the
// declared collection). The reason names the expected key so a drift is readable at a glance.
/** `itemsKey` is a path: `consultas.items` reads `data.consultas.items` (the contract nests the page). */
export function itemsAt(data: unknown, itemsKey = DEFAULT_ITEMS_KEY): unknown {
  let current: unknown = data;
  for (const part of itemsKey.split('.')) {
    if (!isRecord(current)) return undefined;
    current = current[part];
  }
  return current;
}

export function checkShape(data: unknown, shape: TestShape, itemsKey = DEFAULT_ITEMS_KEY): string {
  if (shape === 'array') {
    return Array.isArray(data) ? '' : `expected array output, got ${describeShape(data)}`;
  }
  if (shape === 'paginated') {
    return Array.isArray(itemsAt(data, itemsKey))
      ? ''
      : `expected paginated { ${itemsKey}: [] }, got ${describeShape(data)}`;
  }
  return isRecord(data) && !Array.isArray(data) ? '' : `expected object output, got ${describeShape(data)}`;
}

export function countItems(data: unknown, itemsKey = DEFAULT_ITEMS_KEY): number {
  if (Array.isArray(data)) return data.length;
  const items = itemsAt(data, itemsKey);
  if (Array.isArray(items)) return items.length;
  if (data !== null && data !== undefined) return 1;
  return 0;
}

// Only scalars are usable as a <seedRef> value; nested arrays/objects are containers to descend into.
function coerceParamFieldRefs(value: unknown): Record<string, string> | undefined {
  if (!isRecord(value)) return undefined;
  const refs: Record<string, string> = {};
  for (const [key, fieldRef] of Object.entries(value)) {
    if (typeof fieldRef === 'string' && fieldRef.trim()) refs[key] = fieldRef.trim();
  }
  return Object.keys(refs).length ? refs : undefined;
}

function fieldIdOfFieldRef(fieldRef: string | undefined): string {
  if (!fieldRef) return '';
  const dot = fieldRef.lastIndexOf('.');
  return (dot < 0 ? fieldRef : fieldRef.slice(dot + 1)).trim();
}

function entityOfFieldRef(fieldRef: string | undefined): string {
  if (!fieldRef) return '';
  const dot = fieldRef.indexOf('.');
  return (dot < 0 ? '' : fieldRef.slice(0, dot)).trim();
}

function entityOfIdField(fieldId: string): string {
  if (!fieldId.endsWith('Id') || fieldId.length <= 2) return '';
  const base = fieldId.slice(0, -2);
  return base.charAt(0).toUpperCase() + base.slice(1);
}

function putPool(pool: Record<string, unknown>, key: string, value: unknown): void {
  if (!key || pool[key] !== undefined || value === null || value === undefined) return;
  if (Array.isArray(value) || isRecord(value)) return;
  pool[key] = value;
}

/** A table/entity of one module, as its metadata declares it: the entity's own id and its columns. */
export interface EntityIndexEntry {
  entity: string;
  pkFieldId: string;
  columnFieldIds: string[];
}

/** Entity index per moduleId: a module's metadata never qualifies another module's rows. */
export type ModuleEntityIndex = Map<string, EntityIndexEntry[]>;

/** The organization Company of the run: an MDM `Company` row with this mdmId is one of these entities. */
export interface HarvestCompany {
  companyMdmId: string;
  entities: Set<string>;
}

function isScalar(value: unknown): boolean {
  return value !== null && value !== undefined && !Array.isArray(value) && !isRecord(value);
}

/**
 * The entity a harvested record PROVABLY belongs to, or '' when nothing proves it. Proof is metadata only:
 * the record carries an indexed entity's own id and every other indexed own id in it is a column of that
 * entity (a signature row carries `petitionId` as FK, so it cannot be the Petition). Or it is the run's
 * organization Company (MDM subtype + mdmId). Never the name of the wrapper key, never "the longest *Id":
 * zero or several survivors leave the record unqualified.
 */
function provenEntityOf(row: Record<string, unknown>, entries: EntityIndexEntry[], company?: HarvestCompany): string[] {
  if (company && row.subtype === 'Company' && row.mdmId === company.companyMdmId) return [...company.entities];
  const present = entries.filter(entry => isScalar(row[entry.pkFieldId]));
  const survivors = present.filter(entry => present.every(other =>
    other.pkFieldId === entry.pkFieldId || entry.columnFieldIds.includes(other.pkFieldId)));
  const names = new Set(survivors.map(entry => entry.entity));
  return names.size === 1 ? [...names] : [];
}

function harvestRecord(
  pool: Record<string, unknown>,
  row: Record<string, unknown>,
  entities: string[],
  bare: boolean,
  moduleId?: string,
): void {
  for (const [key, value] of Object.entries(row)) {
    if (!isScalar(value)) continue;
    for (const entity of entities) {
      if (moduleId) putPool(pool, `${moduleId}.${entity}.${key}`, value);
      putPool(pool, `${entity}.${key}`, value);
    }
    if (bare) putPool(pool, key, value);
  }
}

/**
 * Harvest a successful response into the pool, without touching it. Bare keys (the legacy lookup without
 * fieldRef) come from the same levels as always: the envelope and the rows of its top-level arrays.
 * Entity-qualified keys come from records at ANY depth (DTOs nest `company`, `member`, `people.items`),
 * but only when `provenEntityOf` proves the entity from the module's metadata. Traversal stops at the
 * FIELD_PATHS_* caps used for the observed field paths. Existing keys are never overwritten, so a seed
 * anchor is not replaced by a later response.
 */
export function harvestRows(
  pool: Record<string, unknown>,
  data: unknown,
  moduleId?: string,
  index?: ModuleEntityIndex,
  company?: HarvestCompany,
): void {
  const entries = (moduleId ? index?.get(moduleId) : undefined) ?? [];
  let visited = 0;
  const walk = (value: unknown, depth: number, bare: boolean): void => {
    if (depth > FIELD_PATHS_MAX_DEPTH || visited >= FIELD_PATHS_MAX_COUNT) return;
    visited += 1;
    if (Array.isArray(value)) {
      for (const item of value) walk(item, depth + 1, bare);
      return;
    }
    if (!isRecord(value)) return;
    harvestRecord(pool, value, provenEntityOf(value, entries, company), bare, moduleId);
    for (const child of Object.values(value)) {
      if (Array.isArray(child)) walk(child, depth + 1, bare && depth === 0);
      else if (isRecord(child)) walk(child, depth + 1, false);
    }
  };
  if (Array.isArray(data)) {
    for (const row of data) walk(row, 1, true);
    return;
  }
  walk(data, 0, true);
}

function columnToField(column: string): string {
  return column.replace(/_([a-z0-9])/gu, (_all, char: string) => char.toUpperCase());
}

/** Scalars of a seed row, including one level of a details envelope (keys there are fieldIds). */
function scalarEntriesOfSeedRow(row: Record<string, unknown>): Array<[string, unknown]> {
  const out: Array<[string, unknown]> = [];
  for (const [column, value] of Object.entries(row)) {
    if (value === null || value === undefined || Array.isArray(value)) continue;
    if (isRecord(value)) {
      for (const [innerKey, innerVal] of Object.entries(value)) {
        if (innerVal === null || innerVal === undefined || Array.isArray(innerVal) || isRecord(innerVal)) continue;
        out.push([innerKey, innerVal]);
      }
      continue;
    }
    out.push([columnToField(column), value]);
  }
  return out;
}

function snakeToPascal(name: string): string {
  return name.split(/[._-]/gu).filter(Boolean).map(part => part.charAt(0).toUpperCase() + part.slice(1)).join('');
}

/**
 * Ontology entity of a table. The repository name is the entity name (`privacyText` → `PrivacyText`,
 * `itemCardapio` → `ItemCardapio`); tableName/logicalTableName only when it is missing. A legacy
 * `<moduleId><Entity>` repository name is cut ONLY when the table's own id or a declared own-id fieldRef
 * (`Petition.petitionId`) proves the shorter name — a module id that merely prefixes a normal name is kept.
 * Both names proved → ambiguous → '' (no entity is anchored for that table).
 */
export function ontologyEntityName(
  definition: { moduleId?: string; repositoryName?: string; tableName: string; logicalTableName?: string; primaryKey?: string[] },
  declaredOwnIdEntities?: ReadonlySet<string>,
): string {
  const repo = definition.repositoryName ?? '';
  const full = snakeToPascal(repo || definition.logicalTableName || definition.tableName);
  const moduleId = definition.moduleId ?? '';
  const rest = moduleId && repo.startsWith(moduleId) ? repo.slice(moduleId.length) : '';
  if (!/^[A-Z]/u.test(rest)) return full;
  const pk = definition.primaryKey?.length === 1 ? entityOfIdField(columnToField(definition.primaryKey[0])) : '';
  const proves = (name: string): boolean => pk === name || (declaredOwnIdEntities?.has(name) ?? false);
  const provedFull = proves(full);
  const provedRest = proves(rest);
  if (provedFull && provedRest) return '';
  return provedRest ? rest : full;
}

/**
 * Put a seeded PK into the pool under the entity-qualified key (`Petition.petitionId`).
 * Named `seedIds` win when their value is actually a row of this table — they pick the intended
 * line (e.g. a published petition) instead of "whatever was first in the file". Existing keys
 * are never overwritten.
 */
export function applySeedAnchors(
  pool: Record<string, unknown>,
  input: {
    entity: string;
    fieldId: string;
    seedRowIds: unknown[];
    namedIds?: Record<string, unknown>;
    moduleId?: string;
    seedRows?: Array<Record<string, unknown>>;
    pkColumn?: string;
  },
): void {
  const entity = input.entity.trim();
  const fieldId = input.fieldId.trim();
  if (!fieldId) return;
  const seeded = input.seedRowIds.filter(value => value !== undefined && value !== null);
  if (seeded.length === 0) return;
  const named = Object.values(input.namedIds ?? {}).filter(value => value !== undefined && value !== null);
  const preferred = named.find(value => seeded.some(rowId => rowId === value)) ?? seeded[0];
  const pkColumn = input.pkColumn;
  const chosenRow = pkColumn
    ? (input.seedRows ?? []).find(row => row?.[pkColumn] === preferred)
    : undefined;
  // An ambiguous entity (ontologyEntityName returned '') keeps only the legacy bare key below.
  if (entity && chosenRow) {
    for (const [fieldId, value] of scalarEntriesOfSeedRow(chosenRow)) {
      putPool(pool, `${entity}.${fieldId}`, value);
      if (input.moduleId) putPool(pool, `${input.moduleId}.${entity}.${fieldId}`, value);
    }
  } else if (entity) {
    putPool(pool, `${entity}.${fieldId}`, preferred);
    if (input.moduleId) putPool(pool, `${input.moduleId}.${entity}.${fieldId}`, preferred);
  }
  putPool(pool, fieldId, preferred);
}

async function loadNamedSeedIds(): Promise<Record<string, unknown>> {
  const named: Record<string, unknown> = {};
  try {
    const config = readProjectsConfig();
    for (const project of Object.values(config.projects)) {
      for (const moduleConfig of project.persistenceModules ?? []) {
        const dir = moduleConfig.tableDefsDir;
        if (!dir) continue;
        try {
          const imported = await import(resolveProjectModuleImportUrl(`${dir.replace(/\/$/u, '')}/seeds.js`)) as { seedIds?: unknown };
          if (!isRecord(imported.seedIds)) continue;
          for (const [key, value] of Object.entries(imported.seedIds)) {
            if (value === null || value === undefined || Array.isArray(value) || isRecord(value)) continue;
            named[key] = value;
          }
        } catch {
          // T3 has not landed on this module, or there is no seeds.ts. Seed rows still apply.
        }
      }
    }
  } catch {
    // Best effort: named anchors are optional.
  }
  return named;
}

/**
 * First leftover per `Entity.fieldId` from the module's `seedSpares` export. Stored under
 * `spare:Entity.fieldId` so a create case cannot pick a value that is already on a seeded row.
 */
export function applySeedSpares(
  pool: Record<string, unknown>,
  seedSpares: unknown,
  moduleId?: string,
): void {
  if (!isRecord(seedSpares)) return;
  for (const [entity, fields] of Object.entries(seedSpares)) {
    if (!isRecord(fields)) continue;
    const entityName = entity.trim();
    if (!entityName) continue;
    for (const [fieldId, values] of Object.entries(fields)) {
      const name = fieldId.trim();
      if (!name) continue;
      const first = Array.isArray(values)
        ? values.find(value => value !== null && value !== undefined && !Array.isArray(value) && !isRecord(value))
        : undefined;
      if (first === undefined) continue;
      putPool(pool, `spare:${entityName}.${name}`, first);
      if (moduleId) putPool(pool, `spare:${moduleId}.${entityName}.${name}`, first);
    }
  }
}

async function loadSeedSparesInto(pool: Record<string, unknown>): Promise<void> {
  try {
    const config = readProjectsConfig();
    for (const project of Object.values(config.projects)) {
      for (const moduleConfig of project.persistenceModules ?? []) {
        const dir = moduleConfig.tableDefsDir;
        if (!dir) continue;
        try {
          const imported = await import(resolveProjectModuleImportUrl(`${dir.replace(/\/$/u, '')}/seeds.js`)) as { seedSpares?: unknown };
          applySeedSpares(pool, imported.seedSpares, moduleConfig.moduleId);
        } catch {
          // seedSpares is optional: modules generated before T11 simply leave create cases inconclusive.
        }
      }
    }
  } catch {
    // Best effort: without spares the affected cases stay inconclusive.
  }
}

/** Rows the monitor may harvest. Same selection as the migration; seedIds/seedSpares stay untouched. */
export function selectMonitorSeedRows(table: SeedPolicyTable, input: SeedModeInput): Record<string, unknown>[] {
  return selectEligibleSeedRows(table, input);
}

/**
 * Fill the id pool from the SEEDED table rows. Seeded ids are the most reliable source for a
 * `<seedRef>` — they do not depend on a prior read having passed, and they are the lines that
 * were actually planted.
 *
 * Some entities are reachable only by someone who already knows their id: the workspace has a detail
 * read that REQUIRES the id and no list or create route produces one (102045 changeOrderWorkspace). No
 * sequence of BFF calls can bootstrap such an id, so those cases could only ever be inconclusive — while
 * the rows that would satisfy them sit in the store, seeded and unused.
 *
 * The rows come from the backend's `seeds.ts` (TableSeedRows merged into the definitions by the
 * persistence registry) and are read HERE, on the runtime side. Eligibility is the same selection the
 * migration uses: initial in every mode, test only in a test mode (platform tables follow serverMode).
 * An anchor names that declared seed. It is not proof the row was persisted or left unedited.
 * The generated page tests only ever carry seed markers (`<seedRef>`, `<seedValue>`, `<seedSpare>`),
 * so the frontend never sees a row value — same boundary as resolveSeededActorMdmId above.
 *
 * Limits:
 *  - only a SINGLE-column primary key is harvested: that is the entity's own identifier, never a foreign
 *    key that happens to appear in several tables;
 *  - existing pool entries are never overwritten;
 *  - the value is stored as `Entity.fieldId` so a later `<seedRef>` with that fieldRef cannot pick an
 *    id harvested from a different entity.
 *
 * Caveat worth knowing when a case then fails: the first seed row is taken (unless a named seedId
 * points at another row of the same table), and it may not be in a state the command accepts
 * (e.g. an already-approved record for an approval command). That is a REAL verdict, not an
 * inconclusive one — which is the point.
 */
async function fillPoolFromSeedRows(
  pool: Record<string, unknown>,
  declaredOwnIds: Map<string, Set<string>>,
): Promise<ModuleEntityIndex> {
  const index: ModuleEntityIndex = new Map();
  try {
    const namedIds = await loadNamedSeedIds();
    const env = readAppEnv();
    const serverMode = readProjectMode(env.projectId);
    const definitions = await loadResolvedTableDefinitions(env);
    for (const definition of definitions) {
      if (definition.primaryKey?.length !== 1) continue;
      const column = definition.primaryKey[0];
      const fieldId = columnToField(column);
      const seedRows = selectMonitorSeedRows(definition, {
        tableName: definition.tableName,
        logicalTableName: definition.logicalTableName,
        projectMode: readProjectMode(definition.projectId),
        serverMode,
      });
      const seedRowIds = seedRows.map(row => row?.[column]);
      const entity = ontologyEntityName(definition, declaredOwnIds.get(definition.moduleId));
      if (entity) {
        const entries = index.get(definition.moduleId) ?? [];
        entries.push({ entity, pkFieldId: fieldId, columnFieldIds: definition.columns.map(col => columnToField(col.name)) });
        index.set(definition.moduleId, entries);
      }
      applySeedAnchors(pool, {
        entity,
        fieldId,
        seedRowIds,
        namedIds,
        moduleId: definition.moduleId,
        seedRows,
        pkColumn: column,
      });
    }
    await loadSeedSparesInto(pool);
  } catch {
    // Best effort: without it the affected cases stay inconclusive, exactly as before.
  }
  return index;
}

/** Per module, the entities a case declares by own-id fieldRef (`Petition.petitionId`). */
function declaredOwnIdEntities(files: DiscoveredTestFile[]): Map<string, Set<string>> {
  const out = new Map<string, Set<string>>();
  for (const file of files) {
    for (const testCase of file.tests?.cases ?? []) {
      for (const fieldRef of Object.values(testCase.paramFieldRefs ?? {})) {
        const entity = entityOfFieldRef(fieldRef);
        if (!entity || fieldIdOfFieldRef(fieldRef) !== `${lowerFirst(entity)}Id`) continue;
        const set = out.get(file.moduleId) ?? new Set<string>();
        set.add(entity);
        out.set(file.moduleId, set);
      }
    }
  }
  return out;
}

interface ResolvedParams {
  params: Record<string, unknown>;
  unresolved: string[];
}

/**
 * Look up a `<seedRef>` in the harvest pool.
 *
 * When the case declares a fieldRef (`Petition.petitionId`), only a value stored under that
 * entity-qualified key is accepted — never an unqualified `petitionId` that another entity's
 * read happened to expose. Files generated before paramFieldRefs existed still resolve by
 * fieldId then wire name. Missing stays unresolved — never invent an id.
 */
function lookupEntityField(
  pool: Record<string, unknown>,
  fieldRef: string | undefined,
  moduleId?: string,
): unknown {
  const entity = entityOfFieldRef(fieldRef);
  if (!entity || !fieldRef) return undefined;
  return (moduleId ? pool[`${moduleId}.${fieldRef}`] : undefined) ?? pool[fieldRef];
}

function lookupSpareField(
  pool: Record<string, unknown>,
  fieldRef: string | undefined,
  moduleId?: string,
): unknown {
  const entity = entityOfFieldRef(fieldRef);
  if (!entity || !fieldRef) return undefined;
  return (moduleId ? pool[`spare:${moduleId}.${fieldRef}`] : undefined) ?? pool[`spare:${fieldRef}`];
}

/** Own-property write: a `__proto__` key in the params stays a plain field, never the object's prototype. */
function setOwn(target: Record<string, unknown>, key: string, value: unknown): void {
  Object.defineProperty(target, key, { value, enumerable: true, writable: true, configurable: true });
}

/**
 * The fieldRef a leaf declares: the exact dotted path first (`items.0.productId`, array index included
 * when the map declares it), then the same path without array indexes (`items.productId`).
 */
function fieldRefAt(paramFieldRefs: Record<string, string> | undefined, path: string, pathNoIndex: string): string | undefined {
  if (!paramFieldRefs) return undefined;
  if (Object.prototype.hasOwnProperty.call(paramFieldRefs, path)) return paramFieldRefs[path];
  if (pathNoIndex !== path && Object.prototype.hasOwnProperty.call(paramFieldRefs, pathNoIndex)) return paramFieldRefs[pathNoIndex];
  return undefined;
}

/**
 * Resolve the seed markers of a case's params — at any depth (`details.identification.countryCode`,
 * `items.0.productId`). Only a value that IS a marker is resolved; a string merely containing one is
 * left as written. The input is never mutated: a fresh tree is returned.
 *
 * Each leaf is looked up by the fieldRef its dotted path declares. The bare-name fallback (no
 * fieldRef) applies to TOP-LEVEL keys only, as files generated before paramFieldRefs expect; a nested
 * leaf is never matched by its field name alone (that would hand another entity's id to it).
 * `unresolved` lists the full path of every marker left without a value — the caller must not run the
 * case then (a request without that value is not the case as written).
 */
export function resolveParams(
  params: Record<string, unknown>,
  pool: Record<string, unknown>,
  paramFieldRefs?: Record<string, string>,
  moduleId?: string,
): ResolvedParams {
  const unresolved: string[] = [];
  const NONE = Symbol('unresolved');
  const resolveLeaf = (value: string, path: string, pathNoIndex: string, topLevel: boolean): unknown => {
    const fieldRef = fieldRefAt(paramFieldRefs, path, pathNoIndex);
    let found: unknown;
    if (value === SEED_REF_MARKER) {
      if (entityOfFieldRef(fieldRef)) found = lookupEntityField(pool, fieldRef, moduleId);
      else {
        const fieldId = fieldIdOfFieldRef(fieldRef);
        found = (fieldId ? pool[fieldId] : undefined) ?? (topLevel ? pool[path] : undefined);
      }
    } else if (value === SEED_VALUE_MARKER) {
      found = lookupEntityField(pool, fieldRef, moduleId);
    } else {
      found = lookupSpareField(pool, fieldRef, moduleId);
    }
    if (found === undefined) {
      unresolved.push(path);
      return NONE;
    }
    return found;
  };
  const walk = (value: unknown, path: string, pathNoIndex: string, topLevel: boolean): unknown => {
    if (value === SEED_REF_MARKER || value === SEED_VALUE_MARKER || value === SEED_SPARE_MARKER) {
      return resolveLeaf(value, path, pathNoIndex, topLevel);
    }
    if (Array.isArray(value)) {
      const out: unknown[] = [];
      value.forEach((item, index) => {
        const next = walk(item, `${path}.${index}`, pathNoIndex, false);
        if (next !== NONE) out.push(next);
      });
      return out;
    }
    if (isRecord(value)) {
      const out: Record<string, unknown> = {};
      for (const [key, item] of Object.entries(value)) {
        const next = walk(item, `${path}.${key}`, `${pathNoIndex}.${key}`, false);
        if (next !== NONE) setOwn(out, key, next);
      }
      return out;
    }
    return value;
  };
  const resolved: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(params)) {
    const next = walk(value, key, key, true);
    if (next !== NONE) setOwn(resolved, key, next);
  }
  return { params: resolved, unresolved };
}

/**
 * The verdict of a case whose params still carry an unresolved seed marker: 'inconclusive', decided
 * BEFORE the request is sent. Sending it without the value (or with the literal marker) would make
 * any rejection — 401/403, required, not found — look like the case's own verdict.
 */
export function unresolvedCaseResult(
  testCase: PageTestCase,
  module: string,
  page: string,
  unresolved: string[],
  notes: string[] = [],
): TestCaseResult {
  const reason = [`unverifiable: seed marker not resolved for ${unresolved.join(', ')} (case not executed)`, ...notes.filter(Boolean)].join('; ');
  return {
    module,
    page,
    id: testCase.id,
    routine: testCase.routine,
    status: 'inconclusive',
    ok: false,
    statusCode: 0,
    durationMs: 0,
    errorCode: null,
    errorMessage: null,
    reason,
  };
}

// A non-mutating success case is a read query — run first so its output feeds the seed pool that
// resolves <seedRef> for the remaining cases.
function isReadCase(testCase: PageTestCase): boolean {
  return testCase.expect.ok && !testCase.mutating;
}

// Negative cases are generated as `<command>.<field>.required`. The case only proves what it claims
// when the rejection names that field; rejected on another field it never reached the field at all.
function fieldUnderTest(testCase: PageTestCase): string | null {
  const parts = testCase.id.split('.');
  return parts.length >= 3 && parts[parts.length - 1] === 'required' ? parts[parts.length - 2] : null;
}

function rejectedField(response: BffResponse): string | null {
  const details = response.error?.details;
  if (isRecord(details) && typeof details.field === 'string') return details.field;
  const match = /^([A-Za-z0-9_]+) is required/u.exec(response.error?.message ?? '');
  return match ? match[1] : null;
}

export function evaluate(
  testCase: PageTestCase,
  module: string,
  page: string,
  exec: { response: BffResponse; statusCode: number },
  durationMs: number,
  unresolved: string[],
): TestCaseResult {
  const { response, statusCode } = exec;
  let status: TestCaseStatus = 'pass';
  let reason = '';
  const unresolvedReason = `unverifiable: seed marker not resolved for ${unresolved.join(', ')} (param omitted from the request)`;
  if (testCase.expect.ok) {
    if (!response.ok) {
      // The omitted params are the likely cause of the rejection — the case never ran as written.
      status = unresolved.length > 0 ? 'inconclusive' : 'fail';
      reason = unresolved.length > 0 ? unresolvedReason : `expected ok, got error ${response.error?.code ?? 'unknown'}`;
    } else {
      // The output shape does not depend on the inputs, so a mismatch is real drift either way.
      const shapeReason = testCase.expect.shape ? checkShape(response.data, testCase.expect.shape, testCase.expect.itemsKey) : '';
      if (shapeReason) {
        status = 'fail';
        reason = shapeReason;
      } else if (unresolved.length > 0) {
        status = 'inconclusive';
        reason = unresolvedReason;
      } else if (testCase.expect.minItems !== undefined) {
        const count = countItems(response.data, testCase.expect.itemsKey);
        if (count < testCase.expect.minItems) {
          status = 'fail';
          reason = `expected >= ${testCase.expect.minItems} item(s), got ${count}`;
        }
      }
    }
  } else if (response.ok) {
    status = 'fail';
    reason = 'expected failure, got ok';
  } else if (testCase.expect.errorCode && response.error?.code !== testCase.expect.errorCode) {
    // Same as the positive branch: with a seed marker unresolved the case never ran as written, so a
    // different rejection (usually the omitted id) is not a verdict on the business rule.
    status = unresolved.length > 0 ? 'inconclusive' : 'fail';
    reason = unresolved.length > 0
      ? unresolvedReason
      : `expected errorCode ${testCase.expect.errorCode}, got ${response.error?.code ?? 'unknown'}`;
  } else {
    const expectedField = fieldUnderTest(testCase);
    const actualField = expectedField ? rejectedField(response) : null;
    if (expectedField && actualField !== expectedField) {
      status = 'inconclusive';
      reason = actualField
        ? `unverifiable: rejected on '${actualField}', not on the field under test '${expectedField}'`
        : `unverifiable: rejection does not name the field under test '${expectedField}'`;
    } else if (unresolved.length > 0) {
      status = 'inconclusive';
      reason = unresolvedReason;
    }
  }
  // A KNOWN failure is not the backend misbehaving: it is work already owned elsewhere. It never becomes
  // 'fail' (that count has to mean "something new broke"), and when it PASSES the mark is reported as
  // stale — the signal that the wave landed and the mark can be dropped from the generator.
  if (testCase.expectedFail) {
    if (status === 'fail') {
      status = 'knownFail';
      reason = `known issue (${testCase.expectedFail}): ${reason}`;
    } else if (status === 'pass') {
      reason = `expectedFail '${testCase.expectedFail}' no longer reproduces — drop the mark`;
    }
  }
  return {
    module,
    page,
    id: testCase.id,
    routine: testCase.routine,
    status,
    ok: response.ok,
    statusCode,
    durationMs,
    errorCode: response.error?.code ?? null,
    errorMessage: response.error?.message ?? null,
    reason,
  };
}

/** The session a declared actor's cases run with — or why they cannot run at all. */
export type ActorSessionResolution =
  | { ok: true; sessionContext: { actorId: string; actorScope: string[]; person: PlatformSessionPerson } }
  | { ok: false; reason: string };

/** Cache key of an actor session: the SAME actorRef in two modules is two different fixtures. */
export function actorSessionKey(moduleId: string, actorRef: string): string {
  return `${moduleId}\u0000${actorRef}`;
}

/**
 * The test session of an l4 actor, resolved BY DATA in the run's own sandbox runtime: agentCbSeeds emits
 * one MDM Person per actor tagged ['<module>.Person', '<module>', 'actor', '<actorRef>'], so the tags alone
 * identify it. Deliberately NOT recomputing the seed's stableUuid hash — that convention has one owner
 * (cbSeedsCore in mls-102021) and duplicating it here would create a second.
 * - `moduleName` is what the seeds tag with; `moduleId` is what the platform qualifies authorities with
 *   (`<moduleId>:<actorRef>`, the same format `withAlphaAuthorities` grants real traffic).
 * - The scope is ONLY that one authority — never every authority of the module — so the case exercises the
 *   actor it declared. The fixture only picks the identity inside the sandbox; it grants nothing to real traffic.
 * - `person` keeps the public PlatformSessionPerson shape. `email` is the fixture's login row when it declares
 *   one; otherwise '' — a simulated identity of a `source: 'test'` run, never an invented e-mail.
 * - Absent, ambiguous or inconsistent (index × document) → not ok, with the reason: the cases are blocked,
 *   never run anonymous.
 */
export async function resolveActorSession(
  data: IDataRuntime,
  input: { moduleId: string; moduleName: string; actorRef: string },
): Promise<ActorSessionResolution> {
  const { moduleId, moduleName, actorRef } = input;
  const who = `actor '${actorRef}' declared by module '${moduleName || moduleId}'`;
  try {
    const rows = await data.mdmEntityIndex.findMany({ where: {} });
    const matches = rows.filter(row => {
      const tags = Array.isArray(row.tags) ? row.tags : [];
      return tags.includes(`${moduleName}.Person`) && tags.includes(moduleName) && tags.includes('actor') && tags.includes(actorRef);
    });
    if (matches.length === 0) return { ok: false, reason: `${who} has no seeded identity — not run anonymous` };
    if (matches.length > 1) return { ok: false, reason: `${who} matches ${matches.length} seeded identities — ambiguous, not run` };
    const row = matches[0];
    if (row.subtype !== 'Person') return { ok: false, reason: `${who}: seeded identity ${row.mdmId} is indexed as '${row.subtype}', not Person` };
    const document = await data.mdmDocument.get({ mdmId: row.mdmId });
    if (!document) return { ok: false, reason: `${who}: seeded identity ${row.mdmId} has an index row but no document` };
    if (document.details.subtype !== 'Person' || document.details.mdmId !== row.mdmId) {
      return { ok: false, reason: `${who}: document of ${row.mdmId} does not match its index row (subtype '${document.details.subtype}', mdmId '${document.details.mdmId}')` };
    }
    const login = await data.mdmTag.findOne({ where: { entityId: row.mdmId, namespace: MDM_LOGIN_NAMESPACE } });
    return {
      ok: true,
      sessionContext: {
        actorId: row.mdmId,
        actorScope: [`${moduleId}:${actorRef}`],
        person: { mdmId: row.mdmId, email: login?.tag ?? '', name: document.details.name },
      },
    };
  } catch (error) {
    return { ok: false, reason: `${who}: identity lookup failed — ${error instanceof Error ? error.message : String(error)}` };
  }
}

/** Where the run's organization comes from: the configured binding and the Company role tags it declares. */
export interface RunOrganizationSource {
  binding: OrganizationBinding | null;
  /** `onboarding.companyType` (`<module>.<Entity>`) when configured: the entity the org Company plays. */
  companyTags: string[];
}

/** The organization Company of ONE run, prepared inside that run's sandbox — or why there is none. */
export type RunOrganization =
  | { ok: true; companyMdmId: string; companyTags: string[] }
  | { ok: false; reason: string; companyTags: string[] };

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/** Same resolver the boot uses (`initializeOrganizationForProcess`), read only — nothing is published. */
export function readRunOrganizationSource(): RunOrganizationSource {
  const projects = readProjectsConfig();
  const onboarding = readOnboardingConfig(projects);
  return { binding: resolveOrganizationBinding(projects), companyTags: onboarding ? [onboarding.companyType] : [] };
}

/**
 * The organization Company the session acts for, created by the platform's own `ensureOrganizationIdentity`
 * against the run's disposable runtime (reservation, transaction and Company live and die there). Never the
 * process initializer: that one writes the shared store and publishes the process-wide Company id.
 * No valid binding → not ok with the reason; no organization is invented.
 */
export async function prepareRunOrganization(
  data: IDataRuntime,
  readSource: () => RunOrganizationSource = readRunOrganizationSource,
): Promise<RunOrganization> {
  let source: RunOrganizationSource;
  try {
    source = readSource();
  } catch (error) {
    return { ok: false, reason: `organization Company unavailable: binding not resolved — ${errorText(error)}`, companyTags: [] };
  }
  if (!source.binding) {
    return { ok: false, reason: 'organization Company unavailable: no organization binding configured (none is invented)', companyTags: source.companyTags };
  }
  try {
    const ctx = createRequestContext(data, { sandbox: true });
    const { companyMdmId } = await ensureOrganizationIdentity(ctx, source.binding);
    return { ok: true, companyMdmId, companyTags: source.companyTags };
  } catch (error) {
    return { ok: false, reason: `organization Company unavailable: sandbox bootstrap failed — ${errorText(error)}`, companyTags: source.companyTags };
  }
}

function splitModuleTag(tag: string): { moduleName: string; entity: string } | null {
  const dot = tag.indexOf('.');
  if (dot <= 0) return null;
  const entity = tag.slice(dot + 1);
  return /^[A-Z][A-Za-z0-9]*$/u.test(entity) ? { moduleName: tag.slice(0, dot), entity } : null;
}

/** Entities whose anchor is the organization Company: the subtype itself and the role tags the config declares. */
function companyEntitiesOf(companyTags: string[]): Set<string> {
  const entities = new Set(['Company']);
  for (const tag of companyTags) {
    const split = splitModuleTag(tag);
    if (split) entities.add(split.entity);
  }
  return entities;
}

/** Why a case's unresolved Company marker stayed unresolved, when the run had no organization Company. */
export function organizationNote(unresolved: string[], paramFieldRefs: Record<string, string> | undefined, org: RunOrganization): string {
  if (org.ok || unresolved.length === 0) return '';
  const companyEntities = companyEntitiesOf(org.companyTags);
  // `key` is a leaf path (s4): `items.0.companyId` also matches a map declared without the index.
  return unresolved.some(key => companyEntities.has(entityOfFieldRef(fieldRefAt(paramFieldRefs, key, key.split('.').filter(part => !/^\d+$/u.test(part)).join('.'))))) ? org.reason : '';
}

interface MdmAnchorCandidate {
  index: MdmEntityIndexRecord;
  document: MdmDocumentRecord;
}

function lowerFirst(name: string): string {
  return name.charAt(0).toLowerCase() + name.slice(1);
}

function putScalars(pool: Record<string, unknown>, prefix: string, record: unknown): void {
  if (!isRecord(record)) return;
  for (const [key, value] of Object.entries(record)) putPool(pool, `${prefix}${key}`, value);
}

/**
 * Anchors for MDM-backed entities, read from the rows ACTUALLY in the run's sandbox (index + document), before
 * any read case runs. An entity is MDM only by origin: the row carries the tag `<moduleName>.<Entity>` of a
 * module in the run. Keys are always `<moduleId>.<Entity>.<field>` — never an unqualified id, so the same UUID
 * is not published as the id of every entity. Per entity: the module namespace (`details.<moduleName>`), the
 * document version, the detail scalars, and the own-id wire alias `<entity>Id` → mdmId. First row wins
 * (named seedIds first, then store order); existing keys are never overwritten. The `Company` subtype and the
 * configured company role are anchored ONLY to the run's organization Company, never to another row or a
 * Person. Nothing is created here: a fixture the module does not provide stays unresolved.
 */
export async function harvestMdmAnchors(
  pool: Record<string, unknown>,
  data: IDataRuntime,
  input: { moduleIdByName: Map<string, string>; organization: RunOrganization; namedIds?: Record<string, unknown> },
): Promise<void> {
  const { moduleIdByName, organization } = input;
  const companyMdmId = organization.ok ? organization.companyMdmId : undefined;
  const companyEntities = companyEntitiesOf(organization.companyTags);
  const named = new Set(Object.values(input.namedIds ?? {}));
  const indexRows = await data.mdmEntityIndex.findMany({ where: {} });
  const ordered = [...indexRows.filter(row => named.has(row.mdmId)), ...indexRows.filter(row => !named.has(row.mdmId))];
  const groups = new Map<string, { moduleId: string; moduleName: string; entity: string; chosen: MdmAnchorCandidate }>();
  const offer = (moduleName: string, entity: string, candidate: MdmAnchorCandidate): void => {
    const moduleId = moduleIdByName.get(moduleName);
    if (!moduleId) return;
    const key = `${moduleId}\u0000${entity}`;
    if (!groups.has(key)) groups.set(key, { moduleId, moduleName, entity, chosen: candidate });
  };

  if (companyMdmId) {
    const index = indexRows.find(row => row.mdmId === companyMdmId);
    const document = await data.mdmDocument.get({ mdmId: companyMdmId });
    if (index && document && index.subtype === 'Company' && document.details.subtype === 'Company') {
      const candidate = { index, document };
      for (const moduleName of moduleIdByName.keys()) offer(moduleName, 'Company', candidate);
      for (const tag of organization.companyTags) {
        const split = splitModuleTag(tag);
        if (split) offer(split.moduleName, split.entity, candidate);
      }
    }
  }

  for (const index of ordered) {
    if (index.mdmId === companyMdmId) continue;
    const tagged = (Array.isArray(index.tags) ? index.tags : [])
      .map(splitModuleTag)
      .filter((split): split is { moduleName: string; entity: string } => split !== null && moduleIdByName.has(split.moduleName))
      .filter(split => !companyEntities.has(split.entity));
    if (tagged.length === 0) continue;
    const document = await data.mdmDocument.get({ mdmId: index.mdmId });
    if (!document || document.mdmId !== index.mdmId || document.details.subtype !== index.subtype) continue;
    for (const split of tagged) offer(split.moduleName, split.entity, { index, document });
  }

  for (const { moduleId, moduleName, entity, chosen } of groups.values()) {
    const prefix = `${moduleId}.${entity}.`;
    const details = chosen.document.details as unknown as Record<string, unknown>;
    putScalars(pool, prefix, details[moduleName]);
    putPool(pool, `${prefix}mdmId`, chosen.index.mdmId);
    putPool(pool, `${prefix}version`, chosen.document.version);
    putScalars(pool, prefix, details);
    putPool(pool, `${prefix}${lowerFirst(entity)}Id`, chosen.index.mdmId);
  }
}

export async function runPageTests(input: { moduleId?: string; page?: string; skipMutating?: boolean } = {}): Promise<TestRunSummary> {
  const env = readAppEnv();
  // Commented out by the new version: the hard TESTS_ENABLED/appEnv server-side
  // block was replaced by a client-side confirmation in the Monitor UI
  // (home.ts renderTestsExecutionGate) — the checkbox shows a localhost-
  // specific or production-specific warning and requires explicit opt-in per
  // session before enabling the Run buttons. Safe to relax server-side because
  // every run below is already sandboxed in its own disposable in-memory
  // runtime (see createMemoryDataRuntime below) — it never reads or writes the
  // process's real Postgres tables regardless of environment.
  // if (!env.testsEnabled) {
  //   throw new AppError('TESTS_DISABLED', 'BFF test execution is disabled (set TESTS_ENABLED=true to allow it).', 403, { appEnv: env.appEnv });
  // }

  const runId = createUuidV7();
  const traceId = createUuidV7();
  const startedAt = new Date().toISOString();
  const files = (await discoverTestFiles({ moduleId: input.moduleId, page: input.page })).filter(file => file.tests);
  // Sandbox: a runtime built for this run only (tables + mdm seeded from the definitions on first
  // access) — never the process singleton, so nobody else's data is in reach and the mutating cases
  // need no transaction/rollback because the whole store is discarded with the run.
  // ONE runtime for the whole run; every context below shares it, so the store (and the harvested ids)
  // are the same no matter which actor a page runs as.
  const dataRuntime = createMemoryDataRuntime({ sandbox: true });
  // The organization Company every context acts for (activeCompanyId), prepared in THIS sandbox by the
  // platform's own bootstrap — never the process-wide one. Without a binding the cases still run; the ones
  // whose Company marker cannot resolve say why.
  const organization = await prepareRunOrganization(dataRuntime);
  const companySession = organization.ok ? { activeCompanyId: organization.companyMdmId } : {};
  const baseCtx = createRequestContext(dataRuntime, { sandbox: true, sessionContext: companySession });
  const cases: TestCaseResult[] = [];

  // A context per (module, ACTOR) pair: the page's routes see the seeded Person of THAT module as the
  // session, with the qualified authority `<moduleId>:<actorRef>` — the shape `enforceActors` accepts —
  // never the bare actorRef (that 403'd every route) and never an empty "permissive" scope. Cached by the
  // pair: two modules declaring the same actorRef are two fixtures. No declared actor → the anonymous
  // baseCtx, as before. A declared actor whose Person is absent, ambiguous or inconsistent → `blocked`
  // with the reason, never run anonymous (that produced a false "defect" red for a missing seed).
  const sessionByActor = new Map<string, { ctx: RequestContext; mdmId: string } | { blocked: string }>();
  const contextFor = async (file: DiscoveredTestFile): Promise<{ ctx: RequestContext; mdmId?: string } | { blocked: string }> => {
    const actorRef = typeof file.tests?.actor === 'string' ? file.tests.actor.trim() : '';
    if (!actorRef) return { ctx: baseCtx };
    const key = actorSessionKey(file.moduleId, actorRef);
    const cached = sessionByActor.get(key);
    if (cached) return cached;
    const resolved = await resolveActorSession(dataRuntime, {
      moduleId: file.moduleId,
      moduleName: file.tests?.moduleName || file.moduleId,
      actorRef,
    });
    const entry = resolved.ok
      ? { ctx: createRequestContext(dataRuntime, { sandbox: true, sessionContext: { ...resolved.sessionContext, ...companySession } }), mdmId: resolved.sessionContext.actorId }
      : { blocked: resolved.reason };
    sessionByActor.set(key, entry);
    return entry;
  };

  // ONE pool per RUN, not per page: the sandbox store is created once above, so an id harvested by any
  // page's read is valid for every other page. With a per-page pool the ids were thrown away and a page
  // whose own reads all require an id could never arm itself (102045 run06: projectId/workTaskId/
  // assignedWorkerId were harvested by dashboardWorkspace and then discarded, leaving 7 cases
  // inconclusive). harvestRecord does not overwrite an existing key, so the FIRST value harvested for a
  // given field name wins — deterministic given the phase order below.
  // Seed anchors go in FIRST: a `<seedRef>` with fieldRef `Petition.petitionId` must resolve to a
  // planted Petition row even when no prior read of Petition succeeded (or when another entity's
  // read exposed a different `petitionId` first).
  const pool: Record<string, unknown> = {};
  const declaredOwnIds = declaredOwnIdEntities(files);
  const entityIndex = await fillPoolFromSeedRows(pool, declaredOwnIds);
  const harvestCompany: HarvestCompany | undefined = organization.ok
    ? { companyMdmId: organization.companyMdmId, entities: companyEntitiesOf(organization.companyTags) }
    : undefined;
  // MDM anchors from the rows actually loaded in the sandbox, after the table seeds (those keep their keys).
  let anchorNote = '';
  try {
    const moduleIdByName = new Map<string, string>();
    for (const file of files) moduleIdByName.set(file.tests!.moduleName || file.moduleId, file.moduleId);
    await harvestMdmAnchors(pool, dataRuntime, { moduleIdByName, organization, namedIds: await loadNamedSeedIds() });
  } catch (error) {
    anchorNote = `MDM anchors not harvested — ${errorText(error)}`;
  }

  // Every successful response feeds the pool, whatever the case's own verdict was — a read that
  // fails its shape assertion still carries the ids the later cases need.
  const runOne = async (file: DiscoveredTestFile, testCase: PageTestCase): Promise<TestCaseResult> => {
    const tests = file.tests!;
    const session = await contextFor(file);
    if ('blocked' in session) {
      // Never fall through to baseCtx for a case that declared an actor: that ran it anonymous and
      // reported a false app-defect red. The real cause is the fixture, so the case is 'blocked',
      // not run, and the reason names the actor and module so it can be fixed at the source.
      return {
        module: file.moduleId,
        page: tests.page,
        id: testCase.id,
        routine: testCase.routine,
        status: 'blocked',
        ok: false,
        statusCode: 0,
        durationMs: 0,
        errorCode: null,
        errorMessage: null,
        reason: session.blocked,
      };
    }
    const { params, unresolved } = resolveParams(testCase.params, pool, testCase.paramFieldRefs, file.moduleId);
    if (unresolved.length > 0) {
      return unresolvedCaseResult(testCase, file.moduleId, tests.page, unresolved, [organizationNote(unresolved, testCase.paramFieldRefs, organization), anchorNote]);
    }
    const request: BffRequest = { routine: testCase.routine, params, meta: { source: 'test', traceId, requestId: createUuidV7() } };
    const startedMs = Date.now();
    const exec = await execBff(request, session.ctx);
    if (exec.response.ok) harvestRows(pool, exec.response.data, file.moduleId, entityIndex, harvestCompany);
    return evaluate(testCase, file.moduleId, tests.page, exec, Math.max(0, Date.now() - startedMs), unresolved);
  };

  // Both phases are GLOBAL (all files, then all files) — not per file. Hoisting the pool alone would
  // leave the outcome dependent on file order: in run06 changeOrderWorkspace ran BEFORE
  // dashboardWorkspace, so its commands would still have seen an empty pool.
  // Phase A: every read query of every page — they build the seed pool for everything else.
  for (const file of files) {
    for (const testCase of file.tests!.cases) {
      if (!isReadCase(testCase)) continue;
      cases.push(await runOne(file, testCase));
    }
  }

  // Between the phases: fill the gaps the reads could not cover, from the SEEDED rows.
  await fillPoolFromSeedRows(pool, declaredOwnIds);

  // Phase B: negative cases and commands — <seedRef> now resolves from the whole run's pool.
  for (const file of files) {
    const tests = file.tests!;
    for (const testCase of tests.cases) {
      if (isReadCase(testCase)) continue;
      if (testCase.mutating && input.skipMutating) {
        cases.push({ module: file.moduleId, page: tests.page, id: testCase.id, routine: testCase.routine, status: 'skipped', ok: false, statusCode: 0, durationMs: 0, errorCode: null, errorMessage: null, reason: 'mutating case skipped (skipMutating)' });
        continue;
      }
      cases.push(await runOne(file, testCase));
    }
  }

  const catalogs = (await discoverBackendCatalogs({ moduleId: input.moduleId }))
    .filter(file => !input.page || file.catalog?.scenarios.some(scenario => scenario.scenarioId === input.page) || file.loadError);
  for (const file of catalogs) {
    if (!file.catalog || file.broken !== 'none') {
      cases.push({
        module: file.moduleId,
        page: 'backend',
        id: 'catalog',
        routine: '',
        status: 'fail',
        ok: false,
        statusCode: 0,
        durationMs: 0,
        errorCode: null,
        errorMessage: file.loadError ?? null,
        reason: `${file.broken === 'none' ? 'import' : file.broken} broken is not an expected failure`,
      });
      continue;
    }
    const scenarios = input.page
      ? file.catalog.scenarios.filter(scenario => scenario.scenarioId === input.page)
      : file.catalog.scenarios;
    for (const scenario of scenarios) {
      const stage = stageOfHandler(scenario.handlerId);
      for (const item of scenario.cases) {
        // Catalog v1.1 `case.runner`. Absent (a v1 catalog) means 'route': everything the monitor
        // already executed keeps being executed exactly as before.
        if (runnerOf(item) === 'module') {
          // Checked BEFORE `skipMutating`: a module case is never executed by execBff at all, so
          // "skipped because mutating" would be a false reason for it.
          cases.push({
            module: file.moduleId,
            page: scenario.scenarioId,
            id: item.caseId,
            routine: item.routine,
            status: 'moduleOnly',
            ok: false,
            statusCode: 0,
            durationMs: 0,
            errorCode: null,
            errorMessage: null,
            reason: 'module case: the monitor does not execute runner: module cases yet',
            stage,
            expectationSource: item.source,
            expectation: item.expectation,
          });
          continue;
        }
        if (item.mutating && input.skipMutating) {
          cases.push({
            module: file.moduleId,
            page: scenario.scenarioId,
            id: item.caseId,
            routine: item.routine,
            status: 'skipped',
            ok: false,
            statusCode: 0,
            durationMs: 0,
            errorCode: null,
            errorMessage: null,
            reason: 'mutating case skipped (skipMutating)',
            stage,
            expectationSource: item.source,
            expectation: item.expectation,
          });
          continue;
        }
        const session = await contextFor({
          projectId: file.projectId,
          moduleId: file.moduleId,
          path: file.path,
          tests: { moduleName: file.catalog.moduleName, page: scenario.scenarioId, variant: scenario.handlerId, actor: item.actorId, cases: [] },
        });
        if ('blocked' in session) {
          // Same rule as the page cases: a declared actor without a valid seeded Person is not run anonymous.
          cases.push({
            module: file.moduleId,
            page: scenario.scenarioId,
            id: item.caseId,
            routine: item.routine,
            status: 'blocked',
            ok: false,
            statusCode: 0,
            durationMs: 0,
            errorCode: null,
            errorMessage: null,
            reason: session.blocked,
            stage,
            expectationSource: item.source,
            expectation: item.expectation,
          });
          continue;
        }
        const startedMs = Date.now();
        let observation: M1Observation;
        try {
          const caller = callerOf(item);
          const request: BffRequest = {
            routine: item.routine,
            params: paramsForCatalogCase(item),
            meta: {
              source: caller.source,
              verifiedAuthorities: caller.authorities,
              traceId,
              requestId: createUuidV7(),
              // Telemetry/back-compat only, and the RESOLVED mdmId, not the actorRef: for `source: 'test'`
              // execBff promotes meta.actorId over the session's, so the bare actorRef would replace the
              // seeded Person. With `source: 'http'` it is discarded by `trustedIdentityClaims`; either way
              // the identity that reaches the handler is the one `contextFor` put in the session.
              actorId: session.mdmId,
            },
          };
          const exec = await execBff(request, session.ctx);
          observation = observationFromExec(item.caseId, Math.max(0, Date.now() - startedMs), exec, {
            actorField: item.expect.isolatedActorField,
          });
        } catch (error) {
          observation = observationFromExec(item.caseId, Math.max(0, Date.now() - startedMs), null, {
            broken: 'transport',
          });
          observation.reason = error instanceof Error ? error.message : String(error);
        }
        const verdict = verdictForCatalogCase(stage, item, observation);
        cases.push({
          module: file.moduleId,
          page: scenario.scenarioId,
          id: item.caseId,
          routine: item.routine,
          status: statusFromVerdict(verdict.verdict),
          ok: observation.ok,
          statusCode: observation.status,
          durationMs: observation.durationMs,
          errorCode: observation.errorCode,
          errorMessage: observation.reason || null,
          reason: verdict.detail,
          stage,
          expectationSource: item.source,
          expectation: item.expectation,
        });
      }
    }
  }

  const reported = reportAppEnv(files[0]?.projectId ?? catalogs[0]?.projectId ?? env.projectId);
  const coverage = emptyRunCoverage(files.length + catalogs.length);
  const untested = cases.length === 0;
  const summary: TestRunSummary = {
    runId,
    traceId,
    startedAt,
    finishedAt: new Date().toISOString(),
    appEnv: reported.appEnv,
    appEnvSource: reported.appEnvSource,
    serverAppEnv: reported.serverAppEnv,
    scope:{ moduleId: input.moduleId, page: input.page },
    total: cases.length,
    passed: cases.filter(c => c.status === 'pass').length,
    failed: cases.filter(c => c.status === 'fail').length,
    knownFail: cases.filter(c => c.status === 'knownFail').length,
    expectedRed: cases.filter(c => c.status === 'expectedRed').length,
    moduleOnly: cases.filter(c => c.status === 'moduleOnly').length,
    blocked: cases.filter(c => c.status === 'blocked').length,
    inconclusive: cases.filter(c => c.status === 'inconclusive').length,
    skipped: cases.filter(c => c.status === 'skipped').length,
    untested,
    untestedReason: untested
      ? (coverage.untestedReason || 'não testado: registered suite produced no cases')
      : '',
    cases,
  };
  storeRun(summary);
  return summary;
}

// ---- results ----

export function loadTestResults(input: { moduleId?: string; page?: string; runId?: string; limit?: number } = {}): { recentRuns: TestRunSummary[] } {
  return { recentRuns: getRecentRuns({ moduleId: input.moduleId, page: input.page, runId: input.runId }, input.limit ?? 20) };
}

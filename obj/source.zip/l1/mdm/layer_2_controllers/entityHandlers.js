/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/entityHandlers.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
export const entityCreateHandler = async ({ ctx, request }) => ok(await ctx.mdm.entity.create({
    details: request.params.detail,
}));
export const entityGetHandler = async ({ ctx, request }) => ok(await ctx.mdm.entity.get({ mdmId: String(request.params.mdmId) }));
export const entityListHandler = async ({ ctx, request }) => {
    const params = (request.params ?? {});
    const type = params.type ?? params.moduleType;
    if (!type) {
        throw new AppError('INVALID_MDM_LIST_INPUT', 'mdm.entity.list requires canonical type/moduleType', 400);
    }
    return ok(await ctx.mdm.collection.listByType({
        ...params,
        type,
    }));
};
export const entityUpdateHandler = async ({ ctx, request }) => ok(await ctx.mdm.entity.update(request.params));

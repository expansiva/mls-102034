/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/prospectFacadeHandlers.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
export const prospectCreateHandler = async ({ ctx, request }) => ok(await ctx.mdm.prospect.create({
    details: request.params.detail,
}));
export const prospectGetHandler = async ({ ctx, request }) => ok(await ctx.mdm.prospect.get({ mdmId: String(request.params.mdmId) }));
export const prospectListHandler = async ({ ctx, request }) => {
    const params = (request.params ?? {});
    const type = params.type ?? params.moduleType;
    if (!type) {
        throw new AppError('INVALID_MDM_PROSPECT_LIST_INPUT', 'mdm.prospect.list requires canonical type/moduleType', 400);
    }
    return ok(await ctx.mdm.prospect.listByType({
        ...params,
        type,
    }));
};
export const prospectUpdateHandler = async ({ ctx, request }) => ok(await ctx.mdm.prospect.update(request.params));
export const prospectPromoteToEntityHandler = async ({ ctx, request }) => ok(await ctx.mdm.prospect.promoteToEntity({
    mdmId: String(request.params.mdmId),
}));

import { createPostgresModuleDataRuntime } from '/_102034_/l1/server/layer_1_external/data/moduleDataRuntime.js';
import { createRuntimeUuid } from '/_102029_/l2/webCrypto.js';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getMdmTableNames } from '/_102034_/l1/mdm/tableNames.js';
import { getSharedPgPool, queryRows, withPgTransaction } from '/_102034_/l1/mdm/layer_1_external/data/postgres/pg.js';
function quoteIdentifier(identifier) {
    return `"${identifier}"`;
}
function buildWhereClause(where, startIndex = 1) {
    const entries = Object.entries(where ?? {}).filter(([, value]) => value !== undefined);
    if (entries.length === 0) {
        return {
            sql: '',
            params: [],
        };
    }
    const params = [];
    return {
        sql: `WHERE ${entries
            .map(([key, value]) => {
            if (value === null) {
                return `${quoteIdentifier(key)} IS NULL`;
            }
            params.push(value);
            return `${quoteIdentifier(key)} = $${startIndex + params.length - 1}`;
        })
            .join(' AND ')}`,
        params,
    };
}
class TableRuntimePostgres {
    constructor(executor, tableName) {
        this.executor = executor;
        this.tableName = tableName;
    }
    async findOne(input) {
        const where = buildWhereClause(input.where);
        const rows = await queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.tableName)} ${where.sql} LIMIT 1`, where.params);
        return rows[0] ?? null;
    }
    async findMany(input) {
        const where = buildWhereClause(input?.where);
        const orderSql = input?.orderBy
            ? `ORDER BY ${quoteIdentifier(String(input.orderBy.field))} ${input.orderBy.direction.toUpperCase()}`
            : '';
        const limitSql = input?.limit ? `LIMIT ${input.limit}` : '';
        return queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.tableName)} ${where.sql} ${orderSql} ${limitSql}`.trim(), where.params);
    }
    async findManyByValues(input) {
        if (input.values.length === 0) {
            return [];
        }
        const limitSql = input.limit ? `LIMIT ${input.limit}` : '';
        return queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.tableName)} WHERE ${quoteIdentifier(String(input.field))} = ANY($1) ${limitSql}`.trim(), [input.values]);
    }
    async insert(input) {
        const entries = Object.entries(input.record);
        const columns = entries.map(([key]) => quoteIdentifier(key));
        const placeholders = entries.map((_, index) => `$${index + 1}`);
        await this.executor.query(`INSERT INTO ${quoteIdentifier(this.tableName)} (${columns.join(', ')}) VALUES (${placeholders.join(', ')})`, entries.map(([, value]) => value));
    }
    async update(input) {
        const patchEntries = Object.entries(input.patch).filter(([, value]) => value !== undefined);
        if (patchEntries.length === 0) {
            return;
        }
        const where = buildWhereClause(input.where, patchEntries.length + 1);
        const setSql = patchEntries
            .map(([key], index) => `${quoteIdentifier(key)} = $${index + 1}`)
            .join(', ');
        await this.executor.query(`UPDATE ${quoteIdentifier(this.tableName)} SET ${setSql} ${where.sql}`.trim(), [...patchEntries.map(([, value]) => value), ...where.params]);
    }
    async delete(input) {
        const where = buildWhereClause(input.where);
        await this.executor.query(`DELETE FROM ${quoteIdentifier(this.tableName)} ${where.sql}`.trim(), where.params);
    }
}
class DocumentRuntimePostgres {
    constructor(executor, tableName) {
        this.executor = executor;
        this.tableName = tableName;
    }
    async get(input) {
        const rows = await queryRows(this.executor, `SELECT "mdmId", "version", "details" FROM "${this.tableName}" WHERE "mdmId" = $1 LIMIT 1`, [input.mdmId]);
        return rows[0] ?? null;
    }
    async getMany(input) {
        if (input.mdmIds.length === 0) {
            return [];
        }
        return queryRows(this.executor, `SELECT "mdmId", "version", "details" FROM "${this.tableName}" WHERE "mdmId" = ANY($1)`, [input.mdmIds]);
    }
    async put(input) {
        // Mechanically sync details.mdmId from the record id (single source of truth) so callers may omit it.
        const details = { ...input.record.details, mdmId: input.record.mdmId };
        if (input.expectedVersion !== undefined && input.expectedVersion !== null) {
            const result = await this.executor.query(`UPDATE "${this.tableName}" SET "version" = $2, "details" = $3::jsonb WHERE "mdmId" = $1 AND "version" = $4`, [input.record.mdmId, input.record.version, details, input.expectedVersion]);
            if (result.rowCount === 0) {
                throw new AppError('CONCURRENCY_CONFLICT', 'Version mismatch', 409);
            }
            return;
        }
        await this.executor.query(`INSERT INTO "${this.tableName}" ("mdmId", "version", "details")
       VALUES ($1, $2, $3::jsonb)
       ON CONFLICT ("mdmId") DO UPDATE SET "version" = EXCLUDED."version", "details" = EXCLUDED."details"`, [input.record.mdmId, input.record.version, details]);
    }
    async delete(input) {
        await this.executor.query(`DELETE FROM "${this.tableName}" WHERE "mdmId" = $1`, [input.mdmId]);
    }
}
class QueueRuntimePostgres {
    constructor(executor, outboxTableName) {
        this.executor = executor;
        this.outboxTableName = outboxTableName;
    }
    async publish(input) {
        const payload = input.payload;
        const nowIso = new Date().toISOString();
        await this.executor.query(`INSERT INTO ${quoteIdentifier(this.outboxTableName)}
       ("id", "aggregateType", "aggregateId", "eventType", "payload", "attemptCount", "processedAt", "lastError", "createdAt", "updatedAt", "topic")
       VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7, $8, $9, $10, $11)`, [
            String(payload.id ?? createRuntimeUuid()),
            String(payload.aggregateType ?? 'QueueMessage'),
            String(payload.aggregateId ?? input.topic),
            String(payload.eventType ?? 'QueuePublish'),
            JSON.stringify(payload),
            Number(payload.attemptCount ?? 0),
            payload.processedAt ?? nowIso,
            payload.lastError ?? null,
            String(payload.createdAt ?? nowIso),
            String(payload.updatedAt ?? nowIso),
            input.topic,
        ]);
    }
    async list(input) {
        const rows = await queryRows(this.executor, input?.topic
            ? `SELECT "topic", "payload" FROM ${quoteIdentifier(this.outboxTableName)} WHERE "topic" = $1 ORDER BY "createdAt" ASC`
            : `SELECT "topic", "payload" FROM ${quoteIdentifier(this.outboxTableName)} ORDER BY "createdAt" ASC`, input?.topic ? [input.topic] : []);
        return rows.map((row) => ({ topic: row.topic, payload: row.payload }));
    }
}
function createPostgresRuntimeWithExecutor(env, executor) {
    const tableNames = getMdmTableNames(env.appEnv);
    const runtime = {
        mode: 'postgres',
        mdmDocument: new DocumentRuntimePostgres(executor, tableNames.documents),
        mdmEntityIndex: new TableRuntimePostgres(executor, tableNames.documentsEntitiesIndex),
        mdmProspectIndex: new TableRuntimePostgres(executor, tableNames.documentsProspectsIndex),
        mdmRelationship: new TableRuntimePostgres(executor, tableNames.relationship),
        mdmProspectRelationship: new TableRuntimePostgres(executor, tableNames.prospectRelationship),
        mdmAuditLog: new TableRuntimePostgres(executor, tableNames.auditLog),
        mdmComment: new TableRuntimePostgres(executor, tableNames.comment),
        mdmAttachment: new TableRuntimePostgres(executor, tableNames.attachment),
        mdmNumberSequence: new TableRuntimePostgres(executor, tableNames.numberSequence),
        mdmMonitoringWrite: new TableRuntimePostgres(executor, tableNames.monitoringWrite),
        mdmErrorLog: new TableRuntimePostgres(executor, tableNames.errorLog),
        mdmStatusHistory: new TableRuntimePostgres(executor, tableNames.statusHistory),
        mdmTag: new TableRuntimePostgres(executor, tableNames.tag),
        mdmOutbox: new TableRuntimePostgres(executor, tableNames.outbox),
        pgQueue: new QueueRuntimePostgres(executor, tableNames.outbox),
        moduleData: createPostgresModuleDataRuntime(env, executor),
        async runInTransaction() {
            throw new AppError('INVALID_RUNTIME', 'Nested transaction runtime is not supported directly', 500);
        },
    };
    runtime.runInTransaction = async (callback) => {
        if ('release' in executor) {
            return callback(runtime);
        }
        return withPgTransaction(executor, async (client) => callback(createPostgresRuntimeWithExecutor(env, client)));
    };
    return runtime;
}
export function createPostgresDataRuntime(env) {
    return createPostgresRuntimeWithExecutor(env, getSharedPgPool(env));
}

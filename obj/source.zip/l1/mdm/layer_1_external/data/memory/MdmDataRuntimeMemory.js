/// <mls fileReference="_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { projectsConfigExists } from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import { createMemoryModuleDataRuntime } from '/_102034_/l1/server/layer_1_external/data/moduleDataRuntime.js';
import { findResolvedTableDefinition } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
async function loadSeedRows(env, repositoryName) {
    if (!projectsConfigExists()) {
        return [];
    }
    try {
        const definition = await findResolvedTableDefinition(repositoryName, env);
        return (definition.seedRows ?? []).map((row) => ({ ...row }));
    }
    catch {
        return [];
    }
}
function matchesWhere(record, where) {
    if (!where) {
        return true;
    }
    return Object.entries(where).every(([key, value]) => {
        if (value === undefined) {
            return true;
        }
        return record[key] === value;
    });
}
class TableRuntimeMemory {
    constructor(seedLoader) {
        this.seedLoader = seedLoader;
        this.records = [];
        this.seeded = false;
    }
    async ensureSeeded() {
        if (this.seeded) {
            return;
        }
        this.seeded = true;
        const rows = this.seedLoader ? await this.seedLoader() : [];
        this.records.push(...rows);
    }
    async findOne(input) {
        await this.ensureSeeded();
        const record = this.records.find((current) => matchesWhere(current, input.where));
        return record ? { ...record } : null;
    }
    async findMany(input) {
        await this.ensureSeeded();
        const records = this.records.filter((record) => matchesWhere(record, input?.where));
        if (input?.orderBy) {
            const { field, direction } = input.orderBy;
            records.sort((left, right) => {
                const leftValue = String(left[String(field)] ?? '');
                const rightValue = String(right[String(field)] ?? '');
                if (leftValue === rightValue) {
                    return 0;
                }
                return direction === 'asc'
                    ? leftValue.localeCompare(rightValue)
                    : rightValue.localeCompare(leftValue);
            });
        }
        const result = input?.limit ? records.slice(0, input.limit) : records;
        return result.map((record) => ({ ...record }));
    }
    async findManyByValues(input) {
        await this.ensureSeeded();
        const valueSet = new Set(input.values);
        const records = this.records.filter((record) => valueSet.has(record[String(input.field)]));
        const result = input.limit ? records.slice(0, input.limit) : records;
        return result.map((record) => ({ ...record }));
    }
    async insert(input) {
        await this.ensureSeeded();
        this.records.push({ ...input.record });
    }
    async update(input) {
        await this.ensureSeeded();
        const record = this.records.find((current) => matchesWhere(current, input.where));
        if (!record) {
            throw new AppError('NOT_FOUND', 'Record not found', 404, input.where);
        }
        Object.assign(record, input.patch);
    }
    async delete(input) {
        await this.ensureSeeded();
        const filtered = this.records.filter((record) => !matchesWhere(record, input.where));
        this.records.length = 0;
        this.records.push(...filtered);
    }
}
class DocumentRuntimeMemory {
    constructor(seedLoader) {
        this.seedLoader = seedLoader;
        this.records = new Map();
        this.seeded = false;
    }
    async ensureSeeded() {
        if (this.seeded) {
            return;
        }
        this.seeded = true;
        const rows = this.seedLoader ? await this.seedLoader() : [];
        for (const row of rows) {
            this.records.set(row.mdmId, { ...row, details: { ...row.details } });
        }
    }
    async get(input) {
        await this.ensureSeeded();
        const record = this.records.get(input.mdmId);
        return record ? { ...record } : null;
    }
    async getMany(input) {
        await this.ensureSeeded();
        return input.mdmIds
            .map((mdmId) => this.records.get(mdmId))
            .filter((record) => record !== undefined)
            .map((record) => ({ ...record }));
    }
    async put(input) {
        await this.ensureSeeded();
        // Mechanically sync details.mdmId from the record id (single source of truth) so callers may omit it.
        const record = { ...input.record, details: { ...input.record.details, mdmId: input.record.mdmId } };
        const currentRecord = this.records.get(record.mdmId);
        if (input.expectedVersion !== undefined && input.expectedVersion !== null) {
            if (!currentRecord || currentRecord.version !== input.expectedVersion) {
                throw new AppError('CONCURRENCY_CONFLICT', 'Version mismatch', 409, {
                    expectedVersion: input.expectedVersion,
                    currentVersion: currentRecord?.version ?? null,
                });
            }
        }
        if (currentRecord && input.expectedVersion === undefined) {
            throw new AppError('DOCUMENT_EXISTS', 'Document already exists', 409, {
                mdmId: record.mdmId,
            });
        }
        this.records.set(record.mdmId, record);
    }
    async delete(input) {
        await this.ensureSeeded();
        this.records.delete(input.mdmId);
    }
}
class QueueRuntimeMemory {
    constructor() {
        this.records = [];
    }
    async publish(input) {
        this.records.push({ ...input });
    }
    async list(input) {
        return input?.topic
            ? this.records.filter((record) => record.topic === input.topic)
            : [...this.records];
    }
}
export function createMemoryDataRuntime() {
    const env = readAppEnv();
    const runtime = {
        mode: 'memory',
        mdmDocument: new DocumentRuntimeMemory(() => loadSeedRows(env, 'mdmDocumentCache')),
        mdmEntityIndex: new TableRuntimeMemory(() => loadSeedRows(env, 'mdmEntityIndex')),
        mdmProspectIndex: new TableRuntimeMemory(),
        mdmRelationship: new TableRuntimeMemory(),
        mdmProspectRelationship: new TableRuntimeMemory(),
        mdmAuditLog: new TableRuntimeMemory(),
        mdmComment: new TableRuntimeMemory(),
        mdmAttachment: new TableRuntimeMemory(),
        mdmNumberSequence: new TableRuntimeMemory(),
        mdmMonitoringWrite: new TableRuntimeMemory(),
        mdmErrorLog: new TableRuntimeMemory(),
        mdmStatusHistory: new TableRuntimeMemory(),
        mdmTag: new TableRuntimeMemory(),
        mdmOutbox: new TableRuntimeMemory(),
        pgQueue: new QueueRuntimeMemory(),
        moduleData: createMemoryModuleDataRuntime(env),
        async runInTransaction(callback) {
            return callback(runtime);
        },
    };
    return runtime;
}

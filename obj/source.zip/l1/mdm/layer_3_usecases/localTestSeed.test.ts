/// <mls fileReference="_102034_/l1/mdm/layer_3_usecases/localTestSeed.test.ts" enhancement="_blank" />
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, test } from 'node:test';
import { fileURLToPath } from 'node:url';

import type { ProjectsConfig } from '/_102029_/l2/runtimeConfigTypes.js';
import type { OrganizationBinding } from '/_102034_/l1/server/layer_1_external/config/onboardingConfig.js';
import { resetProjectsConfigCache } from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
import { resetResolvedTableDefinitionsCache } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { createRequestContext } from '/_102034_/l1/server/layer_2_controllers/execBff.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { createMemoryDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.js';
import { ensureOrganizationCompany, ensureOrganizationIdentity } from '/_102034_/l1/mdm/layer_3_usecases/organizationBootstrap.js';
import { ensureLocalTestPair, localTestEmail, localTestSub } from '/_102034_/l1/mdm/layer_3_usecases/localTestSeed.js';
import { assertLocalSeedEnvironment } from '/_102034_/l1/scripts/seedLocalTest.js';

const previousCwd = process.cwd();
const workspace = mkdtempSync(join(tmpdir(), 'rt85-s1-'));

before(() => {
  symlinkSync(fileURLToPath(new URL('../../..', import.meta.url)), join(workspace, 'mls-102034'));
  writeFileSync(join(workspace, 'config.json'), JSON.stringify({
    defaultProjectId: '102047',
    projects: {
      '102047': {
        root: './client',
        type: 'client',
        persistenceModules: [{
          moduleId: 'mdm',
          persistenceEntrypoint: './_102034_/l1/mdm/persistence.js',
        }],
      },
      '102029': { root: './fe', type: 'master frontend' },
      '102034': { root: './be', type: 'master backend' },
    },
  }));
  process.chdir(workspace);
  resetProjectsConfigCache();
  resetResolvedTableDefinitionsCache();
});

after(() => {
  process.chdir(previousCwd);
  resetProjectsConfigCache();
  resetResolvedTableDefinitionsCache();
  rmSync(workspace, { recursive: true, force: true });
});

function ctxAt(day: string): RequestContext {
  const ctx = createRequestContext(createMemoryDataRuntime());
  ctx.clock = { nowIso: () => `${day}T15:00:00.000Z` };
  return ctx;
}

function binding(): OrganizationBinding {
  return { key: 'org-bench', name: 'Bench Org', source: 'project-file' };
}

function projectsConfig(projectId = '102047', moduleIds: string[] = [], withOnboarding = true): ProjectsConfig {
  return {
    defaultProjectId: projectId,
    ...(withOnboarding ? {
      onboarding: {
        moduleId: 'mod-bench',
        entryPath: '/inicio',
        personType: 'Member',
        companyType: 'mod-bench.Company',
      },
    } : { organization: { source: 'development-project' } }),
    projects: moduleIds.length === 0 ? {} : {
      [projectId]: {
        root: './client',
        type: 'client',
        modules: moduleIds.map((moduleId) => ({ moduleId, basePath: '/', shellMode: 'spa' as const })),
      },
    },
  } as ProjectsConfig;
}

test('three bench people share one company and stay incomplete', async () => {
  const ctx = ctxAt('2026-10-18');
  const seeded = await ensureLocalTestPair(ctx, projectsConfig(), binding());
  assert.equal(seeded.organizationKey, 'org-bench');
  assert.equal(seeded.personas.length, 3);
  assert.notEqual(seeded.personas[0].personMdmId, seeded.personas[1].personMdmId);
  assert.notEqual(seeded.personas[0].email, seeded.personas[1].email);
  const companies = new Set<string>();
  for (const persona of seeded.personas) {
    assert.equal(persona.email, localTestEmail('102047', persona.alias));
    assert.equal(persona.sub, localTestSub('102047', persona.alias));
    assert.notEqual(persona.sub, persona.personMdmId);
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.subtype, 'Person');
    assert.equal(person.details.countryCode, '');
    assert.equal(person.details.privacyConsent ?? null, null);
    assert.equal(await ctx.mdm.identity.findByLogin(persona.email), persona.personMdmId);
    const links = await ctx.data.mdmRelationship.findMany({ where: { fromId: persona.personMdmId, type: 'AssignedTo' } });
    assert.equal(links.length, 1);
    assert.equal(links[0].toId, seeded.companyMdmId);
    assert.equal(links[0].status, 'Active');
    companies.add(links[0].toId);
  }
  assert.equal(companies.size, 1);
  const people = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } });
  assert.equal(people.length, 3);
});

test('a repeat keeps ids and tester-filled data without a new version', async () => {
  const ctx = ctxAt('2026-10-18');
  const first = await ensureLocalTestPair(ctx, projectsConfig(), binding());
  const target = first.personas[0];
  const current = await ctx.mdm.entity.get({ mdmId: target.personMdmId });
  await ctx.mdm.entity.update({
    mdmId: target.personMdmId,
    expectedVersion: current.version,
    patch: { name: 'Filled by tester', countryCode: 'BR' },
  });
  const filled = await ctx.mdm.entity.get({ mdmId: target.personMdmId });
  const second = await ensureLocalTestPair(ctx, projectsConfig(), binding());
  assert.equal(second.companyMdmId, first.companyMdmId);
  assert.deepEqual(
    second.personas.map((persona) => persona.personMdmId),
    first.personas.map((persona) => persona.personMdmId),
  );
  const after = await ctx.mdm.entity.get({ mdmId: target.personMdmId });
  assert.equal(after.details.name, 'Filled by tester');
  assert.equal(after.details.countryCode, 'BR');
  assert.equal(after.version, filled.version);
  const people = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } });
  assert.equal(people.length, 3);
  assert.equal(second.personas[0].name, 'Filled by tester');
});

test('an ambiguous contact is not released', async () => {
  const ctx = ctxAt('2026-10-18');
  const email = localTestEmail('102047', 'responsavel');
  const ada = await ctx.mdm.entity.create({ details: { subtype: 'Person', name: 'Ada', countryCode: 'US' } });
  const grace = await ctx.mdm.entity.create({ details: { subtype: 'Person', name: 'Grace', countryCode: 'US' } });
  const mail = await ctx.mdm.entity.create({
    details: { subtype: 'ContactChannel', name: 'mail', contactType: 'Email', value: email, countryCode: 'US' },
  });
  await ctx.mdm.entity.link({ fromId: ada.mdmId, toId: mail.mdmId, type: 'HasContact' });
  await ctx.mdm.entity.link({ fromId: grace.mdmId, toId: mail.mdmId, type: 'HasContact' });
  await assert.rejects(
    ensureLocalTestPair(ctx, projectsConfig(), binding()),
    /ambiguous and was not released/,
  );
  assert.equal(await ctx.mdm.identity.findByLogin(email), null);
});

const otherOnboarding = { moduleId: 'mod-other', entryPath: '/inicio', personType: 'Member', companyType: 'mod-other.Company' };

async function activeCompanies(ctx: RequestContext, personMdmId: string): Promise<string[]> {
  const links = await ctx.data.mdmRelationship.findMany({ where: { fromId: personMdmId, type: 'AssignedTo' } });
  return links.filter((link) => link.status === 'Active').map((link) => link.toId);
}

test('a bench login linked to another company is moved to the current one', async () => {
  const ctx = ctxAt('2026-10-18');
  const first = await ensureLocalTestPair(ctx, projectsConfig(), binding());
  assert.deepEqual(first.personas.map((persona) => persona.relinked), [false, false, false]);

  const moved = await ensureLocalTestPair(ctx, projectsConfig(), { key: 'org-moved', name: 'Moved', source: 'project-file' });
  assert.notEqual(moved.companyMdmId, first.companyMdmId);
  assert.deepEqual(moved.personas.map((persona) => persona.relinked), [true, true, true]);
  for (const [index, persona] of moved.personas.entries()) {
    assert.equal(persona.personMdmId, first.personas[index].personMdmId);
    assert.deepEqual(await activeCompanies(ctx, persona.personMdmId), [moved.companyMdmId]);
    const links = await ctx.data.mdmRelationship.findMany({ where: { fromId: persona.personMdmId, type: 'AssignedTo' } });
    const old = links.filter((link) => link.toId === first.companyMdmId);
    assert.equal(old.length, 1);
    assert.equal(old[0].status, 'Inactive');
  }

  const again = await ensureLocalTestPair(ctx, projectsConfig(), { key: 'org-moved', name: 'Moved', source: 'project-file' });
  assert.equal(again.companyMdmId, moved.companyMdmId);
  assert.deepEqual(again.personas.map((persona) => persona.relinked), [false, false, false]);
  assert.deepEqual(again.personas.map((persona) => persona.personMdmId), moved.personas.map((persona) => persona.personMdmId));
});

test('a person that is not a bench login keeps its link to another company', async () => {
  const ctx = ctxAt('2026-10-18');
  const other = await ensureOrganizationCompany(ctx, { key: 'org-other', name: 'Other', source: 'project-file' }, otherOnboarding);
  const stranger = await ctx.mdm.entity.create({ details: { subtype: 'Person', name: 'Stranger', countryCode: '' } });
  await ctx.mdm.identity.setLogin(stranger.mdmId, 'someone@example.com');
  await ctx.mdm.entity.link({ fromId: stranger.mdmId, toId: other.companyMdmId, type: 'AssignedTo', role: 'member' });

  const first = await ensureLocalTestPair(ctx, projectsConfig(), binding());
  await ensureLocalTestPair(ctx, projectsConfig(), { key: 'org-moved', name: 'Moved', source: 'project-file' });

  assert.deepEqual(await activeCompanies(ctx, stranger.mdmId), [other.companyMdmId]);
  assert.equal(first.personas.some((persona) => persona.personMdmId === stranger.mdmId), false);
});

test('the cli refuses before a write when mode or url is missing', () => {
  const testUrl = 'postgres://tester:secret@127.0.0.1:5432/mdm_test';
  const prodUrl = 'postgres://tester:secret@127.0.0.1:5432/mdm';
  assert.throws(
    () => assertLocalSeedEnvironment({
      declared: false,
      mode: 'presentation',
      runtimeMode: 'postgres',
      databaseUrlTest: testUrl,
    }),
    /not explicitly declared/,
  );
  assert.throws(
    () => assertLocalSeedEnvironment({
      declared: true,
      mode: 'presentation',
      runtimeMode: 'postgres',
    }),
    /DATABASE_URL_TEST is not set/,
  );
  assert.throws(
    () => assertLocalSeedEnvironment({
      declared: true,
      mode: 'production',
      runtimeMode: 'postgres',
      databaseUrlTest: testUrl,
    }),
    /not development or presentation/,
  );
  assert.throws(
    () => assertLocalSeedEnvironment({
      declared: true,
      mode: 'development',
      runtimeMode: 'memory',
      databaseUrlTest: testUrl,
    }),
    /RUNTIME_MODE=postgres/,
  );
  assert.throws(
    () => assertLocalSeedEnvironment({
      declared: true,
      mode: 'development',
      runtimeMode: 'postgres',
      databaseUrlTest: prodUrl,
      databaseUrl: prodUrl,
    }),
    /production database/,
  );
  const allowed = assertLocalSeedEnvironment({
    declared: true,
    mode: 'development',
    runtimeMode: 'postgres',
    databaseUrlTest: testUrl,
    databaseUrl: prodUrl,
  });
  assert.equal(allowed.database, 'mdm_test');
});

test('member roles tag the two people with a role, leave semPapel without them, and a repeat does not change the version', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas']);
  const first = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
  const versions = new Map<string, number>();
  for (const persona of first.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.tags.includes('tarefas.Participante'), persona.alias !== 'semPapel');
    assert.equal(person.details.status, 'Active');
    const links = await ctx.data.mdmRelationship.findMany({ where: { fromId: persona.personMdmId, type: 'AssignedTo' } });
    assert.equal(links.length, 1);
    assert.equal(links[0].toId, first.companyMdmId);
    assert.equal(links[0].role, 'member');
    assert.equal(links[0].status, 'Active');
    versions.set(persona.personMdmId, person.version);
  }
  const second = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
  assert.deepEqual(
    second.personas.map((persona) => persona.personMdmId),
    first.personas.map((persona) => persona.personMdmId),
  );
  for (const persona of second.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.version, versions.get(persona.personMdmId));
    assert.equal(person.details.tags.filter((tag) => tag === 'tarefas.Participante').length, persona.alias === 'semPapel' ? 0 : 1);
  }
  const people = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } });
  assert.equal(people.length, 3);
});

test('a repeat with another first role keeps ids and versions and tags both people with every role', async () => {
  for (const withOnboarding of [true, false]) {
    const ctx = ctxAt('2026-10-18');
    const config = projectsConfig('102047', ['tarefas', 'compras'], withOnboarding);
    const first = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
    const versions = new Map<string, number>();
    for (const persona of first.personas) {
      versions.set(persona.personMdmId, (await ctx.mdm.entity.get({ mdmId: persona.personMdmId })).version);
    }
    const second = await ensureLocalTestPair(ctx, config, binding(), ['compras.Comprador', 'tarefas.Participante']);
    assert.deepEqual(second.personas.map((persona) => persona.personMdmId), first.personas.map((persona) => persona.personMdmId));
    for (const persona of second.personas) {
      const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
      assert.equal(person.details.status, 'Active');
      const given = ['compras.Comprador', 'tarefas.Participante'].filter((tag) => person.details.tags.includes(tag));
      if (persona.alias === 'semPapel') {
        // With onboarding the registration tag is the onboarding's, so no member role is given; without it the
        // registration itself attaches the first role of each call (see the dedicated test).
        if (withOnboarding) assert.deepEqual(given, []);
        continue;
      }
      assert.deepEqual(given, ['compras.Comprador', 'tarefas.Participante']);
      assert.equal(person.details.tags.filter((tag) => tag === 'tarefas.Participante').length, 1);
      assert.equal(person.version > (versions.get(persona.personMdmId) ?? 0), true);
    }
    const third = await ensureLocalTestPair(ctx, config, binding(), ['compras.Comprador', 'tarefas.Participante']);
    for (const persona of third.personas) {
      assert.equal((await ctx.mdm.entity.get({ mdmId: persona.personMdmId })).version, (await ctx.mdm.entity.get({ mdmId: second.personas.find((item) => item.alias === persona.alias)!.personMdmId })).version);
    }
    const people = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } });
    assert.equal(people.length, 3);
  }
});

test('semPapel gets no member role: with onboarding only the registration tag, and it is Active', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas', 'compras']);
  const seeded = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante', 'compras.Comprador']);
  assert.deepEqual(seeded.personas.map((persona) => persona.alias), ['responsavel', 'membro', 'semPapel']);
  for (const persona of seeded.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.status, 'Active');
    if (persona.alias === 'semPapel') {
      assert.equal(person.details.name, 'Bench no role');
      assert.deepEqual(person.details.tags.filter((tag) => tag.startsWith('tarefas.') || tag.startsWith('compras.')), []);
      assert.deepEqual(person.details.tags, ['mod-bench.Member']);
      assert.equal(persona.email, localTestEmail('102047', 'semPapel'));
      assert.equal(persona.sub, localTestSub('102047', 'semPapel'));
    } else {
      assert.equal(person.details.tags.includes('tarefas.Participante'), true);
      assert.equal(person.details.tags.includes('compras.Comprador'), true);
    }
  }
  const again = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante', 'compras.Comprador']);
  assert.deepEqual(again.personas.map((persona) => persona.personMdmId), seeded.personas.map((persona) => persona.personMdmId));
});

test('a module outside the project config is refused before any write', async () => {
  const ctx = ctxAt('2026-10-18');
  await assert.rejects(
    ensureLocalTestPair(ctx, projectsConfig(), binding(), ['tarefas.Participante']),
    /not in the project config/,
  );
  const people = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } });
  assert.equal(people.length, 0);
  const companies = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Company' } });
  assert.equal(companies.length, 0);
});

test('a person that is not Active is refused and left inactive', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas']);
  const seeded = await ensureLocalTestPair(ctx, config, binding());
  for (const persona of seeded.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    await ctx.mdm.entity.inactivate({ mdmId: persona.personMdmId, expectedVersion: person.version });
  }
  await assert.rejects(
    ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']),
    /not Active/,
  );
  for (const persona of seeded.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.status, 'Inactive');
  }
});

test('omitting member roles leaves the bench without a module role', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas']);
  const seeded = await ensureLocalTestPair(ctx, config, binding());
  const again = await ensureLocalTestPair(ctx, config, binding(), []);
  assert.deepEqual(again.personas, seeded.personas);
  for (const persona of again.personas) {
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.tags.includes('tarefas.Participante'), false);
  }
});

test('without onboarding, a member role seeds three Active people in the organization company', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas'], false);
  // The boot creates the organization company before any seed runs.
  const boot = await ensureOrganizationIdentity(ctx, binding());
  const seeded = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
  assert.equal(seeded.companyMdmId, boot.companyMdmId);
  assert.equal(seeded.organizationKey, 'org-bench');
  assert.equal(seeded.personas.length, 3);
  assert.notEqual(seeded.personas[0].sub, seeded.personas[1].sub);
  assert.notEqual(seeded.personas[0].personMdmId, seeded.personas[1].personMdmId);
  for (const persona of seeded.personas) {
    assert.equal(persona.email, localTestEmail('102047', persona.alias));
    assert.equal(persona.sub, localTestSub('102047', persona.alias));
    const person = await ctx.mdm.entity.get({ mdmId: persona.personMdmId });
    assert.equal(person.details.status, 'Active');
    // semPapel carries only the tag the registration itself needs: here, the first member role.
    assert.equal(person.details.tags.includes('tarefas.Participante'), true);
    assert.equal(await ctx.mdm.identity.findByLogin(persona.email), persona.personMdmId);
    const links = await ctx.data.mdmRelationship.findMany({ where: { fromId: persona.personMdmId, type: 'AssignedTo' } });
    assert.equal(links.length, 1);
    assert.equal(links[0].toId, boot.companyMdmId);
    assert.equal(links[0].status, 'Active');
  }
  const company = await ctx.mdm.entity.get({ mdmId: boot.companyMdmId });
  assert.equal(company.details.tags.some((tag) => tag.endsWith('.Company')), false);
  const companies = await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Company' } });
  assert.equal(companies.length, 1);
});

test('without onboarding, a repeat keeps ids and versions', async () => {
  const ctx = ctxAt('2026-10-18');
  const config = projectsConfig('102047', ['tarefas'], false);
  const first = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
  const versions = new Map<string, number>();
  for (const persona of first.personas) {
    versions.set(persona.personMdmId, (await ctx.mdm.entity.get({ mdmId: persona.personMdmId })).version);
  }
  const second = await ensureLocalTestPair(ctx, config, binding(), ['tarefas.Participante']);
  assert.deepEqual(second, first);
  for (const persona of second.personas) {
    assert.equal((await ctx.mdm.entity.get({ mdmId: persona.personMdmId })).version, versions.get(persona.personMdmId));
  }
  assert.equal((await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } })).length, 3);
  assert.equal((await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Company' } })).length, 1);
});

test('without onboarding and without a member role nothing is written', async () => {
  const ctx = ctxAt('2026-10-18');
  await assert.rejects(
    ensureLocalTestPair(ctx, projectsConfig('102047', ['tarefas'], false), binding()),
    /onboarding config or a member role is required/,
  );
  assert.equal((await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Person' } })).length, 0);
  assert.equal((await ctx.data.mdmEntityIndex.findMany({ where: { subtype: 'Company' } })).length, 0);
});

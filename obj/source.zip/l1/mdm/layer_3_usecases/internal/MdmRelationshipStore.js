/// <mls fileReference="_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
export class MdmRelationshipEntity {
    static async findOne(ctx, id) {
        const entityRelationship = await ctx.data.mdmRelationship.findOne({ where: { id } });
        if (entityRelationship) {
            return {
                scope: 'entity',
                relationship: entityRelationship,
            };
        }
        const prospectRelationship = await ctx.data.mdmProspectRelationship.findOne({ where: { id } });
        if (prospectRelationship) {
            return {
                scope: 'prospect',
                relationship: prospectRelationship,
            };
        }
        throw new AppError('NOT_FOUND', 'Relationship not found', 404, { id });
    }
}

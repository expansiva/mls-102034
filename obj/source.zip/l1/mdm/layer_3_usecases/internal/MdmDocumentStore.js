/// <mls fileReference="_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
export class MdmDocumentEntity {
    static async get(ctx, mdmId) {
        const document = await ctx.data.mdmDocument.get({ mdmId });
        if (!document) {
            throw new AppError('NOT_FOUND', 'Document not found', 404, { mdmId });
        }
        return document;
    }
    static parseDetails(document) {
        if (typeof document.details === 'string') {
            return JSON.parse(document.details);
        }
        return document.details;
    }
    static async create(ctx, record) {
        await ctx.data.mdmDocument.put({ record });
    }
    static async replace(ctx, record, expectedVersion) {
        await ctx.data.mdmDocument.put({ record, expectedVersion });
    }
}

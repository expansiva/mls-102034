/// <mls fileReference="_102034_/l1/mdm/layer_3_usecases/mdmFacade.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { MdmDocumentEntity } from '/_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore.js';
import { MdmRelationshipEntity } from '/_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore.js';
import { createEntity, createProspect, enqueueWriteBehind, getProspect, promoteProspect, updateEntity, updateProspect, } from '/_102034_/l1/mdm/layer_3_usecases/internal/entityPersistence.js';
import { createRelationship, updateRelationship } from '/_102034_/l1/mdm/layer_3_usecases/internal/relationshipPersistence.js';
import { AuditLogService, runMonitoredWrite, } from '/_102034_/l1/mdm/layer_3_usecases/core/DataRecordService.js';
import { getMdmModuleTypes, refreshRelationshipRefs, } from '/_102034_/l1/mdm/layer_3_usecases/mdmSupport.js';
const DEFAULT_GET_MANY_CHUNK_SIZE = 100;
function buildReadResult(document, index) {
    const details = MdmDocumentEntity.parseDetails(document);
    return {
        mdmId: document.mdmId,
        version: document.version,
        document,
        index,
        details,
        related(key) {
            return details.relationshipRefs[key] ?? [];
        },
    };
}
function buildProspectReadResult(document, index) {
    const details = MdmDocumentEntity.parseDetails(document);
    return {
        mdmId: document.mdmId,
        version: document.version,
        document,
        index,
        details,
        related(key) {
            return details.relationshipRefs[key] ?? [];
        },
    };
}
function assertCanonicalModuleType(type) {
    if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(type)) {
        throw new AppError('INVALID_MDM_MODULE_TYPE', 'type must use the canonical <moduleId>.<type> format', 400, { type });
    }
}
function uniqueIds(ids) {
    return [...new Set(ids.filter((id) => typeof id === 'string' && id.length > 0))];
}
function chunks(values, size) {
    const normalizedSize = Math.max(1, size);
    const result = [];
    for (let index = 0; index < values.length; index += normalizedSize) {
        result.push(values.slice(index, index + normalizedSize));
    }
    return result;
}
function activeRelationships(relationships) {
    return relationships.filter((relationship) => relationship.status === 'Active');
}
function dedupeRelationships(relationships) {
    return relationships.filter((relationship, index, all) => all.findIndex((candidate) => candidate.id === relationship.id) === index);
}
async function findEntityRelationships(ctx, mdmIds) {
    const ids = uniqueIds(mdmIds);
    if (ids.length === 0) {
        return [];
    }
    return dedupeRelationships([
        ...(await ctx.data.mdmRelationship.findManyByValues({ field: 'fromId', values: ids })),
        ...(await ctx.data.mdmRelationship.findManyByValues({ field: 'toId', values: ids })),
    ]);
}
async function assertPermanentEntityLinkEndpoints(ctx, input) {
    const ids = uniqueIds([input.fromId, input.toId]);
    const entityIndexes = await ctx.data.mdmEntityIndex.findManyByValues({
        field: 'mdmId',
        values: ids,
    });
    const entityIds = new Set(entityIndexes.map((index) => index.mdmId));
    const missingIds = ids.filter((id) => !entityIds.has(id));
    if (missingIds.length === 0) {
        return;
    }
    const prospectIndexes = await ctx.data.mdmProspectIndex.findManyByValues({
        field: 'mdmId',
        values: missingIds,
    });
    if (prospectIndexes.length > 0) {
        throw new AppError('INVALID_RELATIONSHIP_SCOPE', 'MdmEntity.link only supports permanent entity endpoints', 400, {
            fromId: input.fromId,
            toId: input.toId,
            prospectMdmIds: prospectIndexes.map((index) => index.mdmId),
        });
    }
    throw new AppError('VALIDATION_ERROR', 'Relationship endpoints must exist', 400, {
        fromId: input.fromId,
        toId: input.toId,
        missingMdmIds: missingIds,
    });
}
export class MdmEntity {
    constructor(ctx) {
        this.ctx = ctx;
    }
    async create(input) {
        const created = await createEntity(this.ctx, {
            detail: {
                ...input.details,
                status: input.details.status ?? 'Active',
            },
        });
        const entity = await this.get({ mdmId: created.mdmId });
        return {
            ...entity,
            alreadyExists: created.alreadyExists,
        };
    }
    async get(input) {
        const results = await new MdmCollection(this.ctx).getMany({ mdmIds: [input.mdmId] });
        const entity = results[0];
        if (!entity) {
            throw new AppError('NOT_FOUND', 'Entity not found', 404, { mdmId: input.mdmId });
        }
        return entity;
    }
    async update(input) {
        await updateEntity(this.ctx, {
            mdmId: input.mdmId,
            expectedVersion: input.expectedVersion,
            patch: input.patch,
        });
        return this.get({ mdmId: input.mdmId });
    }
    async inactivate(input) {
        await updateEntity(this.ctx, {
            mdmId: input.mdmId,
            expectedVersion: input.expectedVersion,
            patch: {
                status: 'Inactive',
            },
        });
        return this.get({ mdmId: input.mdmId });
    }
    async delete(input) {
        const entity = await this.get({ mdmId: input.mdmId });
        const relationships = await findEntityRelationships(this.ctx, [input.mdmId]);
        const active = activeRelationships(relationships);
        if (active.length > 0 && !input.allowActiveRelationships) {
            throw new AppError('MDM_DELETE_BLOCKED_BY_RELATIONSHIPS', 'Entity has active relationships; inactivate it or unlink relationships before physical delete', 409, {
                mdmId: input.mdmId,
                relationshipIds: active.map((relationship) => relationship.id),
            });
        }
        await runMonitoredWrite(this.ctx, {
            entityType: 'MdmEntity',
            entityId: input.mdmId,
            module: 'mdm',
            routine: 'mdm.entity.delete',
            action: 'delete',
        }, async () => {
            await this.ctx.data.runInTransaction(async (runtime) => {
                const runtimeCtx = { ...this.ctx, data: runtime };
                const relatedIds = relationships
                    .flatMap((relationship) => [relationship.fromId, relationship.toId])
                    .filter((mdmId) => mdmId !== input.mdmId);
                for (const relationship of relationships) {
                    await runtime.mdmRelationship.delete({ where: { id: relationship.id } });
                }
                await runtime.mdmEntityIndex.delete({ where: { mdmId: input.mdmId } });
                await runtime.mdmDocument.delete({ mdmId: input.mdmId });
                await AuditLogService.record(this.ctx, runtime, {
                    entityType: 'MdmEntity',
                    entityId: input.mdmId,
                    action: 'delete',
                    module: 'mdm',
                    routine: 'mdm.entity.delete',
                    before: {
                        index: entity.index,
                        details: entity.details,
                    },
                    after: null,
                });
                await refreshRelationshipRefs(runtimeCtx, 'entity', relatedIds, async (document) => enqueueWriteBehind(this.ctx, runtime, document));
            });
        });
        return {
            mdmId: input.mdmId,
            deleted: true,
        };
    }
    async link(input) {
        await assertPermanentEntityLinkEndpoints(this.ctx, input);
        return createRelationship(this.ctx, {
            fromId: input.fromId,
            toId: input.toId,
            type: input.type,
            role: input.role ?? null,
            metadata: input.metadata ?? {},
            validFrom: input.validFrom ?? this.ctx.clock.nowIso().slice(0, 10),
            validTo: input.validTo ?? null,
            status: input.status ?? 'Active',
            isBidirectional: input.isBidirectional,
        });
    }
    async unlink(input) {
        const located = await MdmRelationshipEntity.findOne(this.ctx, input.relationshipId);
        if (located.scope !== 'entity') {
            throw new AppError('INVALID_RELATIONSHIP_SCOPE', 'MdmEntity.unlink only supports entity relationships', 400, {
                relationshipId: input.relationshipId,
            });
        }
        return updateRelationship(this.ctx, {
            id: input.relationshipId,
            patch: {
                status: 'Inactive',
            },
        });
    }
}
export class MdmProspect {
    constructor(ctx) {
        this.ctx = ctx;
    }
    async create(input) {
        const created = await createProspect(this.ctx, {
            detail: {
                ...input.details,
                status: input.details.status ?? 'New',
            },
        });
        return this.get({ mdmId: created.mdmId });
    }
    async get(input) {
        const result = await getProspect(this.ctx, input.mdmId);
        return buildProspectReadResult(result.document, result.index);
    }
    async update(input) {
        await updateProspect(this.ctx, {
            mdmId: input.mdmId,
            expectedVersion: input.expectedVersion,
            patch: input.patch,
        });
        return this.get({ mdmId: input.mdmId });
    }
    async listByType(input) {
        assertCanonicalModuleType(input.type);
        const records = await this.ctx.data.mdmProspectIndex.findMany({
            where: {
                subtype: input.subtype,
                status: input.status,
            },
            orderBy: input.sort,
        });
        const normalizedName = input.name?.trim().toLowerCase() ?? '';
        const requiredTags = input.tags ?? [];
        const filtered = records.filter((record) => {
            if (!record.tags.includes(input.type)) {
                return false;
            }
            if (requiredTags.some((tag) => !record.tags.includes(tag))) {
                return false;
            }
            if (normalizedName && !record.name.toLowerCase().includes(normalizedName)) {
                return false;
            }
            return true;
        });
        const page = Math.max(1, input.page ?? 1);
        const pageSize = Math.max(1, input.pageSize ?? (filtered.length || 1));
        const offset = (page - 1) * pageSize;
        return {
            items: filtered.slice(offset, offset + pageSize),
            page,
            pageSize,
            total: filtered.length,
        };
    }
    async promoteToEntity(input) {
        const result = await promoteProspect(this.ctx, { mdmId: input.mdmId });
        return {
            promoted: result.promoted,
            status: result.status,
            mdmId: result.mdmId,
            prospectMdmId: 'prospectMdmId' in result ? result.prospectMdmId : undefined,
            candidateMdmId: 'candidateMdmId' in result ? result.candidateMdmId : undefined,
        };
    }
}
export class MdmCollection {
    constructor(ctx) {
        this.ctx = ctx;
    }
    async getMany(input) {
        const ids = uniqueIds(input.mdmIds);
        if (ids.length === 0) {
            return [];
        }
        const chunkSize = input.chunkSize ?? DEFAULT_GET_MANY_CHUNK_SIZE;
        const documents = (await Promise.all(chunks(ids, chunkSize).map((chunk) => this.ctx.data.mdmDocument.getMany({ mdmIds: chunk })))).flat();
        const indexes = (await Promise.all(chunks(ids, chunkSize).map((chunk) => this.ctx.data.mdmEntityIndex.findManyByValues({
            field: 'mdmId',
            values: chunk,
        })))).flat();
        const documentById = new Map(documents.map((document) => [document.mdmId, document]));
        const indexById = new Map(indexes.map((index) => [index.mdmId, index]));
        const results = [];
        for (const mdmId of input.mdmIds) {
            const document = documentById.get(mdmId);
            if (!document) {
                continue;
            }
            const index = indexById.get(mdmId);
            if (!index) {
                throw new AppError('MDM_INDEX_MISSING', 'Document exists without entity index', 500, { mdmId });
            }
            results.push(buildReadResult(document, index));
        }
        return results;
    }
    async listByType(input) {
        assertCanonicalModuleType(input.type);
        const records = await this.ctx.data.mdmEntityIndex.findMany({
            where: {
                subtype: input.subtype,
                status: input.status,
            },
            orderBy: input.sort,
        });
        const normalizedName = input.name?.trim().toLowerCase() ?? '';
        const requiredTags = input.tags ?? [];
        const filtered = records.filter((record) => {
            if (!record.tags.includes(input.type)) {
                return false;
            }
            if (requiredTags.some((tag) => !record.tags.includes(tag))) {
                return false;
            }
            if (normalizedName && !record.name.toLowerCase().includes(normalizedName)) {
                return false;
            }
            return true;
        });
        const page = Math.max(1, input.page ?? 1);
        const pageSize = Math.max(1, input.pageSize ?? (filtered.length || 1));
        const offset = (page - 1) * pageSize;
        return {
            items: filtered.slice(offset, offset + pageSize),
            page,
            pageSize,
            total: filtered.length,
        };
    }
    async relatedOfMany(input) {
        const ids = uniqueIds(input.mdmIds);
        const relationships = (await findEntityRelationships(this.ctx, ids)).filter((relationship) => {
            if (input.status && relationship.status !== input.status) {
                return false;
            }
            if (!input.status && relationship.status !== 'Active') {
                return false;
            }
            if (input.type && relationship.type !== input.type) {
                return false;
            }
            return true;
        });
        const idSet = new Set(ids);
        const grouped = Object.fromEntries(ids.map((mdmId) => [mdmId, []]));
        for (const relationship of relationships) {
            if (idSet.has(relationship.fromId)) {
                grouped[relationship.fromId]?.push({
                    mdmId: relationship.toId,
                    relationshipId: relationship.id,
                    type: relationship.type,
                    direction: 'from',
                    role: relationship.role ?? null,
                    metadata: relationship.metadata ?? {},
                });
            }
            if (idSet.has(relationship.toId)) {
                grouped[relationship.toId]?.push({
                    mdmId: relationship.fromId,
                    relationshipId: relationship.id,
                    type: relationship.type,
                    direction: 'to',
                    role: relationship.role ?? null,
                    metadata: relationship.metadata ?? {},
                });
            }
        }
        return grouped;
    }
    async hydrateMany(input) {
        const entities = await this.getMany(input);
        const requestedSections = new Set(input.sections ?? []);
        const includeAllSections = requestedSections.size === 0;
        const includeRelationshipRefs = input.includeRelationshipRefs ?? true;
        return entities.map((entity) => {
            const details = entity.details;
            const hydrated = {
                mdmId: details.mdmId,
                subtype: details.subtype,
                name: details.name,
                status: details.status,
                moduleTypes: getMdmModuleTypes(details),
                tags: details.tags,
            };
            if (includeRelationshipRefs) {
                hydrated.relationshipRefs = details.relationshipRefs;
            }
            if (includeAllSections) {
                return {
                    mdmId: entity.mdmId,
                    version: entity.version,
                    details,
                };
            }
            for (const section of requestedSections) {
                if (section in details) {
                    hydrated[section] = details[section];
                }
            }
            return {
                mdmId: entity.mdmId,
                version: entity.version,
                details: hydrated,
            };
        });
    }
}
export function createMdmFacade(ctx) {
    return {
        entity: new MdmEntity(ctx),
        prospect: new MdmProspect(ctx),
        collection: new MdmCollection(ctx),
    };
}

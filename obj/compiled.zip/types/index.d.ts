declare module "_102034_/l1/audit/module" {
    export interface AuditNamedCount {
        label: string;
        count: number;
    }
    export interface AuditLogEventRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: string;
        actorId: string;
        actorType: string;
        module: string;
        routine: string;
        createdAt: string;
        hasRemoteDiff: boolean;
    }
    export interface AuditStatusEventRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: string;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface AuditHomeResponse {
        generatedAt: string;
        system: {
            appEnv: string;
            runtimeMode: 'memory' | 'postgres';
            writeBehindEnabled: boolean;
            awsRegion: string;
        };
        summary: {
            auditLog: {
                total: number;
                last24h: number;
                uniqueModules: number;
                uniqueActors: number;
            };
            statusHistory: {
                total: number;
                last24h: number;
                uniqueEntities: number;
                uniqueTransitions: number;
            };
        };
        explanation: {
            auditLog: string;
            statusHistory: string;
        };
        distribution: {
            byModule: AuditNamedCount[];
            byEntityType: AuditNamedCount[];
            byActorId: AuditNamedCount[];
        };
        recentEvents: {
            auditLog: AuditLogEventRecord[];
            statusHistory: AuditStatusEventRecord[];
        };
    }
    export interface AuditLogLoadParams {
        module?: string;
        entityType?: string;
        entityId?: string;
        actorId?: string;
        actorType?: string;
        action?: string;
        from?: string;
        to?: string;
        page?: number;
        pageSize?: number;
    }
    export interface AuditLogDetailsParams {
        id: string;
    }
    export interface AuditLogDetailsResponse {
        generatedAt: string;
        event: (AuditLogEventRecord & {
            diff: unknown[] | null;
        }) | null;
    }
    export interface AuditLogResponse {
        generatedAt: string;
        filters: Required<AuditLogLoadParams>;
        summary: {
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
            uniqueModules: number;
            uniqueActors: number;
            createCount: number;
            updateCount: number;
            deleteCount: number;
            restoreCount: number;
        };
        groups: {
            byModule: AuditNamedCount[];
            byRoutine: AuditNamedCount[];
            byActorId: AuditNamedCount[];
            byAction: AuditNamedCount[];
        };
        events: AuditLogEventRecord[];
    }
    export interface AuditStatusHistoryLoadParams {
        module?: string;
        entityType?: string;
        entityId?: string;
        fromStatus?: string;
        toStatus?: string;
        actorId?: string;
        reasonCode?: string;
        from?: string;
        to?: string;
        page?: number;
        pageSize?: number;
    }
    export interface AuditStatusHistoryResponse {
        generatedAt: string;
        filters: Required<AuditStatusHistoryLoadParams>;
        summary: {
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
            uniqueModules: number;
            uniqueEntities: number;
            uniqueTransitions: number;
        };
        groups: {
            byModule: AuditNamedCount[];
            byEntityType: AuditNamedCount[];
            byTransition: AuditNamedCount[];
            currentStatuses: AuditNamedCount[];
        };
        events: AuditStatusEventRecord[];
    }
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls ctx.mdm.prospect.promoteToEntity({ mdmId: prospectMdmId })
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Person | Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Person | Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/personAccess" {
    import type { PrivacyConsentValue } from "_102034_/l1/mdm/module";
    export interface PersonAccessData {
        name?: string | null;
        countryCode?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
    }
    export function isTwoLetterCountry(countryCode: string): boolean;
    export function isValidPrivacyConsent(consent: PrivacyConsentValue | null | undefined): boolean;
    /** Name, country and, in a protected country, a valid consent. Ignores registrationDraft. */
    export function isPersonAccessComplete(detail: PersonAccessData): boolean;
    /** Expects an already normalized ISO code (BR / EU). */
    export function isProtectedPrivacyCountry(countryCode: string): boolean;
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    /**
     * Organization-level registration namespace (the third MDM layer: base · general · module).
     * Schema lives in the project's solution registry (l4); the engine only reserves the key
     * and does not filter it on read.
     */
    export type MdmGeneralNamespace = Record<string, unknown>;
    export const MDM_GENERAL_NAMESPACE = "general";
    export const MDM_ORGANIZATION_MODULE_ID = "organization";
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        /** Platform bootstrap marker. Absent once the type's minimum data is stored. Not a role. */
        registrationDraft?: true;
        createdAt: string;
        updatedAt: string;
        general?: MdmGeneralNamespace;
        /** Computed on facade reads: other modules' namespace keys (no content). Not persisted. */
        namespaces?: string[];
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;
    export type MdmDetailInput = DistributiveOmit<MdmDetailRecord, 'mdmId'> & {
        mdmId?: string;
    };
    export interface MdmDocumentInput {
        mdmId: string;
        version: number;
        details: MdmDetailInput;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface CreateRegistrationEntityParams {
        mdmId: string;
        detail: CreateableMdmDetailInput;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
    export type { PersonAccessData } from "_102034_/l1/mdm/personAccess";
    export { isPersonAccessComplete, isProtectedPrivacyCountry, isValidPrivacyConsent, } from "_102034_/l1/mdm/personAccess";
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts" {
    import type { ContactSummaryValue } from "_102034_/l1/mdm/module";
    export type MdmUserStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmListUsersStatusFilter = MdmUserStatus | 'all';
    export type MdmRoleTagMode = 'with' | 'without';
    export interface MdmListUsersInput {
        name?: string;
        status?: MdmListUsersStatusFilter;
        roleTag?: string;
        roleTagMode?: MdmRoleTagMode;
        pageSize?: number;
        cursor?: string;
    }
    export interface MdmUserSummary {
        mdmId: string;
        version: number;
        name: string;
        loginEmail: string;
        status: MdmUserStatus;
        tags: string[];
        contacts: ContactSummaryValue[];
    }
    export interface MdmListUsersResult {
        items: MdmUserSummary[];
        nextCursor: string | null;
    }
    /** Normalized directory page. `limit` is pageSize + 1. Filters exclude page size. */
    export interface MdmUserDirectoryQuery {
        foldedName: string | null;
        status: MdmListUsersStatusFilter;
        roleTag: string | null;
        roleTagMode: MdmRoleTagMode | null;
        afterMdmId: string | null;
        limit: number;
    }
    export interface MdmUserDirectoryFilter {
        foldedName: string | null;
        status: MdmListUsersStatusFilter;
        roleTag: string | null;
        roleTagMode: MdmRoleTagMode | null;
    }
    /**
     * Index plus the few document fields the facade must check.
     * No private namespaces, consent, tokens, or the whole document.
     */
    export interface MdmUserDirectoryRow {
        mdmId: string;
        name: string;
        status: MdmUserStatus;
        tags: string[];
        version: number | null;
        documentMdmId: string | null;
        documentSubtype: string | null;
        contacts: unknown;
        loginTags: string[];
    }
    export interface MdmIdentityUserReader {
        listPage(query: MdmUserDirectoryQuery): Promise<MdmUserDirectoryRow[]>;
    }
    /** NFD, drop combining marks U+0300..U+036F, then lowercase. Literal characters stay. */
    export function foldUserName(value: string): string;
    /** SHA-256 hex of the stable filter projection. Page size is not part of the key. */
    export function userDirectoryFilterKey(filter: MdmUserDirectoryFilter): string;
    /**
     * Navigation cursor only: base64url JSON `{v,lastMdmId,filterKey}` at most 4 KiB.
     * It is not an authorization grant and it carries no login data.
     */
    export function encodeUserDirectoryCursor(lastMdmId: string, filter: MdmUserDirectoryFilter): string;
    /** Validates a list input and returns the directory query. Unknown fields and bad cursors are 400. */
    export function normalizeListUsersInput(input: unknown): MdmUserDirectoryQuery;
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentLimits" {
    export const DEFAULT_ATTACHMENT_MAX_BYTES: number;
    export const DEFAULT_ATTACHMENT_ALLOWED_MIME: readonly ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"];
    export interface AttachmentLimits {
        maxBytes: number;
        allowedMime: readonly string[];
    }
    export function defaultAttachmentLimits(): AttachmentLimits;
    export function parseAllowedMime(value: string | undefined): string[];
    export function validateAttachmentPayload(input: {
        mimeType: string;
        sizeBytes: number;
        limits?: AttachmentLimits;
    }): void;
    /** Decode the body of a dedicated upload route. `data:` URLs are stripped; raw base64 is accepted. */
    export function decodeAttachmentBase64(raw: string): Buffer;
}
declare module "_102034_/l1/server/layer_1_external/storage/objectBuckets" {
    /**
     * Object-storage buckets of a published app.
     *
     * One PERMANENT bucket per client project, named with the project id (default `collab-{projectId}`).
     * Business attachments (a pet photo, a signed PDF) live there and nowhere else — a lifecycle rule
     * that expires objects would leave `mdm_attachment` pointing at a dead key.
     *
     * A second, OPTIONAL tmp bucket (default `collab-{projectId}-tmp`) exists for ephemeral artifacts
     * (LLM images that may vanish). MDM attachments never use it. Empty `S3_BUCKET_TMP` disables it.
     *
     * Without AWS credentials, without a resolvable project id, or with `S3_BUCKET` explicitly empty,
     * the runtime falls back to local disk. The reason is always named — never a generic S3 crash.
     */
    export type ObjectBucketKind = 'permanent' | 'tmp';
    export type ObjectStorageProvider = 's3' | 'local';
    export const DEFAULT_PERMANENT_BUCKET_PATTERN = "collab-{projectId}";
    export const DEFAULT_TMP_BUCKET_PATTERN = "collab-{projectId}-tmp";
    export interface ObjectBucketResolution {
        provider: ObjectStorageProvider;
        projectId: string;
        /** Permanent bucket name (S3) or directory leaf (local). Always set. */
        permanent: string;
        /** Tmp bucket name, or null when the operator disabled it. MDM attach never reads this. */
        tmp: string | null;
        /** Why we are on `local`, empty when S3 is ready. */
        localReason: string;
    }
    export interface ObjectBucketEnv {
        s3BucketPattern?: string | null;
        s3BucketTmpPattern?: string | null;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        projectId?: string;
    }
    export function applyProjectId(pattern: string, projectId: string): string;
    export function resolveObjectBuckets(env: ObjectBucketEnv): ObjectBucketResolution;
    export function bucketFor(kind: ObjectBucketKind, resolution: ObjectBucketResolution): string | null;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        /** Minute tick that calls `onTick` of each module. Same gate as write-behind: postgres only. */
        tickEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
        testsEnabled: boolean;
        projectId?: string;
        projectDomain?: string;
        studioEnabled: boolean;
        activeCompanyId?: string;
        activeUnitId?: string;
        currentWorkspaceId?: string;
        actorId?: string;
        actorScope: string[];
        /**
         * Organization country (ISO 3166-1 alpha-2). Installation default `US` (MDM ontology).
         * Not derived from UI language. Platform org config is a pending source.
         */
        organizationCountryCode: string;
        organizationCurrency?: string;
        organizationTimezone?: string;
        /**
         * Permanent object-storage bucket pattern. `{projectId}` is replaced with the client project
         * (default `collab-{projectId}`). Empty string forces local disk.
         */
        s3BucketPattern: string;
        /** Optional tmp bucket pattern (default `collab-{projectId}-tmp`). Empty disables it. MDM never uses it. */
        s3BucketTmpPattern: string;
        attachmentMaxBytes: number;
        attachmentAllowedMime: string[];
        attachmentLocalDir?: string;
        /**
         * Redis connection URL. Present on the VM (`install.sh` installs Redis); absent on lima.
         * Identity cache branches on this capability, never on the host name.
         */
        redisUrl?: string;
        /** TTL of `identity:login:<email>` cache entries. Default 300 s. */
        identityCacheTtlSeconds: number;
    }
    export function ensureEnvFileLoaded(): void;
    export function readAppEnv(): AppEnv;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    /** Where this project is read from and saved to. Replaces the `cadastro` blob. */
    export interface ProjectSettingsConfig {
        /** Destination: 'GitHub' | 'GitLab' | 'vm'. Routed by getDefaultDriver in the cfe. */
        driver: string;
        /** >= 3 '/'-separated segments: getMyKeysBranch takes the LAST three as branch/owner/repo. */
        url: string;
        name?: string;
        userAuth?: 'public' | 'private';
    }
    /** Optional cadastro module. It does not decide whether the organization exists. */
    export interface ProjectOnboardingConfig {
        moduleId: string;
        entryPath: string;
        personType: string;
        companyType: string;
        /**
         * Transitional. Prefer `ProjectsConfig.organization.source`.
         * Used only when `organization` itself was omitted. Ignored when that field is set.
         */
        organizationSource?: 'project-file' | 'development-project';
        /** Automatic entry into cadastro. Absent equals true. false keeps provisioning and does not redirect. */
        redirect?: boolean;
    }
    /** Organization identity source. Independent of the cadastro module. Absent `source` means project-file. */
    export interface ProjectOrganizationConfig {
        source?: 'project-file' | 'development-project';
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        clientShell?: ProjectClientShellConfig;
        /** Optional same-origin favicon href (`/…`). Cross-origin values are ignored. */
        favicon?: string;
        /** Destination of this project's source. Read by the runtime login from l5/config.json. */
        projectSettings?: ProjectSettingsConfig;
        /** Declared workspace project ids. Read by cbeLogin.readProjectDependencies. */
        workspaceDependencies?: string[];
        /**
         * Organization identity source. Absent `organization` keeps the transitional onboarding.organizationSource.
         * A valid sites project file still wins over either source.
         */
        organization?: ProjectOrganizationConfig;
        /** Cadastro module tags. Supplied by the module, not fixed in the library. Does not gate organization identity. */
        onboarding?: ProjectOnboardingConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        name?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export type { ProjectClientShellConfig, ProjectConfigRecord, ProjectDynamicRegionConfig, ProjectFrontendPageConfig, ProjectModuleConfig, ProjectModuleFrontendConfig, ProjectModuleFrontendEntrypoint, ProjectNavigationEntry, ProjectPersistenceModuleConfig, ProjectRegionRendererConfig, ProjectShellRegionProfiles, ProjectType, ProjectsConfig, } from "_102029_/l2/runtimeConfigTypes";
    export function projectsConfigExists(): boolean;
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function resolveWebDistPath(relativePath?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/config/projectMode" {
    export type ProjectMode = 'production' | 'homologation' | 'development' | 'presentation';
    /** A generated module is born in `presentation`; anything unreadable falls back to it, loudly. */
    export const DEFAULT_PROJECT_MODE: ProjectMode;
    export function isProjectMode(value: unknown): value is ProjectMode;
    /** Test modes run against the TEST database and may be written to by the test runner. */
    export function isTestMode(mode: ProjectMode): boolean;
    /**
     * The mode declared by `l5/project.json` of a project. Absent or invalid ⇒ `presentation` with a warning:
     * defaulting to production would point a freshly generated module at real data, which is the one mistake
     * this whole concept exists to prevent.
     */
    /**
     * Did the project DECLARE its mode, or is it running on the default?
     *
     * The difference decides whether a missing `DATABASE_URL_TEST` is a failure: a project that explicitly
     * says `presentation` and has no test connection string is misconfigured and must say so; a project that
     * declared nothing at all is simply older than the modes, and breaking its boot over a default would be
     * this feature's worst outcome.
     */
    export function hasDeclaredProjectMode(projectId?: string | number): boolean;
    export function readProjectMode(projectId?: string | number): ProjectMode;
    /** Which env var holds the connection string for this mode. */
    export function databaseUrlEnvFor(mode: ProjectMode): 'DATABASE_URL' | 'DATABASE_URL_TEST';
    /**
     * The connection string for a mode — and a LEGIBLE failure when a test mode has none.
     *
     * Falling back to `DATABASE_URL` here would be the worst possible bug of this feature: a presentation
     * module quietly writing curated seeds over production data. So the absence is an error, not a default.
     */
    export function resolveDatabaseUrl(mode: ProjectMode): string;
    /**
     * Create the TEST database when it does not exist yet.
     *
     * "Nothing manual per project": provisioning a generated app flows through the publish, so a test mode
     * that points at a database nobody created should create it instead of demanding an SSH session. Only the
     * DATABASE is created — the schema is the bootstrap's job — and only in a test mode: nobody
     * auto-provisions production. Returns what happened, so the caller can log it; a missing privilege is
     * reported, not swallowed, because then the legible failure IS the answer.
     */
    export function ensureTestDatabase(mode: ProjectMode, connect: (adminUrl: string) => Promise<{
        exists: (database: string) => Promise<boolean>;
        create: (database: string) => Promise<void>;
        end: () => Promise<void>;
    }>): Promise<{
        created: boolean;
        database: string;
        reason: string;
    }>;
    /** The database name of a connection string, plus the same string pointed at `postgres` (admin). */
    export function parseDatabaseUrl(url: string): {
        database: string;
        adminUrl: string;
    } | null;
    export interface WriteAttempt {
        /** Where the request came from — the transport stamps it; `test` is the monitor runner. */
        source?: 'http' | 'message' | 'test';
        /** The routine's command segment (`cmdCreateClient`, `qryListClient`). */
        command?: string;
    }
    /**
     * May this request write? The SERVER half of the two defences.
     *
     * The runner is supposed to keep its destructive suite for test modes, but "supposed to" is what let a
     * production run write junk once. The generated vocabulary makes the check deterministic: `cmd*` mutates,
     * `qry*` reads. A read-only smoke from the runner stays allowed everywhere, which is what makes production
     * still observable.
     */
    export function refuseTestWrite(mode: ProjectMode, attempt: WriteAttempt): string;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    /** Draft process: MDM reads the app database. Absent variable keeps today's single pool. */
    export function getMdmPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
        /** Partial-index predicate, e.g. `"namespace" = 'login'`. */
        where?: string;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
        seedRows?: Array<Record<string, unknown>>;
    }
    export type SeedPurpose = 'initial' | 'test';
    /** Seed rows shipped in a separate file inside the module's tableDefsDir (so generated
     *  table definitions stay untouched). Discovered by shape, like TableDefinition.
     *  `purpose` omitted means test, so existing exports stay valid. */
    export interface TableSeedRows {
        seedFor: string;
        purpose?: SeedPurpose;
        rows: Array<Record<string, unknown>>;
    }
    /** Provenance of one seed export after it is attached to a resolved table. */
    export interface SeedExportOrigin {
        purpose: SeedPurpose;
        source: string;
        projectId: string;
        moduleId: string;
        seedFor: string;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        logicalTableName: string;
        dynamoResolvedTableName: string | null;
        /** Initial-purpose rows only. Absent on tables that received none. Not part of the schema snapshot. */
        initialSeedRows?: Array<Record<string, unknown>>;
        /** Export groups attached to this table, initial and test, with the module that exported each one. */
        seedOrigins?: SeedExportOrigin[];
    }
    /** Column fields the Postgres rebuild materializes. Seed rows are not part of the snapshot. */
    export interface SchemaSnapshotColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
            columns: SchemaSnapshotColumn[];
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    /** A project is namespaced when it owns application (client) tables. Platform tables live in
     *  master-backend / lib projects and stay on their canonical, shared names. */
    export function isClientProjectType(projectType: string | undefined): boolean;
    /** Physical-name prefix for a client project. `mls` keeps the identifier unquoted-safe in Postgres
     *  (a bare `102051_order` would require quoting everywhere), and readable. */
    export function projectTableNamespacePrefix(projectId: string): string;
    /** Lowercased module token used as the physical-name prefix. `listaAssinatura3` → `listaassinatura3_`.
     *  Keep in sync with `moduleTableNamespacePrefix` in mls-102021 (l2 cannot import this file). */
    export function moduleTableNamespacePrefix(moduleId: string): string;
    /** Strip the module prefix CB now emits on `tableName`, so lookup stays `petition_signature`.
     *  Idempotent on older tables that were generated without the prefix. */
    export function logicalTableNameFromEmitted(emittedName: string, moduleId: string): string;
    /** Lookup keys: repositoryName, unprefixed logical name, physical name, and the CB-emitted
     *  (module-prefixed, pre-project) name adapters copy from TableDefinition.tableName. */
    export function matchesTableLookup(definition: Pick<ResolvedTableDefinition, 'repositoryName' | 'logicalTableName' | 'tableName' | 'projectId'>, key: string): boolean;
    /**
     * Namespaces a physical storage name (Postgres table or DynamoDB table) with the owning project when
     * that project owns application tables, so several client projects can share one database/schema on a
     * VM without colliding on generic names (`order`, `daily_shift`, ...). Platform tables (mdm_*, monitor,
     * _schema_migrations) belong to master/lib projects and are left on their canonical names. Idempotent:
     * a name already carrying the prefix is returned unchanged.
     */
    export function applyProjectTableNamespace(physicalName: string, projectId: string, projectType: string | undefined): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102034_/l1/server/layer_1_external/persistence/seedPolicy" {
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import type { SeedExportOrigin, SeedPurpose, TableIndexDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export interface SeedPolicyColumn {
        name: string;
        nullable?: boolean;
    }
    /** Table fields the seed policy needs. Rows are read and never written. */
    export interface SeedPolicyTable {
        tableName: string;
        logicalTableName: string;
        storageProfile: string;
        columns: SeedPolicyColumn[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        seedRows?: ReadonlyArray<Record<string, unknown>>;
        initialSeedRows?: ReadonlyArray<Record<string, unknown>>;
    }
    export interface SeedModeInput {
        tableName: string;
        logicalTableName: string;
        projectMode: ProjectMode;
        serverMode: ProjectMode;
    }
    export function readSeedPurpose(value: unknown, origin: Pick<SeedExportOrigin, 'source' | 'seedFor'>): SeedPurpose;
    /** Unprefixed physical name ⇒ platform table. Platform seeds follow serverMode. */
    export function isPlatformSeedTable(table: Pick<SeedPolicyTable, 'tableName' | 'logicalTableName'>): boolean;
    export function seedModeFor(input: SeedModeInput): {
        platform: boolean;
        mode: ProjectMode;
    };
    /** Initial is always eligible. Test follows the same mode rule as today. */
    export function isTestSeedEligible(input: SeedModeInput): boolean;
    /** PK, then unique indexes with no predicate, whose columns all exist and are not nullable. */
    export function completeUniqueKeys(table: Pick<SeedPolicyTable, 'columns' | 'primaryKey' | 'indexes'>): string[][];
    /**
     * Initial rows require Postgres, a declared complete unique key, and columns that exist.
     * dynamoOnly has no seed application in this engine and is refused here.
     */
    export function assertInitialSeed(table: SeedPolicyTable, rows: ReadonlyArray<Record<string, unknown>>, origin: SeedExportOrigin): void;
    /**
     * Selects initial rows always and test rows only in a test mode.
     * A test row that collides with an initial row on any complete unique key is omitted.
     * Returned array is new; `seedRows` and `initialSeedRows` are not modified.
     */
    export function selectEligibleSeedRows(table: SeedPolicyTable, input: SeedModeInput): Record<string, unknown>[];
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    /** Snapshot row used for the schema hash. Columns in; seedRows out — a seed-only edit must not rebuild. */
    export function toSchemaSnapshotTable(definition: ResolvedTableDefinition): SchemaSnapshot['tables'][number];
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
    /**
     * A module that wants to be woken up exports `onTick` from its persistence file, next to
     * `tableDefinitions` and `viewDefinitions`. The platform only lends the clock: what the module does
     * with the minute — which occurrences it owes, where it records them — is the module's business.
     */
    export type ModuleTickHandler = (ctx: RequestContext, now: Date) => Promise<void> | void;
    export interface ModuleTickRegistration {
        moduleId: string;
        onTick: ModuleTickHandler;
    }
    /**
     * Collects `onTick` the same way `loadViewDefinitions` collects `viewDefinitions` — with one
     * difference on purpose: a module whose import throws is warned about and skipped instead of
     * rejecting the whole load. `loadViewDefinitions` above has no such isolation; the tick runs every
     * minute forever, so one broken module must not silence every other module's clock.
     */
    export function loadModuleTickHandlers(): Promise<ModuleTickRegistration[]>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        /** Case-insensitive substring per column (`ILIKE` in Postgres). Empty/absent values are ignored. */
        ilike?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
        /** Rows to skip after filtering/ordering. Absent = 0. `findMany` without limit/offset is unchanged. */
        offset?: number;
    }
    /** Default page size when a list asks to paginate without saying how many. */
    export const DEFAULT_PAGE_SIZE = 20;
    /** Hard cap: a requested pageSize above this is cut, and the envelope declares the effective size. */
    export const MAX_PAGE_SIZE = 200;
    export interface ResolvedListPage {
        page: number;
        pageSize: number;
        limit: number;
        offset: number;
    }
    /**
     * Convert optional page/pageSize into LIMIT/OFFSET. Default 20, cap 200 — the cut is declared
     * (returned pageSize is the effective one), never silent and never a rejection.
     */
    export function resolveListPage(input?: {
        page?: number;
        pageSize?: number;
    }): ResolvedListPage;
    export function applyFindManyWindow<TRecord>(rows: TRecord[], input?: Pick<IFindManyInput<TRecord>, 'limit' | 'offset'>): TRecord[];
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        /** Rows matching the filter, ignoring limit/offset. Same WHERE as findMany. */
        count(input?: IFindManyInput<TRecord>): Promise<number>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function buildFindManySql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function buildCountSql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    /** Same selection the migration uses: initial always, test only in the owning mode, initial wins a key clash. */
    export function copyEligibleSeedRows(definition: ResolvedTableDefinition, env: Pick<AppEnv, 'projectId'>): Record<string, unknown>[];
    /** A disposable sandbox run: initial and test rows in any mode (initial still wins a key clash). */
    export function copySandboxSeedRows(definition: ResolvedTableDefinition): Record<string, unknown>[];
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
    /** In-memory ITableRepository without the persistence registry — fixture for tests, not a generated app. */
    export function createMemoryTableRepository<TRecord extends object>(records: TRecord[]): ITableRepository<TRecord>;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmDocumentInput, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord, MdmKvRecord } from "_102034_/l1/mdm/module";
    import type { MdmIdentityUserReader } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentInput;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        /** Same physical table as `moduleData.getTable('mdmKv')`; bound to the MDM executor. */
        mdmRegistrationKv: ITableRuntime<MdmKvRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        /** Optional directory reader. Absence must not open a global pool. */
        mdmIdentityUsers?: MdmIdentityUserReader;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>, options?: {
            lockKey: string;
        }): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory" {
    export interface ICacheRuntime {
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
    export class CacheRuntimeMemory implements ICacheRuntime {
        private readonly defaultTtlSeconds?;
        private readonly values;
        constructor(defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmDetailRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmDocumentEntity {
        static get(ctx: RequestContext, mdmId: string): Promise<MdmDocumentRecord>;
        static parseDetails(document: MdmDocumentRecord): MdmDetailRecord;
        static create(ctx: RequestContext, record: MdmDocumentRecord): Promise<void>;
        static replace(ctx: RequestContext, record: MdmDocumentRecord, expectedVersion: number): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRecordStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export class MdmRecordEntity {
        static getEntityIndex(ctx: RequestContext, mdmId: string): Promise<MdmEntityIndexRecord>;
        static getProspectIndex(ctx: RequestContext, mdmId: string): Promise<MdmProspectIndexRecord>;
        static findEntityByDocument(ctx: RequestContext, docType?: string | null, docId?: string | null): Promise<MdmEntityIndexRecord | null>;
        static findEntityByContact(ctx: RequestContext, contactType?: string | null, value?: string | null): Promise<MdmEntityIndexRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    export class MdmRelationshipEntity {
        static findOne(ctx: RequestContext, id: string): Promise<{
            scope: 'entity' | 'prospect';
            relationship: MdmRelationshipRecord;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmSupport" {
    import type { MdmProspectStatus, MdmStatus, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CreateRecordParams, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { isPersonAccessComplete, isProtectedPrivacyCountry } from "_102034_/l1/mdm/personAccess";
    export { isPersonAccessComplete, isProtectedPrivacyCountry };
    type RelationshipScope = 'entity' | 'prospect';
    export function getMdmModuleTypes(detail: MdmDetailRecord | Record<string, unknown>): string[];
    export function refreshRelationshipRefs(ctx: RequestContext, relationshipScope: RelationshipScope, mdmIds: string[], enqueueDocumentWrite: (document: {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }) => Promise<void>): Promise<void>;
    export function normalizeCountryCode(countryCode?: string | null): string;
    export function normalizeDocumentId(docId?: string | null): string | null;
    export function normalizeContactValue(value?: string | null): string | null;
    export function normalizeDetailInput(input: CreateRecordParams['detail'], ctx: RequestContext, mdmId: string, options?: {
        registrationDraft?: true;
    }): MdmDetailRecord;
    export function applyPatchToDetail(currentDetail: MdmDetailRecord, patch: Partial<MdmDetailRecord>, ctx: RequestContext): MdmDetailRecord;
    export function normalizeStatus(detail: MdmDetailRecord): MdmStatus | MdmProspectStatus;
    export function validateDetail(detail: MdmDetailRecord): void;
    export function toDocumentRecord(detail: MdmDetailRecord, version: number): {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    };
    export function buildEntityIndex(detail: MdmDetailRecord): MdmEntityIndexRecord;
    export function buildProspectIndex(detail: MdmDetailRecord): MdmProspectIndexRecord;
    export function normalizeEntityStatus(detail: MdmDetailRecord): MdmStatus;
    export function normalizeProspectStatus(detail: MdmDetailRecord): MdmProspectStatus;
    export function buildSearchVector(detail: MdmDetailRecord): string;
    export function relationshipIsBidirectional(type: RelationshipType): boolean;
    export function migrateProspectRelationships(ctx: RequestContext, prospectMdmId: string): Promise<{
        affectedIds: string[];
        migratedRelationships: MdmRelationshipRecord[];
    }>;
    export function buildRelationshipSearchText(relationship: MdmRelationshipRecord): string;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/mdmEntityDefs" {
    import type { EntityDef, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export const mdmEntityDef: EntityDef<MdmDetailRecord, MdmEntityIndexRecord>;
    export const mdmProspectDef: EntityDef<MdmDetailRecord, MdmProspectIndexRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/entityPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateableMdmDetailInput, CreateRecordParams, ListRecordsParams, MergeEntityParams, MdmDocumentRecord, MdmRelationshipDocumentRecord, PromoteProspectParams, RecordDetailResponse, UpdateRecordParams } from "_102034_/l1/mdm/module";
    export function enqueueWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], document: MdmDocumentRecord): Promise<void>;
    export function enqueueRelationshipWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], relationship: MdmRelationshipDocumentRecord): Promise<void>;
    export function createEntity(ctx: RequestContext, params: CreateRecordParams): Promise<{
        alreadyExists: boolean;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: boolean;
        mdmId: string;
        version: number;
    }>;
    type RegistrationDraftDetailInput = Partial<CreateableMdmDetailInput> & {
        subtype: 'Person' | 'Company';
    };
    export function createRegistrationEntity(ctx: RequestContext, params: {
        mdmId: string;
        detail: RegistrationDraftDetailInput;
    }): Promise<{
        alreadyExists: true;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: false;
        mdmId: string;
        version: number;
    }>;
    export function createProspect(ctx: RequestContext, params: CreateRecordParams): Promise<{
        mdmId: string;
        version: number;
    }>;
    export function getEntity(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function getProspect(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function listEntities(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord[]>;
    export function listProspects(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord[]>;
    export function updateEntity(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
    }>;
    export function updateProspect(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus | import("_102034_/l1/mdm/defs/ontology").MdmProspectStatus;
    }>;
    export function promoteProspect(ctx: RequestContext, params: PromoteProspectParams): Promise<{
        promoted: boolean;
        status: string;
        mdmId: string;
        prospectMdmId: string;
        candidateMdmId: string;
    } | {
        promoted: boolean;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
        mdmId: string;
    }>;
    export function mergeEntity(ctx: RequestContext, params: MergeEntityParams): Promise<{
        winnerMdmId: string;
        loserMdmId: string;
        status: string;
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/relationshipPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRelationshipParams, ListRelationshipsParams, SearchParams, UpdateRelationshipParams } from "_102034_/l1/mdm/module";
    export function createRelationship(ctx: RequestContext, params: CreateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            role: string;
            metadata: Record<string, unknown>;
            isBidirectional: boolean;
            validFrom: string;
            validTo: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            createdAt: string;
            updatedAt: string;
        };
    }>;
    export function listRelationships(ctx: RequestContext, params: ListRelationshipsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[]>;
    export function updateRelationship(ctx: RequestContext, params: UpdateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            updatedAt: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            role?: string | null;
            metadata?: Record<string, unknown>;
            validFrom: string;
            validTo?: string | null;
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            isBidirectional: boolean;
            createdAt: string;
        };
    }>;
    export function runSearch(ctx: RequestContext, params: SearchParams): Promise<{
        records: (import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord | import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord)[];
        relationships: import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[];
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export function attachFile(ctx: RequestContext, params: AttachFileParams): Promise<MdmAttachmentRecord>;
    export function detachFile(ctx: RequestContext, params: DetachFileParams): Promise<MdmAttachmentRecord>;
    export function findAttachmentsByEntity(ctx: RequestContext, params: FindAttachmentsByEntityParams): Promise<MdmAttachmentRecord[]>;
}
declare module "_102034_/l1/mdm/defs/platformDetailKeys" {
    /**
     * Runtime classification of MDM `details` keys: platform catalog fields vs engine
     * compatibility extras vs computed. Consumers share this module; they do not keep
     * a mirrored Set. Classification does not grant write access to derived fields.
     */
    /** Names declared by the platform catalog (identification, base, and subtypes). */
    export const MDM_CATALOG_PLATFORM_DETAIL_KEYS: readonly ["subtype", "name", "status", "moduleTypes", "docType", "docId", "countryCode", "tags", "aliases", "contacts", "relationshipRefs", "addresses", "mergedInto", "createdAt", "updatedAt", "privacyConsent", "birthDate", "gender", "nationality", "occupation", "photoUrl", "notes", "companyKind", "parentCompanyId", "externalCode", "legalName", "tradeName", "legalType", "foundingDate", "taxRegime", "industryCode", "website", "sku", "productType", "category", "brand", "unitOfMeasure", "isInventoried", "serviceCode", "serviceKind", "parentServiceId", "serviceType", "durationMinutes", "deliveryMode", "locationType", "locationCode", "parentLocationId", "capacity", "propertyAddress", "assetCategory", "serialNumber", "manufacturer", "model", "contactType", "value", "isVerified", "verifiedAt", "storageBucket", "storagePath", "originModule", "docCategory", "fileName", "mimeType", "bankRoutingNumber", "bankName", "accountNumber", "accountType", "swift", "iban", "pixKey", "pixKeyType", "acquisitionDate", "areaM2", "areaSqft", "breed", "color", "expiresAt", "fileSizeKb", "fuelType", "isNeutered", "issuedAt", "issuer", "microchip", "plate", "propertyType", "registrationNumber", "sex", "species", "taxParcelId", "vin", "year"];
    /**
     * Engine/prospect extras accepted by the current contract. Not catalog fields and
     * not module namespaces. Exported for the parity test; do not copy these strings.
     */
    export const MDM_ENGINE_COMPAT_DETAIL_KEYS: readonly ["mdmId", "registrationDraft", "promotionSource", "promotedTo", "ttlExpiresAt"];
    /** Computed on facade reads; never a persisted module namespace. */
    export const MDM_COMPUTED_DETAIL_KEYS: ReadonlySet<string>;
    export const MDM_PLATFORM_DETAIL_KEYS: ReadonlySet<string>;
    export function isMdmComputedDetailKey(key: string): boolean;
    export function isMdmPlatformDetailKey(key: string): boolean;
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeRedis" {
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export class CacheRuntimeRedis implements ICacheRuntime {
        private readonly defaultTtlSeconds;
        private socket;
        private connecting;
        private queue;
        private readonly target;
        constructor(url: string, defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
        close(): Promise<void>;
        private command;
        private ensureConnected;
        private commandOn;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/identityCache" {
    import { type ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export const IDENTITY_CACHE_KEY_PREFIX = "identity:login:";
    export const DEFAULT_IDENTITY_CACHE_TTL_SECONDS = 300;
    export interface IdentityCacheValue {
        mdmId: string;
        name: string;
    }
    export function identityCacheKey(email: string): string;
    export function identityCacheTtlSeconds(): number;
    /**
     * Pick the cache implementation by capability: Redis when REDIS_URL is present,
     * in-memory otherwise. Never by host name.
     */
    export function createIdentityCache(redisUrl?: string | null): ICacheRuntime;
    export function getSharedIdentityCache(): ICacheRuntime;
    export function resetSharedIdentityCacheForTests(): void;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityLogin" {
    export function normalizeLoginEmail(email: string): string;
    export function assertLoginEmail(email: string): string;
    export function storedLoginEmailFromTags(tags: readonly string[], mdmId: string): string | null;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsecases" {
    import { type PlatformSessionPerson, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type IdentityCacheValue } from "_102034_/l1/server/layer_1_external/cache/identityCache";
    export const MDM_LOGIN_NAMESPACE = "login";
    export const MDM_LOGIN_ENTITY_TYPE = "MdmEntity";
    export interface MdmIdentityInviteInput {
        mdmId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }
    export interface MdmIdentityInviteResult {
        token: string;
        expiresAt: string;
        teamIds?: string[];
    }
    export function lookupLoginEmail(ctx: RequestContext, mdmId: string): Promise<string | null>;
    export function lookupLogin(ctx: RequestContext, email: string): Promise<IdentityCacheValue | null>;
    export function findByLogin(ctx: RequestContext, email: string): Promise<string | null>;
    export function resolveSessionPerson(ctx: RequestContext, email: string): Promise<PlatformSessionPerson | null>;
    export function setLogin(ctx: RequestContext, mdmId: string, email: string): Promise<{
        mdmId: string;
        email: string;
    }>;
    export function createCollabAuthInviteHttp(input: {
        baseUrl: string;
        apiKey: string;
        orgId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }): Promise<MdmIdentityInviteResult>;
    export function invite(ctx: RequestContext, input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsers" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type MdmListUsersInput, type MdmListUsersResult } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    /** Reads one directory page. Does not authorize the caller and does not mutate MDM. */
    export function listUsers(ctx: RequestContext, input?: MdmListUsersInput): Promise<MdmListUsersResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmFacade" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export { MDM_PLATFORM_DETAIL_KEYS, isMdmComputedDetailKey, isMdmPlatformDetailKey, } from "_102034_/l1/mdm/defs/platformDetailKeys";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord, CompactRelationshipRefKey, CreateableMdmDetailInput, MdmDetailRecord, MdmDocumentRecord, MdmEntityIndexRecord, MdmModuleNamespaceValue, MdmProspectIndexRecord, RelationshipStatus } from "_102034_/l1/mdm/module";
    import type { MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import { type MdmIdentityInviteInput, type MdmIdentityInviteResult } from "_102034_/l1/mdm/layer_3_usecases/identityUsecases";
    import type { MdmListUsersInput, MdmListUsersResult, MdmUserSummary } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    export type { MdmListUsersInput, MdmListUsersResult, MdmUserSummary };
    export type MdmEntityCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmEntityCreateInput {
        details: MdmEntityCreateDetails;
    }
    export type MdmProspectCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmProspectCreateInput {
        details: MdmProspectCreateDetails;
    }
    export interface MdmEntityUpdateInput {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface MdmProspectUpdateInput extends MdmEntityUpdateInput {
    }
    export interface MdmEntityGetInput {
        mdmId: string;
    }
    export interface MdmProspectGetInput extends MdmEntityGetInput {
    }
    export interface MdmProspectPromoteToEntityInput {
        mdmId: string;
    }
    export interface MdmEntityInactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    /** Mirror of MdmEntityInactivateInput: the cadastral cycle is symmetric, so its input is too. */
    export interface MdmEntityReactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    export interface MdmEntityDeleteInput {
        mdmId: string;
        allowActiveRelationships?: boolean;
    }
    export interface MdmLinkInput {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom?: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface MdmUnlinkInput {
        relationshipId: string;
    }
    export interface MdmGetManyInput {
        mdmIds: string[];
        chunkSize?: number;
    }
    export interface MdmListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmProspectListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmProspectStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmHydrateManyInput extends MdmGetManyInput {
        sections?: string[];
        includeRelationshipRefs?: boolean;
    }
    export interface MdmRelatedOfManyInput {
        mdmIds: string[];
        type?: RelationshipType;
        status?: RelationshipStatus;
    }
    export interface MdmRelatedRef {
        mdmId: string;
        relationshipId: string;
        type: RelationshipType;
        direction: 'from' | 'to';
        role?: string | null;
        metadata?: Record<string, unknown>;
    }
    export interface MdmEntityReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmEntityIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmEntityWriteResult extends MdmEntityReadResult {
        alreadyExists?: boolean;
    }
    export interface MdmProspectReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmProspectIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmProspectWriteResult extends MdmProspectReadResult {
    }
    export type MdmProspectListByTypeItem = MdmProspectIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmProspectListByTypeResult {
        items: MdmProspectListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmProspectPromoteToEntityResult {
        promoted: boolean;
        status: MdmStatus | MdmProspectStatus;
        mdmId: string;
        prospectMdmId?: string;
        candidateMdmId?: string;
    }
    export interface MdmDeleteResult {
        mdmId: string;
        deleted: true;
    }
    export type MdmListByTypeItem = MdmEntityIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmListByTypeResult {
        items: MdmListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmHydratedEntity {
        mdmId: string;
        version: number;
        details: Partial<MdmDetailRecord>;
    }
    export interface MdmFacade {
        entity: MdmEntity;
        prospect: MdmProspect;
        collection: MdmCollection;
        attachment: MdmAttachment;
        identity: MdmIdentity;
    }
    export function isUnrestrictedMdmCaller(moduleId?: string | null): boolean;
    export function projectDetailsForModule(details: MdmDetailRecord | Record<string, unknown>, moduleId?: string | null): MdmDetailRecord;
    export class MdmEntity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmEntityCreateInput): Promise<MdmEntityWriteResult>;
        get(input: MdmEntityGetInput): Promise<MdmEntityReadResult>;
        update(input: MdmEntityUpdateInput): Promise<MdmEntityWriteResult>;
        findByDocument(docType: string, docId: string): Promise<MdmEntityReadResult | null>;
        findByContact(contactType: string, value: string): Promise<MdmEntityReadResult | null>;
        /**
         * Create-or-attach: add tag `<moduleId>.<role>` without duplicating, and optionally write the
         * caller module's namespace. Role may be the entity id (`Cliente`) or the canonical tag.
         */
        attachRole(mdmId: string, role: string, namespace?: MdmModuleNamespaceValue): Promise<MdmEntityWriteResult>;
        inactivate(input: MdmEntityInactivateInput): Promise<MdmEntityWriteResult>;
        /**
         * The other half of the cadastral cycle. An MDM entity is NEVER deleted by a generated module: the
         * tier-1 catalogue emits `inactivate`/`reactivate` for `storage.target: 'mdm'` instead of `delete`,
         * so a generated `cmdReactivate*` had no target here at all until this method existed.
         *
         * Deliberately the exact mirror of `inactivate` — same optimistic version, same single-field patch —
         * because any asymmetry between the two halves shows up as a record that can be hidden and not
         * brought back.
         */
        reactivate(input: MdmEntityReactivateInput): Promise<MdmEntityWriteResult>;
        delete(input: MdmEntityDeleteInput): Promise<MdmDeleteResult>;
        link(input: MdmLinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                role: string;
                metadata: Record<string, unknown>;
                isBidirectional: boolean;
                validFrom: string;
                validTo: string;
                status: RelationshipStatus;
                createdAt: string;
                updatedAt: string;
            };
        }>;
        unlink(input: MdmUnlinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                updatedAt: string;
                status: RelationshipStatus;
                role?: string | null;
                metadata?: Record<string, unknown>;
                validFrom: string;
                validTo?: string | null;
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                isBidirectional: boolean;
                createdAt: string;
            };
        }>;
    }
    export class MdmProspect {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmProspectCreateInput): Promise<MdmProspectWriteResult>;
        get(input: MdmProspectGetInput): Promise<MdmProspectReadResult>;
        update(input: MdmProspectUpdateInput): Promise<MdmProspectWriteResult>;
        listByType(input: MdmProspectListByTypeInput): Promise<MdmProspectListByTypeResult>;
        promoteToEntity(input: MdmProspectPromoteToEntityInput): Promise<MdmProspectPromoteToEntityResult>;
    }
    export class MdmCollection {
        private readonly ctx;
        constructor(ctx: RequestContext);
        getMany(input: MdmGetManyInput): Promise<MdmEntityReadResult[]>;
        listByType(input: MdmListByTypeInput): Promise<MdmListByTypeResult>;
        relatedOfMany(input: MdmRelatedOfManyInput): Promise<Record<string, MdmRelatedRef[]>>;
        hydrateMany(input: MdmHydrateManyInput): Promise<MdmHydratedEntity[]>;
    }
    /**
     * Attachments of any record, through the facade.
     *
     * The usecases already existed (`attachFile`/`detachFile`/`findAttachmentsByEntity`, with write-behind and
     * audit) but nothing in a generated module could reach them: `ctx.mdm` exposed only entity/prospect/
     * collection. This is the wiring, nothing more — no new rule, no new storage.
     *
     * An attachment is ORTHOGONAL to the record it belongs to (`entityType` + `entityId` + `category`), which
     * is why a photo never becomes a field of the ontology. AUTHORIZATION v1 is the owner's: whoever may read
     * or edit the record may list and attach — the caller has already been through the route's own gate, and a
     * finer rule needs the party/dataScope work that is not here yet.
     *
     * The BYTES are not this API's business: it registers metadata plus a `storageKey`. Uploading through
     * `/execBff` (JSON) is never right; that is what the presigned-URL entry point is for.
     */
    export class MdmAttachment {
        private readonly ctx;
        constructor(ctx: RequestContext);
        attach(input: AttachFileParams): Promise<MdmAttachmentRecord>;
        detach(input: DetachFileParams): Promise<{
            id: string;
            deleted: true;
        }>;
        /**
         * LIVE attachments of a record (optionally one category).
         *
         * `detach` is a SOFT delete — it stamps `deletedAt` — and the underlying query does not filter it, so a
         * gallery built straight on it would keep showing a photo the user removed. Filtering here keeps the
         * usecase (and the existing `mdm.attachment.*` route, which returns the full history) untouched, and
         * `includeDetached` is there for whoever wants the history on purpose.
         */
        listByEntity(input: FindAttachmentsByEntityParams & {
            includeDetached?: boolean;
        }): Promise<MdmAttachmentRecord[]>;
    }
    export class MdmIdentity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        findByLogin(email: string): Promise<string | null>;
        setLogin(mdmId: string, email: string): Promise<{
            mdmId: string;
            email: string;
        }>;
        invite(input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
        listUsers(input?: MdmListUsersInput): Promise<MdmListUsersResult>;
        getLoginEmail(mdmId: string): Promise<string | null>;
    }
    export function createMdmFacade(ctx: RequestContext): MdmFacade;
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    import type { MdmFacade } from "_102034_/l1/mdm/layer_3_usecases/mdmFacade";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
            userId?: string;
            authToken?: string;
            /**
             * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
             * usefully — the http transport overwrites them from the JWKS-verified token, and every other
             * identity field of this meta is discarded on that transport. This is the only channel through which
             * a request may tell execBff who it is.
             */
            verifiedUserId?: string;
            verifiedEmail?: string;
            /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
            verifiedAuthorities?: string[];
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            actorId?: string;
            actorScope?: string[];
            activeCompanyId?: string;
            activeUnitId?: string;
            workspaceId?: string;
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRegionName = 'header' | 'aside' | 'content';
    export interface FrontendDynamicRegionConfig {
        renderer: FrontendRegionRendererRegistration;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface FrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, FrontendDynamicRegionConfig>;
    }
    export interface FrontendClientShellConfig {
        mode: ShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: FrontendShellRegionProfiles;
            aside?: FrontendShellRegionProfiles;
        };
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
        /** Optional Lucide icon name. Absent when the config item has none. */
        icon?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestBusinessContext {
        activeCompanyId?: string;
        activeUnitId?: string;
    }
    export interface RequestActorSession {
        actorId?: string;
        scope?: string[];
    }
    export interface RequestCurrentWorkspace {
        workspaceId?: string;
    }
    export interface RequestProjectContext {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface RequestOrganizationContext {
        countryCode: string;
        currency?: string;
        timezone?: string;
    }
    /**
     * Typed projection of the signed-in Person onto the session — public contract, not the MDM document.
     * Resolved from the login row of `mdm_tag` for a verified e-mail; absent when the e-mail has no login.
     * The monitor test runner (`source: 'test'`) sets it from the sandbox fixture's seeded Person, with
     * `email` '' when that fixture declares no login (a simulated identity, never an invented e-mail).
     */
    export interface PlatformSessionPerson {
        mdmId: string;
        email: string;
        name: string;
    }
    export interface CollabAuthInviteClient {
        createInvite(input: {
            orgId: string;
            email: string;
            apiKey: string;
            moduleId: string;
            actorId: string;
        }): Promise<{
            token: string;
            expiresAt: string;
            teamIds?: string[];
        }>;
    }
    export interface RequestSessionContext {
        /** The Company the session acts for, resolved by the platform for the organization; it is not the signed-in Person. */
        activeCompanyId?: string;
        activeUnitId?: string;
        actorId?: string;
        actorScope?: string[];
        workspaceId?: string;
        /** Typed projection of the Person: set when `mdm.identity.findByLogin` resolves the verified e-mail, or by the monitor runner from its sandbox fixture. */
        person?: PlatformSessionPerson;
        businessContext: RequestBusinessContext;
        actorSession: RequestActorSession;
        currentWorkspace: RequestCurrentWorkspace;
        project: RequestProjectContext;
    }
    export interface RequestContext {
        data: IDataRuntime;
        mdm: MdmFacade;
        cache: ICacheRuntime;
        /** Test/override seam for collab-auth invites. Production uses COLLAB_AUTH_* env. */
        collabAuthInvite?: CollabAuthInviteClient;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        sessionContext: RequestSessionContext;
        /**
         * Caller module of this BFF (`ordenServicio2`). Absent on platform/test callers.
         * `organization` is the super module: unfiltered MDM reads and writes.
         */
        moduleId?: string;
        /** Installation/org locale — never derived from UI language. */
        organization: RequestOrganizationContext;
        sandbox?: boolean;
        requestMeta?: {
            requestId?: string;
            /**
             * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
             * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
             */
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ControllerRoute {
        key: string;
        handler: BffHandler;
    }
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
        backendControllers?: string;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        languages?: string[];
        designSystems?: string[];
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
        clientShell?: FrontendClientShellConfig;
        /** Same-origin favicon href injected into the served HTML (`<link rel="icon">`). */
        faviconHref?: string;
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/pg" {
    export { getSharedPgPool, queryRows, withPgTransaction, } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
}
declare module "_102034_/l1/mdm/tableNames" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getMdmTableNames(appEnv: AppEnv['appEnv']): {
        documents: string;
        documentsEntitiesIndex: string;
        documentsProspectsIndex: string;
        kv: string;
        relationship: string;
        prospectRelationship: string;
        auditLog: string;
        tag: string;
        comment: string;
        attachment: string;
        numberSequence: string;
        outbox: string;
        replicationFailures: string;
        monitoringWrite: string;
        errorLog: string;
        statusHistory: string;
    };
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/MdmIdentityUsersPostgres" {
    import type { Pool, PoolClient } from "_102034_/l1/mdm/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmIdentityUserReader, MdmUserDirectoryQuery } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    type PgExecutor = Pool | PoolClient;
    export interface MdmIdentityUsersPageSql {
        sql: string;
        params: unknown[];
    }
    /**
     * One page over the person index. Filters run before afterMdmId and LIMIT.
     * Table names come only from getMdmTableNames. Values and the limit are parameters.
     */
    export function buildIdentityUsersPageSql(appEnv: AppEnv['appEnv'], query: MdmUserDirectoryQuery): MdmIdentityUsersPageSql;
    export function createPostgresMdmIdentityUsersReader(env: AppEnv, executor: PgExecutor): MdmIdentityUserReader;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres" {
    import type { Pool } from "_102034_/l1/mdm/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    /**
     * `pool` is where everything lives. `moduleDataPool` splits the module tables out to another pool
     * (draft process: the MDM reads the app database, the business data stays in the draft database).
     */
    export function createPostgresDataRuntime(env: AppEnv, pool?: Pool, moduleDataPool?: Pool): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient" {
    import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function createDynamoDocumentClient(env: AppEnv): DynamoDBDocumentClient;
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAuditLogRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmAuditLogDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmAuditLogRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmAuditLogDocumentRecord): Promise<void>;
        get(id: string): Promise<MdmAuditLogDocumentRecord | null>;
    }
}
declare module "_102034_/l1/audit/layer_3_usecases/auditUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AuditHomeResponse, AuditLogDetailsParams, AuditLogDetailsResponse, AuditLogLoadParams, AuditLogResponse, AuditStatusHistoryLoadParams, AuditStatusHistoryResponse } from "_102034_/l1/audit/module";
    export function loadAuditHome(ctx: RequestContext): Promise<AuditHomeResponse>;
    export function loadAuditLog(ctx: RequestContext, input?: AuditLogLoadParams): Promise<AuditLogResponse>;
    export function loadAuditLogDetails(ctx: RequestContext, input: AuditLogDetailsParams): Promise<AuditLogDetailsResponse>;
    export function loadAuditStatusHistory(ctx: RequestContext, input?: AuditStatusHistoryLoadParams): Promise<AuditStatusHistoryResponse>;
}
declare module "_102034_/l1/audit/layer_2_controllers/auditHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const auditHomeLoadHandler: BffHandler;
    export const auditAuditLogLoadHandler: BffHandler;
    export const auditAuditLogDetailsHandler: BffHandler;
    export const auditStatusHistoryLoadHandler: BffHandler;
}
declare module "_102034_/l1/audit/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createAuditRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/mdm/integration" {
    import type { MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import { type CompactRelationshipRefs, type CompanyKind, type MdmDetailRecord, type MdmEntityIndexRecord, type MdmModuleNamespaceValue, type MdmProspectIndexRecord, type MdmRelationshipRecord, type ServiceKind } from "_102034_/l1/mdm/module";
    export type MdmSubtypeRef = MdmSubtype;
    export type { CompanyKind, ServiceKind };
    export interface MdmRef {
        mdmId: string;
        subtype: MdmSubtypeRef;
        name: string;
    }
    export interface MdmLookupResult extends MdmRef {
        status: MdmStatus | string;
        countryCode?: string | null;
        docType?: string | null;
        docId?: string | null;
        companyKind?: CompanyKind | null;
        serviceKind?: ServiceKind | null;
        parentCompanyId?: string | null;
        parentServiceId?: string | null;
        relationshipRefs?: CompactRelationshipRefs;
        moduleNamespaces?: Record<string, MdmModuleNamespaceValue>;
    }
    export interface MdmRelationshipSummary {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        status: MdmRelationshipRecord['status'];
        role?: string | null;
    }
    export interface MdmSearchFilter {
        subtype?: MdmSubtypeRef;
        status?: string;
        countryCode?: string;
        companyKind?: CompanyKind;
        serviceKind?: ServiceKind;
        docType?: string;
        docId?: string;
        query?: string;
        limit?: number;
    }
    export interface MdmIntegrationContract {
        getByMdmId(input: {
            mdmId: string;
        }): Promise<MdmLookupResult | null>;
        search(input: MdmSearchFilter): Promise<MdmLookupResult[]>;
        listRelationships(input: {
            mdmId: string;
            type?: RelationshipType;
            scope?: 'entity' | 'prospect' | 'all';
        }): Promise<MdmRelationshipSummary[]>;
        resolveCourseHierarchy(input: {
            mdmId: string;
        }): Promise<{
            current: MdmLookupResult | null;
            parentCourse: MdmLookupResult | null;
            cohorts: MdmLookupResult[];
        }>;
        resolveOrganizationTree(input: {
            mdmId: string;
        }): Promise<{
            current: MdmLookupResult | null;
            parent: MdmLookupResult | null;
            children: MdmLookupResult[];
        }>;
    }
    export type MdmRecordSummary = MdmEntityIndexRecord | MdmProspectIndexRecord;
    export function toMdmLookupResult(detail: MdmDetailRecord, summary?: Partial<MdmRecordSummary>): MdmLookupResult;
    export function toMdmRelationshipSummary(relationship: MdmRelationshipRecord): MdmRelationshipSummary;
}
declare module "_102034_/l1/mdm/persistence" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/server/layer_1_external/config/alphaAuthorities" {
    type AlphaConfig = {
        alphaAllAuthorities?: unknown;
    };
    /** Per-release alpha switch. True only when config.json has alphaAllAuthorities === true. */
    export function isAlphaAllAuthorities(_projectId?: string | number, readConfig?: () => AlphaConfig): boolean;
    export function moduleActorRefs(controllersDir: string): Promise<string[]>;
    export function resetAlphaAuthoritiesCache(): void;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeTypes" {
    export const CBE_HTTP_OK = 200;
    export const CBE_HTTP_BAD_REQUEST = 400;
    export const CBE_HTTP_UNAUTHORIZED = 401;
    export const CBE_HTTP_NOT_FOUND = 404;
    export const CBE_HTTP_NOT_MODIFIED = 304;
    export const CBE_HTTP_SERVER_ERROR = 500;
    export interface CbeProjectsLastModified {
        project: number;
        lastModified: string;
    }
    export interface CbeRequestBase {
        action: string;
    }
    export interface CbeRequestLogin extends CbeRequestBase {
        action: 'login';
        queryString?: string;
        baseProject?: number;
        actualProject?: number;
        projectsLastModified?: CbeProjectsLastModified[];
    }
    export interface CbeRequestAuthSession extends CbeRequestBase {
        action: 'authSession';
        access_token?: string;
        refresh_token?: string;
        org_id?: string;
    }
    export interface CbeSourceFile {
        /** `l<level>/<folder>/<shortName><extension>` — same key the login's filesInfo uses. */
        shortPath: string;
        content: string;
        /** utf8 for text, base64 for binary (l3 assets). */
        encoding: 'utf8' | 'base64';
    }
    export interface CbeRequestGetContents extends CbeRequestBase {
        action: 'getContents';
        project?: number;
        shortPaths?: string[];
    }
    export interface CbeRequestSetContents extends CbeRequestBase {
        action: 'setContents';
        project?: number;
        files?: CbeSourceFile[];
        deletes?: string[];
        /** The studio's save comment — becomes the message of the commit cbeGitCommit makes. */
        comments?: string | null;
    }
    export interface CbeRequestLoadFilesInfo extends CbeRequestBase {
        action: 'loadFilesInfo';
        project?: number;
    }
    export interface CbeHistoryEntry {
        /** Commit sha; opaque to the cfe, handed back verbatim to getHistoryContent. */
        ref: string;
        authorName: string;
        /** ISO-8601 author date. */
        date: string;
        message: string;
        additions: number;
        deletions: number;
    }
    export interface CbeRequestGetHistory extends CbeRequestBase {
        action: 'getHistory';
        project?: number;
        shortPath?: string;
    }
    export interface CbeRequestGetHistoryContent extends CbeRequestBase {
        action: 'getHistoryContent';
        project?: number;
        shortPath?: string;
        ref?: string;
    }
    export interface CbeRequestPromote extends CbeRequestBase {
        action: 'promote';
        project?: number;
        draft?: string;
        /** `production` merges now. `homolog` is reserved and answers NOT_YET. */
        target?: string;
        /** Becomes the merge subject: `promote <branch>: <comment>`. */
        comment?: string;
    }
    export interface CbeRequestDiscardDraft extends CbeRequestBase {
        action: 'discardDraft';
        project?: number;
        draft?: string;
    }
    export interface CbeRequestDraftResetDatabase extends CbeRequestBase {
        action: 'draftResetDatabase';
        project?: number;
        draft?: string;
    }
    export interface CbeRequestDraftRestorePaths extends CbeRequestBase {
        action: 'draftRestorePaths';
        project?: number;
        draft?: string;
        /** `main`, or a 40-hex commit that is an ancestor of the draft branch. */
        ref?: string;
        paths?: string[];
    }
    export interface CbeRequestDraftSync extends CbeRequestBase {
        action: 'draftSync';
        project?: number;
        draft?: string;
    }
    export interface CbeRequestListDrafts extends CbeRequestBase {
        action: 'listDrafts';
        project?: number;
    }
    export interface CbeRequestDraftDiff extends CbeRequestBase {
        action: 'draftDiff';
        project?: number;
        draft?: string;
        shortPath?: string;
    }
    export interface CbePrjSourcesFile {
        shortPath: string;
        versionRef?: string;
        Length?: number;
        update_at?: string;
        /** gzip+base64 of the compiled js content (same encoding the central cbe uses). */
        jsContent?: string;
    }
    export interface CbePrjSourcesInfo {
        filesInfo: CbePrjSourcesFile[];
        importsMap: string;
        indexModules: string;
    }
    export interface CbePrjSettings {
        id: number;
        name: string;
        owner: string;
        value: string;
        created_at: string;
        archived_at: string;
        repository_lastModified: string;
        userAuth: 'public' | 'private';
        prj_dependencies: number[];
        /** gzip+base64 of CbePrjSourcesInfo — only present when newer than the frontend copy. */
        files?: string;
    }
    export interface CbeOrgInfo {
        key: string;
        value: string;
        sett: {
            name: string;
            created_at: string;
            description: string;
            projects: CbePrjSettings[];
            users: string[];
            teams: {
                name: string;
                auth: string;
                usrIndex: number[];
            }[];
        };
        VersionNumber: number;
    }
    export interface CbeResponseBase {
        statusCode: number;
        msg: string;
        error?: string;
    }
    export interface CbeResponseLogin extends CbeResponseBase {
        services: unknown[];
        orgs: {
            [org: string]: CbeOrgInfo;
        };
        inits: {
            [widget: string]: string;
        };
        providers: string[];
        avatar_url: string;
        baseProject: number;
        alertMessage: string;
        errorMessage: string;
    }
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeCompiledLocal" {
    import type { CbePrjSourcesFile } from "_102034_/l1/server/layer_1_external/cbe/cbeTypes";
    /** Base dir where the mls-<id> source folders live. Order: .env override -> VM standard -> dev workspace. */
    export function getProjectsBaseDir(): string;
    /**
     * Resolves a path inside a project's source folder at the base (e.g. 'obj/compiled.zip').
     * `sourceRoot`, when set, replaces `<base>/mls-<id>` — a draft worktree, absolute.
     * Omitted, the path is exactly what it was.
     */
    export function resolveProjectSourcePath(projectId: number, relativePath: string, sourceRoot?: string): string;
    interface CompiledProjectCacheEntry {
        zipMtimeMs: number;
        /** ISO date of the compiled sources (from fileinfos.json, falling back to the zip mtime). */
        lastModified: string;
        /** gzip+base64 of CbePrjSourcesInfo, ready to send to the frontend. */
        filesPayload: string;
        /** Same list, plain — served to the VM driver's loadFilesInfo. */
        filesInfo: CbePrjSourcesFile[];
        /** true when the zip has no usable fileinfos — the project must not be sent. */
        isEmpty: boolean;
    }
    export function compressAndEncodeBase64(data: object | string | Uint8Array): string;
    export function hasCompiledZip(projectId: number): boolean;
    /**
     * The project's file list in plain form — the same index the login ships gzipped,
     * used by the VM storage driver's loadFilesInfo so both answer with one truth.
     */
    export function getProjectFilesInfo(projectId: number): CbePrjSourcesFile[];
    /**
     * Shared read of one project's compiled zip. A second caller (the login arriving
     * while boot warmup is still in flight) gets the same promise, not a second read.
     * The read itself is deferred so the caller can attach before it starts.
     */
    export function loadCompiledProject(projectId: number): Promise<CompiledProjectCacheEntry | null>;
    /**
     * After listen: warm each project's compiled zip without blocking the boot callback.
     * One project at a time, yielding between them, so `/health` stays responsive.
     * A failure is one log line inside `loadCompiledProject` and does not stop the rest.
     */
    export function warmCompiledProjects(projectIds: readonly number[]): void;
    export function getCompiledProject(projectId: number): CompiledProjectCacheEntry | null;
    /**
     * Incremental delivery control (same rule as the central cbe): only return the
     * files payload when the local compiled sources are newer than what the
     * frontend reported having in its IndexedDB.
     */
    export function getFilesIfNewer(projectId: number, frontendLastModified: string | undefined): {
        files?: string;
        lastModified: string;
    } | null;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeLogin" {
    import { type CbePrjSettings, type CbeProjectsLastModified, type CbeRequestLogin, type CbeResponseLogin } from "_102034_/l1/server/layer_1_external/cbe/cbeTypes";
    import type { ProjectSettingsConfig } from "_102029_/l2/runtimeConfigTypes";
    interface ProjectFileV1 {
        schema: number;
        generatedAt: string;
        org: {
            orgId: string;
            slug: string;
            name: string;
            createdAt: string;
        };
        project: {
            projectId: string;
            domain: string;
            appEnv: string | null;
            language: string | null;
            type: string;
            createdAt: string;
        };
        /** Private server extension. Presence is not required for login or organization. */
        collabMessages?: unknown;
    }
    /**
     * Reads the project file the sites writes at `getProjectFilesDir()`, cached by
     * mtime like the compiled.zip (cbeCompiledLocal.ts). Missing is normal and does
     * not log. Invalid (broken JSON, or schema/org.slug/org.name missing or
     * malformed) logs a console.error with the path and the error class, never
     * the parser text, file contents, stack, or cause, and is treated as missing —
     * once per mtime, since an unchanged mtime returns the cached result without
     * re-parsing.
     */
    export function readProjectFile(projectId: number): ProjectFileV1 | null;
    /**
     * One org per VM (the sites guarantees it via assertProjectBelongsToOrg). The
     * org comes from the valid project files of the servable projects: all with
     * the same org.orgId resolve to that org; files with different org.orgId log
     * a console.error (once per set of mtimes) and fall back to 'local'; no valid
     * file logs a single console.warn per process and falls back to 'local'.
     */
    export function resolveOrgInfo(projectIds: number[]): {
        slug: string;
        name: string;
        createdAt: string;
    };
    export function readProjectSettings(projectId: number): ProjectSettingsConfig;
    /** VM-wide driver announcement. An empty or whitespace-only override is absent. */
    export function announcedProjectDriver(settingsDriver: string, env: {
        CBE_PROJECT_DRIVER_OVERRIDE?: string;
    }): string;
    export function buildProjectSettings(projectId: number, projectsLastModified: CbeProjectsLastModified[]): CbePrjSettings | null;
    export function listServableProjectIds(): number[];
    export function executeCbeLogin(args: CbeRequestLogin, loginUser?: string, avatarUrl?: string): CbeResponseLogin;
}
declare module "_102034_/l1/server/layer_1_external/config/organizationConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    import { readProjectFile } from "_102034_/l1/server/layer_1_external/cbe/cbeLogin";
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    export interface OrganizationBinding {
        key: string;
        name: string;
        source: 'project-file' | 'development-project';
    }
    type SitesProjectFile = NonNullable<ReturnType<typeof readProjectFile>>;
    export interface OrganizationBindingIo {
        readProjectFile: (projectId: number) => SitesProjectFile | null;
        readProjectMode: (projectId: string) => ProjectMode;
        readL5Project: (projectId: string) => {
            orgName?: unknown;
        };
    }
    /**
     * Resolves the organization of config.defaultProjectId (the client), never the master that served the module.
     * A valid sites project file wins. A name fallback exists only when the effective source is development-project
     * and the client mode is development or presentation. The key stays org:<orgId> or development-org:<NFKC lower>.
     * An explicit organization field is not allowed to read or validate the cadastro module.
     * With neither organization nor onboarding, a missing file returns null and does not invent an organization.
     */
    export function resolveOrganizationBinding(config: ProjectsConfig, io?: Partial<OrganizationBindingIo>): OrganizationBinding | null;
}
declare module "_102034_/l1/server/layer_1_external/config/onboardingConfig" {
    import type { ProjectOnboardingConfig, ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export type { OrganizationBinding, OrganizationBindingIo } from "_102034_/l1/server/layer_1_external/config/organizationConfig";
    export { resolveOrganizationBinding } from "_102034_/l1/server/layer_1_external/config/organizationConfig";
    export class OnboardingConfigError extends Error {
        constructor(message: string);
    }
    /** Returns null when onboarding is omitted. Throws when the block is present but incomplete. */
    export function readOnboardingConfig(config: Pick<ProjectsConfig, 'onboarding'> | null | undefined): ProjectOnboardingConfig | null;
}
declare module "_102034_/l1/server/layer_1_external/config/registrationScope" {
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import { type OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    export function loadRegistrationScope(): {
        projectId: string;
        binding: OrganizationBinding;
        config: ProjectOnboardingConfig;
    };
}
declare module "_102034_/l1/mdm/layer_3_usecases/registrationContracts" {
    /** Session claims resolved on the server. Never taken from a request body. */
    export interface RegistrationActor {
        email: string;
        name: string;
    }
    export type SelfRegistrationStatus = 'ready' | 'incomplete' | 'pending';
    /** Company readiness does not affect status. Person completeness is the rt80 predicate. */
    export interface SelfRegistrationResult {
        status: SelfRegistrationStatus;
        person?: {
            mdmId: string;
        };
        requestId?: string;
        company: {
            mdmId: string;
        };
    }
    export type AccessRequestStatus = 'pending' | 'resolved';
    export type AccessRequestDecision = 'use-existing' | 'create-new';
    /**
     * candidateId is a token reserved on the request.
     * It is not an mdmId and is not a free resolution parameter.
     */
    export interface AccessRequestCandidate {
        candidateId: string;
        mdmId: string;
    }
    /**
     * email, candidate mdmId and resolvedMdmId stay inside the stored record.
     * Callers resolve by requestId plus a reserved candidateId, not by those fields.
     */
    export interface AccessRequestRecord {
        schema: 1;
        kind: 'access-request';
        requestId: string;
        organizationKey: string;
        email: string;
        name: string;
        status: AccessRequestStatus;
        version: number;
        createdAt: string;
        updatedAt: string;
        candidates: AccessRequestCandidate[];
        reservedPersonId?: string;
        resolvedMdmId?: string;
        decision?: AccessRequestDecision;
    }
    /** Person that owns a matching contact. Finding one never links a login. */
    export interface RegistrationCandidateRef {
        mdmId: string;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/registrationCandidates" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { RegistrationCandidateRef } from "_102034_/l1/mdm/layer_3_usecases/registrationContracts";
    export function normalizeRegistrationEmail(email: string): string;
    /**
     * Every Person that owns a ContactChannel for this email.
     * Owners come from an in-force HasContact or from a persisted ContactSummary
     * that points at that same channel. Companies and other channels are ignored.
     * The list is deduped. Nothing here creates or links a login.
     */
    export function findRegistrationCandidates(ctx: RequestContext, email: string): Promise<RegistrationCandidateRef[]>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/registrationStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    /** Platform KV prefix. Public mdm.kv get/put must refuse it. */
    export const REGISTRATION_STORE_PREFIX = "runtime.onboarding/";
    export function isRegistrationStoreKey(key: string): boolean;
    export function assertPublicKvKey(key: unknown): void;
    /** Missing row is null. A stored row that is not platform JSON throws. */
    export function readRegistrationStore(ctx: RequestContext, key: string): Promise<Record<string, unknown> | null>;
    export function writeRegistrationStore(ctx: RequestContext, key: string, value: Record<string, unknown>): Promise<void>;
    /** lockKey = prefix + SHA-256 of the JSON tuple. Same tuple, same key. */
    export function registrationLockKey(scope: readonly unknown[]): string;
    /**
     * Keyed transaction. The callback sees bound data, a rebound facade and a private cache.
     * The parent cache is left untouched; callers drop identityCacheKey on the parent only after this resolves.
     */
    export function withRegistrationTransaction<TValue>(ctx: RequestContext, scope: readonly unknown[], callback: (ctx: RequestContext) => Promise<TValue>): Promise<TValue>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeAuthJwt" {
    import { type JWTPayload } from 'jose';
    export interface CollabAuthClaims extends JWTPayload {
        sub: string;
        email: string;
        name?: string;
        /** Standard OIDC profile claim — avatar URL (tokens issued before the claim existed lack it). */
        picture?: string;
        org_id?: string;
        active_org?: {
            id?: string;
        };
        orgs?: Array<{
            id?: string;
            name?: string;
        }>;
    }
    export function isJwtAuthEnabled(): boolean;
    /**
     * Verifies a collab-auth access token offline against the cached JWKS.
     * Honors `grace_until`: an expired token is still accepted while within its
     * grace window (same behavior as the central cbe / collab-llm).
     */
    export function verifyAccessToken(token: string): Promise<CollabAuthClaims>;
    /** An org list is a choice, not an active tenant. Conflicting signed claims are invalid. */
    export function activeOrganizationId(claims: CollabAuthClaims): string | null;
    export function availableOrganizations(claims: CollabAuthClaims): Array<{
        id: string;
        name: string;
    }>;
    export function sameSelectedSession(previous: CollabAuthClaims, current: CollabAuthClaims, orgId: string | null): boolean;
    /** The issuer checks membership; the returned JWT is checked again locally. */
    export function selectOrganization(accessToken: string, original: CollabAuthClaims, orgId: string): Promise<string | null>;
    /** Exchanges a refresh token for a fresh access token; null on any failure. */
    export function refreshAccessToken(refreshToken: string, orgId?: string): Promise<string | null>;
    /** Session fields taken from a verified access token. Null when it has no active org. */
    export function jwtSessionFromClaims(claims: CollabAuthClaims, extra?: Pick<JwtSession, 'newAccessToken'>): JwtSession | null;
    export interface JwtSession {
        email?: string;
        /** OIDC picture claim — the login response's avatar_url. */
        picture?: string;
        /** Active organization from the verified access token. */
        orgId?: string;
        /** Set when a refresh produced a new access token that should replace the cauth cookie. */
        newAccessToken?: string;
    }
    /**
     * Resolves the JWT session from the cauth/crefresh cookie values. Returns an
     * empty session (anonymous) when there is no usable JWT — never throws.
     */
    export function resolveJwtSession(cauth: string, crefresh: string): Promise<JwtSession>;
    /** Parses a Cookie request header into name -> decoded value (last one wins). */
    export function parseCookies(header: string | undefined): Record<string, string>;
}
declare module "_102034_/l1/server/layer_1_external/config/localTestConfig" {
    /** Aliases provisioned by the lima bench. Browser-supplied MDM or cm ids are not a lookup key. */
    export const LOCAL_TEST_ALIASES: readonly ["responsavel", "membro"];
    export type LocalTestAlias = (typeof LOCAL_TEST_ALIASES)[number];
    export interface LocalTestPersona {
        alias: LocalTestAlias;
        email: string;
        name: string;
        sub: string;
        personMdmId: string;
        cmUserId: string;
    }
    export interface LocalTestConfig {
        enabled: true;
        projectId: string;
        organizationKey: string;
        companyMdmId: string;
        cmOrgId: string;
        cmTarget: string;
        storagePrefix: string;
        allowedOrigins: readonly string[];
        cookieKey: string;
        personas: Record<LocalTestAlias, LocalTestPersona>;
    }
    export type LocalTestConfigState = {
        enabled: false;
    } | LocalTestConfig;
    export class LocalTestConfigError extends Error {
        constructor(message: string);
    }
    export interface LocalTestConfigDeps {
        readText?: (filePath: string) => string;
        fileMode?: (filePath: string) => number;
        defaultProjectId?: () => string;
        /** When set, skips l5/project.json. `declared: false` is an undeclared mode. */
        projectMode?: (projectId: string) => {
            declared: boolean;
            mode: string;
        };
    }
    /** Slot port of a client project id (102047 → 2047). Unknown shapes are refused. */
    export function localTestAppPort(projectId: string): number | null;
    /**
     * Reads the private lima manifest once the flag and the absolute path are both set.
     * Anything else returns disabled without touching the file. Callers that need a fresh
     * file must call `resetLocalTestConfigCache` and reload the process configuration.
     */
    export function loadLocalTestConfig(env?: NodeJS.ProcessEnv, deps?: LocalTestConfigDeps): LocalTestConfigState;
    /** Process cache. A changed manifest is picked up only after `resetLocalTestConfigCache`. */
    export function getLocalTestConfig(env?: NodeJS.ProcessEnv, deps?: LocalTestConfigDeps): LocalTestConfigState;
    export function resetLocalTestConfigCache(): void;
    /** Server-side resolution by alias, email or sub. Ids from the browser are ignored. */
    export function lookupLocalTestPersona(query: {
        alias?: string;
        email?: string;
        sub?: string;
    }, state?: LocalTestConfigState): LocalTestPersona | null;
    /**
     * The proxy calls this with the target it is about to use.
     * A disabled bench or any other destination refuses, and the message carries no secret.
     */
    export function assertLocalTestProxyTarget(effectiveTarget: string, state?: LocalTestConfigState): void;
}
declare module "_102034_/l1/server/layer_1_external/auth/localTestSession" {
    import { type LocalTestAlias, type LocalTestConfig, type LocalTestConfigState, type LocalTestPersona } from "_102034_/l1/server/layer_1_external/config/localTestConfig";
    /** Selection cookie. The value is an HMAC payload, not an IdP JWT. */
    export const LOCAL_TEST_COOKIE_PREFIX = "collab_local_test_";
    export const LOCAL_TEST_MAX_AGE_SEC: number;
    /** Same shape the BFF accepts (`CollabAuthClaims` / jose `JWTPayload`), including the string index. */
    export interface LocalTestSessionClaims {
        sub: string;
        email: string;
        name: string;
        active_org: {
            id: string;
        };
        [propName: string]: unknown;
    }
    export type LocalTestHeaderOutcome = {
        kind: 'skip';
    } | {
        kind: 'reject';
    } | {
        kind: 'ok';
        claims: LocalTestSessionClaims;
        source: 'local-test';
    };
    export function localTestCookieName(projectId: string): string;
    /** Sign the bench selection. Ids stay in the manifest; the cookie carries only the alias. */
    export function mintLocalTestCookie(alias: LocalTestAlias, state: LocalTestConfig, nowMs?: number): string;
    /**
     * Verify one cookie against the manifest. A forged person id or cm id in the payload is ignored:
     * the alias is the only selector, and the profile comes from the server-side manifest.
     */
    export function readLocalTestCookie(token: string, state: LocalTestConfig, host: string, origin: string, nowMs?: number): LocalTestPersona | null;
    export function claimsForLocalTestPersona(persona: LocalTestPersona, state: LocalTestConfig): LocalTestSessionClaims;
    /** Tests substitute the manifest reader. Production always uses the process cache. */
    export function setLocalTestConfigLoaderForTests(loader?: () => LocalTestConfigState): void;
    /**
     * No real cauth/Bearer was presented. Disabled bench: ignore a leftover cookie.
     * Active bench with a bad cookie: explicit rejection. No cookie: caller keeps the anonymous path.
     */
    export function localTestSessionFromHeaders(headers: Record<string, string | string[] | undefined> | undefined, nowMs?: number): LocalTestHeaderOutcome;
}
declare module "_102034_/l1/server/layer_1_external/auth/bffAuth" {
    import { type JWTPayload } from 'jose';
    export interface CollabAuthClaims extends JWTPayload {
        sub: string;
        email: string;
        name?: string;
        /**
         * Module authorities of the user, as `<moduleId>:<actorId>` (`petShop:admin`) — the platform's own role
         * shape (`sites:admin`, `collab-llm:operator`) and exactly what the generated controllers already gate
         * on. The issuer writes them on `active_org.teams[].roles`; these top-level fields are read if present.
         */
        authorities?: string[];
        /** Same list under the name the platform uses elsewhere; whichever arrives is read. */
        roles?: string[];
        /** Org selected at login. `teams[].roles` is `<module>:<permission>` — the platform convention. */
        active_org?: {
            id?: string;
            teams?: Array<{
                id?: string;
                name?: string;
                roles?: string[];
            }>;
        };
    }
    /**
     * Every authority in the verified claims: top-level `authorities` ∪ `roles` ∪ `active_org.teams[].roles`.
     * Non-empty strings, deduplicated, no module filter. `/session/info` returns this set to the shell menu
     * and the monitor card; `moduleAuthorities` is the same list kept when it starts with `<moduleId>:`.
     */
    export function claimAuthorities(claims: CollabAuthClaims | undefined): string[];
    /**
     * The authorities of a module, from verified claims — `<moduleId>:<actorId>` filtered by this module.
     *
     * The prefix is the filter, not a convention to re-derive: an authority of another module says nothing
     * about this one. The list is what `sessionContext.actorScope` becomes, which is what `enforceActors` in
     * every generated controller reads.
     */
    export function moduleAuthorities(claims: CollabAuthClaims | undefined, moduleId: string): string[];
    /**
     * Is an EMPTY authority list a refusal?
     *
     * Today it is not: `enforceActors` treats an empty scope as permissive, which is why the actor gate is
     * inert for real HTTP traffic. Flipping that before the issuer emits authorities would lock every user out
     * of every module, so it waits behind its own flag (`BFF_ACTORS_ENFORCED`, default false) — the same staged
     * shape as the authentication itself.
     */
    export function isActorEnforcementOn(): boolean;
    /**
     * Is the 401 ENFORCED?
     *
     * Default **false** on purpose (stage 1 of the rollout): the verifier runs and the server reports who
     * WOULD have been rejected, without locking anyone out of an app that is already published. Flipping
     * `BFF_JWT_ENABLED=true` is a later act — env + restart, no deploy — and the same env back to `false` is
     * the emergency rollback afterwards.
     */
    export function isBffAuthEnforced(): boolean;
    /** A bearer token from an Authorization header value, or '' when absent/malformed. */
    export function bearerFromHeader(authorization: string | undefined): string;
    /** The value of one cookie from a raw Cookie header, or '' when absent. */
    export function cookieFromHeader(cookieHeader: string | undefined, name: string): string;
    /** Cookie `cauth` first (the browser path), Authorization header second. */
    export function tokenFromRequest(headers: Record<string, string | string[] | undefined> | undefined): string;
    /** Verified claims, honouring `grace_until` exactly like the rest of the platform. */
    export function verifyAccessToken(token: string): Promise<CollabAuthClaims>;
    export interface BffAuthOutcome {
        /** Verified identity, when a valid token was presented. */
        claims?: CollabAuthClaims;
        /** True when the request must be refused (no/invalid token AND enforcement is on). */
        reject: boolean;
        reason: 'ok' | 'missing-token' | 'invalid-token';
        newAccessToken?: string;
        /** Set only when the identity came from the lima bench cookie, not from collab-auth. */
        source?: 'local-test';
    }
    /**
     * Resolve the session of one `/execBff` call. Never throws: an unverifiable token is an OUTCOME, not an
     * exception, because stage 1 has to keep serving while reporting who would have been rejected.
     */
    export function resolveBffSession(headers: Record<string, string | string[] | undefined> | undefined): Promise<BffAuthOutcome>;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_1_external/observability/ConsoleLogger" {
    import type { ILogger } from "_102034_/l1/server/layer_2_controllers/contracts";
    export class ConsoleLogger implements ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/moduleRegistry" {
    import { type BffHandler, type ModuleBffRegistration, type RoutineResolution } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function loadRouterFromControllers(controllersDir: string): Promise<Map<string, BffHandler>>;
    export function loadConfiguredModuleCompositionRoot(projectId: string, moduleId: string): Promise<void>;
    export function resetConfiguredModuleCompositionCache(): void;
    export function getModuleBffRegistrations(): ModuleBffRegistration[];
    export function resolveRoutineResolution(routine: string): RoutineResolution;
    export function loadModuleRouter(registration: ModuleBffRegistration): Promise<Map<string, BffHandler>>;
    export function resetModuleRouterCache(): void;
}
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmIdentityUsersMemory" {
    import { type MdmIdentityUserReader } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    /** Reads users from the tables of the given runtime. Does not open another store. */
    export function createMemoryMdmIdentityUsersReader(runtime: IDataRuntime): MdmIdentityUserReader;
}
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    /** `sandbox`: a disposable run (the monitor) loads initial and test seed rows whatever the mode. */
    export function createMemoryDataRuntime(options?: {
        sandbox?: boolean;
    }): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/runtimeFactory" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    export function getSharedDataRuntime(): IDataRuntime;
    export function resetSharedDataRuntime(): void;
}
declare module "_102034_/l1/monitor/module" {
    export type MonitorStatusGroup = 'success' | 'client_error' | 'server_error' | 'not_found';
    export interface MonitorBffExecutionLogRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    /** Continuous aggregate — no id or updatedAt, maintained by TimescaleDB. */
    export interface MonitorBffExecutionAggregateMinuteRecord {
        bucketStart: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        totalCount: number;
        successCount: number;
        clientErrorCount: number;
        serverErrorCount: number;
        notFoundCount: number;
        totalDurationMs: number;
    }
    export interface MonitorClientTelemetryEventRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        module: string;
        routine: string;
        eventType: string;
        label?: string | null;
        durationMs?: number | null;
        metadata?: unknown;
        recordedAt: string;
        receivedAt: string;
    }
    export interface MonitorSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorExecutionEvent {
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/persistence/MonitorPersistenceMetadata" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export interface MonitorTableMetadata {
        projectId: string;
        moduleId: string;
        repositoryName: string;
        tableName: string;
        logicalTableName: string;
        runtimeDatabase: string;
        description: string;
        purpose: string;
        storageProfile: string;
        backupHot: boolean;
        writeMode: string;
        dynamoTableName: string | null;
        dynamoPartitionKey: string | null;
        dynamoSortKey: string | null;
        dynamoTtlField: string | null;
        localIndexes: Array<{
            name: string;
            unique: boolean;
            columns: string[];
        }>;
        detailsInDynamoOnly: boolean;
    }
    export class MonitorPersistenceMetadata {
        private readonly env;
        constructor(env: AppEnv);
        listAll(): Promise<MonitorTableMetadata[]>;
        listPostgresTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        listDynamoTables(): Promise<import("_102034_/l1/server/layer_1_external/persistence/contracts").ResolvedTableDefinition[]>;
        findByPostgresTableName(tableName: string): Promise<MonitorTableMetadata | null>;
        findByDynamoTableName(tableName: string): Promise<MonitorTableMetadata | null>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/operations" {
    export type MonitorOperationsWindow = '1h' | '6h' | '24h' | '7d';
    export type MonitorOperationsSeverity = 'green' | 'yellow' | 'red';
    export interface MonitorOperationsSummaryRequest {
        window?: MonitorOperationsWindow;
        module?: string;
    }
    export interface MonitorOperationsSummaryResponse {
        generatedAt: string;
        window: {
            label: MonitorOperationsWindow;
            hours: number;
            startedAt: string;
            finishedAt: string;
            previousStartedAt: string;
            previousFinishedAt: string;
        };
        severity: MonitorOperationsSeverity;
        health: {
            score: number;
            reasons: string[];
        };
        filters: {
            module: string | null;
        };
        executions: {
            total: number;
            success: number;
            clientError: number;
            serverError: number;
            notFound: number;
            okPercent: number;
            avgDurationMs: number;
            p95DurationMs: number;
            p99DurationMs: number;
            previous: {
                total: number;
                serverError: number;
                okPercent: number;
                p95DurationMs: number;
            };
            change: {
                total: number;
                serverError: number;
                okPercent: number;
                p95DurationMs: number;
            };
            slowestRoutines: Array<{
                routine: string;
                module: string;
                total: number;
                avgDurationMs: number;
                p95DurationMs: number;
                lastFinishedAt: string;
            }>;
            failingRoutines: Array<{
                routine: string;
                module: string;
                total: number;
                failures: number;
                failurePercent: number;
                lastFinishedAt: string;
                lastErrorCode: string | null;
            }>;
        };
        abends: {
            total: number;
            groups: Array<{
                routine: string;
                module: string;
                count: number;
                firstAt: string;
                lastAt: string;
                latest: {
                    requestId: string;
                    traceId: string;
                    statusCode: number;
                    errorCode: string | null;
                    errorStack: string | null;
                    durationMs: number;
                };
            }>;
        };
        frontendErrors: {
            total: number;
            groups: Array<{
                routine: string;
                eventType: string;
                count: number;
                firstAt: string;
                lastAt: string;
                latestLabel: string | null;
            }>;
        };
        release: {
            activeId: string | null;
            activatedAt: string | null;
            cwd: string;
        };
        infra: {
            process: {
                uptimeSeconds: number;
                nodeVersion: string;
                pid: number;
                rssMb: number;
                heapUsedMb: number;
            };
            system: {
                totalMemMb: number;
                freeMemMb: number;
                freeMemPercent: number;
                cpuCount: number;
                loadAvg1m: number;
                loadAvg5m: number;
                loadAvg15m: number;
            };
            postgres: {
                currentDatabase: string;
                activeConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                pendingOutbox: number;
                replicationFailures: number;
            };
            disks: Array<{
                path: string;
                exists: boolean;
                sizeBytes: number | null;
                freeBytes: number | null;
                usedPercent: number | null;
            }>;
        };
        copyText: string;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres" {
    import { type AttributeValue } from '@aws-sdk/client-dynamodb';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MonitorBffExecutionLogRecord, MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    import type { MonitorOperationsSummaryResponse } from "_102034_/l2/monitor/shared/contracts/operations";
    type MonitorPostgresColumn = {
        name: string;
        dataType: string;
        isNullable: boolean;
        defaultValue: string | null;
    };
    type MonitorPostgresIndex = {
        name: string;
        unique: boolean;
        method: string;
        columns: string[];
    };
    type MonitorDynamoKey = Record<string, AttributeValue>;
    export function normalizeStringList(value: unknown): string[];
    export function isSafeMonitorIdentifier(value: string): boolean;
    export function normalizeInspectFilters(input: unknown): Record<string, string>;
    export function normalizeDynamoKey(key: MonitorDynamoKey | undefined): string | null;
    export function decodeDynamoKey(cursor?: string | null): MonitorDynamoKey | undefined;
    export function parseRoutineParts(routine: string): {
        module: string;
        pageName: string;
        command: string;
    };
    export function getStatusGroup(statusCode: number): "success" | "client_error" | "server_error" | "not_found";
    /**
     * The draft process (`COLLAB_DRAFT`) runs with no AWS door on purpose: env, files and network are closed to its own
     * database. The AWS SDK then fails inside promises nobody awaits and Deno ends the whole process, so a draft never
     * calls DynamoDB: it answers like the non-postgres modes (tables listed, `exists: false`).
     */
    export function dynamoIsReachable(runtimeMode: AppEnv['runtimeMode'], draftSlug: string | undefined): boolean;
    export class MonitorRuntimePostgres {
        private readonly env;
        private readonly metadata;
        constructor(env?: AppEnv);
        recordExecution(event: MonitorExecutionEvent): Promise<void>;
        static isMissingMonitorStorageError(error: unknown): boolean;
        listKnownPostgresTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
        }>>;
        private listAvailableDatabases;
        private getKnownPostgresTableNames;
        private getKnownDynamoTableNames;
        private getTableNameByRepositoryName;
        private assertKnownPostgresTable;
        private assertKnownDynamoTable;
        private getPoolForDatabase;
        private listPostgresColumns;
        private getPostgresPrimaryKey;
        private listPostgresIndexes;
        private getPostgresTableMetrics;
        listKnownPostgresTablesDetailed(databaseName?: string): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
            totalSizeBytes: number | null;
        }>>;
        getPostgresTableDetails(input: {
            databaseName?: string;
            tableName: string;
        }): Promise<{
            databaseName: string;
            tableName: string;
            logicalTableName: string | null;
            projectId: string | null;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            metrics: {
                rowCount: number;
                totalSizeBytes: number;
            };
            columns: MonitorPostgresColumn[];
            primaryKey: string[];
            indexes: MonitorPostgresIndex[];
        }>;
        inspectPostgresTable(input: {
            databaseName?: string;
            tableName: string;
            page?: number;
            filters?: unknown;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<Pick<MonitorPostgresColumn, 'name' | 'dataType' | 'isNullable'>>;
            pagination: {
                page: number;
                pageSize: number;
                totalRows: number;
                totalPages: number;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            order: {
                primary: string[];
                fallback: string;
            };
        }>;
        listKnownDynamoTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            itemCount: number | null;
            tableStatus: string | null;
            tableSizeBytes: number | null;
            metricsAreApproximate: boolean;
        }>>;
        getPostgresSnapshot(input?: {
            databaseName?: string;
        }): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            connection: {
                host: string;
                port: number;
                runtimeDatabase: string;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                activeConnectionsByState: Record<string, number>;
                maxConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        }>;
        getDynamoSnapshot(): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            region: string;
            tables: Array<{
                tableName: string;
                description: string | null;
                moduleId: string | null;
                repositoryName: string | null;
                storageProfile: string | null;
                backupHot: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        }>;
        getDynamoTableDetails(input: {
            tableName: string;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            summary: {
                tableStatus: string | null;
                itemCount: number;
                tableSizeBytes: number;
                billingMode: string | null;
                tableClass: string | null;
                metricsAreApproximate: boolean;
            };
            keys: {
                partitionKey: string | null;
                sortKey: string | null;
            };
            attributeDefinitions: Array<{
                name: string;
                type: string;
            }>;
            globalSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
            localSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
        }>;
        inspectDynamoTable(input: {
            tableName: string;
            cursor?: string;
            filters?: unknown;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<{
                name: string;
                type: string;
                filterable: boolean;
            }>;
            pagination: {
                pageSize: number;
                cursor: string | null;
                nextCursor: string | null;
                hasNextPage: boolean;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            metricsAreApproximate: boolean;
        }>;
        getSnapshotData(): Promise<{
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<MonitorBffExecutionLogRecord, 'routine' | 'statusCode' | 'statusGroup' | 'errorCode' | 'finishedAt'>>;
        }>;
        loadOperationsSummaryData(input: {
            windowHours: number;
            module?: string;
        }): Promise<{
            executions: MonitorOperationsSummaryResponse['executions'];
            abends: MonitorOperationsSummaryResponse['abends'];
            frontendErrors: MonitorOperationsSummaryResponse['frontendErrors'];
            postgres: MonitorOperationsSummaryResponse['infra']['postgres'];
        }>;
        recordTelemetry(events: Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            module: string;
            routine: string;
            eventType: string;
            label: string;
            durationMs: number | null;
            metadata: Record<string, unknown> | null;
            recordedAt: string;
            receivedAt: string;
        }>): Promise<void>;
        /** Recent frontend errors (js_error / unhandled_rejection) captured by the client telemetry. */
        loadClientErrors(input: {
            limit?: number;
            sinceHours?: number;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            eventType: string;
            label: string;
            metadata: Record<string, unknown> | null;
            recordedAt: string;
            receivedAt: string;
        }>>;
        loadRequestTrace(input: {
            requestId?: string;
            traceId?: string;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            ok: boolean;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
        loadAbends(input: {
            module?: string;
            limit?: number;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore" {
    import type { MonitorExecutionEvent, MonitorSeriesPoint } from "_102034_/l1/monitor/module";
    export class BffExecutionSeriesStore {
        private readonly maxWindowSeconds;
        private readonly buckets;
        constructor(maxWindowSeconds?: number);
        record(event: MonitorExecutionEvent): void;
        getSeries(input?: {
            windowSeconds?: number;
            routine?: string;
            source?: 'http' | 'message' | 'test';
        }): MonitorSeriesPoint[];
        reset(): void;
        private trim;
        private listRecentTimestamps;
        private incrementDetailPoint;
    }
    export function getSharedBffExecutionSeriesStore(): BffExecutionSeriesStore;
    export function resetSharedBffExecutionSeriesStore(): void;
}
declare module "_102034_/l1/monitor/layer_4_entities/MonitorExecutionEntity" {
    import type { MonitorExecutionEvent } from "_102034_/l1/monitor/module";
    export class MonitorExecutionEntity {
        static record(event: MonitorExecutionEvent): Promise<void>;
    }
}
declare module "_102034_/l1/server/layer_2_controllers/execBff" {
    import { type BffRequest, type BffResponse, type RequestContext, type RequestOrganizationContext, type RequestSessionContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    type SessionContextInput = Partial<RequestSessionContext> & {
        activeCompanyId?: string;
        activeUnitId?: string;
        actorId?: string;
        actorScope?: string[];
        workspaceId?: string;
        person?: RequestSessionContext['person'];
    };
    export interface CreateRequestContextOptions {
        sessionContext?: SessionContextInput;
        sandbox?: boolean;
        moduleId?: string;
        organization?: Partial<RequestOrganizationContext>;
        cache?: RequestContext['cache'];
        collabAuthInvite?: RequestContext['collabAuthInvite'];
    }
    export function readOrganizationContext(overrides?: Partial<RequestOrganizationContext>): RequestOrganizationContext;
    export function createRequestContext(dataRuntime?: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime, options?: CreateRequestContextOptions): RequestContext;
    export function createDefaultRequestContext(): RequestContext;
    /**
     * Who the session belongs to, from the only sources that may decide it.
     *
     * `http` carries whatever the browser typed, so nothing it CLAIMS about identity is read: the transport
     * has already verified the collab-auth token (cookie `cauth`) and put the claims in `verifiedUserId` /
     * `verifiedEmail`, and those are the only identity fields of an http meta that mean anything. Before
     * this, `meta.actorId ?? meta.userId` became `sessionContext.actorId` and the generated controllers
     * authorize from there (`enforceActors`) — a request body granting itself permissions.
     *
     * `message` (collab-messages) and `test` (the monitor runner) are server-side callers and keep declaring
     * directly. Exported because it is the one line standing between a request body and the authorization
     * gate of every generated controller.
     */
    export function trustedIdentityClaims(meta: BffRequest['meta']): BffRequest['meta'] | undefined;
    export type AlphaAuthorityDeps = {
        isAlphaAllAuthorities?: (projectId?: string | number) => boolean;
        moduleActorRefs?: (controllersDir: string) => Promise<string[]>;
    };
    /** Union of the JWT authorities with every `<moduleId>:<actorRef>` when alpha is on. Pure aside from `deps`. */
    export function withAlphaAuthorities(meta: BffRequest['meta'], moduleId: string, projectId: string | number | undefined, controllersDir: string | undefined, deps?: AlphaAuthorityDeps): Promise<BffRequest['meta']>;
    export function execBff(request: BffRequest, ctx?: RequestContext): Promise<{
        response: BffResponse;
        statusCode: number;
    }>;
    /** Resolve the MDM person for a verified login e-mail onto the session. No row → unchanged. */
    export function applyVerifiedEmailToSession(ctx: RequestContext, session: RequestSessionContext, verifiedEmail: string | undefined): Promise<RequestSessionContext>;
    export function createSessionContext(overrides?: SessionContextInput): RequestSessionContext;
}
declare module "_102034_/l1/mdm/layer_3_usecases/organizationBootstrap" {
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import type { OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface OrganizationCompany {
        companyMdmId: string;
    }
    /** One-shot fault for the memory resume tests. Production leaves this null. */
    export type OrganizationBootstrapFault = 'after-reserve' | 'before-return';
    export function setOrganizationBootstrapFault(next: OrganizationBootstrapFault | null): void;
    /** Synchronous. Does not read config, the database, or process.env. */
    export function getResolvedOrganizationCompanyId(): string | undefined;
    export function resetResolvedOrganizationCompanyId(): void;
    export function organizationReservationKey(organizationKey: string): string;
    /**
     * One Company per organization key, with no module role.
     * The reservation is written before the MDM row so a memory process can resume after a later step fails.
     * Postgres holds the same steps in one locked transaction.
     */
    export function ensureOrganizationIdentity(ctx: RequestContext, binding: OrganizationBinding): Promise<OrganizationCompany>;
    /**
     * Onboarding adapter. Same reservation and the same transaction as identity, then the company role.
     * Creating the Company and attaching the role are not two transactions.
     */
    export function ensureOrganizationCompany(ctx: RequestContext, binding: OrganizationBinding, config: ProjectOnboardingConfig): Promise<OrganizationCompany>;
    /**
     * Boot/migrate entry. A missing module still ensures the organization Company.
     * A null binding (legacy preview without an organization source) does not create one.
     * The id is cleared first and published only after ensure succeeds.
     */
    export function initializeOrganizationForProcess(): Promise<void>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/selfRegistration" {
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import type { OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmDetailRecord } from "_102034_/l1/mdm/module";
    import type { AccessRequestRecord, RegistrationActor, SelfRegistrationResult } from "_102034_/l1/mdm/layer_3_usecases/registrationContracts";
    /** One-shot fault so memory tests can resume after a completed MDM step. */
    export type SelfRegistrationFault = 'after-reserve' | 'after-create' | 'after-set-login' | 'after-link';
    export function setSelfRegistrationFault(next: SelfRegistrationFault | null): void;
    /** Same fault points as self-registration, for a decision that resumes the reserved person. */
    export function checkSelfRegistrationFault(phase: SelfRegistrationFault): void;
    export function requestIndexKey(organizationKey: string, email: string): string;
    export function requestRecordKey(requestId: string): string;
    export function requireCompany(ctx: RequestContext, binding: OrganizationBinding): Promise<string>;
    export function isRequestIndex(value: Record<string, unknown>, organizationKey: string, email: string): string;
    export function isAccessRequest(value: Record<string, unknown>, requestId: string, organizationKey: string, email: string): AccessRequestRecord;
    /** Open or reload the organization e-mail request. Retry keeps the same requestId and tokens. */
    export function openOrRecoverAccessRequest(ctx: RequestContext, input: {
        organizationKey: string;
        email: string;
        name: string;
        candidateMdmIds: string[];
    }): Promise<AccessRequestRecord>;
    export function reserveLoginPerson(ctx: RequestContext, email: string, personMdmId?: string): Promise<string>;
    export function ensureDraftPerson(ctx: RequestContext, personMdmId: string, name: string): Promise<void>;
    /** Role tag and member link. Skips writes that are already present. Does not write the module namespace. */
    export function attachPersonMembership(ctx: RequestContext, input: {
        personMdmId: string;
        companyMdmId: string;
        moduleId: string;
        personType: string;
    }): Promise<void>;
    export function personByLogin(ctx: RequestContext, email: string): Promise<MdmDetailRecord | null>;
    /**
     * Repeated self-registration for a server-resolved actor.
     * The lock is the e-mail in this database. The request is per organization and e-mail.
     * Callers drop the parent identity cache only after this returns.
     */
    export function ensureSelfRegistration(ctx: RequestContext, binding: OrganizationBinding, config: ProjectOnboardingConfig, actor: RegistrationActor): Promise<SelfRegistrationResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/registrationRequests" {
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import type { OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AccessRequestDecision, AccessRequestRecord, RegistrationActor } from "_102034_/l1/mdm/layer_3_usecases/registrationContracts";
    /** What the requester is allowed to see: status and id of their own request. */
    export interface OwnAccessRequestProjection {
        requestId: string;
        status: AccessRequestRecord['status'];
        version: number;
    }
    /** Organization follow-up. Candidate tokens only; mdmId is not a resolution parameter. */
    export interface OrganizationAccessRequestProjection {
        requestId: string;
        organizationKey: string;
        email: string;
        name: string;
        status: AccessRequestRecord['status'];
        version: number;
        candidateIds: string[];
        decision?: AccessRequestDecision;
        resolvedMdmId?: string;
    }
    export interface ResolveAccessRequestInput {
        requestId: string;
        expectedVersion: number;
        decision: AccessRequestDecision;
        candidateId?: string;
    }
    export interface AccessRequestDecisionResult {
        requestId: string;
        status: 'resolved';
        version: number;
        decision: AccessRequestDecision;
        person: {
            mdmId: string;
        };
        company: {
            mdmId: string;
        };
        registrationStatus: 'ready' | 'incomplete';
    }
    /**
     * Open or resend the organization request. A resend cannot rewrite email, name, id or tokens.
     * Candidates come from the registration query, not from the caller.
     */
    export function openAccessRequest(ctx: RequestContext, binding: OrganizationBinding, actor: RegistrationActor): Promise<OwnAccessRequestProjection>;
    /** Own request only. A different e-mail or organization does not receive the record. */
    export function readOwnAccessRequest(ctx: RequestContext, input: {
        requestId: string;
        organizationKey: string;
        email: string;
    }): Promise<OwnAccessRequestProjection>;
    /**
     * Direct store read for one organization. Missing id, a missing record, or another
     * organization is refused. The caller does not learn who owns the record.
     */
    export function readOrganizationAccessRequest(ctx: RequestContext, organizationKey: string, requestId: string): Promise<OrganizationAccessRequestProjection>;
    /** Follow-up list for one organization. Requests of other organizations are omitted. */
    export function listOrganizationAccessRequests(ctx: RequestContext, organizationKey: string): Promise<OrganizationAccessRequestProjection[]>;
    /**
     * Resolve under the global e-mail lock. The keyed wrapper is not called again inside it.
     * create-new uses the reserved person id and the stored e-mail and name.
     */
    export function resolveAccessRequest(ctx: RequestContext, binding: OrganizationBinding, config: ProjectOnboardingConfig, actor: RegistrationActor, input: ResolveAccessRequestInput): Promise<AccessRequestDecisionResult>;
}
declare module "_102034_/l1/mdm/registration" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type OrganizationAccessRequestProjection } from "_102034_/l1/mdm/layer_3_usecases/registrationRequests";
    /** Minimal state for a trusted module/process. No e-mail, name or candidate tokens. */
    export type AccessRequestState = {
        requestId: string;
        status: 'pending';
        version: number;
    } | {
        requestId: string;
        status: 'resolved';
        version: number;
        person: {
            mdmId: string;
        };
    };
    /** Direct reread by id for trusted module/process code. A pending wait may have no Person. */
    export function readAccessRequestState(ctx: RequestContext, input: {
        requestId: string;
    }): Promise<AccessRequestState>;
    /** Pending follow-up for the configured organization. Requires the runtime session person. */
    export function listPendingAccessRequests(ctx: RequestContext): Promise<OrganizationAccessRequestProjection[]>;
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Shape of the level-1 ontology as the solution agents read it. Until ns5_43 these types described files
     * emitted into l4/organization/ontology; that emitter and those files are gone. `level1Catalog.ts`
     * (mls-102035) now derives this shape from l4/ontology/mdm.defs.ts, so these are a READING form and no
     * longer a source.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformEvent {
        eventId: string;
        on: string;
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                services?: readonly string[];
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
        /** Platform events a module may receive with `inbound.from: 'organization'`. No handler in alpha. */
        events?: readonly MdmPlatformEvent[];
    }
}
declare module "_102034_/l1/mdm/defs/ontologyTypes" {
    /**
     * The grammar of the platform ontology — the types `l4/ontology/mdm.defs.ts` is written against, and that
     * `l2/mdm/resolveMdmEntity.ts` and the module ontology of `mls-102035/l2/solution/types.ts` read.
     *
     * A record is `{ id, version, details }`, mirroring `mdm_documents`: `id` and `version` are columns and
     * `details` is the JSONB document, laid out as a map of branches — `identification` (the fields that are
     * also columns of the index table), `base` (common to every subtype), `<subtype>` (exactly one per
     * record), `general` (the organization) and `<moduleId>` (the module namespace). The base is declared
     * ONCE, instead of being repeated in each of the 13 subtypes.
     *
     * Defaults are omitted, not written: `required: false`, `nullable: false`, `title` equal to the id, and
     * the layer — which the branch already gives, since `identification` is a column and every other branch
     * lives in the document.
     *
     * `InferMdmRecord` derives the runtime type of a record from the ontology data, so `tsc` keeps code and
     * ontology on one shape instead of a hand-written interface that drifts.
     */
    /** The scalar forms a field may take. */
    export type MdmScalarKind = 'string' | 'text' | 'integer' | 'number' | 'money' | 'boolean' | 'date' | 'timestamp' | 'uuid';
    export type MdmValueTypeName = 'Address' | 'GeoPoint' | 'PrivacyConsent' | 'ContactSummary';
    export type MdmSubtypeName = 'Person' | 'Company' | 'ContactChannel' | 'Animal' | 'Product' | 'Service' | 'Location' | 'BankAccount' | 'Document' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment';
    /**
     * A field of the closed form. Absent flag = the default; `type` plus its own constraints carry everything,
     * so a constraint is never prose. `of` names a reusable type, `to` a record this one points at — both
     * checked by the compiler because they are unions of the declared names, not `string`.
     */
    export interface MdmDefField {
        type: MdmScalarKind | 'enum' | 'object' | 'record';
        required?: true;
        nullable?: true;
        collection?: true;
        /** A reusable type of `types`. */
        of?: MdmValueTypeName;
        /** Subtypes this field may point at. */
        to?: readonly MdmSubtypeName[];
        /** Closed domain. Plain strings when the label is the code itself. */
        values?: readonly string[];
        /** Inline object. */
        fields?: MdmDefFields;
        maxLength?: number;
        pattern?: string;
        min?: number;
        max?: number;
        default?: string | number | boolean;
        /** On `details` only: the branches the document is split into. */
        groups?: readonly string[];
        unique?: true;
        /** Backed by a real index today (a column of `identification` without it is a column with no index). */
        indexed?: true;
        /** The engine writes it; no form and no tool schema ever asks for it. */
        derived?: true;
        /** A prior read must supply this engine-owned value when a record is written. */
        writePrecondition?: boolean;
        /** Only when it differs from the id. */
        title?: string;
        description?: string;
    }
    export type MdmDefFields = Readonly<Record<string, MdmDefField>>;
    /** Catalog entry. `from`/`to` are subtype names, so a typo is a compile error and not a dead link. */
    export interface MdmDefRelationship {
        type: string;
        title: string;
        description: string;
        from: readonly MdmSubtypeName[];
        to: readonly MdmSubtypeName[];
        bidirectional: boolean;
        /** Values `mdm_relationship.role` accepts for this type. Empty when the type has no meaningful role. */
        roles: readonly string[];
        /** Keys the engine writes on each side's `relationshipRefs`, derived from `mapRelationshipKeys`. */
        compactKeys: {
            from: readonly string[];
            to: readonly string[];
        };
    }
    /**
     * One branch of `details`. `open: true` means the key set is not closed here: `general` is declared by the
     * organization in the project registry, and each module declares its own namespace in its own ontology.
     */
    export interface MdmDefGroup {
        type: 'object';
        owner: 'platform' | 'organization' | 'module';
        description: string;
        fields?: MdmDefFields;
        open?: true;
    }
    /**
     * A subtype carries only its DELTA: its own fields, and the capabilities and rules that are not universal.
     * The ids are plain strings here and are checked against the catalogs of the ontology object itself, in
     * `mdmOntology.test.ts` — the file is one JSON literal, so there is no `keyof typeof` to lean on inside it.
     */
    export interface MdmSubtypeDef {
        title?: string;
        description: string;
        fields: MdmDefFields;
        /** Only what does NOT apply to every subtype. */
        capabilities?: readonly string[];
        /** Only what does NOT apply to every subtype. */
        rules?: readonly string[];
    }
    export interface MdmOntology {
        schemaVersion: string;
        /** The three columns of `mdm_documents`, as fields, plus what a screen shows to recognise the record. */
        record: {
            fields: MdmDefFields;
            displayField: string;
        };
        types: Readonly<Record<MdmValueTypeName, MdmDefFields>>;
        /** The branches of `details`: `identification`, `base`, `general` and `<moduleId>`. The subtype branch
         * is not here — it comes from `subtypes.<S>.fields`, one per record. */
        groups: Readonly<Record<string, MdmDefGroup>>;
        subtypes: Readonly<Record<MdmSubtypeName, MdmSubtypeDef>>;
        relationships: readonly MdmDefRelationship[];
        /** id → one sentence: what it does · how · who uses it · platform: ready|partial|missing. */
        capabilities: Readonly<Record<string, string>>;
        /** id → one sentence: what is always true · who enforces it · platform. */
        rules: Readonly<Record<string, string>>;
        statuses: readonly string[];
        docTypes: readonly string[];
        storage: {
            indexTable: string;
            prospectIndexTable: string;
            documentTable: string;
            documentColumn: string;
            /** Document-visible columns that carry a real index today. */
            indexedColumns: readonly string[];
            reservedKeys: readonly string[];
        };
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    /**
     * The three families of data, by NATURE, not by origin (`hdm`/`vdm` classify origin and are another
     * axis): `mdm` is the master record of the organization, shared between modules; `tdm` is the movement,
     * the event, the operation of one module; `ddm` is what is recalculated from the other two and has no
     * writer at all.
     */
    export type DataFamilyName = 'mdm' | 'tdm' | 'ddm';
    /** What the platform really offers today for a capability. Measured, never promised. */
    export type DataFamilyReadiness = 'ready' | 'partial' | 'missing';
    /**
     * One capability of a family catalog. `sentence` is the same three-part line the `mdm` catalog writes as
     * prose (what it does · how · who uses it), `platform` the measured status, and `evidence` where it was
     * measured — `file.ts:line` or a section of `l1/mdm/mdmImplementation.md`. `evidence` is for whoever
     * reviews this file; the projection that reaches a prompt drops it.
     */
    export interface DataFamilyCapability {
        sentence: string;
        /** `table`: the module table engine itself. `platform`: lent by an MDM service. */
        source: 'table' | 'platform';
        platform: DataFamilyReadiness;
        evidence: string;
    }
    /**
     * The catalog a table of one family starts from, in the same spirit as `mdm.defs.ts`: the record it
     * carries, the lines the generator should keep in mind while writing it, what it may do, and the gap
     * between this file and the engine. `record.fields` uses the same field grammar as the platform record,
     * so `tsc` checks the shapes here too.
     */
    export interface DataFamilyOntology {
        schemaVersion: string;
        family: DataFamilyName;
        title: string;
        description: string;
        record: {
            fields: MdmDefFields;
        };
        /** One line each, read whole into the fan-out prompt: what this family's table looks like. */
        recommendations: readonly string[];
        capabilities: Readonly<Record<string, DataFamilyCapability>>;
        /** id → one sentence about where and how the rows live. */
        storage: Readonly<Record<string, string>>;
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    type ScalarOf<K extends MdmScalarKind> = K extends 'string' | 'text' | 'date' | 'timestamp' | 'uuid' ? string : K extends 'integer' | 'number' | 'money' ? number : K extends 'boolean' ? boolean : never;
    type DefValue<F extends MdmDefField, O extends MdmOntology> = F extends {
        type: 'enum';
    } ? (F extends {
        values: readonly (infer V)[];
    } ? V : string) : F extends {
        type: 'record';
    } ? string : F extends {
        type: 'object';
    } ? F extends {
        fields: MdmDefFields;
    } ? InferGroup<F['fields'], O> : F extends {
        of: infer V extends MdmValueTypeName;
    } ? InferGroup<O['types'][V], O> : object : F extends {
        type: infer K extends MdmScalarKind;
    } ? ScalarOf<K> : never;
    type DefWrapped<F extends MdmDefField, O extends MdmOntology> = F extends {
        collection: true;
    } ? DefValue<F, O>[] : DefValue<F, O>;
    type DefNulled<F extends MdmDefField, O extends MdmOntology> = F extends {
        nullable: true;
    } ? DefWrapped<F, O> | null : DefWrapped<F, O>;
    type DefRequiredKeys<T extends MdmDefFields> = {
        [K in keyof T]: T[K] extends {
            required: true;
        } ? K : never;
    }[keyof T];
    type DefOptionalKeys<T extends MdmDefFields> = Exclude<keyof T, DefRequiredKeys<T>>;
    /** One group of `details` as a runtime object. */
    export type InferGroup<T extends MdmDefFields, O extends MdmOntology> = {
        [K in DefRequiredKeys<T>]: DefNulled<T[K], O>;
    } & {
        [K in DefOptionalKeys<T>]?: DefNulled<T[K], O>;
    };
    /**
     * The record of one subtype: `{ id, version, details }`, `details` grouped. The subtype group is keyed by
     * the subtype name with a lowercase first letter (`Person` → `person`, `AssetVehicle` → `assetVehicle`),
     * and any other key is a module namespace — an object only that module writes.
     */
    type GroupFields<O extends MdmOntology, K extends string> = O['groups'][K] extends {
        fields: infer F extends MdmDefFields;
    } ? F : MdmDefFields;
    export type InferMdmRecord<O extends MdmOntology, S extends MdmSubtypeName> = {
        id: string;
        version: number;
        details: {
            identification: InferGroup<GroupFields<O, 'identification'>, O>;
        } & {
            base: InferGroup<GroupFields<O, 'base'>, O>;
        } & {
            [K in Uncapitalize<S>]: InferGroup<O['subtypes'][S]['fields'], O>;
        } & {
            general?: object;
        } & {
            [moduleId: string]: object;
        };
    };
}
declare module "_102035_/l2/solution/helpers/organizationTypes" {
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    /**
     * A papel of a module over a level-1 subtype. ns5_43 T4 names the three parts the way the v3 ontology
     * names them (`Ns5OntologyRoleV3`): `subtype` is the MDM subtype, `roleTag` is what `attachRole` writes
     * into `identification.tags`. Registries written before ns5_43 carry `mdmSubtype`/`role` instead; they
     * are read through `ns4RegistryRoleSubtype` / `ns4RegistryRoleTag` and rewritten on the next finalize80.
     */
    export interface Ns4SolutionRegistryRole {
        subtype: string;
        roleTag: string;
        namespace: string;
        /** Legacy spelling of `subtype`, written before ns5_43. Never written again. */
        mdmSubtype?: string;
        /** Legacy spelling of `roleTag`, written before ns5_43. Never written again. */
        role?: string;
    }
    export function ns4RegistryRoleSubtype(role: Ns4SolutionRegistryRole): string;
    export function ns4RegistryRoleTag(role: Ns4SolutionRegistryRole): string;
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    /** Entities this module owns. Siblings read this list instead of opening ontology files. */
    export interface Ns4SolutionRegistryEntity {
        entityId: string;
        /** v2 `kind`, or the v3 `role` / `entity`. */
        kind: string;
        mdmSubtype?: string;
        /** v3 table only: `core | event | supporting`, which v2 carried in `kind` (ns5_43 T4). */
        class?: string;
    }
    /** Outbound events this module publishes. `on` is `Entity.transitionId` or `Entity.create`. */
    export interface Ns4SolutionRegistryEvent {
        eventId: string;
        on: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        entities?: Ns4SolutionRegistryEntity[];
        events?: Ns4SolutionRegistryEvent[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102035_/l2/solution/types" {
    import type { MdmDefField, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    /**
     * p4_20: the read-only view of an artifact type, read only by the `.defs.ts` emitter
     * (`fs.ts` `renderDefsSource`: `as const satisfies Ns5Readonly<T>`). An `as const` literal is
     * read-only all the way down; the Studio compiler (TypeScript 5.0.2) refuses it against a mutable
     * array of `T` (TS1360), 5.9.3 accepts. The value keeps its own `as const` type, so readers of the
     * exported const see no change. The `Ns5*` types themselves stay as they are.
     */
    export type Ns5Readonly<T> = T extends readonly (infer U)[] ? readonly Ns5Readonly<U>[] : T extends object ? {
        readonly [K in keyof T]: Ns5Readonly<T[K]>;
    } : T;
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v2";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-11-ns5-ontology-v2";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_RULES_SCHEMA_VERSION_V2: "2026-09-16-ns5-rules-v2";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-12-ns5-workflows-v2";
    /**
     * ns5_48: v3 adds the `alert` stage (a recurring duty of a person). The shape is a superset of v2,
     * so there is ONE artifact interface and the version is a union — the same move ontology30 made with
     * `NS5_ONTOLOGY_SCHEMA_VERSION_V3`. `workflows50` emits v3; the thirteen recorded runs stay v2 and
     * are replayed through `buildNs5WorkflowsArtifact`.
     */
    export const NS5_WORKFLOWS_SCHEMA_VERSION_V3: "2026-09-17-ns5-workflows-v3";
    export type Ns5WorkflowsSchemaVersion = typeof NS5_WORKFLOWS_SCHEMA_VERSION | typeof NS5_WORKFLOWS_SCHEMA_VERSION_V3;
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-12-ns5-access-v3";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-12-ns5-integration-v2";
    export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION: "2026-09-12-ns5-integration-request-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    /**
     * ns5_49: `workflows50` runs BEFORE `ontology30`. A process stage cites the entity and the transition
     * it makes happen; the ontology then declares them with the stage as owner.
     * ns5_62: `judge35` runs AFTER `ontology30` and BEFORE `rules40`/`access60`. Completeness of the
     * journeys is judged only once the ontology (and the processes) exist. The numeric suffixes are
     * identity, not order — they are frozen so recorded runs keep their step ids.
     */
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "workflows50", "ontology30", "judge35", "rules40", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 copies survivors onto access.defs.ts; finalize80 I3 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    /**
     * access60 actor. `personEntity` is the role record this login is; `''` means this module has
     * none. Optional only so v3 files written before the field still satisfy the type. access60 always
     * writes it. Readers use `personEntity ?? ''`. Absence is not `''` for the gate.
     */
    export interface Ns5AccessActor extends Ns5ModuleActor {
        personEntity?: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, Ns5OntologyDetail>;
    }
    export interface Ns5JourneyStep {
        /** Identity of the step; I6 names a handoff by this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /**
         * Required on `kind: act`. `create` opens the record (or attaches, when mdm);
         * `transition` applies `transitionRef`; `update` writes fields without a state change.
         * Readers: I2, master backend, master frontend.
         */
        effect?: 'create' | 'update' | 'transition';
        /**
         * Required iff `effect === 'transition'`. Ontology `transitionId` of `entity` (lowerCamel).
         * Readers: I2, master backend, master frontend.
         */
        transitionRef?: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
        /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
        icon?: string;
        /**
         * On a branch step, the `stepId` of the `kind: 'decide'` step this branch belongs to.
         * A later step without `decisionRef` is the continuation. journeys20 rejects an unknown or non-decide target.
         */
        decisionRef?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from the pipeline (then access.defs.ts). */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
            icon?: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyDetail {
        /** Typed JSON column and screen formatting. */
        type: Ns5OntologyField['type'];
        /** Planner / UI; rules may cite details.<name>. */
        description: string;
    }
    export interface Ns5OntologyEnumValue {
        /** Stable English lowerCamel code; status.enum.value covers lifecycleStates[].state. */
        value: string;
        /** Screen select/badge label in userLanguage. */
        title: string;
    }
    export interface Ns5OntologyFieldConstraints {
        /** Inclusive lower bound; number, integer or money. */
        min?: number;
        /** Inclusive upper bound; number, integer or money. */
        max?: number;
        /** string or text only. */
        maxLength?: number;
        /** money or number only. */
        precision?: number;
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Simple uniqueness; DDL unique index. Never the identity field. */
        unique?: boolean;
        /** Closed domain; value is the code, title is the screen label. */
        enum?: Ns5OntologyEnumValue[];
        /** Intrinsic to the type (day 1..31, percent 0..100). Never a business policy. */
        constraints?: Ns5OntologyFieldConstraints;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** kind mdm only: level-1 fields this role uses (selection, tightened domain); stores nothing in the module. Readers: f2_04b screen, access60 (ns5_35), masters. */
        fieldsBase?: Ns5OntologyField[];
        /** Composite uniqueness; fieldIds of this entity, never idField. finalize80 I9. */
        uniqueKeys?: string[][];
        /** Calculated values; typed JSON column; rules may cite details.<name>. */
        details?: Record<string, Ns5OntologyDetail>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
        /**
         * How this entity is written. Omitted = `journey` (an `act` writes it as `entity` or `affects`).
         * `crud` = reference catalog nobody creates in a journey (no lifecycle); master
         * frontend emits a data grid, master backend emits CRUD usecases.
         * `inbound` = created/updated by an integration inbound item; integration70 requires
         * a matching `inbound.writes` row. ontology30 normalize drops `crud`/`inbound` when
         * an act already writes the entity. ontology30 / access60 / finalize80 I10 I8.
         * Replaces `maintenance?: 'crud'` (ns5_31).
         */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** Ontology screen edge label; master frontend. One sentence, userLanguage. */
        description: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V3: "2026-09-15-ns5-ontology-v3";
    /**
     * v3.1 (ns5_47): what nobody writes is a `derived` field of the row (`description` says the condition), not a
     * lifecycle state; `time` is therefore gone from `reachedBy` and from `by`. The v3 artifacts already
     * recorded stay readable — the form only lost a way of saying something, so every reader accepts both
     * versions through `isNs5OntologyV3Version` and only the generator emits v3.1.
     */
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V31: "2026-09-17-ns5-ontology-v3.1";
    export type Ns5OntologySchemaVersionV3 = typeof NS5_ONTOLOGY_SCHEMA_VERSION_V3 | typeof NS5_ONTOLOGY_SCHEMA_VERSION_V31;
    /** Every reader of the v3 form asks this, never an equality against one constant. */
    export function isNs5OntologyV3Version(value: unknown): value is Ns5OntologySchemaVersionV3;
    /** Closed-domain value of a v3 field: the bare code, or the code plus its label. */
    export type Ns5OntologyValueV3 = string | {
        value: string;
        title?: string;
        description?: string;
    };
    /** One field of a v3 record. The platform grammar, widened where a module needs it (see above). */
    export interface Ns5OntologyFieldV3 extends Omit<MdmDefField, 'to' | 'values' | 'fields' | 'groups'> {
        /** MDM subtypes AND entity ids of this module. */
        to?: readonly string[];
        values?: readonly Ns5OntologyValueV3[];
        fields?: Ns5OntologyFieldsV3;
        /**
         * Only on a branch of `details`: who writes it. `platform` = the MDM record,
         * `organization` = the promoted layer, `module` = `details.<moduleName>`.
         */
        owner?: 'platform' | 'organization' | 'module';
        /** Only on a branch: the key set is not closed here (declared elsewhere). */
        open?: true;
    }
    export type Ns5OntologyFieldsV3 = Readonly<Record<string, Ns5OntologyFieldV3>>;
    /** One named link of an entity. `relationshipId` is the row of the module index that carries it. */
    export interface Ns5OntologyRelationshipV3 {
        /** Must exist in `index.defs.ts`; that index is the source, this is the reading copy. */
        relationshipId: string;
        /** Entity id of this module, or an MDM subtype. */
        to: string;
        /**
         * `mode: 'fk'` — the column that holds it; `mode: 'throughTable'` — the table walked;
         * absent mode — the MDM relationship type of `mdm.relationships[].type`.
         */
        via: string;
        mode?: 'fk' | 'throughTable';
        /** Which end of the catalog link this entity sits on, when it is not the `from`. */
        direction?: 'from' | 'to';
        /** Role of `mdm_relationship.role`, single or many. */
        role?: string;
        roles?: readonly string[];
        cardinality: '1:1' | '1:N' | 'N:1' | 'N:N';
        /** `true`, or the condition in the user language ("quando menor de 18 anos"). */
        required?: boolean | string;
        /** Walked, never stored. */
        derived?: true;
        /** Only on `throughTable`: the walk, as written. */
        path?: string;
        /** Planner / screen. */
        title: string;
        description?: string;
        /** Narrows the far end, field → accepted values. */
        target?: Readonly<Record<string, readonly string[]>>;
    }
    /** What a `role` and a table share. Exported so `nsArtifactFieldRatchet.test.ts` can reach its keys. */
    export interface Ns5OntologyEntityV3Base<Cap extends string = string, Rule extends string = string> {
        /** Gate: the v3 form. */
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        title: string;
        description: string;
        /** Path a screen shows to recognise the record: `details.identification.name`, `scheduledAt`. */
        displayField: string;
        /** `{ id, version, details }` on a role; plus the indexed columns on an entity. */
        record: {
            fields: Ns5OntologyFieldsV3;
        };
        /** Composite uniqueness, by field id. */
        uniqueKeys?: readonly (readonly string[])[];
        /** ns5_47: only what somebody moves. A condition over data is a `derived` field of the row. */
        lifecycleStates?: readonly {
            state: string;
            reachedBy: 'actor' | 'command';
        }[];
        transitions?: readonly {
            transitionId: string;
            from: readonly string[];
            to: string;
            /** Actor ids of the module; empty when a process owns the move. */
            by: readonly string[];
            description: string;
            /** Record paths the transition command consumes; an explicit empty list means identity only. */
            payload?: readonly string[];
            ruleRefs?: readonly string[];
        }[];
        relationships: Readonly<Record<string, Ns5OntologyRelationshipV3>>;
        /**
         * id → one sentence. A platform id of `mdm.capabilities`, or `<moduleName>.<id>`.
         * Optional per key because an entity picks from the catalog; that `Cap` is an upper bound and not a
         * requirement. Assigning a `const` here therefore does NOT reject an invented id (no excess-property
         * check off a fresh literal) — a reader that wants that proof asserts `Exclude<keyof …, Cap>` is
         * `never`, as `resolveMdmEntity.test.ts` does.
         */
        capabilities: {
            readonly [K in Cap]?: string;
        };
        /** Ids of `mdm.rules` ∪ `ruleId` of the module `rules.defs.ts`. */
        rules: readonly Rule[];
        /** How the entity is written, when it is not a journey. */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    /** A papel of this module over an MDM record. Stores nothing but `details.<moduleName>`. */
    export interface Ns5OntologyRoleV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'role';
        /** The MDM subtype the papel sits on; must be a key of `mdm.subtypes`. */
        subtype: MdmSubtypeName;
        /** `<moduleName>.<entityId>`; what `attachRole` writes into `identification.tags`. */
        roleTag: string;
        /** The platform ontology this papel copies from. */
        source: string;
    }
    /** A table of the module. */
    export interface Ns5OntologyTableV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'entity';
        class: 'core' | 'event' | 'supporting';
        /**
         * `kind` is the family's storage (ns5_46): `relational` is one Postgres table of the module,
         * `timeSeries` a series chunked by time. Optional because the hand-written v3 form predates it and a
         * table without it is read as `relational`.
         */
        storage: {
            target: 'moduleDatabase';
            table: string;
            kind?: 'relational' | 'timeSeries';
        };
        /** What the table starts with in every database, in one sentence (e.g. 'all ISO 3166-1 countries'); absent = no initial data. Test data is not initialData. */
        initialData?: string;
    }
    export type Ns5OntologyEntityV3<Cap extends string = string, Rule extends string = string> = Ns5OntologyRoleV3<Cap, Rule> | Ns5OntologyTableV3<Cap, Rule>;
    /** One row of the v3 index: the canonical list of entities. */
    export interface Ns5OntologyIndexEntityV3 {
        entityId: string;
        kind: 'role' | 'entity';
        /** On `role` only. */
        subtype?: MdmSubtypeName;
        /** On `entity` only. */
        class?: 'core' | 'event' | 'supporting';
    }
    /** One row of the v3 index: the canonical list of links. The entities repeat these for reading. */
    export interface Ns5OntologyIndexRelationshipV3 {
        relationshipId: string;
        from: string;
        to: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        mode: 'fk' | 'mdmRelationship' | 'throughTable';
        /** `mode: 'fk'`: the column, as `Entity.field`. */
        field?: string;
        /** `mode: 'mdmRelationship'`: a `type` of `mdm.relationships`. */
        catalogType?: string;
        /** `mode: 'throughTable'`: the entity walked. */
        through?: string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        description: string;
    }
    export interface Ns5OntologyIndexV3 {
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        businessDomain: string;
        /** Path of the platform ontology this module is written on top of. */
        platformOntology: string;
        /** The branch of `details` only this module writes. */
        moduleNamespace: {
            key: string;
            description: string;
        };
        entities: readonly Ns5OntologyIndexEntityV3[];
        relationships: readonly Ns5OntologyIndexRelationshipV3[];
    }
    /** What a reader gets from an ontology entity file, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5OntologyAnyEntity = Ns5OntologyEntityArtifact | Ns5OntologyEntityV3;
    /** The discriminator every reader of a written entity uses; accepts v3 and v3.1 alike (ns5_47). */
    export function isNs5OntologyEntityV3(entity: Ns5OntologyAnyEntity): entity is Ns5OntologyEntityV3;
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    /**
     * The same catalog as a MAP, aligned with `mls-102034/l4/ontology/mdm.defs.ts`, whose `rules` and
     * `capabilities` are both `Record<id, sentence>` — one id, one sentence, no place to put a second.
     * `rules40` emits this form; the v1 array above stays valid and is still what the recorded runs hold.
     * Read either form through `solution/rulesView.ts`, never by branching on the field.
     *
     * The TOOL still asks for `[{ ruleId, description }]`: a strict tool schema must declare
     * `additionalProperties: false` on every object, so an open key set is not expressible
     * (`steps/ontology30/contractsV3.ts:175` says the same of `record.fields` and `capabilities`).
     * Array to map is the normalize's job.
     */
    export interface Ns5RulesArtifactV2 {
        /** Discriminates the two forms. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION_V2;
        /** Folder. */
        moduleName: string;
        /** `ruleId` to the one business sentence; I4 checks cited ruleRefs exist. */
        rules: Readonly<Record<string, string>>;
    }
    /** What a reader gets from `rules.defs.ts`, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5RulesAny = Ns5RulesArtifact | Ns5RulesArtifactV2;
    export interface Ns5WorkflowTrigger {
        /** Gate: scheduled needs schedule, event needs event, manual needs actorRef. */
        kind: 'scheduled' | 'event' | 'manual';
        /** Required iff kind === 'scheduled'. Prose ("every month, day 1"). Backend job. */
        schedule?: string;
        /** Required iff kind === 'event'. '<Entity>.<transitionId>' of this module (inbound '<mod>.<eventId>' is ns5_31). */
        event?: string;
        /** Required iff kind === 'manual'. */
        actorRef?: string;
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. Unique in the process. */
        taskId: string;
        /**
         * Gate: no neutral value; every stage is one of these. `alert` (v3, ns5_48) is a recurring duty
         * of a person: the schedule is on `trigger`, the instruction is the `description`, and it carries
         * neither journeyRef nor entityRef.
         */
        kind: 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
        /** Required on human and on alert. */
        actorRef?: string;
        /** Required on human, forbidden on alert. The journey the person runs, never a screen step. */
        journeyRef?: string;
        /** Required on mechanical|llm. Entity the stage acts on. */
        entityRef?: string;
        /** Required on mechanical|llm. Same form as act.effect (ns5_28). */
        effect?: 'create' | 'update' | 'transition';
        /** Required iff effect === 'transition'. Ontology transitionId; by is system or the actor. */
        transitionRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. Wait: the pause (time or event) in prose. */
        description: string;
        /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
        icon?: string;
        /**
         * Whether the process routine asks to be woken while this stage waits (plan §6). Only on kind 'wait'.
         * The routine decides what to do; waking is not a message to a person. Optional only for recorded
         * artifacts; absent → 'none'. `every` is an ISO 8601 duration (PT1H, P1D), required iff mode === 'periodic'.
         */
        wake?: {
            mode: 'none' | 'periodic';
            every?: string;
        };
    }
    export interface Ns5WorkflowFunction {
        /** lowerCamel; unique within the module. */
        functionId: string;
        /** Prose: who calls it (screen, harness, schedule), what it validates, writes, notifies and returns, and what happens on a repeated call. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** How the process starts. Tela da Fase 2, harness, backend job. */
        trigger: Ns5WorkflowTrigger;
        /** finalize80 I6: every journey handoff appears as a human journeyRef. */
        tasks: Ns5WorkflowTask[];
        /** The functions the L1 workflow service implements for this process. Optional only for artifacts saved before functions existed. */
        functions?: Ns5WorkflowFunction[];
        /**
         * Default room of an occurrence, chosen by the module (plan §§5, 9). 'exclusive': one room per occurrence;
         * 'person': the room of the person who owns the occurrence, and only that person enters; 'group': only the
         * members of the group enter. The cm resolves the concrete room and refuses an actor outside the audience.
         * Optional only for artifacts recorded before this spec; readers treat it as absent → 'exclusive'.
         */
        room?: 'exclusive' | 'person' | 'group';
    }
    export interface Ns5JourneyDecision {
        /** Must exist in the journey index. Tela da Fase 2 shows why a journey stayed out. */
        journeyId: string;
        /** One decision per journey in the same LLM call. */
        inProcess: boolean;
        /** Required iff inProcess. */
        processId?: string;
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty processes is valid. v2 recorded on disk stays readable. */
        schemaVersion: Ns5WorkflowsSchemaVersion;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
        /** One row per journey; the screen lists who is in a process. */
        journeyDecisions: Ns5JourneyDecision[];
        /** workflows50 normalize: dropped duplicate stages. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. Unique. */
        grantId: string;
        /** Must be an actorId from access.actors. */
        actorRef: string;
        /** Access matrix screen. */
        title: string;
        /** Access matrix screen. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Pipeline actors plus personEntity. The LLM does not emit this list; access60 merges actorPersons onto it. */
        actors: Ns5AccessActor[];
        /** The grant is the capability. Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. Unique across inbound and outbound. */
        id: string;
        /** Gate vs registry / plugin catalogue / platform events. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** Inbound source: sibling module, `organization` (platform catalog), or external system. */
        from?: string;
        /** Outbound destination: sibling module, `any`, or external system. */
        to?: string;
        /** Event id this row receives (inbound) or publishes (outbound). Defaults to `id`. */
        event?: string;
        /**
         * Inbound: entities of this module the arrival creates/updates.
         * Counts as a writer (ontology30 WITHOUT_WRITER, access60, I10) and as `trigger.event`.
         */
        writes?: string[];
        /** Inbound: what the arrival does to `writes`. Required on inbound. */
        effect?: 'create' | 'update' | 'transition';
        /** Inbound, required iff `effect === 'transition'`. */
        transitionRef?: string;
        /**
         * Outbound: when this module publishes. `Entity.transitionId` or `Entity.create`.
         * Payload is the entity record at that moment (not declared in l4). I12 checks it exists.
         */
        on?: string;
        /** Planner / UI. Cites `inbound.id` when the rule maps a sibling payload. */
        description: string;
        /** Outbound (and inbound leftover): entity ids this row touches. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** `journeyId.stepId` or `processId.taskId` that uses the plugin. I12. */
        usedBy: string[];
    }
    /** Queued request that a sibling (or a predicted module) publish an event. */
    export interface Ns5IntegrationRequestArtifact {
        schemaVersion: typeof NS5_INTEGRATION_REQUEST_SCHEMA_VERSION;
        requestedBy: string;
        eventId: string;
        on?: string;
        entityRefs: string[];
        description: string;
        status: 'requested';
        /** Organization inbox: the predicted module that should publish. */
        to?: string;
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    /** Form change recorded on `pipeline.json` `steps.<step>`. Shape is step-specific. */
    export interface Ns5PipelineNormalization {
        kind: string;
        detail: string;
        entityId?: string;
        grantId?: string;
        journeyId?: string;
        stepId?: string;
        inboundId?: string;
        /** access60 `anchorFromActor`: the anchor the model wrote. */
        from?: string;
        /** access60 `anchorFromActor`: the actor's personEntity. */
        to?: string;
    }
    export interface Ns5PipelineLiftedField {
        entityId: string;
        detail: string;
    }
    /**
     * p4_20: the Studio compile of the `.defs.ts` a step wrote, recorded on `steps.<step>.compile`.
     * `unavailable` is the absence of `mls.l2.typescript` (or of a model/dependency to compile): a state,
     * never a clean compile. Reader: finalize80 (`ns5CompileBlockers`), which runs the oracle only when
     * every writing step recorded `clean`.
     */
    export interface Ns5CompileRecord {
        status: 'clean' | 'errors' | 'unavailable';
        /** How many `.defs.ts` the step asked the compiler about. */
        files: number;
        /** `errors`: one line per diagnostic, prefixed by the display path of the file. */
        errors?: string[];
        /** `unavailable`: why nothing was compiled. */
        reason?: string;
    }
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /**
         * module10: actors the normalize removed because they are external systems, not people
         * (`dropSystemActor<Actor>`). An external system the request names is a plugin or an inbound of
         * integration70, never an actor. The clarification/maintenance screen of Fase 2 reads this to
         * show what the step decided without asking.
         */
        systemDecisions?: Ns5SystemDecision[];
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /**
         * Form changes this step applied (pt→pt-BR, dropCrud, liftedFields, …).
         * Same records as the step draft `normalizations[]`. Fase 2 reads this.
         */
        normalizations?: Ns5PipelineNormalization[];
        /**
         * ontology30: extra fields discarded when a panel entity was lifted
         * (`normalizations[].kind === 'liftedFields'`).
         */
        liftedFields?: Ns5PipelineLiftedField[];
        /**
         * ontology30 v3: rule ids the entities cited, platform and module together. `rules40` receives the
         * module ones as data and has to produce them (ns5_42 T7 records it; ns5_43 T2 wires the reading).
         */
        citedRules?: string[];
        /** ontology30 v3: capability ids the entities cited, catalog and module together. */
        citedCapabilities?: string[];
        /** module10: actors born by the step. Later steps read them via `readNs5Actors`. */
        actors?: Ns5ModuleActor[];
        /** journeys20: actorIds dropped as inferred-external without an exclusive step. */
        droppedActors?: string[];
        /** workflows50: true when processes is [] because there is no handoff, no cross-actor decide and no time/event phrase in the prompt. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
        /** judge35: true when the deterministic candidate list was empty and the step approved without an LLM call. */
        noJudgeSignal?: boolean;
        /** judge35: `transitionUnjustified` verdicts recorded for the human; the transition is not deleted. */
        warnings?: string[];
        /** p4_20: Studio compile of the `.defs.ts` this step wrote. Reader: finalize80. */
        compile?: Ns5CompileRecord;
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module (l1/l2/l4/l5 trees plus l5 json / registry). */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** Display paths unlinked under l1/l2/l4/l5/<module>/. */
        deleted: string[];
        /** Display paths rewritten (l5 jsons and the organization registry). */
        edited: string[];
        at: string;
    }
    /** Mailbox of the module pool: one folder per owner (`l4/<module>/pool/<box>/`). */
    export type PoolBox = 'l1' | 'l2' | 'l4';
    /** Implement = do it; estimate = simulate the change and answer the cost. */
    export type PoolMode = 'implement' | 'estimate';
    /** What the owner did with the message it processed. */
    export type PoolOutcome = 'delivered' | 'processed' | 'disputed';
    /**
     * One processed pool message, appended to `pipeline.json`. Readers: the pool screen (p4_04) and
     * L4 itself (round counting). Helpers in `/_102035_/l2/solution/pool.js`.
     */
    export interface PoolTraceLine {
        /** ISO timestamp of the trace. */
        at: string;
        /** Display path of the message file, e.g. `l4/<module>/pool/l2/<stamp>_<thread>_<round>.json`. */
        file: string;
        from: PoolBox;
        to: PoolBox;
        thread: string;
        round: number;
        mode: PoolMode;
        outcome: PoolOutcome;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /**
         * Thread of the request that created the module (`context.message.threadId`).
         * One per module: `/rebuild all` keeps the value already stored. Token `^[A-Za-z0-9_.-]{1,100}$`.
         */
        messageThreadId?: string;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        /** Pool trace, appended by `tracePool`. Absent in pipelines written before the pool existed. */
        pool?: PoolTraceLine[];
        /**
         * What `agentPlannerL4` entry10 added to `l5/config.json` (reader: that step).
         * Tokens like `workspaceDependencies:+102021`. Absent when nothing was missing.
         */
        l5Adjusted?: string[];
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102035_/l2/solution/helpers/organizationTypes";
}
declare module "_102034_/l2/mdm/resolveMdmEntity" {
    /**
     * The reader of the ontology: it turns `l4/ontology/mdm.defs.ts` (the platform) and a module ontology in
     * the v3 form (`mls-<client>/l4/<module>/ontology/<Entity>.defs.ts`) into ONE view — the columns, the
     * `details` tree, the links, the capabilities and the rules of a single entity (ns5_39 T3).
     *
     * PURE ON PURPOSE. No `node:*`, no engine (`module.ts`, `mdmFacade.ts`, `persistence.ts`), no I/O: the
     * clarification screen imports this file in the browser and hands it two objects it already read.
     * `resolveMdmEntity.test.ts` asserts that purity against this file's own source, so it cannot rot.
     *
     * What it does NOT do: it does not validate. A divergence is reported ON the node (`conflict`,
     * `tightened`, `unresolved`) for the screen to show — never thrown, never silently repaired. The gate is
     * `ontology30`, and it is still v2 (out of scope here).
     */
    import type { MdmOntology, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    import type { Ns5OntologyEntityV3, Ns5OntologyIndexV3, Ns5RulesAny } from "_102035_/l2/solution/types";
    /** How ready the platform is, read from the tail of the catalog sentence. A badge, never a gate. */
    export type OntologyPlatformStatus = 'ready' | 'partial' | 'missing';
    /** Who writes the field. `derived` wins over `platform`: the engine owns it, so no form may offer it. */
    export type OntologyOrigin = 'platform' | 'module' | 'derived';
    export interface OntologyValue {
        value: string;
        title: string;
    }
    export interface OntologyNode {
        /** Field id inside its parent. */
        id: string;
        /** Full path from the record root: `details.identification.name`, `scheduledAt`. */
        path: string;
        title: string;
        type: string;
        required: boolean;
        nullable: boolean;
        collection: boolean;
        derived: boolean;
        indexed: boolean;
        unique: boolean;
        /** Reusable value type of `mdm.types`. */
        of?: string;
        /** Records this field points at. */
        to?: readonly string[];
        values?: readonly OntologyValue[];
        /** Only on a branch of `details`. */
        owner?: 'platform' | 'organization' | 'module';
        /** The branch declares no closed key set (`general`, the module namespace on the platform side). */
        open?: true;
        description?: string;
        /** Only on a module view. */
        origin?: OntologyOrigin;
        /** The module declares a field the platform already owns under that branch, or an identity field
         * inside its own namespace (`rule-identity-never-in-namespace`). The screen warns. */
        conflict?: true;
        /** The module narrowed a closed domain the platform declares wider. Legitimate; shown as a note. */
        tightened?: true;
        children?: OntologyNode[];
    }
    export interface OntologyRelationshipView {
        /** The name the entity gave the link; on the platform view, the catalog type. */
        name: string;
        /** The row of the module index that carries it. Absent on the platform view. */
        relationshipId?: string;
        /** Catalog type (`GuardianOf`), or the column / table walked. */
        via: string;
        title: string;
        description?: string;
        /** The far end. */
        to: readonly string[];
        /** Which end of the link this entity sits on. */
        side: 'from' | 'to' | 'both';
        mode: 'fk' | 'throughTable' | 'mdmRelationship';
        cardinality?: string;
        required?: boolean | string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        /** Says how the entity and the module index disagree. The index is the source. */
        conflict?: string;
    }
    export interface OntologyCapabilityView {
        id: string;
        /** The catalog sentence for a platform id; the module sentence for a module id. */
        sentence: string;
        /** Only on a platform id: what the platform sentence says about itself. */
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        /** Only on a module view of a platform id: what the module says it uses it for. */
        moduleSentence?: string;
        /** The id is in no catalog. */
        unresolved?: true;
    }
    export interface OntologyRuleView {
        id: string;
        text: string;
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        unresolved?: true;
    }
    export interface OntologyTreeView {
        entityId: string;
        title: string;
        description: string;
        kind: 'platform' | 'role' | 'entity';
        /** The MDM subtype, on the platform view and on a role. */
        subtype?: string;
        displayField: string;
        /**
         * The top-level fields of the record OTHER than `details` — `details` is returned expanded below.
         * `{ id, version }` on an MDM record; on a module table also every indexed column.
         */
        columns: OntologyNode[];
        /** The branches of the document, in the order `record.fields.details.groups` declares. */
        details: OntologyNode[];
        relationships: OntologyRelationshipView[];
        capabilities: OntologyCapabilityView[];
        rules: OntologyRuleView[];
    }
    /** The badge, read from the tail of the catalog sentence. Absent when the sentence does not say. */
    export function readPlatformStatus(sentence: string): OntologyPlatformStatus | undefined;
    /**
     * The whole platform record of one subtype: `{ id, version }` plus the five branches of `details`, the
     * relationship types the subtype takes part in, and the capabilities and rules that reach it.
     *
     * `moduleId` names the module namespace branch; without it the branch keeps the placeholder key
     * `<moduleId>` the ontology itself uses.
     */
    export function resolvePlatformEntity(mdm: MdmOntology, subtype: MdmSubtypeName, moduleId?: string): OntologyTreeView;
    /**
     * The entity of a module, read against the platform it sits on.
     *
     * On a `role`, every node of `details` is marked `platform` / `module` / `derived` by comparing it with
     * the branch the platform declares; a module field that shadows a platform field — or any identity field
     * inside the module namespace — is flagged `conflict`. The capabilities and rules keep BOTH sentences:
     * the catalog's (what the platform does) and the module's (what the clinic uses it for). The links are
     * crossed with the module index, which is the source; a disagreement becomes `conflict` on the link.
     */
    export function resolveModuleEntity(entity: Ns5OntologyEntityV3, index: Ns5OntologyIndexV3, mdm: MdmOntology, moduleRules: Ns5RulesAny): OntologyTreeView;
}
declare module "_102034_/l1/mdm/defs/resolveMdmEntity" {
    export * from "_102034_/l2/mdm/resolveMdmEntity";
}
declare module "_102034_/l1/mdm/defs/rules" {
    /**
     * MDM — Master Data Model
     * Business rules for all MDM entities and workflows.
     *
     * Schema per rule:
     *   kind               → "domain" | "policy" | "platform" | "validation"
     *   description        → what the rule enforces, in plain English
     *   scope              → entity names, capability names, or "global"
     *   entities           → MDM entity subtypes directly affected (optional)
     *   acceptanceCriteria → verifiable conditions that confirm the rule is met
     */
    export const MdmRules: {
        readonly rule_mdm_single_id_space: {
            readonly kind: "platform";
            readonly description: "Every entity in the MDM — regardless of subtype — shares a single mdmId space. Any module may store an mdmId as a foreign key without knowing the subtype.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["mdmId is a UUID generated at creation and never changed.", "No module-specific ID scheme is allowed to replace or shadow mdmId.", "On prospect promotion, the mdmId is preserved — no new ID is generated unless a merge conflict is resolved."];
        };
        readonly rule_mdm_default_country_us: {
            readonly kind: "platform";
            readonly description: "The default country for all MDM entities is the United States (US). Country-specific validation (document formats, tax regimes, privacy consent) is applied based on the countryCode field.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["countryCode defaults to \"US\" when not explicitly provided.", "Document type validation (SSN, EIN, CPF, CNPJ, etc.) is gated on countryCode.", "Privacy consent is required only when countryCode is \"BR\" (LGPD) or an EU member state (GDPR)."];
        };
        readonly rule_mdm_dependency_direction: {
            readonly kind: "platform";
            readonly description: "MDM has no knowledge of any consuming module. Dependency is always unidirectional: module → MDM. Module-specific data is stored in extension tables owned by the module, not in MDM.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["No MDM entity, rule, or service may import or reference a non-MDM module.", "Module extensions use a dedicated table (e.g. CrmMdmExt) with mdmId as FK.", "MDM write operations never trigger module-specific side effects."];
        };
        readonly rule_mdm_read_from_dynamo: {
            readonly kind: "platform";
            readonly description: "Full entity data is read from the operational document store exposed by the backend runtime. In the current architecture, PostgreSQL local cache is the operational read source and DynamoDB remains the remote recovery/replication source of truth.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["BFF handlers that return entity details fetch the MDM document record, not only the Postgres index row.", "Postgres index fields are used for filtering, searching, joining, and deduplication.", "The operational runtime may serve details from mdm_cache, as long as the full document shape is preserved.", "DynamoDB remains the remote backup and restore source for rebuilding local tables when needed."];
        };
        readonly rule_mdm_version_optimistic_concurrency: {
            readonly kind: "platform";
            readonly description: "DynamoDB writes use optimistic concurrency via the version field. A write is rejected if the version in the store differs from the version read by the caller.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["Every write increments version by 1.", "Write operations include a condition expression: version = expectedVersion.", "On conflict, the caller receives a ConcurrencyConflict error and must re-fetch before retrying."];
        };
        readonly rule_entity_dedup_by_doc_id: {
            readonly kind: "domain";
            readonly description: "In MdmEntity, the combination of (docType, docId) must be unique. Attempting to create a new entity with an existing (docType, docId) pair returns the existing mdmId instead of creating a duplicate.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person", "Company"];
            readonly acceptanceCriteria: readonly ["PostgreSQL enforces UNIQUE(docType, docId) on MdmEntity.", "The creation service checks for an existing match before inserting.", "When a match is found, the existing mdmId is returned with a 200 (not a 201).", "The caller is informed that the returned record already existed."];
        };
        readonly rule_prospect_no_dedup_constraint: {
            readonly kind: "domain";
            readonly description: "MdmProspect does not enforce uniqueness on (docType, docId). The same document number may appear multiple times as separate prospects. Deduplication is resolved at promotion time.";
            readonly scope: readonly ["MdmProspect"];
            readonly acceptanceCriteria: readonly ["No UNIQUE constraint on (docType, docId) in MdmProspect.", "Duplicate prospects with the same docId are allowed and flagged during promotion.", "The promotion workflow presents duplicate candidates to the operator for manual resolution."];
        };
        readonly rule_merge_preserves_mdm_id: {
            readonly kind: "domain";
            readonly description: "When two entities are merged, one mdmId is designated as the winner. The loser record is set to status Merged with mergedInto pointing to the winner. The loser mdmId is never deleted — it remains as a tombstone for backward compatibility.";
            readonly scope: readonly ["MdmEntity"];
            readonly acceptanceCriteria: readonly ["Merged records have status \"Merged\" and a non-null mergedInto field.", "All foreign key references to the loser mdmId continue to resolve (tombstone is permanent).", "A lookup by the loser mdmId returns the tombstone record with a redirect to the winner mdmId.", "No hard deletion of merged records."];
        };
        readonly rule_prospect_promotion_workflow: {
            readonly kind: "domain";
            readonly description: "A prospect is promoted to a permanent entity via an explicit promotion call. The workflow checks for duplicates in MdmEntity and either promotes directly or flags for operator review.";
            readonly scope: readonly ["MdmProspect", "MdmEntity", "cap_promote_prospect"];
            readonly acceptanceCriteria: readonly ["Promotion is triggered by an explicit ctx.mdm.prospect.promoteToEntity({ mdmId: prospectMdmId }) call.", "If no MdmEntity match is found: the DynamoDB document is unchanged; the PostgreSQL row is moved from MdmProspect to MdmEntity; the same mdmId is used.", "If a match is found: prospect status is set to PendingMerge; an operator review task is created.", "After promotion, the calling module updates its extension table to point to the final mdmId.", "MdmProspectRelationship rows referencing the promoted entity are migrated to MdmRelationship."];
        };
        readonly rule_prospect_ttl_expiry: {
            readonly kind: "policy";
            readonly description: "Prospects with a ttlExpiresAt timestamp are automatically expired when the TTL is reached without promotion. Expired prospects are not deleted — they are set to status Expired.";
            readonly scope: readonly ["MdmProspect"];
            readonly acceptanceCriteria: readonly ["A background job checks for prospects where ttlExpiresAt < now() and status is New or InProgress.", "Qualifying prospects are set to status Expired.", "Expired prospects are retained for audit purposes and can be manually reactivated.", "Null ttlExpiresAt means no expiry — the prospect remains until explicitly promoted or discarded."];
        };
        readonly rule_person_ssn_unique_for_us: {
            readonly kind: "validation";
            readonly description: "For persons with countryCode \"US\", the SSN (docType: SSN) must be unique in MdmEntity. SSN is treated as the primary deduplication key for US individuals.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person"];
            readonly acceptanceCriteria: readonly ["If docType is SSN and countryCode is US, the UNIQUE(docType, docId) constraint in Postgres applies.", "SSN is stored as digits only, no dashes.", "SSN is never returned in list responses — only in single-entity reads with explicit field projection."];
        };
        readonly rule_person_privacy_consent_required_br_eu: {
            readonly kind: "policy";
            readonly description: "For persons with countryCode in Brazil (BR) or any EU member state, a PrivacyConsent record must be present in the entity document before the record is set to status Active.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person"];
            readonly acceptanceCriteria: readonly ["Creation of a Person with countryCode BR or an EU code without privacyConsent results in status Inactive.", "The entity is set to Active only after privacyConsent.consentedAt is recorded.", "Revocation (privacyConsent.revokedAt set) triggers a status change to Inactive."];
        };
        readonly rule_company_ein_unique_for_us: {
            readonly kind: "validation";
            readonly description: "For companies with countryCode \"US\", the EIN (docType: EIN) must be unique in MdmEntity.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Company"];
            readonly acceptanceCriteria: readonly ["If docType is EIN and countryCode is US, the UNIQUE(docType, docId) constraint applies.", "EIN is stored as digits only, no dashes."];
        };
        readonly rule_company_legal_name_required: {
            readonly kind: "validation";
            readonly description: "Every Company entity must have a non-empty legalName in its detail document.";
            readonly scope: readonly ["MdmEntity", "MdmProspect"];
            readonly entities: readonly ["Company"];
            readonly acceptanceCriteria: readonly ["Creation or update of a Company without legalName is rejected with a validation error.", "tradeName is optional; legalName is not."];
        };
        readonly rule_bank_account_holder_via_relationship: {
            readonly kind: "domain";
            readonly description: "The holder of a BankAccount is not stored as a field inside the BankAccount document. The ownership relationship is expressed via a HoldsAccount relationship in MdmRelationship.";
            readonly scope: readonly ["MdmRelationship"];
            readonly entities: readonly ["BankAccount"];
            readonly acceptanceCriteria: readonly ["No \"holderId\" or \"ownerMdmId\" field exists in BankAccountDetail.", "To find the holder of an account, query MdmRelationship where toId = bankAccountMdmId and type = HoldsAccount.", "A BankAccount may have multiple holders (joint accounts) — each represented as a separate HoldsAccount relationship."];
        };
        readonly rule_bank_account_routing_required_for_us: {
            readonly kind: "validation";
            readonly description: "For BankAccount entities used in US domestic transfers, bankRoutingNumber is required.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["BankAccount"];
            readonly acceptanceCriteria: readonly ["If a BankAccount is associated with a US-based holder (countryCode US) and accountType is Checking or Savings, bankRoutingNumber must be present.", "International accounts (IBAN/SWIFT) are exempt from this requirement."];
        };
        readonly rule_document_parties_via_relationships: {
            readonly kind: "domain";
            readonly description: "Parties involved in a Document (signatories, issuees, subjects) are not stored as an array inside the Document detail. They are represented as Signed or HasContact relationships in MdmRelationship.";
            readonly scope: readonly ["MdmRelationship"];
            readonly entities: readonly ["Document"];
            readonly acceptanceCriteria: readonly ["No parties[] or signatories[] field exists in DocumentDetail.", "To find all parties of a document, query MdmRelationship where toId = documentMdmId and type = Signed.", "The role field in MdmRelationship carries the party role: contractor, client, witness, notary."];
        };
        readonly rule_document_path_immutable: {
            readonly kind: "policy";
            readonly description: "The storageBucket and storagePath fields of a Document are immutable after creation. Files must never be moved or renamed in storage without creating a new Document entity.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Document"];
            readonly acceptanceCriteria: readonly ["Update operations that attempt to change storageBucket or storagePath are rejected with a validation error.", "To update a file, a new Document entity must be created with the new path.", "The old Document entity is set to status Inactive, not deleted."];
        };
        readonly rule_contact_value_unique_per_type: {
            readonly kind: "validation";
            readonly description: "Within MdmEntity, the combination of (contactType, value) must be unique. The same phone number or email address cannot belong to two different ContactChannel entities.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["ContactChannel"];
            readonly acceptanceCriteria: readonly ["Attempting to create a ContactChannel with an existing (contactType, value) pair returns the existing mdmId.", "Uniqueness is enforced at the service layer before the DynamoDB write.", "MdmProspect does not enforce this constraint — duplicates are resolved on promotion."];
        };
        readonly rule_relationship_valid_period: {
            readonly kind: "domain";
            readonly description: "All relationships must have a validFrom date. validTo is optional and null means currently active. Historical relationships are retained — not deleted when they end.";
            readonly scope: readonly ["MdmRelationship", "MdmProspectRelationship"];
            readonly acceptanceCriteria: readonly ["validFrom is required on creation.", "When a relationship ends, validTo is set — the row is not deleted.", "Queries for active relationships must filter by validTo IS NULL OR validTo >= today.", "Multiple non-overlapping relationship periods between the same two entities are allowed (e.g. rehire)."];
        };
        readonly rule_relationship_bidirectional_query: {
            readonly kind: "platform";
            readonly description: "For bidirectional relationships (isBidirectional: true), only one row is stored in the database. Querying \"all relationships of entity X\" must check both fromId and toId columns.";
            readonly scope: readonly ["MdmRelationship", "MdmProspectRelationship"];
            readonly acceptanceCriteria: readonly ["isBidirectional = true relationships are stored as a single row with fromId being the creator.", "The relationship query service returns the relationship when X appears in either fromId or toId.", "No duplicate rows are created for bidirectional relationships."];
        };
        readonly rule_async_worker_idempotency: {
            readonly kind: "platform";
            readonly description: "The background worker that processes write-behind events to DynamoDB and other remote stores must be idempotent. Re-processing the same outbox event must not create duplicate remote state or corrupt data.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["The worker processes durable outbox events generated by the local write transaction.", "Remote writes are idempotent for the same aggregateId and version or equivalent event payload.", "Worker failures and retries do not cause duplicate remote rows or data corruption.", "Successfully replicated outbox rows are deleted from mdm_outbox as the normal completion path.", "Failed outbox rows remain in mdm_outbox with retry metadata and the last error message for operator visibility."];
        };
        readonly rule_sync_fields_written_atomically: {
            readonly kind: "platform";
            readonly description: "SYNC fields (mdmId, subtype, name, status, docType, docId, mergedInto, dynamoPk) must be written atomically to the local PostgreSQL operational tables in the same request as the local document write. Remote DynamoDB replication is performed asynchronously via write-behind.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["The entity write service writes the local document, index rows, and outbox event in the same local transaction.", "If the local transaction fails, no partial local state is committed.", "If remote replication succeeds, the corresponding outbox row is removed from mdm_outbox.", "If remote replication fails, the outbox retains the pending event for retry or operator intervention.", "The system must never have a state where a committed local document exists without its required local SYNC index row."];
        };
    };
    export type MdmRuleId = keyof typeof MdmRules;
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAttachmentRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export class MdmAttachmentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmAttachmentRecord): Promise<void>;
        get(id: string): Promise<MdmAttachmentRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmCommentRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmCommentRecord } from "_102034_/l1/mdm/module";
    export class MdmCommentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmCommentRecord): Promise<void>;
        get(id: string): Promise<MdmCommentRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmDocumentRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmDocumentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        get(mdmId: string): Promise<MdmDocumentRecord | null>;
        put(record: MdmDocumentRecord): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmNumberSequenceRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmNumberSequenceRecord } from "_102034_/l1/mdm/module";
    export class MdmNumberSequenceRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmNumberSequenceRecord): Promise<void>;
        get(id: string): Promise<MdmNumberSequenceRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmRelationshipRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmRelationshipDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmRelationshipRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        private getTableName;
        put(record: MdmRelationshipDocumentRecord): Promise<void>;
        delete(id: string, scope: 'entity' | 'prospect'): Promise<void>;
        listAll(scope: 'entity' | 'prospect'): Promise<MdmRelationshipDocumentRecord[]>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmTagRemoteRuntimeDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmTagRecord } from "_102034_/l1/mdm/module";
    export class MdmTagRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmTagRecord): Promise<void>;
        get(id: string): Promise<MdmTagRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/queue/RestoreFromDynamoUsecase" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { MdmDocumentRecord, MdmRelationshipDocumentRecord } from "_102034_/l1/mdm/module";
    export class RestoreFromDynamoUsecase {
        private readonly env;
        private readonly runtime;
        private readonly remoteRuntime;
        private readonly remoteRelationshipRuntime;
        constructor(env?: AppEnv);
        restoreDocument(document: MdmDocumentRecord): Promise<void>;
        restoreById(mdmId: string): Promise<void>;
        restoreRelationship(relationship: MdmRelationshipDocumentRecord): Promise<void>;
        restoreAllRelationships(): Promise<number>;
    }
}
declare module "_102034_/l1/server/layer_1_external/persistence/dynamoAdmin" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition, SchemaSnapshot } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export function ensureRegisteredDynamoTables(env: AppEnv): Promise<void>;
    export function deleteRegisteredDynamoTables(env: AppEnv): Promise<void>;
    export function writeSchemaSnapshotLog(env: AppEnv, snapshot: SchemaSnapshot): Promise<void>;
    export function deleteDynamoItem(env: AppEnv, definition: ResolvedTableDefinition, key: Record<string, unknown>): Promise<void>;
    export function putDynamoItem(env: AppEnv, definition: ResolvedTableDefinition, item: Record<string, unknown>): Promise<void>;
    export function scanAllDynamoItems(env: AppEnv, definition: ResolvedTableDefinition): Promise<Array<Record<string, unknown>>>;
}
declare module "_102034_/l1/mdm/layer_1_external/queue/WriteBehindWorker" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export class WriteBehindWorker {
        private readonly env;
        private readonly runtime;
        private readonly remoteAuditRuntime;
        private readonly remoteRuntime;
        private readonly remoteRelationshipRuntime;
        private readonly remoteTagRuntime;
        private readonly remoteCommentRuntime;
        private readonly remoteAttachmentRuntime;
        private readonly remoteNumberSequenceRuntime;
        constructor(env?: AppEnv);
        private static readonly MAX_ATTEMPT_COUNT;
        runOnce(limit?: number): Promise<{
            processed: number;
            failed: number;
        }>;
        private handleRegistryTablePayload;
    }
}
declare module "_102034_/l1/mdm/layer_2_controllers/attachmentHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const attachmentAttachHandler: BffHandler;
    export const attachmentDetachHandler: BffHandler;
    export const attachmentFindByEntityHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/commentUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AddCommentParams, EditCommentParams, FindCommentsByEntityParams, MdmCommentRecord, RemoveCommentParams } from "_102034_/l1/mdm/module";
    export function addComment(ctx: RequestContext, params: AddCommentParams): Promise<MdmCommentRecord>;
    export function editComment(ctx: RequestContext, params: EditCommentParams): Promise<MdmCommentRecord>;
    export function removeComment(ctx: RequestContext, params: RemoveCommentParams): Promise<MdmCommentRecord>;
    export function findCommentsByEntity(ctx: RequestContext, params: FindCommentsByEntityParams): Promise<MdmCommentRecord[]>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/commentHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const commentAddHandler: BffHandler;
    export const commentEditHandler: BffHandler;
    export const commentRemoveHandler: BffHandler;
    export const commentFindByEntityHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/entityHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const entityCreateHandler: BffHandler;
    export const entityGetHandler: BffHandler;
    export const entityListHandler: BffHandler;
    export const entityUpdateHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/kvUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { GetMdmKvParams, MdmKvRecord, PutMdmKvParams } from "_102034_/l1/mdm/module";
    export function getMdmKv(ctx: RequestContext, params: GetMdmKvParams): Promise<MdmKvRecord | null>;
    export function putMdmKv(ctx: RequestContext, params: PutMdmKvParams): Promise<MdmKvRecord>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/kvHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const kvGetHandler: BffHandler;
    export const kvPutHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/numberSequenceUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmNumberSequenceRecord, NumberSequenceNextParams } from "_102034_/l1/mdm/module";
    export function nextSequence(ctx: RequestContext, params: NumberSequenceNextParams): Promise<{
        record: MdmNumberSequenceRecord;
        value: string;
    }>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/numberSequenceHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const numberSequenceNextHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/prospectFacadeHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const prospectCreateHandler: BffHandler;
    export const prospectGetHandler: BffHandler;
    export const prospectListHandler: BffHandler;
    export const prospectUpdateHandler: BffHandler;
    export const prospectPromoteToEntityHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/relationshipHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const relationshipCreateHandler: BffHandler;
    export const relationshipListHandler: BffHandler;
    export const relationshipUpdateHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/tagUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AddTagParams, FindTagsByEntityParams, FindTagsByTagParams, MdmTagRecord, RemoveTagParams } from "_102034_/l1/mdm/module";
    export function addTag(ctx: RequestContext, params: AddTagParams): Promise<{
        alreadyExists: boolean;
        tag: MdmTagRecord;
    }>;
    export function removeTag(ctx: RequestContext, params: RemoveTagParams): Promise<{
        removed: boolean;
        id: string;
    }>;
    export function findTagsByEntity(ctx: RequestContext, params: FindTagsByEntityParams): Promise<MdmTagRecord[]>;
    export function findTagsByTag(ctx: RequestContext, params: FindTagsByTagParams): Promise<MdmTagRecord[]>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/tagHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const tagAddHandler: BffHandler;
    export const tagRemoveHandler: BffHandler;
    export const tagFindByEntityHandler: BffHandler;
    export const tagFindByTagHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/statusHistoryUsecases" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { FindLatestStatusByEntityParams, FindStatusHistoryByEntityParams } from "_102034_/l1/mdm/module";
    export function findStatusHistoryByEntity(ctx: RequestContext, params: FindStatusHistoryByEntityParams): Promise<import("/_102034_/l1/mdm/module.js").MdmStatusHistoryRecord[]>;
    export function findLatestStatusByEntity(ctx: RequestContext, params: FindLatestStatusByEntityParams): Promise<import("/_102034_/l1/mdm/module.js").MdmStatusHistoryRecord>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/statusHistoryHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const statusHistoryFindByEntityHandler: BffHandler;
    export const statusHistoryFindLatestHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createMdmRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentKey" {
    /**
     * S3 / disk key of a BUSINESS attachment.
     *
     * Collab-messages uses `images/tmp/…` + duration `30d` for ephemeral LLM images that a lifecycle
     * rule may delete. A record attachment (the pet photo) is business data: it MUST live under the
     * permanent prefix. If it lands in tmp, the row in `mdm_attachment` points at a dead object.
     *
     * The key is the only thing persisted. A presigned URL is derived at read time and is never stored.
     */
    export const PERMANENT_ATTACHMENT_PREFIX = "attachments";
    export function buildPermanentAttachmentKey(input: {
        projectId: string;
        entityType: string;
        entityId: string;
        attachmentId: string;
        fileName: string;
    }): string;
    export function assertPermanentAttachmentKey(key: string): void;
}
declare module "_102034_/l1/server/layer_1_external/storage/objectStore" {
    import type { ObjectStorageProvider } from "_102034_/l1/server/layer_1_external/storage/objectBuckets";
    export interface ObjectPutInput {
        bucket: string;
        key: string;
        body: Buffer;
        contentType: string;
        metadata?: Record<string, string>;
    }
    export interface ObjectStore {
        readonly provider: ObjectStorageProvider;
        put(input: ObjectPutInput): Promise<void>;
        delete(input: {
            bucket: string;
            key: string;
        }): Promise<void>;
        getPresignedGetUrl(input: {
            bucket: string;
            key: string;
            expiresIn: number;
        }): Promise<string>;
        /** Local provider only: read the bytes back. S3 reads go through the signed URL. */
        readLocal?(input: {
            bucket: string;
            key: string;
        }): Promise<Buffer>;
    }
    export class MemoryObjectStore implements ObjectStore {
        readonly provider: ObjectStorageProvider;
        readonly objects: Map<string, {
            body: Buffer;
            contentType: string;
        }>;
        put(input: ObjectPutInput): Promise<void>;
        delete(input: {
            bucket: string;
            key: string;
        }): Promise<void>;
        getPresignedGetUrl(input: {
            bucket: string;
            key: string;
            expiresIn: number;
        }): Promise<string>;
        readLocal(input: {
            bucket: string;
            key: string;
        }): Promise<Buffer>;
    }
    export class LocalDiskObjectStore implements ObjectStore {
        private readonly rootDir;
        readonly provider: ObjectStorageProvider;
        constructor(rootDir: string);
        put(input: ObjectPutInput): Promise<void>;
        delete(input: {
            bucket: string;
            key: string;
        }): Promise<void>;
        getPresignedGetUrl(input: {
            bucket: string;
            key: string;
            expiresIn: number;
        }): Promise<string>;
        readLocal(input: {
            bucket: string;
            key: string;
        }): Promise<Buffer>;
        private pathOf;
    }
    export function localAttachmentRoot(override?: string): string;
}
declare module "_102034_/l1/server/layer_1_external/storage/s3ObjectStore" {
    import type { ObjectPutInput, ObjectStore } from "_102034_/l1/server/layer_1_external/storage/objectStore";
    export interface S3ObjectStoreConfig {
        region: string;
        accessKeyId: string;
        secretAccessKey: string;
        sessionToken?: string;
    }
    export const PRESIGNED_GET_EXPIRES_SECONDS = 3600;
    export class S3ObjectStore implements ObjectStore {
        private readonly config;
        readonly provider: "s3";
        constructor(config: S3ObjectStoreConfig);
        put(input: ObjectPutInput): Promise<void>;
        delete(input: {
            bucket: string;
            key: string;
        }): Promise<void>;
        getPresignedGetUrl(input: {
            bucket: string;
            key: string;
            expiresIn: number;
        }): Promise<string>;
        private host;
        private sign;
        private presignGet;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUpload" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type ObjectBucketResolution } from "_102034_/l1/server/layer_1_external/storage/objectBuckets";
    import { type AttachmentLimits } from "_102034_/l1/server/layer_1_external/storage/attachmentLimits";
    import { MemoryObjectStore, type ObjectStore } from "_102034_/l1/server/layer_1_external/storage/objectStore";
    import type { MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export interface UploadAttachmentInput {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        category?: string | null;
        base64: string;
        details?: Record<string, unknown> | null;
    }
    export interface UploadAttachmentResult {
        record: MdmAttachmentRecord;
        bucket: string;
        /** Why S3 was not used. Empty when provider is s3. */
        localReason: string;
    }
    export interface AttachmentReadUrl {
        id: string;
        url: string;
        expiresIn: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
    }
    export interface AttachmentStorageDeps {
        store?: ObjectStore;
        buckets?: ObjectBucketResolution;
        limits?: AttachmentLimits;
    }
    export function resetAttachmentStorage(): void;
    export function resolveAttachmentBucketsFromEnv(): ObjectBucketResolution;
    export function createAttachmentObjectStore(buckets?: ObjectBucketResolution): ObjectStore;
    export function uploadAttachment(ctx: RequestContext, input: UploadAttachmentInput, deps?: AttachmentStorageDeps): Promise<UploadAttachmentResult>;
    export function getAttachmentReadUrl(ctx: RequestContext, id: string, deps?: AttachmentStorageDeps): Promise<AttachmentReadUrl>;
    export function readLocalAttachmentBytes(ctx: RequestContext, id: string, deps?: AttachmentStorageDeps): Promise<{
        body: Buffer;
        contentType: string;
        fileName: string;
    }>;
    export { MemoryObjectStore };
}
declare module "_102034_/l1/mdm/layer_3_usecases/localTestSeed" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    import { type OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    /** Bench profiles. They are not role grants; both people keep the alpha super user. */
    export const LOCAL_TEST_ALIASES: readonly ["responsavel", "membro"];
    export type LocalTestAlias = (typeof LOCAL_TEST_ALIASES)[number];
    export interface LocalTestPersona {
        alias: LocalTestAlias;
        email: string;
        name: string;
        sub: string;
        personMdmId: string;
    }
    export interface LocalTestSeedResult {
        organizationKey: string;
        companyMdmId: string;
        personas: LocalTestPersona[];
    }
    export function localTestEmail(projectId: string, alias: LocalTestAlias): string;
    export function localTestSub(projectId: string, alias: LocalTestAlias): string;
    /** `<moduleId>.<Tipo>` checked against the project config. No writes. */
    export function parseMemberRoles(config: ProjectsConfig, memberRoles: readonly string[]): {
        moduleId: string;
        personType: string;
        tag: string;
    }[];
    /**
     * Company plus two bench people. Repeated calls keep the same ids and do not
     * overwrite a name, country, link or version the tester already stored.
     * A pending match or a link to another company is an error; nothing is released.
     * `memberRoles` attaches existing module roles; an empty list keeps the previous behavior.
     */
    export function ensureLocalTestPair(ctx: RequestContext, config: ProjectsConfig, binding: OrganizationBinding, memberRoles?: readonly string[]): Promise<LocalTestSeedResult>;
}
declare module "_102034_/l1/mdm/plugin/index" {
    export const mdmPlugin: {
        module: string;
    };
}
declare module "_102034_/l1/monitor/persistence" {
    import type { TableDefinition, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
    export const viewDefinitions: ViewDefinition[];
}
declare module "_102034_/l2/monitor/shared/contracts/runtimeMetrics" {
    export interface RuntimeMetricSample {
        sampledAt: string;
        projectId: string;
        processInstance: string;
        pid: number;
        releaseId: string | null;
        nodeVersion: string;
        allocator: 'system' | 'jemalloc';
        optimizeForSize: boolean;
        uptimeSeconds: number;
        rssBytes: number;
        heapUsedBytes: number;
        heapTotalBytes: number;
        heapLimitBytes: number;
        externalBytes: number;
        arrayBuffersBytes: number;
        cpuUserMicros: number;
        cpuSystemMicros: number;
        cpuPercent: number;
        eventLoopUtilization: number;
        eventLoopDelayP50Ms: number;
        eventLoopDelayP95Ms: number;
        eventLoopDelayP99Ms: number;
        systemTotalMemBytes: number;
        systemFreeMemBytes: number;
        systemLoadAvg1m: number;
        systemLoadAvg5m: number;
        systemLoadAvg15m: number;
    }
    export interface RuntimeMetricsResponse {
        projectId: string;
        intervalSeconds: number;
        retentionDays: number;
        requestedMinutes: number;
        limit: number;
        count: number;
        samples: RuntimeMetricSample[];
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/RuntimeMetricsPostgres" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { RuntimeMetricSample } from "_102034_/l2/monitor/shared/contracts/runtimeMetrics";
    export const RUNTIME_METRICS_INTERVAL_SECONDS = 5;
    export const RUNTIME_METRICS_RETENTION_DAYS = 45;
    export class RuntimeMetricsPostgres {
        private readonly env;
        constructor(env?: AppEnv);
        ensureStorage(): Promise<void>;
        insert(sample: RuntimeMetricSample): Promise<void>;
        list(input: {
            projectId: string;
            minutes: number;
            limit: number;
        }): Promise<RuntimeMetricSample[]>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/abend" {
    export interface MonitorAbendEntry {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        statusCode: number;
        statusGroup: string;
        durationMs: number;
        errorCode: string | null;
        errorStack: string | null;
        startedAt: string;
        finishedAt: string;
    }
    export interface MonitorAbendResponse {
        entries: MonitorAbendEntry[];
        totalCount: number;
        generatedAt: string;
    }
    /** Frontend error captured by the client telemetry (js_error / unhandled_rejection). */
    export interface MonitorClientErrorEntry {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        eventType: string;
        label: string;
        metadata: Record<string, unknown> | null;
        recordedAt: string;
        receivedAt: string;
    }
    export interface MonitorClientErrorsResponse {
        entries: MonitorClientErrorEntry[];
        totalCount: number;
        sinceHours: number;
        generatedAt: string;
    }
}
declare module "_102034_/l1/monitor/layer_3_usecases/abendUsecases" {
    import type { MonitorAbendResponse, MonitorClientErrorsResponse } from "_102034_/l2/monitor/shared/contracts/abend";
    export function loadAbends(input: {
        module?: string;
        limit?: number;
    }): Promise<MonitorAbendResponse>;
    export function loadClientErrors(input: {
        limit?: number;
        sinceHours?: number;
    }): Promise<MonitorClientErrorsResponse>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/abendHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorAbendLoadHandler: BffHandler;
    export const monitorClientErrorsLoadHandler: BffHandler;
}
declare module "_102034_/l1/server/layer_1_external/frontend/faviconHtml" {
    import { type ProjectsConfig } from "_102034_/l1/server/layer_1_external/config/projectConfig";
    /** Default tab icon: same-origin l3 asset of the master frontend (not23). */
    export const DEFAULT_APP_FAVICON_HREF = "/_102033_/l3/assets/favicon.png";
    export type FaviconSource = 'config' | 'default';
    /** Indexed access on `ProjectsConfig.favicon` so a missing field is a compile error (not25 R1). */
    export function resolveAppFaviconHref(favicon: ProjectsConfig['favicon'] | null): {
        href: string;
        source: FaviconSource;
    };
    /** First 12 hex of sha256. Same width the build writes into `?v=`. */
    export function contentHash12(bytes: Buffer): string;
    /** Hash of a same-origin favicon, kept for the life of the process. Missing file caches as empty. */
    export function faviconContentHash(href: string): string;
    /** Bytes of the same-origin file `resolveAppFaviconHref` chose. Missing or unsafe href is null. */
    export function readAppFaviconFile(href: string): {
        body: Buffer;
        contentType: string;
    } | null;
    export interface FaviconIcoHttp {
        statusCode: 200 | 304 | 404;
        body: Buffer | '';
        headers?: {
            'content-type': string;
            'cache-control': 'no-cache';
            etag: string;
        };
    }
    /** 200 with the file type, or 304 when `If-None-Match` equals the ETag. Always `no-cache`. */
    export function faviconIcoFromFile(file: {
        body: Buffer;
        contentType: string;
    }, ifNoneMatch: string | undefined): FaviconIcoHttp;
    /** `GET /favicon.ico`: the file `resolveAppFaviconHref` chose. Missing file is 404 plus one log line. */
    export function faviconIcoResponse(favicon: ProjectsConfig['favicon'] | null, ifNoneMatch: string | undefined): FaviconIcoHttp;
    export function injectFaviconLink(html: string, href: string): string;
}
declare module "_102034_/l1/server/layer_1_external/frontend/appRegistry" {
    import type { FrontendAppRegistration } from "_102034_/l1/server/layer_2_controllers/contracts";
    /** Resolve the HTML shell for a module. Names the missing key instead of throwing
     *  `Cannot read properties of undefined (reading 'spa')` — that silent shape is what
     *  left pm2 green with nothing listening. */
    export function requireShellTemplate(shellTemplates: {
        spa?: string;
        pwa?: string;
    } | undefined, shellMode: string): string;
    export function getFrontendAppRegistrations(): Promise<FrontendAppRegistration[]>;
    export function getFrontendAppByBasePath(urlPath: string): Promise<FrontendAppRegistration>;
    export function getAppPublicRootDir(app: FrontendAppRegistration): string;
    /**
     * Directories that back this app's own `/{basePath}/...` asset URLs, tried after the shell root.
     *
     * Exactly ONE root: the module's own l3 asset dir (`_<project>_/l3/<moduleId>`). That makes
     * `/cafeFlow/assets/seed/MenuItem/x.webp` resolve to `_<project>_/l3/cafeFlow/assets/seed/...` — the
     * exact path the seed generator writes into `imageUrl` — and keeps it module-scoped, so two modules can
     * hold same-named assets without colliding. Before this, no root was consulted at all and a seed image
     * answered 200 with the SPA shell instead of its bytes.
     *
     * Deliberately NOT including `app.assetRoots` (every project's published l2): those files are already
     * reachable at `/_<project>_/l2/...` via tryReadProjectAsset, and mirroring them under every app's
     * basePath would add a second path to the same bytes for no benefit.
     */
    export function getAppAssetRootDirs(app: FrontendAppRegistration): string[];
}
declare module "_102034_/l1/monitor/layer_2_controllers/configHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorConfigLoadHandler: BffHandler;
    export const monitorAppsMenuHandler: BffHandler;
}
declare module "_102034_/l2/monitor/shared/contracts/messages" {
    export interface MonitorMessagesStorage {
        dynamoRegion?: string;
        s3Region?: string;
        bucket?: string;
        tablePrefix?: string;
        instanceId?: string | null;
        accountId?: string;
        ok?: boolean;
        error?: string;
    }
    export interface MonitorMessagesHealth {
        reachable: boolean;
        url: string;
        statusCode: number | null;
        error?: string;
        storage: MonitorMessagesStorage | null;
    }
    export interface MonitorMessagesReady {
        reachable: boolean;
        url: string;
        statusCode: number | null;
        status?: string;
        error?: string;
    }
    export interface MonitorMessagesPm2Process {
        name: string;
        instances: number;
        status: string;
        restarts: number;
        uptimeMs: number | null;
        memoryMb: number | null;
        cpu: number | null;
    }
    export interface MonitorMessagesStatusResponse {
        generatedAt: string;
        target: string;
        local: boolean;
        health: MonitorMessagesHealth;
        ready: MonitorMessagesReady;
        pm2: MonitorMessagesPm2Process[];
        pm2Error?: string;
    }
}
declare module "_102034_/l1/monitor/layer_3_usecases/messagesStatusUsecases" {
    import type { MonitorMessagesStatusResponse } from "_102034_/l2/monitor/shared/contracts/messages";
    export interface MessagesStatusDeps {
        fetchFn?: typeof fetch;
        listPm2?: () => unknown;
        now?: () => Date;
        getTarget?: () => string;
    }
    export function resolveMsgProxyTarget(env?: NodeJS.ProcessEnv): string;
    export function isLocalMsgTarget(target: string): boolean;
    export function msgHealthUrl(target: string, local: boolean): string;
    export function msgReadyUrl(target: string, local: boolean): string;
    export function loadMessagesStatus(deps?: MessagesStatusDeps): Promise<MonitorMessagesStatusResponse>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/messagesHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type MessagesStatusDeps } from "_102034_/l1/monitor/layer_3_usecases/messagesStatusUsecases";
    export function createMessagesStatusHandler(deps?: MessagesStatusDeps): BffHandler;
    export const monitorMessagesStatusHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_3_usecases/statisticsUsecases" {
    import type { MonitorSeriesPoint } from "_102034_/l1/monitor/module";
    export function getStatisticsSnapshot(): Promise<{
        generatedAt: string;
        storage: {
            postgres: {
                runtimeMode: "memory" | "postgres";
                tables: {
                    tableName: string;
                    description: string | null;
                    moduleId: string | null;
                    repositoryName: string | null;
                    storageProfile: string | null;
                    backupHot: boolean;
                    exists: boolean;
                    rowCount: number | null;
                }[];
            };
            dynamodb: {
                region: string;
                tables: {
                    tableName: string;
                    description: string | null;
                    moduleId: string | null;
                    repositoryName: string | null;
                    storageProfile: string | null;
                    backupHot: boolean;
                    exists: boolean;
                    itemCount: number | null;
                    tableStatus: string | null;
                    tableSizeBytes: number | null;
                    metricsAreApproximate: boolean;
                }[];
            };
        };
        counts: {
            postgresIndexes: {
                mdmEntityIndex: number;
                mdmProspectIndex: number;
                mdmRelationship: number;
                mdmProspectRelationship: number;
                monitorBffExecutionLog: number;
                monitorBffExecutionAggMinute: number;
            };
        };
        bff: {
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<import("/_102034_/l1/monitor/module.js").MonitorBffExecutionLogRecord, "routine" | "statusCode" | "statusGroup" | "errorCode" | "finishedAt">>;
        };
    }>;
    export function getStatisticsSeries(input?: {
        windowSeconds?: number;
        routine?: string;
        source?: 'http' | 'message' | 'test';
    }): Promise<{
        generatedAt: string;
        windowSeconds: number;
        totals: {
            total: number;
            success: number;
            clientError: number;
            serverError: number;
            notFound: number;
        };
        series: MonitorSeriesPoint[];
    }>;
    export function loadMonitorHome(): Promise<{
        generatedAt: string;
        system: {
            appEnv: "development" | "staging" | "production";
            runtimeMode: "memory" | "postgres";
            writeBehindEnabled: boolean;
            awsRegion: string;
        };
        bff: {
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<import("/_102034_/l1/monitor/module.js").MonitorBffExecutionLogRecord, "routine" | "statusCode" | "statusGroup" | "errorCode" | "finishedAt">>;
        };
        recentSeries: MonitorSeriesPoint[];
        postgres: {
            host: string;
            port: number;
            currentDatabase: string;
            availableDatabases: string[];
            tableCount: number;
            missingTableCount: number;
            activeConnections: number;
            cacheHitRate: number;
            pendingOutbox: number;
            replicationFailures: number;
        };
        dynamodb: {
            totalTables: number;
            availableTables: number;
            missingTables: number;
            totalItemCount: number;
            metricsAreApproximate: boolean;
        };
    }>;
    export function loadMonitorPostgres(input?: {
        databaseName?: string;
    }): Promise<{
        generatedAt: string;
        postgres: {
            runtimeMode: import("/_102034_/l1/server/layer_1_external/config/env.js").AppEnv["runtimeMode"];
            connection: {
                host: string;
                port: number;
                runtimeDatabase: string;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                activeConnectionsByState: Record<string, number>;
                maxConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        };
    }>;
    export function loadMonitorDynamodb(): Promise<{
        generatedAt: string;
        dynamodb: {
            runtimeMode: import("/_102034_/l1/server/layer_1_external/config/env.js").AppEnv["runtimeMode"];
            region: string;
            tables: Array<{
                tableName: string;
                description: string | null;
                moduleId: string | null;
                repositoryName: string | null;
                storageProfile: string | null;
                backupHot: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        };
    }>;
    export function loadMonitorArchitecture(): Promise<{
        generatedAt: string;
        architecture: {
            totalTables: number;
            postgresBackedTables: number;
            dynamoBackedTables: number;
            hotBackupTables: number;
            tables: import("/_102034_/l1/monitor/layer_1_external/data/persistence/MonitorPersistenceMetadata.js").MonitorTableMetadata[];
        };
    }>;
    export function loadMonitorPostgresTableInspect(input: {
        databaseName?: string;
        tableName: string;
        page?: number;
        filters?: Record<string, string>;
    }): Promise<{
        databaseName: string;
        tableName: string;
        description: string | null;
        moduleId: string | null;
        repositoryName: string | null;
        storageProfile: string | null;
        backupHot: boolean;
        exists: boolean;
        columns: Array<Pick<{
            name: string;
            dataType: string;
            isNullable: boolean;
            defaultValue: string | null;
        }, "name" | "dataType" | "isNullable">>;
        pagination: {
            page: number;
            pageSize: number;
            totalRows: number;
            totalPages: number;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        order: {
            primary: string[];
            fallback: string;
        };
        generatedAt: string;
    }>;
    export function loadMonitorPostgresTableDetails(input: {
        databaseName?: string;
        tableName: string;
    }): Promise<{
        databaseName: string;
        tableName: string;
        logicalTableName: string | null;
        projectId: string | null;
        description: string | null;
        moduleId: string | null;
        repositoryName: string | null;
        storageProfile: string | null;
        backupHot: boolean;
        exists: boolean;
        metrics: {
            rowCount: number;
            totalSizeBytes: number;
        };
        columns: {
            name: string;
            dataType: string;
            isNullable: boolean;
            defaultValue: string | null;
        }[];
        primaryKey: string[];
        indexes: {
            name: string;
            unique: boolean;
            method: string;
            columns: string[];
        }[];
        generatedAt: string;
    }>;
    export function loadMonitorDynamoTableInspect(input: {
        tableName: string;
        cursor?: string;
        filters?: Record<string, string>;
    }): Promise<{
        tableName: string;
        description: string | null;
        moduleId: string | null;
        repositoryName: string | null;
        storageProfile: string | null;
        backupHot: boolean;
        exists: boolean;
        columns: Array<{
            name: string;
            type: string;
            filterable: boolean;
        }>;
        pagination: {
            pageSize: number;
            cursor: string | null;
            nextCursor: string | null;
            hasNextPage: boolean;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        metricsAreApproximate: boolean;
        generatedAt: string;
    }>;
    export function loadMonitorDynamoTableDetails(input: {
        tableName: string;
    }): Promise<{
        tableName: string;
        description: string | null;
        moduleId: string | null;
        repositoryName: string | null;
        storageProfile: string | null;
        backupHot: boolean;
        exists: boolean;
        summary: {
            tableStatus: string | null;
            itemCount: number;
            tableSizeBytes: number;
            billingMode: string | null;
            tableClass: string | null;
            metricsAreApproximate: boolean;
        };
        keys: {
            partitionKey: string | null;
            sortKey: string | null;
        };
        attributeDefinitions: Array<{
            name: string;
            type: string;
        }>;
        globalSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
        localSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
        generatedAt: string;
    }>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/monitorGetStatistics" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorGetStatisticsSnapshotHandler: BffHandler;
    export const monitorGetStatisticsSeriesHandler: BffHandler;
    export const monitorHomeLoadHandler: BffHandler;
    export const monitorPostgresLoadHandler: BffHandler;
    export const monitorDynamodbLoadHandler: BffHandler;
    export const monitorArchitectureLoadHandler: BffHandler;
    export const monitorPostgresTableInspectHandler: BffHandler;
    export const monitorPostgresTableDetailsHandler: BffHandler;
    export const monitorDynamodbTableInspectHandler: BffHandler;
    export const monitorDynamodbTableDetailsHandler: BffHandler;
}
declare module "_102034_/l2/monitor/shared/contracts/process" {
    export interface MonitorProcessResponse {
        generatedAt: string;
        memory: {
            heapUsedMb: number;
            heapTotalMb: number;
            rssMb: number;
            externalMb: number;
            heapUsedPercent: number;
        };
        system: {
            freememMb: number;
            totalMemMb: number;
            freeMemPercent: number;
            cpuCount: number;
            loadAvg1m: number;
            loadAvg5m: number;
            loadAvg15m: number;
        };
        process: {
            uptimeSeconds: number;
            nodeVersion: string;
            pid: number;
        };
    }
}
declare module "_102034_/l1/monitor/layer_3_usecases/processHealthUsecases" {
    import type { MonitorProcessResponse } from "_102034_/l2/monitor/shared/contracts/process";
    export function loadProcessHealth(): MonitorProcessResponse;
}
declare module "_102034_/l1/monitor/layer_3_usecases/operationsUsecases" {
    import type { MonitorOperationsSummaryResponse, MonitorOperationsWindow } from "_102034_/l2/monitor/shared/contracts/operations";
    export function loadOperationsSummary(input: {
        window?: MonitorOperationsWindow;
        module?: string;
    }): Promise<MonitorOperationsSummaryResponse>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/operationsHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorOperationsSummaryHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/processHealthHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorProcessLoadHandler: BffHandler;
}
declare module "_102034_/l2/monitor/shared/contracts/logs" {
    export type MonitorLogApp = 'msg' | 'msg-worker';
    export type MonitorLogStream = 'out' | 'error';
    export interface MonitorLogPageInput {
        app: MonitorLogApp;
        stream: MonitorLogStream;
        startAt?: string;
        text?: string;
        cursor?: string;
        limit?: number;
    }
    export interface MonitorLogEntry {
        id: string;
        timestamp: string | null;
        text: string;
        truncated: boolean;
    }
    export interface MonitorLogPage {
        app: MonitorLogApp;
        stream: MonitorLogStream;
        file: string;
        updatedAt: string | null;
        entries: MonitorLogEntry[];
        nextCursor: string | null;
        hasMore: boolean;
        limited: boolean;
        scannedBytes: number;
        untimedEntries: number;
    }
    /** Server-side cursor. Opaque to the client. Carries no filesystem path. */
    export interface MonitorLogCursor {
        v: 1;
        app: MonitorLogApp;
        stream: MonitorLogStream;
        filterKey: string;
        sourceKey: string;
        offset: number;
    }
}
declare module "_102034_/l1/monitor/layer_3_usecases/logEntries" {
    import type { MonitorLogApp, MonitorLogCursor, MonitorLogEntry, MonitorLogStream } from "_102034_/l2/monitor/shared/contracts/logs";
    export const LOG_QUERY_CURSOR_MAX_BYTES = 4096;
    export const LOG_QUERY_TEXT_MAX = 500;
    export const LOG_QUERY_LIMIT_DEFAULT = 100;
    export const LOG_QUERY_LIMIT_MAX = 200;
    export interface NormalizedLogQuery {
        app: MonitorLogApp;
        stream: MonitorLogStream;
        startAt: string | null;
        text: string | null;
        cursor: MonitorLogCursor | null;
        limit: number;
    }
    export interface LogQueryError {
        status: 400;
        code: 'INVALID_LOG_QUERY';
        message: string;
    }
    export type LogQueryValidation = {
        ok: true;
        value: NormalizedLogQuery;
    } | {
        ok: false;
        error: LogQueryError;
    };
    export interface LogFilterResult {
        entries: MonitorLogEntry[];
        untimedEntries: number;
    }
    /** ISO with Z or a numeric offset. A zone-less PM2 stamp does not match. */
    export function parseExplicitTimestamp(value: string): string | null;
    export function parseMonitorLogEntries(fileKey: string, raw: string, baseOffset?: number): MonitorLogEntry[];
    /** Time and text both apply before any page cut. Untimed rows stay visible only without a time filter. */
    export function filterMonitorLogEntries(entries: readonly MonitorLogEntry[], filters: {
        startAt: string | null;
        text: string | null;
    }): LogFilterResult;
    /** Keeps chronological order. The cut is the latest `limit` rows after filtering. */
    export function cutLatestLogPage(entries: readonly MonitorLogEntry[], limit: number): MonitorLogEntry[];
    /** SHA-256 hex of the normalized filters (no page size). The cursor carries this, not the search text. */
    export function filterKeyOf(startAt: string | null, text: string | null): string;
    export function encodeMonitorLogCursor(cursor: MonitorLogCursor): string;
    export function validateMonitorLogPageInput(value: unknown): LogQueryValidation;
}
declare module "_102034_/l1/monitor/layer_3_usecases/logFilePages" {
    import type { MonitorLogPage } from "_102034_/l2/monitor/shared/contracts/logs";
    export const LOG_PAGE_READ_BUDGET: number;
    export const LOG_PAGE_TEXT_BUDGET: number;
    export interface LogFileTarget {
        file: string;
    }
    export interface LogFilePageError {
        status: 400 | 409;
        code: 'INVALID_LOG_QUERY' | 'LOG_SOURCE_CHANGED';
        message: string;
    }
    export type LogFilePageResult = {
        ok: true;
        page: MonitorLogPage;
    } | {
        ok: false;
        error: LogFilePageError;
    };
    /**
     * Reads one page of an already resolved log file. History is walked backward.
     * The snapshot is dev/ino, the size at open, a hash of the first 64 bytes, and
     * a hash of 64 bytes at the cursor. Appends past that size are ignored.
     * A same-length rewrite that preserves those anchors is not detected.
     */
    export function readLogFilePage(target: LogFileTarget, input: unknown): Promise<LogFilePageResult>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/releaseHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface LogTarget {
        app: string;
        file: string;
        updatedAt: string | null;
    }
    export interface LogTargetOptions {
        logsDir?: string;
        msgLogsDir?: string;
    }
    export const monitorReleasesListHandler: BffHandler;
    export const monitorReleasesActivateHandler: BffHandler;
    export function listLogTargets(stream: 'out' | 'error', options?: LogTargetOptions): LogTarget[];
    export function selectLogTarget(stream: 'out' | 'error', requestedApp: unknown, options?: LogTargetOptions): {
        target: LogTarget;
        available: LogTarget[];
    };
    export const monitorLogsTailHandler: BffHandler;
    export function createMonitorLogsPageHandler(options?: LogTargetOptions): BffHandler;
    export const monitorLogsPageHandler: BffHandler;
}
declare module "_102034_/l2/monitor/shared/contracts/trace" {
    export interface MonitorTraceEntry {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        statusCode: number;
        statusGroup: string;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    export interface MonitorTraceResponse {
        requestId: string | null;
        traceId: string | null;
        entries: MonitorTraceEntry[];
        totalCount: number;
    }
}
declare module "_102034_/l1/monitor/layer_3_usecases/traceUsecases" {
    import type { MonitorTraceResponse } from "_102034_/l2/monitor/shared/contracts/trace";
    export function loadRequestTrace(input: {
        requestId?: string;
        traceId?: string;
    }): Promise<MonitorTraceResponse>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/traceHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorRequestTraceLoadHandler: BffHandler;
}
declare module "_102021_/l2/helpers/l1Defs/definition" {
    /**
     * C0 contract for defs v2. Exclusive owner of this file: d1_30.
     *
     * d1_31 (writer/finalize), m1_01 (planner) and m1_04 (tests) import from here:
     *   /_102021_/l2/helpers/l1Defs/definition.js
     *
     * Does not import d1Artifact: d1_31 will import this module, and a reverse
     * runtime import would cycle. Business `data` keeps the D1 field names.
     */
    export const M1_DEFINITION_SCHEMA: "2026-09-24-d1-definition-v2";
    export const M1_RECEIPT_SCHEMA: "2026-09-24-m1-receipt-v1";
    export const D1_DEFINITION_SCHEMA_V1: "2026-09-21-d1-definition-v1";
    export const M1_STATUSES: readonly ["pending", "generated", "blocked", "failed"];
    export type M1Status = typeof M1_STATUSES[number];
    export const M1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound", "workflowProcess"];
    export type M1ArtifactType = typeof M1_ARTIFACT_TYPES[number];
    export const M1_STAGES: readonly ["plan", "generate", "compile", "verify", "promote"];
    export type M1Stage = typeof M1_STAGES[number];
    export const M1_VERIFICATION_KINDS: readonly ["compile", "test", "schema", "hash"];
    export type M1VerificationKind = typeof M1_VERIFICATION_KINDS[number];
    /** Public names d1_31 must import. Do not duplicate these enums in agentDefsL1. */
    export const D1_31_IMPORT: "/_102021_/l2/helpers/l1Defs/definition.js";
    export const D1_31_EXPORTS: readonly ["M1_DEFINITION_SCHEMA", "M1_STATUSES", "M1_ARTIFACT_TYPES", "parseDefinitionSource", "renderDefinition", "definitionIssues", "canonicalProjection", "semanticHash", "referenceIssues", "traverseDefinitions", "statusEvidenceIssues", "generatedAllowsSkip", "receiptIssues", "receiptPathFor", "diagnoseUnit"];
    export interface M1Definition {
        schemaVersion: typeof M1_DEFINITION_SCHEMA;
        artifactType: M1ArtifactType;
        artifactId: string;
        moduleName: string;
        status: M1Status;
        dependencies: string[];
        data: Record<string, unknown>;
    }
    export interface M1Verification {
        id: string;
        kind: M1VerificationKind;
        passed: boolean;
        detail: string;
    }
    export interface M1ReceiptFailure {
        code: string;
        detail: string;
    }
    export interface MaterializationReceipt {
        schemaVersion: typeof M1_RECEIPT_SCHEMA;
        runId: string;
        candidateId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        recipeVersion: string;
        semanticHash: string;
        dependencyHashes: Record<string, string>;
        sourceHashes: Record<string, string>;
        outputHashes: Record<string, string>;
        stage: M1Stage;
        verifications: M1Verification[];
        failures: M1ReceiptFailure[];
        attempts: number;
        reason: string;
    }
    export interface KnownArtifact {
        artifactType: M1ArtifactType;
        artifactId: string;
        defPath: string;
    }
    export interface ReferenceIndex {
        files: readonly string[];
        artifacts: readonly KnownArtifact[];
    }
    export interface IndexedDefinition {
        defPath: string;
        definition: M1Definition;
    }
    export interface UnitDiagnosis {
        unitId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        status: M1Status;
        stage: M1Stage;
        issues: string[];
        inputHash: string;
        outputHash: string;
    }
    export function isM1Status(value: string): value is M1Status;
    export function isM1ArtifactType(value: string): value is M1ArtifactType;
    export function isM1Stage(value: string): value is M1Stage;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function receiptFolder(moduleName: string): string;
    /**
     * Receipt file for one def. The def path is unique on disk; artifactId is not,
     * and a case-only difference is the same file. The base name has no extra dot.
     */
    export function receiptPathFor(defPath: string): string;
    export function outputPathFromDefPath(defPath: string): string;
    export function qualifiedFileIssues(path: string, field: string): string[];
    export function definitionIssues(value: unknown): string[];
    export function parseDefinitionSource(source: string): {
        definition: unknown;
    } | {
        issues: string[];
    };
    export function renderDefinition(definition: M1Definition, defPath: string): {
        source: string;
    } | {
        issues: string[];
    };
    export function readDefinition(value: unknown): M1Definition | {
        issues: string[];
    };
    export function canonicalProjection(definition: M1Definition): Record<string, unknown>;
    export function semanticHash(definition: M1Definition): Promise<string>;
    export function referenceIssues(definition: M1Definition, index: ReferenceIndex): string[];
    export function traverseDefinitions(units: readonly IndexedDefinition[], knownFiles?: readonly string[]): {
        order: string[];
        issues: string[];
    };
    export function receiptIssues(value: unknown): string[];
    export function statusEvidenceIssues(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<string[]>;
    export function generatedAllowsSkip(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<boolean>;
    export function diagnoseUnit(input: {
        defPath: string;
        definition: M1Definition;
        receipt?: MaterializationReceipt | null;
        index?: ReferenceIndex;
        stage?: M1Stage;
        currentDependencyHashes?: Readonly<Record<string, string>>;
    }): Promise<UnitDiagnosis>;
    /** Top-level `data` keys. d1_31 uses this list; agentDefsL1 does not keep a second copy. */
    export function dataAllowList(type: M1ArtifactType): readonly string[];
}
declare module "_102021_/l2/agentMaterializeL1/core/registry" {
    /**
     * Closed handler registry. This file is the only integrator: m1_03, m1_06 and m1_07
     * deliver a MaterializeHandler; wiring it stays here. A type with no named entry is
     * blocked by the planner. Nothing in this module writes a file.
     */
    import { type M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_HANDLER_STAGES: readonly ["structure", "implement"];
    export type M1HandlerStage = typeof M1_HANDLER_STAGES[number];
    /** Platform capabilities a handler may ask the context resolver to load. MDM catalog is not one of them. */
    export const M1_CONTEXT_CAPABILITIES: readonly ["requestContext", "dataRuntime", "tableDefinition", "repositoryRegistry", "mdmFacade"];
    export type M1ContextCapability = typeof M1_CONTEXT_CAPABILITIES[number];
    export interface MaterializeHandler {
        readonly id: string;
        readonly artifactType: M1ArtifactType;
        readonly stage: M1HandlerStage;
        /** False means the recipe is local. Simulate never calls a model for this handler. */
        readonly needsLlm: boolean;
        readonly capabilities: readonly M1ContextCapability[];
    }
    /** Implement recipes. Null is a written absence: no fallback onto the structure scaffolder. */
    export const M1_IMPLEMENT_HANDLERS: Record<M1ArtifactType, MaterializeHandler | null>;
    export const M1_STRUCTURE_HANDLERS: Readonly<Record<M1ArtifactType, MaterializeHandler>>;
    export function handlerFor(type: string, stage?: M1HandlerStage): MaterializeHandler | null;
    export function registeredHandlerIds(stage?: M1HandlerStage): string[];
}
declare module "_102021_/l2/agentMaterializeL1/testing/catalog" {
    /**
     * Scenario catalog for one module. The monitor imports the rendered module
     * (export `scenarioCatalog` only). The sibling test file of each unit carries
     * the same scenario as data (`renderScenarioTest`); nothing here runs a case.
     */
    import type { M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    import type { M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    export const M1_CATALOG_SCHEMA: "2026-09-25-m1-scenario-catalog-v1";
    /** Additive: each case names its runner, and a route case names its caller. */
    export const M1_CATALOG_SCHEMA_V11: "2026-09-26-m1-scenario-catalog-v1.1";
    /** Additive: a route case may name `<seedRef>` params and the entity field each one addresses. */
    export const M1_CATALOG_SCHEMA_V12: "2026-10-02-m1-scenario-catalog-v1.2";
    export const M1_CATALOG_SCHEMAS: readonly ["2026-09-25-m1-scenario-catalog-v1", "2026-09-26-m1-scenario-catalog-v1.1", "2026-10-02-m1-scenario-catalog-v1.2"];
    /** Literal the monitor resolves from a seeded row. Never an invented id. */
    export const M1_SEED_REF: "<seedRef>";
    export type M1CatalogSchema = typeof M1_CATALOG_SCHEMAS[number];
    /** Positive case of an operation that addresses one stored record. */
    export const M1_EXISTING_RECORD = "existing record";
    export const M1_CATALOG_EXPORT: "scenarioCatalog";
    /** Config key x1_02 will read. It is not `frontend.pageTests`. */
    export const M1_CATALOG_CONFIG_KEY: "backend.scenarioCatalog";
    /** Provisional stub from the structure handler. Business expectations do not use this code. */
    export const M1_STUB_ERROR: "USECASE_NOT_IMPLEMENTED";
    export const M1_STUB_STATUS = 501;
    export const M1_GATES: readonly ["compile", "contract", "auth", "business"];
    export type M1Gate = typeof M1_GATES[number];
    export interface M1SyntheticRow {
        entity: string;
        id: string;
        professionalId: string;
        patientId: string;
        scheduledAt: string;
        status: string;
        version: number;
        attendanceNote: string;
    }
    export interface M1ExpectedFailure {
        caseId: string;
        stage: 'structure';
        errorCode: typeof M1_STUB_ERROR;
        status: typeof M1_STUB_STATUS;
    }
    /** Definitive assertion. A repair is not allowed to change it. */
    export interface M1CaseExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        forbiddenFields: string[];
        /** When set, every returned row must carry this actor id. Shape alone does not pass. */
        isolatedActorField: string | null;
    }
    export type M1CaseRunner = 'route' | 'module';
    /** Present only on a route case. Authorities come from the grant, not from the case id. */
    export interface M1CaseCaller {
        source: 'http';
        authorities: string[];
    }
    export interface M1ScenarioCase {
        caseId: string;
        gate: M1Gate;
        mandatory: true;
        source: string;
        expectation: string;
        preconditions: string[];
        synthetic: M1SyntheticRow[];
        actorId: string;
        routine: string;
        mutating: boolean;
        expect: M1CaseExpect;
        expectedFailure: M1ExpectedFailure | null;
        /** Absent on a v1 catalog. */
        runner?: M1CaseRunner;
        /** Absent on a module case and on a v1 catalog. */
        caller?: M1CaseCaller;
        /** Absent before v1.2. Values may be the literal `<seedRef>`. */
        params?: Record<string, string>;
        /** `<Entity>.<field>` for each `<seedRef>` param. Absent before v1.2. */
        paramFieldRefs?: Record<string, string>;
    }
    export interface M1Scenario {
        scenarioId: string;
        source: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        handlerId: string;
        productionFile: string;
        testFile: string;
        cases: M1ScenarioCase[];
    }
    export interface M1ScenarioCatalog {
        schemaVersion: M1CatalogSchema;
        moduleName: string;
        store: 'memory';
        scenarios: M1Scenario[];
    }
    export interface M1CatalogParse {
        catalog: M1ScenarioCatalog | null;
        issues: string[];
    }
    export interface M1RepairProposal {
        caseId: string;
        ok?: boolean;
        status?: number;
        errorCode?: string | null;
        ruleId?: string | null;
        dropForbiddenFields?: readonly string[];
        clearActorFilter?: boolean;
        dropExpectedFailure?: boolean;
        replaceExpectedFailure?: {
            errorCode: string;
            status: number;
        };
    }
    export function canonicalJson(value: unknown): string;
    export function extractCatalogJson(source: string): string | null;
    export function parseCatalog(source: string): M1CatalogParse;
    /** Implement removes the provisional mark. This is not a repair. */
    export function catalogForStage(catalog: M1ScenarioCatalog, stage: M1HandlerStage): M1ScenarioCatalog;
    /**
     * Drops a rule or a filter from a copy of the case. Used only to prove the
     * original assertion fails when that rule is absent. Repair refuses the same edit.
     */
    export function withoutRule(item: M1ScenarioCase, ruleId: string): M1ScenarioCase;
    export function repairRefusal(item: M1ScenarioCase, proposal: M1RepairProposal): string[];
    export function applyRepair(catalog: M1ScenarioCatalog, proposal: M1RepairProposal): {
        catalog: M1ScenarioCatalog;
        refused: string[];
    };
    export function renderMonitorCatalog(catalog: M1ScenarioCatalog, fileReference: string): string;
    /** Qualified file or import (`_NNNNN_/…` or `/_NNNNN_/…`) as `/_NNNNN_/….js`. Anything else is refused. */
    export function moduleSpecifier(file: string): string;
    /** Export of the per-unit `.test.ts`: that unit's scenario, as data. */
    export const M1_TEST_EXPORT: "scenarioCases";
    /**
     * The per-unit `.test.ts` is data: the scenario the monitor runs from the module catalog
     * (`backend.scenarioCatalog`). No import, no runner, nothing executes when it loads, so it
     * compiles in the Studio like any other module (conduta 28/09, rule 4).
     */
    export function renderScenarioTest(scenario: M1Scenario): string;
    /** A test this agent rendered before m1_35: a node runner bound to the catalog. It is rewritten, never kept. */
    export function isLegacyNodeTest(text: string, testFile: string): boolean;
    export function testFileFor(productionFile: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/core/io" {
    /** Read port for simulate. There is no write, delete, migrate or model method on purpose. */
    export interface MaterializeReadIo {
        read(ref: string): Promise<string | null>;
    }
    export function contentHash(value: string): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/testing/verify" {
    /**
     * Classifies one batch against the catalog. Stage comes from the handler
     * registered by m1_01. An unstructured exception or a broken compile is
     * never expected-red.
     */
    import type { MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import type { MaterializeHandler, M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    import { type M1ScenarioCase } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    export const M1_CHECKPOINT_SCHEMA: "2026-09-25-m1-checkpoint-v1";
    export const M1_CHECKPOINT_BUDGET_MS: number;
    export const M1_VERDICTS: readonly ["passed", "expectedRed", "failed", "blocked", "skipped", "inconclusive"];
    export type M1Verdict = typeof M1_VERDICTS[number];
    export const M1_BROKEN: readonly ["none", "compile", "import", "transport"];
    export type M1Broken = typeof M1_BROKEN[number];
    /** What one case did. The caller fills this. This module does not call a database. */
    export interface M1Observation {
        caseId: string;
        durationMs: number;
        broken: M1Broken;
        thrown: boolean;
        skipped: boolean;
        inconclusive: boolean;
        blocked: boolean;
        blockOwner: string;
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        fields: string[];
        rowActorIds: string[];
        reason: string;
    }
    export interface M1Evidence {
        caseId: string;
        verdict: M1Verdict;
        errorCode: string | null;
        status: number | null;
        durationMs: number;
        detail: string;
    }
    export interface M1CheckpointCounts {
        passed: number;
        expectedRed: number;
        failed: number;
        blocked: number;
        skipped: number;
        inconclusive: number;
    }
    export interface M1Checkpoint {
        schemaVersion: typeof M1_CHECKPOINT_SCHEMA;
        runId: string;
        inputHash: string;
        commit: string;
        stage: M1HandlerStage;
        handlerId: string;
        startedAt: string;
        finishedAt: string;
        budgetMs: typeof M1_CHECKPOINT_BUDGET_MS;
        counts: M1CheckpointCounts;
        durationsMs: {
            total: number;
        };
        ready: boolean;
        accepted: boolean;
        evidence: M1Evidence[];
        nextAction: string;
        monitor: {
            delivered: boolean;
            error: string | null;
        };
    }
    /** Verification request. The handler and the read port belong to m1_01. */
    export interface MaterializeVerificationRequest {
        handler: MaterializeHandler;
        io: MaterializeReadIo;
        catalogRef: string;
        /** When set, only this artifact's scenarios are scored. An empty match is not a failed batch. */
        artifactId?: string;
        observations: readonly M1Observation[];
        runId: string;
        commit: string;
        startedAt: string;
        finishedAt: string;
        monitorError: string | null;
    }
    export function checkpointDue(elapsedMs: number, batchClosed: boolean): boolean;
    export function classifyCase(stage: M1HandlerStage, item: M1ScenarioCase, observation: M1Observation | undefined): M1Evidence;
    export function verifyBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    /**
     * The agent's own gate (m1_34). The agent runs in the browser and does not run a case, so a case
     * with no observation and a predicted ok/status decide nothing: the case verdict is the monitor's
     * (m1_35). What blocks is only what the agent sees without running: a broken compile or import, an
     * unstructured exception, and a def gap with an owner (held). The catalog checks stay fail-closed.
     */
    export function gateBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    export function noteMonitorFailure(report: M1Checkpoint, error: string): M1Checkpoint;
}
declare module "_102034_/l1/monitor/layer_3_usecases/testsUsecases" {
    import { type BffResponse, type PlatformSessionPerson } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    import { type OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { type SeedModeInput, type SeedPolicyTable } from "_102034_/l1/server/layer_1_external/persistence/seedPolicy";
    import type { M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    import { type M1ScenarioCase } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    import { type M1Broken, type M1Observation, type M1Verdict } from "_102021_/l2/agentMaterializeL1/testing/verify";
    type TestShape = 'object' | 'array' | 'paginated';
    interface PageTestCase {
        id: string;
        routine: string;
        params: Record<string, unknown>;
        /**
         * Ontology fieldRef of each seed-marker param (`Task.taskId`), keyed by the input's wire name.
         * The harvest pool is filled from response field names (usually the fieldId); matching by
         * inputId alone misses `taskTaskId` vs `taskId`. Optional: files generated before this existed
         * keep resolving by name only.
         */
        paramFieldRefs?: Record<string, string>;
        expect: {
            ok: boolean;
            errorCode?: string;
            minItems?: number;
            shape?: TestShape;
            itemsKey?: string;
        };
        mutating: boolean;
        /**
         * A failure that is already understood and owned by a named wave of work (e.g. 'mdm-rebuild'). The case
         * still RUNS and still reports what happened: it is counted apart from `failed`, so a suite can be green
         * with knowns instead of red with noise, and the day it passes the run says so — which is how the wave
         * gets proved in production instead of on someone's word.
         */
        expectedFail?: string;
    }
    interface PageTestsFile {
        moduleName: string;
        page: string;
        variant: string;
        actor?: string;
        cases: PageTestCase[];
    }
    export type TestCaseStatus = 'pass' | 'fail' | 'inconclusive' | 'skipped' | 'knownFail' | 'expectedRed' | 'blocked' | 'moduleOnly';
    export interface TestCaseResult {
        module: string;
        page: string;
        id: string;
        routine: string;
        status: TestCaseStatus;
        ok: boolean;
        statusCode: number;
        durationMs: number;
        errorCode: string | null;
        errorMessage: string | null;
        reason: string;
        /** Handler stage the producer classified (`structure` | `implement`). Catalog cases only. */
        stage?: string;
        /** Catalog `source`: who wrote the expectation. Not a screen-authored label. */
        expectationSource?: string;
        /** Catalog `expectation` text. */
        expectation?: string;
    }
    export interface TestRunSummary {
        runId: string;
        traceId: string;
        startedAt: string;
        finishedAt: string;
        /** ProjectMode from l5/project.json — not the server APP_ENV. */
        appEnv: string;
        /** Where `appEnv` was read from, so a VM with APP_ENV=production is not mistaken for the project mode. */
        appEnvSource: string;
        /** Server deployment (`APP_ENV`): development | staging | production. */
        serverAppEnv: string;
        scope: {
            moduleId?: string;
            page?: string;
        };
        total: number;
        passed: number;
        failed: number;
        /** Failures a case declared as already-owned work (`expectedFail`): known, not new. */
        knownFail: number;
        /** Catalog verdict `expectedRed` (structure stub). Not a pass and not a new failure. */
        expectedRed: number;
        /** Catalog cases with `runner: 'module'`: reported, not executed by the monitor. Not a pass, not a failure. */
        moduleOnly: number;
        blocked: number;
        inconclusive: number;
        skipped: number;
        /** No registered frontend pageTests and no backend.scenarioCatalog in scope. Never a green empty run. */
        untested: boolean;
        untestedReason: string;
        cases: TestCaseResult[];
    }
    export interface TestListResult {
        appEnv: string;
        appEnvSource: string;
        serverAppEnv: string;
        executionEnabled: boolean;
        modules: Array<{
            moduleId: string;
            projectId: string;
            /** page21/page31 share page11's BFF contract; cases are generated once. */
            variantPolicy: string;
            untestedPages: Array<{
                page: string;
                reason: string;
            }>;
            pages: Array<{
                page: string;
                variant: string;
                path: string;
                loadError?: string;
                cases: Array<{
                    id: string;
                    routine: string;
                    mutating: boolean;
                    expect: PageTestCase['expect'];
                }>;
            }>;
        }>;
        recentRuns: TestRunSummary[];
    }
    export const PAGE11_VARIANT_POLICY = "page21/page31 share page11's contract; cases are generated once for page11.";
    export function untestedPageEntries(configuredPageIds: string[], testedPageIds: Iterable<string>): Array<{
        page: string;
        reason: string;
    }>;
    export function getRecentRuns(filter?: {
        moduleId?: string;
        page?: string;
        runId?: string;
    }, limit?: number): TestRunSummary[];
    export function coercePageTestsFile(raw: unknown): PageTestsFile | null;
    /** Params the catalog case can state without reading a route contract. Omitted names come from preconditions. */
    export function paramsForCatalogCase(item: M1ScenarioCase): Record<string, unknown>;
    /** Pure. See module comment above `FIELD_PATHS_MAX_DEPTH` for the path format this feeds. */
    export function fieldPathsOf(data: unknown): string[];
    export function observationFromExec(caseId: string, durationMs: number, exec: {
        response: BffResponse;
        statusCode: number;
    } | null, patch?: {
        broken?: M1Broken;
        thrown?: boolean;
        actorField?: string | null;
    }): M1Observation;
    /** Producer owns the verdict. expectedRed is only the structure stub (caseId + USECASE_NOT_IMPLEMENTED + 501). */
    export function verdictForCatalogCase(stage: M1HandlerStage, item: M1ScenarioCase, observation: M1Observation | undefined): {
        verdict: M1Verdict;
        detail: string;
    };
    export function emptyRunCoverage(registered: number): {
        untested: boolean;
        untestedReason: string;
    };
    /** ProjectMode from l5/project.json wins over APP_ENV. The test report prints both so they cannot be confused. */
    export function reportAppEnv(projectId?: string): {
        appEnv: string;
        appEnvSource: string;
        serverAppEnv: string;
    };
    export function listPageTests(): Promise<TestListResult>;
    /** `itemsKey` is a path: `consultas.items` reads `data.consultas.items` (the contract nests the page). */
    export function itemsAt(data: unknown, itemsKey?: string): unknown;
    export function checkShape(data: unknown, shape: TestShape, itemsKey?: string): string;
    export function countItems(data: unknown, itemsKey?: string): number;
    /** A table/entity of one module, as its metadata declares it: the entity's own id and its columns. */
    export interface EntityIndexEntry {
        entity: string;
        pkFieldId: string;
        columnFieldIds: string[];
    }
    /** Entity index per moduleId: a module's metadata never qualifies another module's rows. */
    export type ModuleEntityIndex = Map<string, EntityIndexEntry[]>;
    /** The organization Company of the run: an MDM `Company` row with this mdmId is one of these entities. */
    export interface HarvestCompany {
        companyMdmId: string;
        entities: Set<string>;
    }
    /**
     * Harvest a successful response into the pool, without touching it. Bare keys (the legacy lookup without
     * fieldRef) come from the same levels as always: the envelope and the rows of its top-level arrays.
     * Entity-qualified keys come from records at ANY depth (DTOs nest `company`, `member`, `people.items`),
     * but only when `provenEntityOf` proves the entity from the module's metadata. Traversal stops at the
     * FIELD_PATHS_* caps used for the observed field paths. Existing keys are never overwritten, so a seed
     * anchor is not replaced by a later response.
     */
    export function harvestRows(pool: Record<string, unknown>, data: unknown, moduleId?: string, index?: ModuleEntityIndex, company?: HarvestCompany): void;
    /**
     * Ontology entity of a table. The repository name is the entity name (`privacyText` → `PrivacyText`,
     * `itemCardapio` → `ItemCardapio`); tableName/logicalTableName only when it is missing. A legacy
     * `<moduleId><Entity>` repository name is cut ONLY when the table's own id or a declared own-id fieldRef
     * (`Petition.petitionId`) proves the shorter name — a module id that merely prefixes a normal name is kept.
     * Both names proved → ambiguous → '' (no entity is anchored for that table).
     */
    export function ontologyEntityName(definition: {
        moduleId?: string;
        repositoryName?: string;
        tableName: string;
        logicalTableName?: string;
        primaryKey?: string[];
    }, declaredOwnIdEntities?: ReadonlySet<string>): string;
    /**
     * Put a seeded PK into the pool under the entity-qualified key (`Petition.petitionId`).
     * Named `seedIds` win when their value is actually a row of this table — they pick the intended
     * line (e.g. a published petition) instead of "whatever was first in the file". Existing keys
     * are never overwritten.
     */
    export function applySeedAnchors(pool: Record<string, unknown>, input: {
        entity: string;
        fieldId: string;
        seedRowIds: unknown[];
        namedIds?: Record<string, unknown>;
        moduleId?: string;
        seedRows?: Array<Record<string, unknown>>;
        pkColumn?: string;
    }): void;
    /**
     * First leftover per `Entity.fieldId` from the module's `seedSpares` export. Stored under
     * `spare:Entity.fieldId` so a create case cannot pick a value that is already on a seeded row.
     */
    export function applySeedSpares(pool: Record<string, unknown>, seedSpares: unknown, moduleId?: string): void;
    /** Rows the monitor may harvest. Same selection as the migration; seedIds/seedSpares stay untouched. */
    export function selectMonitorSeedRows(table: SeedPolicyTable, input: SeedModeInput): Record<string, unknown>[];
    interface ResolvedParams {
        params: Record<string, unknown>;
        unresolved: string[];
    }
    /**
     * Resolve the seed markers of a case's params — at any depth (`details.identification.countryCode`,
     * `items.0.productId`). Only a value that IS a marker is resolved; a string merely containing one is
     * left as written. The input is never mutated: a fresh tree is returned.
     *
     * Each leaf is looked up by the fieldRef its dotted path declares. The bare-name fallback (no
     * fieldRef) applies to TOP-LEVEL keys only, as files generated before paramFieldRefs expect; a nested
     * leaf is never matched by its field name alone (that would hand another entity's id to it).
     * `unresolved` lists the full path of every marker left without a value — the caller must not run the
     * case then (a request without that value is not the case as written).
     */
    export function resolveParams(params: Record<string, unknown>, pool: Record<string, unknown>, paramFieldRefs?: Record<string, string>, moduleId?: string): ResolvedParams;
    /**
     * The verdict of a case whose params still carry an unresolved seed marker: 'inconclusive', decided
     * BEFORE the request is sent. Sending it without the value (or with the literal marker) would make
     * any rejection — 401/403, required, not found — look like the case's own verdict.
     */
    export function unresolvedCaseResult(testCase: PageTestCase, module: string, page: string, unresolved: string[], notes?: string[]): TestCaseResult;
    export function evaluate(testCase: PageTestCase, module: string, page: string, exec: {
        response: BffResponse;
        statusCode: number;
    }, durationMs: number, unresolved: string[]): TestCaseResult;
    /** The session a declared actor's cases run with — or why they cannot run at all. */
    export type ActorSessionResolution = {
        ok: true;
        sessionContext: {
            actorId: string;
            actorScope: string[];
            person: PlatformSessionPerson;
        };
    } | {
        ok: false;
        reason: string;
    };
    /** Cache key of an actor session: the SAME actorRef in two modules is two different fixtures. */
    export function actorSessionKey(moduleId: string, actorRef: string): string;
    /**
     * The test session of an l4 actor, resolved BY DATA in the run's own sandbox runtime: agentCbSeeds emits
     * one MDM Person per actor tagged ['<module>.Person', '<module>', 'actor', '<actorRef>'], so the tags alone
     * identify it. Deliberately NOT recomputing the seed's stableUuid hash — that convention has one owner
     * (cbSeedsCore in mls-102021) and duplicating it here would create a second.
     * - `moduleName` is what the seeds tag with; `moduleId` is what the platform qualifies authorities with
     *   (`<moduleId>:<actorRef>`, the same format `withAlphaAuthorities` grants real traffic).
     * - The scope is ONLY that one authority — never every authority of the module — so the case exercises the
     *   actor it declared. The fixture only picks the identity inside the sandbox; it grants nothing to real traffic.
     * - `person` keeps the public PlatformSessionPerson shape. `email` is the fixture's login row when it declares
     *   one; otherwise '' — a simulated identity of a `source: 'test'` run, never an invented e-mail.
     * - Absent, ambiguous or inconsistent (index × document) → not ok, with the reason: the cases are blocked,
     *   never run anonymous.
     */
    export function resolveActorSession(data: IDataRuntime, input: {
        moduleId: string;
        moduleName: string;
        actorRef: string;
    }): Promise<ActorSessionResolution>;
    /** Where the run's organization comes from: the configured binding and the Company role tags it declares. */
    export interface RunOrganizationSource {
        binding: OrganizationBinding | null;
        /** `onboarding.companyType` (`<module>.<Entity>`) when configured: the entity the org Company plays. */
        companyTags: string[];
    }
    /** The organization Company of ONE run, prepared inside that run's sandbox — or why there is none. */
    export type RunOrganization = {
        ok: true;
        companyMdmId: string;
        companyTags: string[];
    } | {
        ok: false;
        reason: string;
        companyTags: string[];
    };
    /** Same resolver the boot uses (`initializeOrganizationForProcess`), read only — nothing is published. */
    export function readRunOrganizationSource(): RunOrganizationSource;
    /**
     * The organization Company the session acts for, created by the platform's own `ensureOrganizationIdentity`
     * against the run's disposable runtime (reservation, transaction and Company live and die there). Never the
     * process initializer: that one writes the shared store and publishes the process-wide Company id.
     * No valid binding → not ok with the reason; no organization is invented.
     */
    export function prepareRunOrganization(data: IDataRuntime, readSource?: () => RunOrganizationSource): Promise<RunOrganization>;
    /** Why a case's unresolved Company marker stayed unresolved, when the run had no organization Company. */
    export function organizationNote(unresolved: string[], paramFieldRefs: Record<string, string> | undefined, org: RunOrganization): string;
    /**
     * Anchors for MDM-backed entities, read from the rows ACTUALLY in the run's sandbox (index + document), before
     * any read case runs. An entity is MDM only by origin: the row carries the tag `<moduleName>.<Entity>` of a
     * module in the run. Keys are always `<moduleId>.<Entity>.<field>` — never an unqualified id, so the same UUID
     * is not published as the id of every entity. Per entity: the module namespace (`details.<moduleName>`), the
     * document version, the detail scalars, and the own-id wire alias `<entity>Id` → mdmId. First row wins
     * (named seedIds first, then store order); existing keys are never overwritten. The `Company` subtype and the
     * configured company role are anchored ONLY to the run's organization Company, never to another row or a
     * Person. Nothing is created here: a fixture the module does not provide stays unresolved.
     */
    export function harvestMdmAnchors(pool: Record<string, unknown>, data: IDataRuntime, input: {
        moduleIdByName: Map<string, string>;
        organization: RunOrganization;
        namedIds?: Record<string, unknown>;
    }): Promise<void>;
    export function runPageTests(input?: {
        moduleId?: string;
        page?: string;
        skipMutating?: boolean;
    }): Promise<TestRunSummary>;
    export function loadTestResults(input?: {
        moduleId?: string;
        page?: string;
        runId?: string;
        limit?: number;
    }): {
        recentRuns: TestRunSummary[];
    };
}
declare module "_102034_/l1/monitor/layer_2_controllers/testsHandlers" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const monitorTestsListHandler: BffHandler;
    export const monitorTestsRunHandler: BffHandler;
    export const monitorTestsResultsHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/router" {
    import { type BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createMonitorRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/monitor/layer_3_usecases/runtimeMetricsUsecases" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import { RuntimeMetricsPostgres } from "_102034_/l1/monitor/layer_1_external/data/postgres/RuntimeMetricsPostgres";
    import type { RuntimeMetricsResponse } from "_102034_/l2/monitor/shared/contracts/runtimeMetrics";
    interface RuntimeMetricIdentity {
        projectId: string;
        processInstance: string;
        releaseId: string | null;
        allocator: 'system' | 'jemalloc';
        optimizeForSize: boolean;
    }
    export function resolveRuntimeMetricIdentity(env: AppEnv, defaultProjectId?: string): RuntimeMetricIdentity;
    export function calculateCpuPercent(cpuUsage: NodeJS.CpuUsage, elapsedMicroseconds: number): number;
    export function parseRuntimeMetricsQuery(url: string): {
        minutes: number;
        limit: number;
    };
    export class RuntimeMetricsCollector {
        private readonly repository;
        private readonly identity;
        private timer;
        private collecting;
        private previousCpuUsage;
        private previousHrtime;
        private previousElu;
        private readonly eventLoopDelay;
        constructor(repository: RuntimeMetricsPostgres, identity: RuntimeMetricIdentity);
        start(): Promise<void>;
        stop(): void;
        collectOnce(): Promise<void>;
    }
    export function createRuntimeMetricsCollector(env: AppEnv, defaultProjectId?: string): RuntimeMetricsCollector;
    export function loadRuntimeMetricSamples(input: {
        minutes: number;
        limit: number;
        defaultProjectId?: string;
    }, env?: AppEnv): Promise<RuntimeMetricsResponse>;
}
declare module "_102034_/l1/scripts/db" {
    export function getSqlDirPaths(): Promise<string[]>;
    export function listSqlFiles(): Promise<string[]>;
    export function readSqlFile(fileName: string): Promise<string>;
    export function getPgPool(): Promise<Pool>;
}
declare module "_102034_/l1/scripts/envCli" {
    export type CliAppEnv = 'development' | 'staging' | 'production';
    export function parseCliAppEnv(value: string | undefined): CliAppEnv;
    export function setCliAppEnv(value: string | undefined): CliAppEnv;
}
declare module "_102034_/l1/scripts/dbDelete" {
    export function dbDelete(inputEnv?: string, confirmation?: string): Promise<void>;
}
declare module "_102034_/l1/server/layer_1_external/platform/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/schemaModulePlan" {
    import type { SchemaSnapshot } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type SnapshotTable = SchemaSnapshot['tables'][number];
    export type ModuleRebuildMode = 'none' | 'recordOnly' | 'full' | 'modules';
    export interface ModuleRebuildPlan {
        mode: ModuleRebuildMode;
        rebuild: string[];
        untouched: string[];
        removed: string[];
    }
    export interface MigrationReportRebuiltModule {
        moduleId: string;
        tables: number;
        seedRows: number;
    }
    export interface MigrationReportSummary {
        rebuilt: MigrationReportRebuiltModule[];
        untouched: string[];
        removed: string[];
        orphans?: string[];
    }
    export function stateKey(projectId: string, moduleId: string): string;
    export function parseStateKey(key: string): {
        projectId: string;
        moduleId: string;
    } | null;
    export function moduleHashes(tables: SnapshotTable[]): Promise<Map<string, string>>;
    export function planModuleRebuild(args: {
        current: Map<string, string>;
        applied: Map<string, string> | null;
        lastSnapshotId: string | null;
        currentSnapshotId: string;
        ownProjects: string[];
    }): ModuleRebuildPlan;
    export function formatMigrationReport(summary: MigrationReportSummary): string;
}
declare module "_102034_/l1/server/layer_1_external/persistence/seedApplier" {
    import type { ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export interface SeedApplyCounts {
        initialInserted: number;
        initialConflicts: number;
        testInserted: number;
    }
    export interface SeedApplyInput {
        projectMode: (projectId: string) => ProjectMode;
        serverMode: ProjectMode;
        /** Physical names created by this rebuild. Test rows are written only for these tables. */
        rebuiltTableNames: ReadonlySet<string>;
    }
    interface Queryable {
        query(sql: string, values?: unknown[]): Promise<{
            rowCount: number | null;
        }>;
    }
    /** JSONB is sent as text. Array columns keep the JS array so node-pg binds the array type. */
    export function serializeSeedValue(postgresType: string, value: unknown): unknown;
    export function buildSeedInsertSql(tableName: string, columnNames: string[], purpose: 'initial' | 'test'): string;
    /**
     * Writes initial rows for every Postgres table, then test rows only for tables created
     * in this rebuild and only when the mode allows them. Initial uses ON CONFLICT DO NOTHING
     * so an existing key is left unchanged. A test row that collides with initial is omitted
     * before INSERT; other test failures stay non-fatal for that table.
     */
    export function applySeedRows(pool: Queryable, definitions: ResolvedTableDefinition[], input: SeedApplyInput): Promise<SeedApplyCounts>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/schemaBootstrap" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import type { ResolvedTableDefinition, TableIndexDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import { type ModuleRebuildMode } from "_102034_/l1/server/layer_1_external/persistence/schemaModulePlan";
    export type OwnedNameDefinition = Pick<ResolvedTableDefinition, 'tableName' | 'logicalTableName' | 'moduleId' | 'projectId'>;
    /** Names that `rebuildPostgresSchema` may drop. `modules: 'all'` is the full rebuild of today. */
    export function ownedNamesFor(definitions: OwnedNameDefinition[], modules: string[] | 'all', removed: string[]): {
        isOwned: (name: string) => boolean;
    };
    /** Tables this rebuild creates. `_schema_migrations` is recreated only in `full`. */
    export function tablesToCreate<T extends OwnedNameDefinition>(definitions: T[], mode: 'full' | 'modules', rebuildModules: string[]): T[];
    /**
     * A leftover client table: project prefix, not in any current definition, and not dropped.
     * Intact modules stay in `definitions`, so they are not orphans. `full` owns the prefix, so the list is empty.
     */
    export function orphanNames(existing: string[], definitions: OwnedNameDefinition[], isOwned: (name: string) => boolean, clientPrefixes: string[]): string[];
    export interface SchemaBootstrapReport {
        rebuilt: Array<{
            moduleId: string;
            tables: number;
            seedRows: number;
        }>;
        untouched: string[];
        removed: string[];
        mode: ModuleRebuildMode;
        orphans: string[];
    }
    export interface SchemaBootstrapResult {
        snapshotId: string;
        postgresTableCount: number;
        dynamoTableCount: number;
        report: SchemaBootstrapReport;
    }
    /**
     * `forceRebuild` is an internal reset. It is allowed only when the app declared a test mode.
     * Production, homologation, and an undeclared mode stop here, before any schema write.
     */
    export function forceRebuildBlockReason(mode: ProjectMode, declared: boolean): string | null;
    /** Equal snapshot keeps the incremental plan. Force selects a full rebuild of the registry modules. */
    export function selectModuleRebuildPlan<T extends {
        mode: ModuleRebuildMode;
        rebuild: string[];
        untouched: string[];
        removed: string[];
    }>(input: {
        forceRebuild: boolean;
        incremental: T;
        registryModuleIds: string[];
    }): T;
    /** Unprefixed physical name ⇒ platform/shared table (mdm_*, monitor_*, _schema_migrations). */
    export function isPlatformOwnedTable(definition: Pick<ResolvedTableDefinition, 'tableName' | 'logicalTableName'>): boolean;
    /**
     * Seeds follow the owning project's mode. Platform tables follow the server's hosted project
     * (`env.projectId`), not APP_ENV — that is a different vocabulary.
     */
    export function shouldApplySeedRows(input: {
        tableName: string;
        logicalTableName: string;
        projectMode: ProjectMode;
        serverMode: ProjectMode;
    }): {
        apply: boolean;
        mode: ProjectMode;
        reason: string;
    };
    export function buildCreateTableSql(definition: ResolvedTableDefinition): string;
    /**
     * Drop indexes that collide with the implicit Postgres PRIMARY KEY index (`<table>_pkey`)
     * or that repeat the same columns. Generated client defs have emitted both; discarding
     * is decide-log-continue so publish does not die with 42P07.
     */
    export function sanitizeDefinitionIndexes<T extends {
        tableName: string;
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        logicalTableName?: string;
    }>(definition: T): T;
    export function buildCreateIndexSql(definition: ResolvedTableDefinition): string[];
    export function rebuiltSummary(env: AppEnv, definitions: ResolvedTableDefinition[], rebuildModules: string[]): SchemaBootstrapReport['rebuilt'];
    export function bootstrapSchema(env: AppEnv, input?: {
        ensureDynamo?: boolean;
        recordSnapshotLog?: boolean;
        forceRebuild?: boolean;
    }): Promise<SchemaBootstrapResult>;
}
declare module "_102034_/l1/scripts/setupServer" {
    export function setupServer(): Promise<void>;
}
declare module "_102034_/l1/scripts/dbInit" {
    export function dbInit(inputEnv?: string): Promise<void>;
}
declare module "_102034_/l1/scripts/ensureDynamoTable" {
    export function ensureDynamoTable(): Promise<void>;
}
declare module "_102034_/l1/scripts/migrate" {
    export function runMigrations(): Promise<void>;
}
declare module "_102034_/l1/scripts/resetLocalDb" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import { hasDeclaredProjectMode, readProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import { bootstrapSchema, type SchemaBootstrapResult } from "_102034_/l1/server/layer_1_external/persistence/schemaBootstrap";
    export interface ResetLocalDbOptions {
        env?: AppEnv;
        /** Process values under test. Defaults to `process.env` when omitted. */
        databaseUrlTest?: string;
        databaseUrl?: string;
        collabProjectId?: string;
        projectIdEnv?: string;
        bootstrap?: typeof bootstrapSchema;
        initializeOrganization?: () => Promise<void>;
        readMode?: typeof readProjectMode;
        hasDeclared?: typeof hasDeclaredProjectMode;
    }
    /** Guards run before bootstrap. Invalid targets never reach DDL. */
    export function assertResetTarget(input: {
        env: AppEnv;
        databaseUrlTest: string | undefined;
        databaseUrl: string | undefined;
        collabProjectId: string | undefined;
        projectIdEnv: string | undefined;
        mode: ReturnType<typeof readProjectMode>;
        declared: boolean;
    }): {
        database: string;
    };
    export const RESET_LOCAL_DB_MARK = "##resetLocalDb ";
    /** Uma linha para o preparador. Módulos vêm do relatório; tabelas, do que o bootstrap declarou semear. */
    export function resetLocalDbSummary(report: SchemaBootstrapResult['report'], database: string, seededTables: string[]): string;
    export function resetLocalDb(options?: ResetLocalDbOptions): Promise<SchemaBootstrapResult>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/restoreFromDynamo" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export class RegistryRestoreFromDynamoUsecase {
        private readonly env;
        constructor(env?: AppEnv);
        restoreTable(repositoryNameOrTableName: string): Promise<number>;
    }
}
declare module "_102034_/l1/scripts/restoreFromDynamo" { }
declare module "_102034_/l1/scripts/runWriteBehindWorker" { }
declare module "_102034_/l1/scripts/seedLocalTest" {
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import { type LocalTestSeedResult } from "_102034_/l1/mdm/layer_3_usecases/localTestSeed";
    export interface LocalTestSeedEnvironment {
        declared: boolean;
        mode: ProjectMode;
        runtimeMode: string;
        databaseUrlTest?: string;
        databaseUrl?: string;
    }
    /** Refuse before any write. Uses only the declared mode and DATABASE_URL_TEST. */
    export function assertLocalSeedEnvironment(input: LocalTestSeedEnvironment): {
        database: string;
    };
    export function runLocalTestSeed(): Promise<LocalTestSeedResult>;
    /** Repeatable `--member-role <moduleId>.<Tipo>`. */
    export function readMemberRoles(argv: readonly string[]): string[];
}
declare module "_102034_/l1/server/persistence" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/server/layer_1_external/auth/authorityOverride" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    export interface AuthorityOverride {
        /** The real user this override belongs to (`claims.sub`). */
        userId: string;
        /** The authorities to act with, `<moduleId>:<actorId>`. Empty clears the override. */
        authorities: string[];
        setAt: string;
    }
    /** The refusal reason, or '' when the mode allows overriding. */
    export function refuseOverride(mode: ProjectMode): string;
    export function readAuthorityOverride(ctx: RequestContext, userId: string): Promise<AuthorityOverride | null>;
    /**
     * What goes into `mdm_kv.value`. Never null: the column is JSONB NOT NULL, so clearing writes the same
     * record with an empty list (which `readAuthorityOverride` already reads as "no override").
     */
    export function storedValue(override: AuthorityOverride): Record<string, unknown>;
    /**
     * Set (or clear, with an empty list) the override of ONE user. The mode is checked here as well as at the
     * route: two defences, because this is the one place that can make a user look like someone else.
     */
    export function writeAuthorityOverride(ctx: RequestContext, mode: ProjectMode, userId: string, authorities: string[]): Promise<AuthorityOverride | null>;
    /**
     * The authorities a request acts with: the override when one is in force, the real claims otherwise.
     *
     * Returns BOTH, always: the audit records the real identity and what was in force, so an action taken in
     * presentation mode is never indistinguishable from the real user's own.
     */
    export function effectiveAuthorities(real: readonly string[], override: AuthorityOverride | null): {
        authorities: string[];
        overridden: boolean;
        real: string[];
    };
}
declare module "_102034_/l1/server/layer_1_external/candidate/candidateStore" {
    interface FileInput {
        path: string;
        sha256: string;
        contentBase64: string;
    }
    interface FileMeta {
        path: string;
        sha256: string;
        bytes: number;
    }
    interface CandidatePointer {
        changeId: string;
        revisionId: string;
        snapshotHash: string;
        revisionNumber: number;
        resultRevisionId?: string;
        resultSnapshotHash?: string;
        resultRevisionNumber?: number;
        resultId?: string;
        resultHash?: string;
        source?: {
            resultId: string;
            resultHash: string;
            revisionId: string;
            snapshotHash: string;
            revisionNumber: number;
        };
        supersedes?: {
            changeId: string;
            revisionId: string;
            revisionNumber: number;
        };
    }
    interface CandidateSnapshot extends CandidatePointer {
        baseId: string;
        requestRevision: number;
        request: string;
        files: FileMeta[];
    }
    interface CandidateFile {
        key: string;
        contentBase64: string;
        sha256: string;
    }
    export interface CandidateSnapshotInput {
        hash: string;
        baseId: string;
        requestRevision: number;
        request: string;
        files: FileInput[];
    }
    interface CandidateOutputSnapshotRecord {
        snapshotHash: string;
        baseId: string;
        requestRevision: number;
        request: string;
        files: FileMeta[];
    }
    interface CandidateSupersede {
        changeId: string;
        revisionId: string;
    }
    interface CandidateRequest {
        key: string;
        owner: string;
        expectedRevisionId: string | null;
        pointer: CandidatePointer;
        supersede?: CandidateSupersede;
    }
    export interface CandidateResultManifest {
        runId: string;
        taskId: string;
        status: "completed" | "failed" | "disputed";
        outputSnapshotHash: string;
        artifacts: Array<{
            path: string;
            sha256: string;
        }>;
        traceHash: string;
    }
    export interface CandidatePublishPermit {
        resultId: string;
        resultHash: string;
        inputRevisionId: string;
        inputSnapshotHash: string;
        inputRevisionNumber: number;
        outputSnapshotHash: string;
    }
    interface CandidateRequestWithPermit extends CandidateRequest {
        permit?: CandidatePublishPermit;
    }
    interface CandidateResultRecord {
        key: string;
        owner: string;
        expectedRevisionId: string;
        expectedSnapshotHash: string;
        expectedRevisionNumber: number;
        resultId: string;
        resultHash: string;
        manifest: CandidateResultManifest;
        outputSnapshot: CandidateOutputSnapshotRecord;
    }
    interface RecordWithKey {
        key: string;
        [field: string]: unknown;
    }
    export interface CandidatePersistence {
        get(key: string): Promise<RecordWithKey | undefined>;
        putFile(item: CandidateFile): Promise<boolean>;
        commit(input: {
            pointerKey: string;
            expectedRevisionId: string | null;
            permit: CandidatePublishPermit | null;
            pointer: CandidatePointer;
            snapshot: CandidateSnapshot & {
                key: string;
            };
            request: CandidateRequestWithPermit;
        }): Promise<boolean>;
        commitResult(input: {
            pointerKey: string;
            expectedRevisionId: string;
            expectedSnapshotHash: string;
            expectedRevisionNumber: number;
            result: CandidateResultRecord;
        }): Promise<boolean>;
    }
    export interface CandidateCaller {
        owner: string;
        orgId: string | null;
    }
    export interface CandidateReadInput {
        project: number;
        moduleName: string;
    }
    export interface CandidatePublishInput extends CandidateReadInput {
        expectedRevisionId: string | null;
        requestId: string;
        changeId: string;
        revisionId: string;
        snapshot: CandidateSnapshotInput;
        permit?: CandidatePublishPermit;
        supersede?: CandidateSupersede;
    }
    export interface CandidateMarkResultInput extends CandidateReadInput {
        expectedRevisionId: string;
        expectedSnapshotHash: string;
        expectedRevisionNumber: number;
        resultId: string;
        resultHash: string;
        result: CandidateResultManifest;
        outputSnapshot: CandidateSnapshotInput;
    }
    export interface CandidateResponse {
        statusCode: number;
        status: "committed" | "marked" | "conflict" | "read" | "error";
        pointer?: CandidatePointer | null;
        snapshot?: CandidateSnapshotInput;
        result?: {
            resultRevisionId: string;
            resultSnapshotHash: string;
            resultRevisionNumber: number;
            resultId: string;
            resultHash: string;
            manifest: CandidateResultManifest;
        };
        msg?: string;
    }
    export function sameCanonical(left: unknown, right: unknown): boolean;
    export function manifestHash(snapshot: Pick<CandidateSnapshot, "baseId" | "requestRevision" | "request" | "files">): string;
    export function candidateRead(caller: CandidateCaller, input: CandidateReadInput, hubOrgId: string | null, store: CandidatePersistence): Promise<CandidateResponse>;
    export function candidatePublish(caller: CandidateCaller, input: CandidatePublishInput, hubOrgId: string | null, store: CandidatePersistence): Promise<CandidateResponse>;
    export function candidateMarkResult(caller: CandidateCaller, input: CandidateMarkResultInput, hubOrgId: string | null, store: CandidatePersistence): Promise<CandidateResponse>;
    /** `/exec` action handler, kept independently testable from the legacy action registry. */
    export function handleCandidateRevision(caller: CandidateCaller, input: ({
        action: "candidateRead";
    } & CandidateReadInput) | ({
        action: "candidatePublish";
    } & CandidatePublishInput) | ({
        action: "candidateMarkResult";
    } & CandidateMarkResultInput), hubOrgId: string | null, store: CandidatePersistence): Promise<CandidateResponse>;
}
declare module "_102034_/l1/server/layer_1_external/candidate/candidatePostgres" {
    import type { Pool } from "pg";
    import type { CandidatePersistence } from "_102034_/l1/server/layer_1_external/candidate/candidateStore";
    type CommitInput = Parameters<CandidatePersistence["commit"]>[0];
    type CommitResultInput = Parameters<CandidatePersistence["commitResult"]>[0];
    type PointerRecord = {
        key: string;
        [field: string]: unknown;
    } | undefined;
    export function ensureCandidateSchema(pool: Pool): Promise<void>;
    /** Pointer condition of the legacy commit: absent key on first publish, else the eight-field update check. */
    export function commitAllowed(currentPointer: PointerRecord, input: CommitInput): boolean;
    /** Pointer condition of the legacy commitResult, including attribute_not_exists(resultId). */
    export function commitResultAllowed(currentPointer: PointerRecord, input: CommitResultInput): boolean;
    export class PostgresCandidatePersistence implements CandidatePersistence {
        private readonly pool;
        constructor(pool: Pool);
        get(key: string): Promise<{
            key: string;
            [field: string]: unknown;
        } | undefined>;
        putFile(item: {
            key: string;
            contentBase64: string;
            sha256: string;
        }): Promise<boolean>;
        commit(input: CommitInput): Promise<boolean>;
        commitResult(input: CommitResultInput): Promise<boolean>;
    }
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeCandidateProxy" {
    export const CANDIDATE_BODY_LIMIT = 1250000;
    export const CANDIDATE_ACTIONS: Set<string>;
    export interface CandidateProxyResult {
        statusCode: number;
        body: unknown;
        contentType: string;
    }
    /** `local` only when CANDIDATE_HUB=local. Anything else forwards. */
    export function candidateHubMode(env?: Record<string, string | undefined>): 'local' | 'forward';
    /** Forward origin. Requires a non-empty CANDIDATE_ORIGIN. HTTPS, or HTTP on loopback only. No fallback host. */
    export function candidateOrigin(env?: Record<string, string | undefined>): string;
    export function candidateActionAllowed(body: unknown): body is {
        action: 'candidateRead' | 'candidatePublish' | 'candidateMarkResult';
    };
    export type CandidateIdentity = {
        kind: 'jwt';
    } | {
        kind: 'service';
        owner: string;
        orgId: string | null;
    } | {
        kind: 'none';
    };
    /** Hub classification. A JWT email wins. Otherwise an exact bearer match against a non-empty COLLAB_SERVICE_TOKEN plus a non-empty X-User-Id. */
    export function candidateIdentity(input: {
        email?: string | null;
        authorization?: string | null;
        userId?: string | null;
        orgId?: string | null;
        serviceToken?: string | null;
    }): CandidateIdentity;
    /** Project file wins. Otherwise CANDIDATE_HUB_ORG_ID. Blank is null. */
    export function candidateHubOrgId(projectFileOrgId: string | null | undefined, env?: Record<string, string | undefined>): string | null;
    /**
     * Local-hub caller. JWT and service keep their identity.
     * `none` becomes the lima desenv only when MSG_PROXY_TOKEN and MSG_PROXY_USER_ID are non-empty; otherwise null (401).
     * The token is never returned.
     */
    export function candidateLocalCaller(identity: CandidateIdentity, session: {
        email?: string | null;
        orgId?: string | null;
    }, env?: Record<string, string | undefined>): {
        owner: string;
        orgId: string | null;
    } | null;
    /** Headers for the forward hop. Built from the verified JWT or from MSG_PROXY_*, never from the inbound Authorization. */
    export function candidateForwardHeaders(verifiedAccessToken: string, env?: Record<string, string | undefined>): Record<string, string> | null;
    export function proxyCandidateRequest(body: unknown, verifiedAccessToken: string, fetchImpl?: typeof fetch, forwardEnv?: Record<string, string | undefined>): Promise<CandidateProxyResult>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeCompiledStatic" {
    export interface CompiledStaticResult {
        content: Buffer;
        eTag: string;
        contentType: string;
    }
    /**
     * A fonte dos módulos l2 do app (`/_<id>_/l2/...`), lidos de obj/compiled.zip.
     * O service worker guarda os mesmos bytes. Um módulo, uma URL, uma fonte.
     *
     * Contrato: toda resposta sai com ETag (sha1 do entry no zip, sufixo `c`) e
     * Cache-Control: no-cache. Ausência de ETag num `.js` de l2 é defeito, não variação.
     * Null quando o path não é de módulo / o projeto ou a entry não existem — 404, nunca dist.
     */
    export function getCompiledStaticFile(rawUrlPath: string): CompiledStaticResult | null;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeDraft" {
    export interface DraftSlug {
        slug: string;
        branch: string;
    }
    export interface RequestDraft {
        slug: string;
        branch: string;
        sourceRoot: string;
    }
    export type DraftGit = (args: string[], cwd: string) => Promise<string>;
    /** First 16 hex of sha256(email, lowercase). Same person, same code. */
    export function personCodeForEmail(email: string): string;
    export function draftSlugForUser(email: string): DraftSlug;
    export function parseDraftSlug(cookieValue: string | undefined): DraftSlug | null;
    export function draftOwnerPath(base: string, slug: string): string;
    export function writeDraftOwner(base: string, slug: string, email: string): Promise<void>;
    export function readDraftOwner(base: string, slug: string): Promise<string | null>;
    export function draftSourceRoot(base: string, slug: string, projectId: number): string;
    export function ensureDraftWorktree(opts: {
        base: string;
        projectId: number;
        slug: string;
        branch: string;
        git?: DraftGit;
    }): Promise<string>;
    export interface DraftRequestHeaders {
        cookie?: string | string[] | undefined;
        'x-collab-draft'?: string | string[] | undefined;
    }
    /**
     * Raw draft mark for this call. A non-empty `x-collab-draft` wins;
     * an empty or absent header falls through to the `collab-draft` cookie.
     * The caller validates with `parseDraftSlug`: an invalid header is null and does not use the cookie.
     */
    export function requestDraftValue(headers: DraftRequestHeaders | undefined): string | undefined;
    /**
     * Draft named by this call (`x-collab-draft`, else the `collab-draft` cookie), with its worktree ready.
     * Missing or invalid slug is null — the caller keeps today's paths.
     */
    export function resolveRequestDraft(headers: DraftRequestHeaders | undefined, base: string, projectId: number): Promise<RequestDraft | null>;
    /**
     * Draft for a source write. A valid mark wins. Missing or invalid marks write to
     * `team-<projectId>`, creating that worktree when it does not exist.
     */
    export function resolveWriteDraft(headers: DraftRequestHeaders | undefined, base: string, projectId: number): Promise<RequestDraft>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeDevProcess" {
    export class AncestorDenoConfigError extends Error {
    }
    export class DraftDatabaseError extends Error {
    }
    export class DraftWorktreeMissingError extends Error {
    }
    export class DenoMissingError extends Error {
    }
    export function draftDatabaseName(slug: string, projectId: number): string;
    /** Parent test URL with only the database name swapped for this draft. Invalid URL throws. */
    export function draftDatabaseUrl(testUrl: string, slug: string, projectId: number): string;
    export function findAncestorDenoConfig(draftDir: string, exists?: (path: string) => boolean): string | undefined;
    export interface DevProcessInfo {
        port: number;
        pid: number;
        startedAt: number;
        lastRequestAt: number;
        /** Draft database name. Present on records written when the process starts. */
        database?: string;
        /** Per-process secret. Shared secret file only — never written to `dev.json`. */
        identitySecret?: string;
        /** `realpath` of the parent release this child was spawned from. */
        codeId?: string;
    }
    export interface DevSpawnOptions {
        cwd: string;
        env: Record<string, string>;
        logPath: string;
    }
    export type DevSpawn = (command: string, args: string[], options: DevSpawnOptions) => {
        pid: number;
    };
    export interface EnsureDevProcessOpts {
        base: string;
        slug: string;
        clientProjectId: number;
        spawn?: DevSpawn;
        now?: () => number;
        writeConfig?: (input: {
            base: string;
            slug: string;
            clientProjectId: number;
        }) => void;
    }
    export function memoryModeAllowEnv(): string[];
    export function buildDenoArgs(base: string, slug: string, port: number, databaseUrl: string): string[];
    export function isDevPidAlive(pid: number): boolean;
    /** Same rule as scripts/runtime/projectPorts.mjs releaseAliasOf. */
    export function releaseAliasOf(projectId: number | string): string;
    export function linkSharedProjects(base: string, slug: string, clientProjectId: number): void;
    /** Tests only: a live record the parent "already knows", as if it had spawned it. */
    export function setDevIdentitySecretForTests(base: string, slug: string, secret: string): void;
    export function ensureDevProcess(opts: EnsureDevProcessOpts): DevProcessInfo;
    /** Stops the draft dev process. `dev.json` is removed, so the database name is not read from it. */
    export function stopDevProcess(base: string, slug: string): void;
    export function restartDevProcess(opts: EnsureDevProcessOpts): Promise<DevProcessInfo>;
    export function reapIdle(opts: {
        base: string;
        now: number;
    }): void;
    export interface WaitForDevReadyOpts {
        timeoutMs?: number;
        stepMs?: number;
        fetchImpl?: typeof fetch;
        sleep?: (ms: number) => Promise<void>;
    }
    /**
     * Polls `GET /health` on the dev port until a 2xx or the deadline.
     * A network error retries. Never throws.
     */
    export function waitForDevReady(port: number, opts?: WaitForDevReadyOpts): Promise<boolean>;
    /** Rewrites `lastRequestAt`. No-op when `dev.json` is absent. `restart`/`ensure` already stamp it. */
    export function touchDevProcess(base: string, slug: string, now: number): void;
    /** One idle sweep per base. The first draft save in this worker arms it. */
    export function ensureDevReaper(base: string): void;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeGitCommit" {
    /**
     * Local tobe folders. Stay on the draft disk and never enter a commit,
     * even when the project `.gitignore` does not list them.
     * Same strings as the tobe entries of BOOKKEEPING_IGNORES in scripts/publishGit.mjs.
     */
    export const TOBE_LOCAL_GITIGNORES: string[];
    export interface GitCommitAuthor {
        name: string;
        email: string;
    }
    export interface GitCommitOutcome {
        /** committed: HEAD moved. nothing: the write produced no diff (same bytes). */
        status: 'committed' | 'nothing' | 'disabled' | 'not-a-repo' | 'failed';
        /** Commit sha, when one was created. */
        ref?: string;
        msg?: string;
    }
    /**
     * CBE_COMMIT_ON_SAVE=always|never overrides; default is production-only — same
     * rule as cbeRebuildOnSave, and for the same reason: a dev checkout must not
     * grow a commit every time someone saves a file from a local studio.
     */
    export function isCommitOnSaveEnabled(): boolean;
    /** Identity for the commit, derived from the caller's collab-auth session. */
    export function authorFromSession(email: string | undefined): GitCommitAuthor;
    /** First line of the save's comment, or a description of what was written. */
    export function commitMessage(comments: string | undefined, fileCount: number): string;
    /**
     * Commits `shortPaths` (relative to the project root, exactly as the driver
     * addresses them) on the current branch.
     *
     * `git add` comes first because `git commit -- <path>` alone cannot pick up a
     * file that is not yet tracked — a brand new file created by the studio. The
     * pathspecs are prefixed with `:(literal)` so a name carrying a glob character
     * is matched as itself and can never widen the commit beyond what was saved.
     */
    export function commitSavedSources(projectId: number, shortPaths: string[], options?: {
        comments?: string;
        author?: GitCommitAuthor;
        sourceRoot?: string;
    }): Promise<GitCommitOutcome>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeSources" {
    import type { CbePrjSourcesFile, CbeSourceFile } from "_102034_/l1/server/layer_1_external/cbe/cbeTypes";
    /**
     * Absolute path of a source file, or null when the shortPath is not acceptable.
     *
     * The shortPath comes from the BROWSER and becomes a write target on the VM's
     * disk, so this is a security boundary, not a formality: the resolved path must
     * stay inside <base>/mls-<id>/. Rejects traversal ('..'), absolute paths,
     * backslashes and NUL bytes.
     *
     * SHORT_PATH_PATTERN is shape, not a level filter: it only requires that what
     * follows an `l<n>/` prefix is non-empty. 'l0/x.ts' and 'l8/x.ts' are accepted
     * and read as an ordinary folder named l0 / l8 inside the project — contained,
     * which is what matters here. What proves containment is the resolved-path
     * check below, not the pattern. The same rules apply when `sourceRoot`
     * replaces `<base>/mls-<id>` (a draft worktree; it must be absolute).
     */
    export function resolveSourcePath(projectId: number, shortPath: string, sourceRoot?: string): string | null;
    /** Reads the requested sources; a file that is not there comes back as null content. */
    export function readSources(projectId: number, shortPaths: string[], sourceRoot?: string): CbeSourceFile[];
    /**
     * Writes the given sources and removes the deleted ones. All-or-nothing is NOT
     * attempted (no transaction on a plain FS): a rejected path aborts the whole
     * call BEFORE any write, so a bad request never leaves a half-applied state.
     *
     * `paths` reports every shortPath actually touched (written and removed), which
     * is what cbeGitCommit commits — the caller never has to re-derive it.
     */
    export function writeSources(projectId: number, files: CbeSourceFile[], deletes: string[], options?: {
        sourceRoot?: string;
    }): {
        ok: boolean;
        msg?: string;
        paths: string[];
    };
    /**
     * The project's file index. Without sourceRoot, the compiled.zip list the login ships.
     * With sourceRoot, l1–l7 come from that draft worktree (`git ls-files`) and l0 from the production index, without jsContent.
     * Git failure logs and returns the production index.
     */
    export function listSources(projectId: number, sourceRoot?: string): CbePrjSourcesFile[];
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeGitPromote" {
    import { type GitCommitAuthor } from "_102034_/l1/server/layer_1_external/cbe/cbeGitCommit";
    export interface GitCapture {
        stdout: string;
        code: number;
        stderr?: string;
    }
    /** Args are an array (no shell). Resolves on every exit code, including 1. */
    export type PromoteGit = (args: string[], cwd: string) => Promise<GitCapture>;
    export type PromoteDraftResult = {
        status: 400;
        code: 'BAD_DRAFT';
    } | {
        status: 404;
        code: 'DRAFT_NOT_FOUND';
    } | {
        status: 409;
        code: 'MAIN_NOT_ON_MAIN';
    } | {
        status: 409;
        code: 'MAIN_DIRTY';
    } | {
        status: 'nothing_to_promote';
    } | {
        status: 409;
        code: 'DRAFT_CONFLICT';
        files: string[];
    } | {
        status: 'merged';
        ref: string;
    } | {
        status: 500;
        code: 'GIT_ERROR';
    };
    export type DiscardDraftResult = {
        status: 400;
        code: 'BAD_DRAFT';
    } | {
        status: 'discarded';
    } | {
        status: 500;
        code: 'GIT_ERROR';
    };
    export type RestoreDraftPathsResult = {
        status: 400;
        code: 'BAD_DRAFT' | 'BAD_REF' | 'BAD_PATH';
        msg: string;
    } | {
        status: 'unchanged';
        head: string;
    } | {
        status: 'restored';
        paths: string[];
        head: string;
        restartDev: boolean;
    } | {
        status: 500;
        code: 'GIT_ERROR';
        msg: string;
    };
    export interface ListedDraft {
        branch: string;
        ahead: number;
        behind: number;
        author: string;
        email: string;
        date: string;
        message: string;
        files: string[];
        /** Person email, `team`, or null when `owner.json` is missing. Never decoded from the slug. */
        owner: string | null;
    }
    export type ListDraftsResult = {
        status: 'listed';
        drafts: ListedDraft[];
    } | {
        status: 500;
        code: 'GIT_ERROR';
    };
    export interface DraftDiffFile {
        status: 'A' | 'M' | 'D' | 'R';
        path: string;
        /** Blob on the draft. Null when the draft deleted the file. */
        sha: string | null;
        /** Previous path. Present only on a rename. */
        from?: string;
    }
    export type DraftDiffResult = {
        status: 400;
        code: 'BAD_DRAFT';
    } | {
        status: 400;
        code: 'BAD_PATH';
    } | {
        status: 'diff';
        text: string;
    } | {
        status: 'files';
        head: string;
        main: string;
        files: DraftDiffFile[];
    } | {
        status: 500;
        code: 'GIT_ERROR';
    };
    export type SyncDraftResult = {
        status: 400;
        code: 'BAD_DRAFT';
    } | {
        status: 409;
        code: 'DRAFT_DIRTY';
    } | {
        status: 'up_to_date';
    } | {
        status: 'fast_forwarded';
        ref: string;
    } | {
        status: 'diverged';
        ahead: number;
        behind: number;
    } | {
        status: 'merged';
        ref: string;
    } | {
        status: 409;
        code: 'DRAFT_CONFLICT';
        files: string[];
    } | {
        status: 500;
        code: 'GIT_ERROR';
    };
    /**
     * Real git for these actions. A non-zero exit (merge conflict is 1) is a
     * result. index.lock is retried here so the domain still sees one answer.
     */
    export function captureGit(args: string[], cwd: string): Promise<GitCapture>;
    export function promoteDraft(opts: {
        base: string;
        projectId: number;
        slug: string;
        author: GitCommitAuthor;
        comment: string;
        git?: PromoteGit;
    }): Promise<PromoteDraftResult>;
    export function discardDraft(opts: {
        base: string;
        projectId: number;
        slug: string;
        git?: PromoteGit;
    }): Promise<DiscardDraftResult>;
    /**
     * Puts the named paths back to `ref` on the draft branch and commits that with the session author.
     * A path missing from `ref` is removed. Does not reset the branch or touch the database.
     */
    export function restoreDraftPaths(opts: {
        base: string;
        projectId: number;
        slug: string;
        ref: string;
        paths: string[];
        author: GitCommitAuthor;
        git?: PromoteGit;
    }): Promise<RestoreDraftPathsResult>;
    export function fastForwardDraft(opts: {
        base: string;
        projectId: number;
        slug: string;
        git?: PromoteGit;
    }): Promise<SyncDraftResult>;
    export function mergeMainIntoDraft(opts: {
        base: string;
        projectId: number;
        slug: string;
        author: GitCommitAuthor;
        git?: PromoteGit;
    }): Promise<SyncDraftResult>;
    export function listDrafts(opts: {
        base: string;
        projectId: number;
        git?: PromoteGit;
    }): Promise<ListDraftsResult>;
    export function draftDiff(opts: {
        base: string;
        projectId: number;
        slug: string;
        shortPath?: string;
        names?: boolean;
        git?: PromoteGit;
    }): Promise<DraftDiffResult>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeDesenv" {
    import type { FastifyReply, FastifyRequest } from 'fastify';
    import { ensureDraftWorktree, type DraftRequestHeaders } from "_102034_/l1/server/layer_1_external/cbe/cbeDraft";
    import { ensureDevProcess, stopDevProcess, waitForDevReady } from "_102034_/l1/server/layer_1_external/cbe/cbeDevProcess";
    import { fastForwardDraft } from "_102034_/l1/server/layer_1_external/cbe/cbeGitPromote";
    import { getProjectsBaseDir } from "_102034_/l1/server/layer_1_external/cbe/cbeCompiledLocal";
    export interface DesenvResult {
        status: number;
        location?: string;
        setCookie?: string;
        body?: {
            statusCode: number;
            msg: string;
        } | {
            statusCode: number;
            ok: true;
            slug: string;
            head?: string;
        };
    }
    /**
     * The workspace's single `type: "client"` project (fallback: `defaultProjectId`). Used by
     * startServer.ts for the boot config and for the draft proxy.
     */
    export function resolveClientProjectId(): string;
    /** Tests replace these calls so /desenv does not create a worktree, sync git, or spawn Deno. */
    export const desenvIo: {
        resolveClientProjectId: typeof resolveClientProjectId;
        getProjectsBaseDir: typeof getProjectsBaseDir;
        ensureDraftWorktree: typeof ensureDraftWorktree;
        fastForwardDraft: typeof fastForwardDraft;
        stopDevProcess: typeof stopDevProcess;
        ensureDevProcess: typeof ensureDevProcess;
        waitForDevReady: typeof waitForDevReady;
        isAllowed: (_request: FastifyRequest) => Promise<boolean>;
    };
    export function draftCookie(slug: string): string;
    export function clearDraftCookie(): string;
    /** A path on this host. `null` is not a safe redirect target. */
    export function draftReturnPath(to: string | undefined): string | null;
    interface PreparedDraft {
        port: number;
        head?: string;
    }
    /**
     * Worktree, fast-forward (stop the child only when the branch moved) and one dev process.
     * A second caller for the same slug waits on the promise already running.
     */
    export function prepareDraft(opts: {
        base: string;
        projectId: number;
        slug: string;
        branch: string;
        stages?: DraftStageMs;
    }): Promise<PreparedDraft>;
    /** Waits out a prepare already running for this slug. A prepare error is logged and does not fail the waiter. */
    export function awaitDraftPrepare(slug: string): Promise<void>;
    /**
     * Studio login (draft mark present: `x-collab-draft` header, else the `collab-draft` cookie, as `requestDraftValue` reads it) prepares that person's draft
     * without waiting. A later draftEnter reuses the same prepare. No cookie, no child.
     * A throw is one log line and never the login result.
     */
    export function warmPersonDraftOnLogin(headers: DraftRequestHeaders | undefined, email: string | undefined): void;
    interface DraftStageMs {
        worktree: number;
        fastForward: number;
        ensureDevProcess: number;
        waitForDevReady: number;
    }
    export function runDesenvEnter(input: {
        allowed: boolean;
        draft: string | undefined;
        to: string | undefined;
    }): Promise<DesenvResult>;
    export function runDraftEnter(input: {
        allowed: boolean;
        draft: string | undefined;
        project: unknown;
    }): Promise<DesenvResult>;
    export function runDesenvExit(input: {
        to: string | undefined;
    }): DesenvResult;
    export function handleDraftEnter(request: FastifyRequest, body: object, reply: FastifyReply): Promise<void>;
    export function handleDesenvEnter(request: FastifyRequest, reply: FastifyReply): Promise<void>;
    export function handleDesenvExit(request: FastifyRequest, reply: FastifyReply): Promise<void>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeDevProcessTwoWorkers" { }
declare module "_102034_/l1/server/layer_1_external/cbe/cbeGit" {
    import type { CbeHistoryEntry } from "_102034_/l1/server/layer_1_external/cbe/cbeTypes";
    /** True when the project folder is a git repository (a dev workspace or a dep
     * cloned outside the standard layout may not be). */
    export function isGitRepo(projectId: number, sourceRoot?: string): boolean;
    /**
     * Commits that touched the file, newest first. `--follow` crosses renames, so
     * the list does not stop at the file's current name.
     *
     * Returns [] for an unknown path, an untracked file or a non-repo — all of
     * which mean "no history", not "failed".
     */
    export function readHistory(projectId: number, shortPath: string, sourceRoot?: string): CbeHistoryEntry[];
    /**
     * The file's content at a commit, or null when the ref is not acceptable, the
     * commit is unknown, or the file did not exist there.
     */
    export function readHistoryContent(projectId: number, shortPath: string, ref: string, sourceRoot?: string): string | null;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeRelease" {
    /** release.json as addNewVersion writes it (scripts/runtime/releaseStamp.mjs). */
    export interface RunningRelease {
        id: string;
        client?: string;
        libs?: string;
        monaco?: string;
        versionRef?: string;
        modelCommit?: string | null;
        platformCommit?: string | null;
    }
    /**
     * Nearest release.json at or above `startDir`, or null when there is none — a dev
     * checkout has no release layout, and that is not an error.
     */
    export function findRelease(startDir: string): RunningRelease | null;
    /** The running release, resolved once. */
    export function getRunningRelease(): RunningRelease | null;
    /** Drops the memoized value so tests can resolve again. */
    export function resetRunningReleaseCache(): void;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeStaticFiles" {
    export interface CbeStaticFileResult {
        statusCode: number;
        content?: Buffer;
        eTag?: string;
        contentType?: string;
        msg?: string;
    }
    /** Shared with cbeLatestJson (latest.json lives beside the /libs/* cache). */
    export function getCbeStaticDir(): string;
    export function patchServiceWorkerForRuntime(content: Buffer, releaseId: string | null): Buffer;
    /** Logs the resolved locations once at startup so deploys are easy to debug. */
    export function logCbeStaticConfig(): void;
    /**
     * Serves a cbe static asset: disk cache -> remote origin (written back to
     * disk). Returns 304 when the client ETag still matches.
     */
    export function getCbeStaticFile(rawUrlPath: string, clientETag: string): Promise<CbeStaticFileResult>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeLatestJson" {
    /** Raw latest.json payload ('' when never fetched and no disk copy). */
    export function getLatestJson(): string;
    /**
     * Startup init, same shape as the central cbe: disk copy first (instant,
     * survives offline restarts), then the remote refresh. Fire-and-forget from
     * the server bootstrap — requests arriving before the fetch completes simply
     * get the disk version (or no window.latest on the very first boot).
     */
    export function initCbeLatestJson(): void;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeLocalAlias" {
    /**
     * `/local/_<id>_<resto>` is the SW cache key; the release module lives at
     * `/_<id>_/l2/<resto>` then `/_<id>_/l4/<resto>`. Query is ignored.
     */
    export function localAliasCandidates(rawUrl: string): string[];
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeProviderToken" {
    export const DEFAULT_APPCONFIG_FILE = "/data/etc/appconfig.json";
    export type ProviderSource = 'github' | 'gitlab';
    export interface ProviderTokenBody {
        source: ProviderSource;
        code: string;
        redirectUri: string;
    }
    export interface ProviderTokenRequest {
        headers: {
            host?: string | string[] | undefined;
        };
    }
    export interface ProviderTokenReply {
        code(status: number): {
            send(payload: unknown): void;
        };
    }
    type ProviderFetch = typeof fetch;
    export function handleProviderToken(request: ProviderTokenRequest, body: unknown, reply: ProviderTokenReply, session: {
        email?: string;
    }, fetchImpl?: ProviderFetch): Promise<void>;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeRebuildOnSave" {
    /**
     * The `current-<id>` symlink the running app uses as its cwd, or '' when there is none.
     *
     * addNewVersion always flips the global `current`, but an ALIAS only moves when
     * COLLAB_RELEASE_ALIAS names it — and pm2 starts this app with cwd on the alias
     * (pm2.apps.d/app<port>.config.js). Without passing it, a save compiled a new release,
     * moved `current`, reloaded pm2 — and the app came back on the OLD release, because its
     * alias never moved. Observed on the VM: current -> 20260918182437 while
     * current-102047 -> 20260918152151, with the build reporting exit=0.
     *
     * lstat, not existsSync: a dangling alias (its target pruned) must still be moved — that
     * is exactly the state that needs fixing, and existsSync follows the link and says no.
     */
    export function releaseAliasFor(clientId: string): string;
    /**
     * The one backgrounded job the build runs as. Everything between `{` and `}`
     * runs as ONE job; the outer `sh -c` invocation returns as soon as it has
     * started it, which is what lets the kernel reparent it to init before any pm2
     * reload can find it still hanging off this worker's process tree.
     *
     * The obj refresh comes BEFORE `pnpm build` so the release it assembles already
     * carries the new zip (and addNewVersion's assertFechoCompiledZips validates
     * that one). It is a separate `;` step: if it fails, the build still runs.
     */
    export function buildShellChain(options: {
        ownerToken: string;
        clientId: string;
        projects: number[];
        releaseAlias?: string;
    }): string;
    /**
     * Whether a build is running RIGHT NOW, for anyone asking "did my save land yet?".
     * Read from disk on every call on purpose: unlike the release stamp, this is exactly
     * the kind of state that changes under the process. The lock is created by the worker
     * that wins the race and removed by the build's own shell chain, so it covers builds
     * started by the other pm2 worker too.
     */
    export function isRebuildInProgress(): boolean;
    /**
     * Call after a successful setContents write, with the project it wrote to — its
     * obj is refreshed before the build (see the header). Debounced + safe across
     * the 2 pm2 cluster workers.
     */
    export function scheduleRebuildOnSave(project?: number): void;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/localTestSessionHttp" {
    import type { FastifyInstance } from 'fastify';
    import { type LocalTestConfig } from "_102034_/l1/server/layer_1_external/config/localTestConfig";
    /** Active bench on an allowed local host. Anything else is hidden (404). */
    export function localTestBenchOrNull(host: string): LocalTestConfig | null;
    /** Host-only cookie. No Domain attribute. Secure only when the request itself is HTTPS. */
    export function localTestSetCookie(name: string, value: string, maxAge: number, secure: boolean): string;
    export function expiredLocalTestCookie(projectId: string, secure: boolean): string;
    export function registerLocalTestSessionRoutes(app: FastifyInstance): void;
}
declare module "_102034_/l1/server/layer_1_external/cbe/cbeRoutes" {
    import type { FastifyInstance, FastifyRequest } from 'fastify';
    import { isRebuildInProgress, scheduleRebuildOnSave } from "_102034_/l1/server/layer_1_external/cbe/cbeRebuildOnSave";
    import { fastForwardDraft, mergeMainIntoDraft } from "_102034_/l1/server/layer_1_external/cbe/cbeGitPromote";
    import { ensureDevProcess, ensureDevReaper, restartDevProcess, stopDevProcess } from "_102034_/l1/server/layer_1_external/cbe/cbeDevProcess";
    export const CBE_MODULE_VERSION = "1.8.7";
    /** Cookies of a completed logout: expire cauth/crefresh/loginMsg, loginUser=anonymous. */
    export function logoutCookies(): string[];
    export function revokeCrefresh(refreshToken: string | undefined, fetchImpl?: typeof fetch): Promise<void>;
    /**
     * The person behind a request: the JWT email wins; otherwise the signed local-test persona
     * (the lima bench, where there is no JWT). A disabled bench or a bad cookie gives no person.
     * Tests replace this so a save can name a person without a signed JWT.
     */
    export const sessionHooks: {
        emailOf: (request: FastifyRequest) => Promise<string | undefined>;
    };
    /** Route tests replace these so a draft save does not spawn Deno. */
    export const draftDevHooks: {
        restartDevProcess: typeof restartDevProcess;
        ensureDevReaper: typeof ensureDevReaper;
        stopDevProcess: typeof stopDevProcess;
        ensureDevProcess: typeof ensureDevProcess;
    };
    /** Route tests replace these so a promote or draftSync does not touch git. */
    export const draftSyncHooks: {
        fastForwardDraft: typeof fastForwardDraft;
        mergeMainIntoDraft: typeof mergeMainIntoDraft;
    };
    /** Route tests replace these so a promote does not start a release build. */
    export const promoteRouteHooks: {
        scheduleRebuildOnSave: typeof scheduleRebuildOnSave;
        isRebuildInProgress: typeof isRebuildInProgress;
        promoteStateDir: () => string;
        now: () => number;
    };
    interface DraftDbDrop {
        dropDatabase(adminUrl: string, name: string): Promise<void>;
    }
    /** Route tests replace `dropDatabase` so a draft reset does not open Postgres. */
    export const draftDbHooks: DraftDbDrop;
    export function registerCbeRoutes(app: FastifyInstance): void;
}
declare module "_102034_/l1/server/layer_1_external/config/messagesIntegration" {
    export interface MessagesIntegration {
        readonly projectId: string;
        readonly organizationId: string;
        readonly token: string;
    }
    /**
     * Server-side credential for one application. The caller passes the project id
     * already resolved on the server. Each call goes through readProjectFile, which
     * refreshes on mtime; this function keeps no token of its own.
     */
    export function readMessagesIntegration(projectId: string): MessagesIntegration;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/msgProxy" {
    import type { FastifyInstance } from 'fastify';
    import { type LocalTestConfigState } from "_102034_/l1/server/layer_1_external/config/localTestConfig";
    export type ServiceIdentityHeaders = {
        inject: null;
    } | {
        inject: {
            authorization: string;
            'x-user-id': string;
            'x-org-id'?: string;
        };
    } | {
        error: string;
    };
    export function serviceIdentityHeaders(env: NodeJS.ProcessEnv): ServiceIdentityHeaders;
    export function msgProxyStartupLog(target: string, identity: ServiceIdentityHeaders): string;
    /** Tests substitute the manifest reader. Production uses the process cache. */
    export function setLocalTestProxyConfigLoaderForTests(loader?: () => LocalTestConfigState): void;
    export function msgProxyTarget(env?: NodeJS.ProcessEnv): string;
    export function registerMsgProxy(app: FastifyInstance): void;
}
declare module "_102036_/l2/shared/interfacesFrontend" {
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501,
        SERVICE_UNAVAILABLE = 503
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
        senderDeviceId?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        messages?: Message[];
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export type AttachmentUploadFailureStage = 'storage_put';
    export type AttachmentUploadFailureKind = 'network' | 'http';
    export interface RequestReportAttachmentUploadFailure extends RequestBase {
        action: "reportAttachmentUploadFailure";
        userId: string;
        threadId: string;
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        stage: AttachmentUploadFailureStage;
        failure: AttachmentUploadFailureKind;
        httpStatus?: number;
        pageOrigin: string;
    }
    export interface ResponseReportAttachmentUploadFailure extends ResponseBase {
        logged: boolean;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        pin?: boolean;
        favorite?: boolean;
        readConfirmation?: "request" | "confirm" | "cancel" | "requestExecution" | "reviewExecution";
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        thread?: Thread;
        messages?: Message[];
        user?: User;
        users?: User[];
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
        moduleAdvance?: {
            commandId: string;
            outcome: 'applied' | 'unchanged';
        };
        moduleMessage?: {
            state: 'sent' | 'pending';
            threadId: string;
            orderAt?: string;
        };
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        subscription?: PushSubscriptionData;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export type HumanDmErrorCode = "not_found" | "self" | "schema" | "not_human" | "legacy_ambiguous" | "archived" | "pair_corrupt" | "storage_unavailable" | "contention_exhausted" | "unknown_outcome";
    export interface RequestEnsureHumanDm extends RequestBase {
        action: "ensureHumanDm";
        userId: string;
        recipientUserId: string;
        group: ThreadGroup;
    }
    export interface ResponseEnsureHumanDm extends ResponseBase {
        outcome?: "created" | "existing";
        thread?: Thread;
        code?: HumanDmErrorCode;
    }
    export interface RequestEnsureModuleThread extends RequestBase {
        action: 'ensureModuleThread';
        userId: string;
        email: string;
        project: string;
        module: string;
        name: string;
    }
    export interface ResponseEnsureModuleThread {
        userId: string;
        thread: Thread;
        created: boolean;
    }
    export interface RequestOpenModuleTask extends RequestBase {
        action: 'openModuleTask';
        ref: TaskModuleRef;
        plan: ModulePlan;
        startStep: string;
        origin: ModuleOrigin;
        owner: string;
        actorNow: string | null;
        title: string;
        room: ModuleRoomChoice;
        message?: {
            content: string;
        };
        executor: TaskModuleExecutor;
    }
    export interface ResponseOpenModuleTask {
        task: TaskData;
        room: Thread;
        created: boolean;
        moduleMessage?: {
            state: 'sent' | 'pending';
            threadId: string;
            orderAt?: string;
        };
    }
    export interface RequestGetModuleTask extends RequestBase {
        action: 'getModuleTask';
        ref: Omit<TaskModuleRef, 'workflowVersion'>;
    }
    export interface ResponseGetModuleTask {
        task: TaskData;
        room: Thread | null;
        roomIssue?: 'not_linked' | 'missing';
        messageId?: string;
    }
    export type ModuleActionError = {
        code: 'busy';
    } | {
        code: 'module_task_incomplete';
        taskId: string;
    } | {
        code: 'ambiguous';
    } | {
        code: 'link_conflict';
    } | {
        code: 'identity_too_large';
    };
    export interface RequestLinkModulePerson extends RequestBase {
        action: 'linkModulePerson';
        userId: string;
        mdmId: string;
        loginEmail: string;
    }
    export interface ResponseLinkModulePerson {
        cmUserId: string;
        outcome: 'linked' | 'existing';
    }
    export interface RequestResolveModulePeople extends RequestBase {
        action: 'resolveModulePeople';
        userId: string;
        mdmIds?: string[];
        cmUserIds?: string[];
    }
    export interface ResponseResolveModulePeople {
        people: {
            mdmId?: string;
            cmUserId?: string;
            state: 'linked' | 'unlinked' | 'removed' | 'inconsistent';
        }[];
    }
    export interface RequestListModuleTasks extends RequestBase {
        action: 'listModuleTasks';
        project: string;
        module: string;
        processId?: string;
        cursor?: string;
        pageSize: number;
    }
    export interface ResponseListModuleTasks {
        items: {
            ref: TaskModuleRef;
            taskId: string;
            revision: number;
            status: TaskStatus;
        }[];
        cursor?: string;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export type UserMemorySectionName = 'identity_hints' | 'communication_style' | 'work_rhythm' | 'decision_style' | 'authority_hints' | 'learned_preferences';
    export interface UserMemorySourceInput {
        kind: 'message' | 'memory_section' | 'confirmation';
        ref: string;
    }
    export interface RequestGetUserMemory extends RequestBase {
        action: 'getUserMemory';
        userId: string;
        threadId: string;
        openSourceMessageId?: string;
    }
    export interface RequestProposeUserMemory extends RequestBase {
        action: 'proposeUserMemory';
        userId: string;
        threadId: string;
        expectedVersion: number;
        idempotencyKey: string;
        updates: Partial<Record<UserMemorySectionName, string>>;
        sources?: Partial<Record<UserMemorySectionName, UserMemorySourceInput[]>>;
        reason: string;
    }
    export interface RequestDecideUserMemoryProposal extends RequestBase {
        action: 'decideUserMemoryProposal';
        userId: string;
        threadId: string;
        proposalId: string;
        decision: 'confirm' | 'reject';
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface RequestCorrectUserMemory extends RequestBase {
        action: 'correctUserMemory';
        userId: string;
        threadId: string;
        section: UserMemorySectionName;
        content: string;
        sources?: UserMemorySourceInput[];
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface RequestInvalidateUserMemory extends RequestBase {
        action: 'invalidateUserMemory';
        userId: string;
        threadId: string;
        section: UserMemorySectionName | 'all';
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface ResponseUserMemory extends ResponseBase {
        memory: unknown;
    }
    export interface RequestGetE01Execution extends RequestBase {
        action: 'getE01Execution';
        userId: string;
        threadId: string;
        executionId?: string;
        sourceMessageId?: string;
        openSourceMessageId?: string;
    }
    export interface RequestCancelE01Execution extends RequestBase {
        action: 'cancelE01Execution';
        userId: string;
        threadId: string;
        executionId: string;
    }
    export interface ResponseE01Execution extends ResponseBase {
        execution: unknown;
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
        initialLoad?: boolean;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
        hasOlder?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface RequestHeartbeat extends RequestBase {
        action: "heartbeat";
        userId: string;
        deviceId: string;
    }
    export interface ResponseHeartbeat extends ResponseBase {
        pending: string[];
        online: {
            users: number;
            devices: number;
        };
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
            isAgent?: true;
            isHuman?: true;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        responseMessage?: Message;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId?: string;
        connectorId?: string;
        agentId?: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
        externalCaseId?: string;
        channel?: string;
        customerIdentity?: string;
        priority?: "low" | "normal" | "high" | "urgent";
        metadata?: Record<string, any>;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        threads: string[];
        notifications?: UserNotifications[];
        favorites?: string[];
        readConfirmations?: UserReadConfirmations;
        kind?: UserKind;
        metadata?: UserMetadata;
        sub?: string;
        email?: string;
    }
    export interface UserReadConfirmations {
        pending?: string[];
        requested?: string[];
    }
    export interface PushSubscriptionData {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        expirationTime?: number | null;
    }
    export interface UserNotifications {
        deviceId: string;
        subscription: PushSubscriptionData;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent" | "module";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS" | "MOMENTS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        agentDm?: AgentDirectMessageBinding;
        personalMemoryProtection?: {
            kind: 'e01-personal-dm';
            ownerUserId: string;
            agentUserId: string;
            protectedAt: string;
        };
        pinnedMessages?: PinnedMessage[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface MomentsPublisher {
        userId: string;
        name: string;
        avatar_url: string;
    }
    export interface MomentsFeedItem {
        threadId: string;
        publisher: MomentsPublisher;
        message: Message;
        seen: boolean;
        reach?: number;
    }
    export interface MomentsSeenItem {
        threadId: string;
        messageId: string;
    }
    export interface MomentsSubscriptionItem {
        threadId: string;
        publisher: MomentsPublisher;
        muted: boolean;
    }
    export interface MomentsStatsPost {
        messageId: string;
        createAt: string;
        preview: string;
        reach: number;
        reactions: number;
    }
    export interface RequestEnsureMomentsRoom extends RequestBase {
        action: "ensureMomentsRoom";
        userId: string;
    }
    export type MomentsAudience = 'all' | 'selected';
    export interface ResponseEnsureMomentsRoom extends ResponseBase {
        thread: Thread;
        audience: MomentsAudience;
    }
    export interface RequestSetMomentsAudience extends RequestBase {
        action: "setMomentsAudience";
        userId: string;
        audience: MomentsAudience;
    }
    export interface ResponseSetMomentsAudience extends ResponseBase {
        thread: Thread;
        audience: MomentsAudience;
    }
    export interface RequestSetMomentsReaders extends RequestBase {
        action: "setMomentsReaders";
        userId: string;
        add?: string[];
        remove?: string[];
    }
    export interface ResponseSetMomentsReaders extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetMomentsFeed extends RequestBase {
        action: "getMomentsFeed";
        userId: string;
        limit?: number;
        before?: string;
    }
    export interface ResponseGetMomentsFeed extends ResponseBase {
        items: MomentsFeedItem[];
    }
    export interface RequestMarkMomentSeen extends RequestBase {
        action: "markMomentSeen";
        userId: string;
        items: MomentsSeenItem[];
    }
    export interface ResponseMarkMomentSeen extends ResponseBase {
        ok: true;
    }
    export interface RequestSetMomentsMute extends RequestBase {
        action: "setMomentsMute";
        userId: string;
        threadId: string;
        muted: boolean;
    }
    export interface ResponseSetMomentsMute extends ResponseBase {
        ok: true;
    }
    export interface RequestGetMomentsSubscriptions extends RequestBase {
        action: "getMomentsSubscriptions";
        userId: string;
    }
    export interface ResponseGetMomentsSubscriptions extends ResponseBase {
        items: MomentsSubscriptionItem[];
    }
    export interface RequestGetMomentsStats extends RequestBase {
        action: "getMomentsStats";
        userId: string;
        limit?: number;
    }
    export interface ResponseGetMomentsStats extends ResponseBase {
        audience: number;
        posts: MomentsStatsPost[];
    }
    export interface PinnedMessage {
        messageId: string;
        pinnedBy: string;
        pinnedAt: string;
        excerpt?: string;
    }
    export interface AgentDirectMessageBinding {
        enabled: boolean;
        agentId: string;
        agentUserId: string;
        agentType: "pma" | "agent";
        status: "active" | "paused" | "disabled";
        configRef?: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: "ws" | "http";
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface OpenClawDeviceState {
        deviceId: string;
        publicKey: string;
        privateKeyPem: string;
        publicKeyPem?: string;
        deviceToken?: string;
        authorizedAt?: string;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        readConfirmations?: MessageReadConfirmation[];
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface MessageReadConfirmation {
        kind?: "read" | "execution";
        requestedBy: string;
        requestedAt: string;
        targetUserIds: string[];
        confirmedBy?: Record<string, string>;
        canceledAt?: string;
        canceledBy?: string;
        followupHistory?: MessageFollowupHistoryEntry[];
    }
    export interface MessageFollowupHistoryEntry {
        userId: string;
        reaction: string;
        at: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export type TaskModuleRef = {
        project: string;
        module: string;
        entity: string;
        recordId: string;
        processId: string;
        workflowVersion: string | null;
    };
    export type ModuleOrigin = {
        kind: 'screen' | 'channel' | 'schedule' | 'event';
        by?: string;
        config?: string;
    };
    export type ModuleRoomChoice = {
        mode: 'exclusive' | 'person' | 'group';
        groupKey?: string;
        members?: string[];
    };
    export type ModuleStepKind = 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
    export type ModuleOwnerKind = 'person' | 'module' | 'agent' | 'clock';
    export type ModuleWake = {
        everyMinutes: number;
        until?: string;
        routine: string;
        nextAt: string;
        seq: number;
    };
    export type ModuleWakeEvent = {
        eventId: string;
        scheduledAt: string;
        attempt: number;
        ref: TaskModuleRef;
        taskId: string;
        stepKey: string;
        pass: number;
        seq: number;
        revision: number;
        routine: string;
    };
    export type ModuleWakeReceipt = {
        eventId: string;
        outcome: 'accepted' | 'stale';
    };
    export type ModulePlanStep = {
        key: string;
        kind: ModuleStepKind;
        ownerKind: ModuleOwnerKind;
        actorRef?: string;
        journeyRef?: string;
        functionRef?: string;
        next: string[];
        title?: string;
        conditions?: string;
        params?: Record<string, string>;
    };
    export type ModulePlan = {
        processId: string;
        title: string;
        moduleTitle: string;
        steps: ModulePlanStep[];
    };
    export type TaskModuleExecutor = {
        kind: 'person';
        userId: string;
    } | {
        kind: 'routine';
        name: string;
    };
    export type TaskModuleHistoryEntry = {
        at: string;
        commandId: string;
        executor: TaskModuleExecutor;
        from: string | null;
        step: string;
        actorNow: string | null;
        done: boolean;
        note?: string;
        message?: {
            state: 'pending' | 'sent';
            threadId: string;
            orderAt?: string;
            content: string;
            author: 'person' | 'virtual';
            userId?: string;
        };
    };
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
        module?: {
            ref: TaskModuleRef;
            origin: ModuleOrigin;
            owner: string;
            revision: number;
            room: ModuleRoomChoice;
            moduleTitle: string;
            history: TaskModuleHistoryEntry[];
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
        /** Typed accounting evidence for one local E01 gateway request. */
        e01GatewayReceipt?: {
            localRequests: 1;
            providerAttempts: number | null;
            costChargedUsd: number | null;
        };
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    /**
     * Narrow transport-only input for the E02 audio worker. The regular agent
     * contract above deliberately remains text-only: audio bytes may exist only
     * while one bounded gateway request is being assembled.
     */
    export interface IAudioHumanMessageInputType {
        type: 'human';
        content: [
            {
                type: 'text';
                text: string;
            },
            {
                type: 'input_audio';
                input_audio: {
                    data: string;
                    format: 'mp3' | 'wav';
                };
            }
        ];
    }
    export type IProxyMessageInputType = IAMessageInputType | IAudioHumanMessageInputType;
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export interface AIModuleStep extends AIStep {
        type: 'module';
        interaction: null;
        module: {
            key: string;
            kind: ModuleStepKind;
            ownerKind: ModuleOwnerKind;
            actorRef?: string;
            journeyRef?: string;
            functionRef?: string;
            next: string[];
            conditions?: string;
            params?: Record<string, string>;
            actorNow?: string | null;
            wake?: ModuleWake;
            passes: number;
        };
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep | AIModuleStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        /** Private service-step controls consumed only by the existing backend scheduler. */
        e01Execution?: {
            schemaVersion: 1;
            executionId: string;
            organizationId: string;
            userId: string;
            threadId?: string;
            manifestRef: string;
            maxAttempts: 1;
            maxOutputTokens: number;
            deadlineAt: string;
            executionMode?: 'bounded' | 'legacy-supervised-pilot';
            pilotId?: string;
            pilotExpiresAt?: string;
            pilotOperationalBudgetUsd?: number;
            pilotLocalRequestLimit?: 6;
            pilotNextRequestCostEstimateUsd?: number;
        };
        /** Compact E02 identity. Audio bytes and transcript text never enter TaskRecord. */
        e02Audio?: {
            schemaVersion: 1;
            processingId: string;
            executionId: string;
            organizationId: string;
            ownerUserId: string;
            threadId: string;
            phase: 'transcription' | 'interpretation';
        };
        prompt?: string;
        rags: string[] | null;
        onFailure?: 'fail' | 'continue' | 'wait_after_prompt' | 'skip';
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
        newTaskTitle?: string;
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntentModuleAdvance = {
        type: 'module-advance';
        taskId: string;
        commandId: string;
        expectedRevision: number;
        from: string;
        to: string;
        actorNow: string | null;
        done?: boolean;
        note?: string;
        executor: TaskModuleExecutor;
        wake?: Omit<ModuleWake, 'nextAt' | 'seq'>;
        message?: {
            content: string;
        };
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook | AgentIntentModuleAdvance;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export * from "_102036_/l2/shared/interfacesFrontend";
}
declare module "_102034_/l1/server/layer_1_external/collabMessages/client" {
    import type { AgentIntentModuleAdvance, RequestAddMessage, RequestAddUserInThread, RequestApplyIntents, RequestEnsureModuleThread, RequestGetModuleTask, RequestGetTaskUpdate, RequestLinkModulePerson, RequestListModuleTasks, RequestOpenModuleTask, RequestResolveModulePeople, ResponseAddMessage, ResponseAddUserInThread, ResponseApplyIntents, ResponseBase, ResponseEnsureModuleThread, ResponseGetModuleTask, ResponseGetTaskUpdate, ResponseLinkModulePerson, ResponseListModuleTasks, ResponseOpenModuleTask, ResponseResolveModulePeople } from "_102036_/l2/shared/interfaces";
    export type MessagesCallResult<T> = {
        httpStatus: number;
        body: ResponseBase & Partial<T> & {
            code?: string;
        };
    };
    export type ServerMessagesClientOptions = {
        env?: NodeJS.ProcessEnv;
        fetchImpl?: typeof fetch;
        timeoutMs?: number;
        /** Server-resolved application id. Module calls read its private credential; common calls ignore it. */
        projectId?: string;
    };
    export type ServerMessagesClient = {
        ensureModuleThread(asUserId: string, input: Omit<RequestEnsureModuleThread, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseEnsureModuleThread>>;
        openModuleTask(asUserId: string, input: Omit<RequestOpenModuleTask, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseOpenModuleTask>>;
        getModuleTask(asUserId: string, input: Omit<RequestGetModuleTask, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseGetModuleTask>>;
        listModuleTasks(asUserId: string, input: Omit<RequestListModuleTasks, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseListModuleTasks>>;
        advanceModuleTask(asUserId: string, intent: AgentIntentModuleAdvance): Promise<MessagesCallResult<ResponseApplyIntents>>;
        applyIntents(asUserId: string, input: Omit<RequestApplyIntents, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseApplyIntents>>;
        getTaskUpdate(asUserId: string, input: Omit<RequestGetTaskUpdate, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseGetTaskUpdate>>;
        addMessage(asUserId: string, input: Omit<RequestAddMessage, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseAddMessage>>;
        addUserInThread(asUserId: string, input: Omit<RequestAddUserInThread, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseAddUserInThread>>;
        linkModulePerson(asUserId: string, input: Omit<RequestLinkModulePerson, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseLinkModulePerson>>;
        resolveModulePeople(asUserId: string, input: Omit<RequestResolveModulePeople, 'action' | 'userId'>): Promise<MessagesCallResult<ResponseResolveModulePeople>>;
    };
    export function createServerMessagesClient(options?: ServerMessagesClientOptions): ServerMessagesClient;
}
declare module "_102034_/l1/server/layer_1_external/id/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentHttp" {
    /**
     * Dedicated binary door of the runtime. NOT `/execBff`: that envelope is JSON, is traced, and a
     * base64 body would blow the limits that already truncated payloads at 500 chars.
     *
     * POST /attachments     — base64 in, bytes to the project's permanent bucket (or local disk), then
     *                         `ctx.mdm.attachment.attach` with the storageKey. Never stores a URL.
     * GET  /attachments/:id/url  — short-lived signed GET (S3) or same-origin file path (local).
     * GET  /attachments/:id/file — local bytes only.
     */
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface AttachmentHttpResult {
        statusCode: number;
        body: unknown;
        headers?: Record<string, string>;
    }
    export function isAttachmentHttpPath(method: string, url: string): boolean;
    export function handleAttachmentHttp(method: string, url: string, body: unknown, ctx: RequestContext | undefined, headers?: Record<string, string | string[] | undefined>): Promise<AttachmentHttpResult>;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/classifyProjectAssetUrl" {
    export type ProjectAssetKind = 'module' | 'static' | 'libs';
    /** Pathname of an esbuild Lit chunk (`chunkNames: 'shared-[hash]'`, 8 chars). No query. */
    export const HASHED_SHARED_JS_PATH: RegExp;
    /**
     * Who answers a runtime URL. Query string is ignored.
     * `module` → obj/compiled.zip only. `static`/`libs` → dist/<target>.
     * `/_chunks/**` and everything else → null (chunks are gone; rest is handleHttpRequest).
     * `l3` is always `static` (never a JS module). `l4` is `module` only
     * (`.js` or extensionless); any other `l4` file is null. `..` in the remainder is refused.
     */
    export function classifyProjectAssetUrl(urlPath: string): ProjectAssetKind | null;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/draftProxy" {
    import type { FastifyReply, FastifyRequest } from 'fastify';
    import type { CollabAuthClaims } from "_102034_/l1/server/layer_1_external/auth/bffAuth";
    import { resolveRequestDraft, type DraftRequestHeaders } from "_102034_/l1/server/layer_1_external/cbe/cbeDraft";
    import { type DevProcessInfo, type EnsureDevProcessOpts } from "_102034_/l1/server/layer_1_external/cbe/cbeDevProcess";
    export interface DraftSessionView {
        reject: boolean;
        newAccessToken?: string;
        claims?: CollabAuthClaims;
        source?: 'local-test';
        reason?: 'ok' | 'missing-token' | 'invalid-token';
    }
    export type DraftExecPlan = {
        action: 'proxy';
        slug: string;
        newAccessToken?: string;
        claims?: CollabAuthClaims;
        source?: 'local-test';
        reason?: 'ok' | 'missing-token' | 'invalid-token';
    } | {
        action: 'unauthorized';
        statusCode: 401;
        slug: string;
        reason: 'ok' | 'missing-token' | 'invalid-token';
    } | {
        action: 'local';
    };
    export interface DraftExecDeps {
        fetchImpl?: typeof fetch;
        ensureDevProcessImpl?: (opts: EnsureDevProcessOpts) => DevProcessInfo;
        touchDevProcessImpl?: (base: string, slug: string, now: number) => void;
        waitForDevReadyImpl?: (port: number) => Promise<boolean>;
        resolveRequestDraftImpl?: typeof resolveRequestDraft;
    }
    export function draftDownBody(): {
        ok: false;
        data: null;
        error: {
            code: 'DRAFT_DOWN';
            message: string;
        };
    };
    /** Slug from this call (`x-collab-draft`, else `collab-draft`), or null when this process is already the draft dev server. */
    export function draftSlugForProxy(headers: DraftRequestHeaders | undefined): string | null;
    /**
     * Auth before proxy. The dev process does not load BFF_JWT_ENABLED, so the parent is the gate.
     * Rejected session falls through to the normal `/execBff` 401. No slug stays on the local server.
     */
    export function planDraftExecBff(headers: DraftRequestHeaders | undefined, resolveSession: () => Promise<DraftSessionView>): Promise<DraftExecPlan>;
    export function proxyExecBff(args: {
        request: FastifyRequest;
        reply: FastifyReply;
        slug: string;
        base: string;
        clientProjectId: number;
        claims?: CollabAuthClaims;
        reason?: 'ok' | 'missing-token' | 'invalid-token';
        source?: 'local-test';
        renewed?: boolean;
    } & DraftExecDeps): Promise<void>;
    /** Runs the draft branch of POST /execBff. `handled: false` means the caller keeps today's flow. */
    export function applyDraftExecBff(args: {
        request: FastifyRequest;
        reply: FastifyReply;
        base: string;
        clientProjectId: string;
        resolveSession: () => Promise<DraftSessionView>;
        refreshedAuthCookie: (token: string) => string;
    } & DraftExecDeps): Promise<{
        handled: boolean;
        statusCode?: 401;
    }>;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/gitHttp" {
    import type { FastifyInstance } from 'fastify';
    /**
     * O verificador entra por parâmetro, não por import.
     *
     * Duas razões, e a segunda é a que importa: (1) o transporte não precisa conhecer o collab-auth — quem
     * costura é o `startServer`, que já é o lugar onde as rotas são montadas; (2) sem o import com alias
     * `/_102034_/…` este arquivo é importável por um teste comum, e a prova ponta a ponta (clone e push de
     * verdade contra um Fastify de verdade) roda sem o runtime inteiro em pé. Um teste que não consegue
     * subir a rota real acaba testando uma cópia da rota, que é o modo de falha que a gente já pagou.
     */
    export interface GitAuthClaims {
        sub?: unknown;
        email?: unknown;
        /** Machine, not person: a token minted from an API key (`POST /auth/token/exchange`, gb53). */
        service?: unknown;
        /** The non-secret prefix of the API key behind a service token. */
        key_prefix?: unknown;
    }
    /**
     * How the push log names who pushed.
     *
     * A service token carries an e-mail so that git has something to stamp, but that e-mail is a
     * machine's. The log must say so: automation showing up as a person is worse than no audit at all.
     */
    export function actorOf(claims: GitAuthClaims): string;
    export interface GitRequestTarget {
        projectId: string;
        /** Endpoint relative to the repository, one of SMART_ENDPOINTS. */
        endpoint: string;
        /** Raw query string without the leading `?` (`service=git-receive-pack`). */
        query: string;
    }
    /**
     * `/git/mls-102043.git/info/refs?service=git-upload-pack` → `{ projectId, endpoint, query }`.
     *
     * `null` for anything else, and that includes anything with a `..` or an id that is not digits: the id
     * becomes a filesystem path below, so this is the containment check, not a formatting nicety.
     */
    export function parseGitPath(url: string | undefined): GitRequestTarget | null;
    /**
     * The token a git client sends. Not `tokenFromRequest` from bffAuth: that one is cookie-first because the
     * browser cannot see the httpOnly `cauth`. A git client has no cookie jar for us — a credential helper
     * produces `Authorization: Basic base64(user:password)`, the GitHub-PAT shape, with the token in the
     * PASSWORD field and the username ignored. Bearer stays as the second path (server-to-server, tests).
     */
    export function tokenFromGitRequest(headers: Record<string, string | string[] | undefined> | undefined): string;
    export interface CgiResponse {
        status: number;
        headers: Record<string, string>;
        /** Body bytes that were already in the same chunk as the headers. */
        rest: Buffer;
    }
    /**
     * Split a CGI response: headers, then a blank line, then the body. `Status:` is CGI's way of setting the
     * HTTP status and must NOT be forwarded as a header. Returns null while the blank line has not arrived.
     */
    export function splitCgiHeaders(buffer: Buffer): CgiResponse | null;
    /**
     * Where the repositories live: the mls-base root.
     *
     * NOT `dirname(process.cwd())`, which is what this was and what a live VM proved wrong. The pm2 app
     * is started with `cwd = <mls-base>/current-<id>`, but that alias is a SYMLINK: the OS resolves it,
     * so the real cwd is `<mls-base>/releases/<id>` and its parent is `releases/`. The route then looked
     * for `releases/mls-<id>/.git` and answered "not hosted on this VM" for a project that is right
     * there — a 404 that looks exactly like a configuration mistake.
     *
     * What identifies the root without depending on how deep the cwd sits: it is the nearest ancestor
     * that CONTAINS a `releases` directory. True from a release dir, from an alias, and from the root
     * itself. `COLLAB_GIT_PROJECT_ROOT` still wins, for a layout nobody predicted.
     */
    export function findProjectRoot(startDir: string): string;
    export function gitProjectRoot(): string;
    /** The git DIRECTORY of a project. The repos are working repos (`updateInstead`), so it is `.git`. */
    export function projectGitDir(root: string, projectId: string): string;
    export interface GitBackendEnvInput {
        root: string;
        projectId: string;
        target: GitRequestTarget;
        method: string;
        email: string;
        remoteAddress: string;
        contentType?: string;
        contentLength?: string;
        contentEncoding?: string;
    }
    /**
     * The CGI environment of `git http-backend`.
     *
     * `GIT_CONFIG_*` instead of writing the repository's config: http-backend refuses a push unless
     * `http.receivepack` is true, and passing it per request means repositories created BEFORE this route
     * existed (gb14a) work with no migration, and no repository is left permanently push-enabled for a
     * caller that arrives some other way.
     *
     * `CONTENT_LENGTH` is set only when the client sent one: with a chunked body, CGI has no length and
     * http-backend reads stdin to EOF, which is exactly what a large push does.
     */
    export function gitBackendEnv(input: GitBackendEnvInput): Record<string, string>;
    export interface PushLogEntry {
        at: string;
        /** `wagner@collab.codes` for a person, `service:cak_ab12…` for automation (see actorOf). */
        actor: string;
        email: string;
        sub: string;
        projectId: string;
        endpoint: string;
        service: string;
        status: number;
        remoteAddress: string;
    }
    /** One JSON object per line, next to the pm2 logs. Best effort: a push never fails because of the log. */
    export function appendPushLog(root: string, entry: PushLogEntry): void;
    export type GitTokenVerifier = (token: string) => Promise<GitAuthClaims>;
    /**
     * The git door. Registered BEFORE the catch-all `GET /*` for the same reason `/libs/*` is: the first
     * matching route wins, and `/git/...` must not be answered with the SPA shell.
     *
     * `COLLAB_GIT_HTTP_ENABLED=false` closes it entirely (the emergency stop). Default open, because
     * closed-by-default would mean a VM nobody can publish to, and the door refuses everyone without a
     * verified token anyway.
     */
    export function registerGitRoutes(app: FastifyInstance, verify: GitTokenVerifier): void;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/newReleaseQaRoute" {
    import type { ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    export interface NewReleaseQaAccess {
        mode: ProjectMode;
        host: string;
        remoteAddress: string;
    }
    export function isQaLoopback(value: string): boolean;
    export function canServeNewReleaseQa(input: NewReleaseQaAccess): boolean;
    export function newReleaseQaProjectHint(url: string, defaultProjectId?: string): number;
    export function extractNewReleaseQaLitImportMap(shellHtml: string): string;
    export function buildNewReleaseQaHtml(release: string, projectHint: number, litImportMap: string): string;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/sessionRegistration" {
    import type { FastifyInstance } from 'fastify';
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import { type BffAuthOutcome } from "_102034_/l1/server/layer_1_external/auth/bffAuth";
    import type { OrganizationBinding } from "_102034_/l1/server/layer_1_external/config/onboardingConfig";
    import { loadRegistrationScope } from "_102034_/l1/server/layer_1_external/config/registrationScope";
    import { fail, ok, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export { loadRegistrationScope };
    export interface SessionRegistrationScope {
        binding: OrganizationBinding;
        config: ProjectOnboardingConfig;
    }
    export type SessionRegistrationKind = 'register' | 'read-own' | 'list' | 'resolve';
    export interface SessionRegistrationCommand {
        kind: SessionRegistrationKind;
        body?: unknown;
        requestId?: string;
        alphaFollowUp: boolean;
        loadScope: () => SessionRegistrationScope;
    }
    export interface SessionRegistrationHttpResult {
        statusCode: number;
        body: ReturnType<typeof ok> | ReturnType<typeof fail>;
    }
    /**
     * Platform registration ports. Identity comes from the resolved session, never from the body.
     * List and resolve stay closed unless the alpha switch is already on.
     */
    export function handleSessionRegistration(ctx: RequestContext, session: BffAuthOutcome, command: SessionRegistrationCommand): Promise<SessionRegistrationHttpResult>;
    export function registerSessionRegistrationRoutes(app: FastifyInstance, options: {
        refreshedAuthCookie: (token: string) => string;
        createContext?: () => RequestContext;
        alphaFollowUp?: () => boolean;
        loadScope?: () => SessionRegistrationScope;
    }): void;
}
declare module "_102034_/l1/workflow/plan" {
    import type { WorkflowStepDef, WorkflowStepKind, WorkflowTable } from "_102034_/l1/workflow/contracts";
    export type StepOwner = 'person' | 'module' | 'agent' | 'clock';
    /** Owner of a step comes from its kind. The module does not store this. */
    export function ownerOf(kind: WorkflowStepKind): StepOwner;
    /** Historical table check shared with the engine. Stricter plan fields stay in prepareWorkflowPlan. */
    export function indexWorkflowTable(table: WorkflowTable, processId: string): Map<string, WorkflowStepDef>;
    export interface WorkflowPlanStepInput extends WorkflowStepDef {
        title: string;
        functionRef?: string;
        conditions?: string;
        params?: Record<string, string>;
    }
    export interface WorkflowPlanInput {
        processId: string;
        title: string;
        moduleTitle: string;
        steps: WorkflowPlanStepInput[];
    }
    export interface WorkflowPlanStep extends WorkflowPlanStepInput {
        ownerKind: StepOwner;
    }
    export interface WorkflowPlan {
        processId: string;
        title: string;
        moduleTitle: string;
        steps: WorkflowPlanStep[];
    }
    export function prepareWorkflowPlan(input: WorkflowPlanInput): WorkflowPlan;
}
declare module "_102034_/l1/workflow/contracts" {
    import type { IClock, RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ModuleWake, ResponseOpenModuleTask, TaskData } from "_102036_/l2/shared/interfaces";
    import type { WorkflowPlan } from "_102034_/l1/workflow/plan";
    export type WorkflowStepKind = 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
    export interface WorkflowStepDef {
        stepId: string;
        kind: WorkflowStepKind;
        actorRef?: string;
        journeyRef?: string;
        next: string[];
    }
    export interface WorkflowTable {
        processId: string;
        steps: WorkflowStepDef[];
    }
    /** Identity of one occurrence. Version is not part of the key. */
    export interface OccurrenceKey {
        project: string;
        module: string;
        processId: string;
        entity: string;
        recordId: string;
    }
    export interface OccurrenceRef extends OccurrenceKey {
        workflowVersion: string | null;
    }
    export interface OccurrenceHistoryEntry {
        at: string;
        /** Session person when one exists. A tick does not invent an identity. */
        by: string | null;
        from: string | null;
        step: string;
        actorNow: string | null;
        done: boolean;
        note?: string;
    }
    export interface OccurrenceSnapshot {
        ref: OccurrenceRef;
        step: string;
        actorNow: string | null;
        done: boolean;
        history: OccurrenceHistoryEntry[];
    }
    export interface OpenOccurrenceResult {
        outcome: 'created' | 'existing';
        occurrence: OccurrenceSnapshot;
    }
    export interface AdvanceOccurrenceCommand {
        from: string;
        to: string;
        actorNow: string | null;
        done: boolean;
        note?: string;
        by: string | null;
    }
    export interface AdvanceOccurrenceResult {
        outcome: 'advanced' | 'unchanged' | 'conflict';
        occurrence: OccurrenceSnapshot;
    }
    /** Fields the occurrence port reads. A full request context satisfies this. */
    export interface OccurrenceContext {
        clock: IClock;
    }
    export interface OccurrencePort {
        open(ctx: OccurrenceContext, ref: OccurrenceRef, step: string, actorNow: string | null, by: string | null): Promise<OpenOccurrenceResult>;
        find(ctx: OccurrenceContext, key: OccurrenceKey): Promise<OccurrenceSnapshot | null>;
        advance(ctx: OccurrenceContext, key: OccurrenceKey, command: AdvanceOccurrenceCommand): Promise<AdvanceOccurrenceResult>;
    }
    /** Person is an MDM id. A cm userId is not an identity in this contract. */
    export type WorkflowExecutor = {
        kind: 'person';
        mdmId: string;
    } | {
        kind: 'routine';
        name: string;
    };
    export interface WorkflowOrigin {
        kind: 'screen' | 'channel' | 'schedule' | 'event';
        /** MDM id of the person who produced the origin, when one exists. */
        by?: string;
        config?: string;
    }
    export interface WorkflowRoomChoice {
        mode: 'exclusive' | 'person' | 'group';
        groupKey?: string;
        /** MDM ids. */
        members?: string[];
    }
    /** Wake requested for the destination step. Absence stays absent; the port owns nextAt and seq. */
    export type WorkflowWakeRequest = Omit<ModuleWake, 'nextAt' | 'seq'>;
    /** Wake stored on the occurrence. Same shape as the cm wake, without a second identity. */
    export type WorkflowWake = ModuleWake;
    /** Delivery state projected from the durable record. Content and cm author stay out. */
    export type TaskOccurrenceMessageStatus = NonNullable<ResponseOpenModuleTask['moduleMessage']>;
    export interface TaskOccurrenceHistoryEntry extends OccurrenceHistoryEntry {
        commandId: string;
        executor: WorkflowExecutor;
        /** Projected delivery state of this entry. Absent is not sent. */
        message?: TaskOccurrenceMessageStatus;
    }
    /** View returned by the task port. The logical step may be `end`; the plan does not contain that id. */
    export interface TaskOccurrenceSnapshot extends OccurrenceSnapshot {
        plan: WorkflowPlan;
        /** Occurrence title. Distinct from plan.title and plan.moduleTitle. */
        title: string;
        taskId: string;
        revision: number;
        status: TaskData['status'];
        /** MDM id of the owner. */
        owner: string;
        origin: WorkflowOrigin;
        room: WorkflowRoomChoice;
        roomId: string;
        pass: number;
        wake?: WorkflowWake;
        history: TaskOccurrenceHistoryEntry[];
    }
    export interface TaskOccurrenceOpenCommand {
        ref: OccurrenceRef;
        plan: WorkflowPlan;
        /** Occurrence title supplied by L1. Not derived from the plan titles. */
        title: string;
        firstStep: string;
        /** MDM id of the acting person, or null when the executor is a routine. */
        actorNow: string | null;
        /** MDM id of the owner. */
        owner: string;
        origin: WorkflowOrigin;
        executor: WorkflowExecutor;
        room: WorkflowRoomChoice;
        message?: {
            content: string;
        };
    }
    export interface TaskOccurrenceAdvanceCommand {
        taskId: string;
        commandId: string;
        expectedRevision: number;
        from: string;
        /** Real step key. Physical close is to=from with done=true. */
        to: string;
        actorNow: string | null;
        done: boolean;
        executor: WorkflowExecutor;
        note?: string;
        /** Present only when the destination should receive a wake. Omission removes or keeps per the port rule. */
        wake?: WorkflowWakeRequest;
        message?: {
            content: string;
        };
    }
    export interface TaskOccurrenceOpenResult {
        outcome: 'created' | 'existing';
        occurrence: TaskOccurrenceSnapshot;
        moduleMessage?: TaskOccurrenceMessageStatus;
    }
    export interface TaskOccurrenceAdvanceResult {
        outcome: 'advanced' | 'unchanged' | 'conflict' | 'paused';
        occurrence: TaskOccurrenceSnapshot;
        moduleMessage?: TaskOccurrenceMessageStatus;
    }
    export interface TaskOccurrencePort {
        readonly kind: 'task';
        open(ctx: RequestContext, command: TaskOccurrenceOpenCommand): Promise<TaskOccurrenceOpenResult>;
        find(ctx: RequestContext, key: OccurrenceKey): Promise<TaskOccurrenceSnapshot | null>;
        advance(ctx: RequestContext, key: OccurrenceKey, command: TaskOccurrenceAdvanceCommand): Promise<TaskOccurrenceAdvanceResult>;
    }
}
declare module "_102034_/l1/workflow/wakeContracts" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ModuleWakeEvent, ModuleWakeReceipt, TaskModuleRef } from "_102036_/l2/shared/interfaces";
    import type { TaskOccurrenceSnapshot } from "_102034_/l1/workflow/contracts";
    export type { ModuleWakeEvent, ModuleWakeReceipt, TaskModuleRef };
    /** 32 KiB. The route checks the raw body as well. */
    export const WORKFLOW_WAKE_BODY_LIMIT_BYTES: number;
    export interface WorkflowWakeScope {
        projectId: string;
        moduleId: string;
        processId: string;
        routine: string;
    }
    export type WorkflowWakeHandler = (ctx: RequestContext, event: ModuleWakeEvent, occurrence: TaskOccurrenceSnapshot) => Promise<void>;
    /** Command id of one firing. The next period uses another eventId, so another command. */
    export function workflowWakeCommandId(eventId: string): string;
    /**
     * Fields that stay the same across retries of one firing.
     * attempt and revision are observations and are not part of this identity.
     * workflowVersion travels inside ref; it is not an occurrence key.
     */
    export interface WorkflowWakeStableIdentity {
        eventId: string;
        scheduledAt: string;
        ref: TaskModuleRef;
        taskId: string;
        stepKey: string;
        pass: number;
        seq: number;
        routine: string;
    }
    export type WorkflowWakeDispatchResult = 'accepted' | 'stale' | {
        retry: {
            code: string;
        };
    };
    export type WorkflowWakeRunNextResult = 'empty' | 'busy' | 'accepted' | 'stale' | 'retry';
    export interface WorkflowWakeEnqueueResult {
        receipt: ModuleWakeReceipt;
        statusCode: 200 | 202;
    }
    /**
     * Durable inbox. These methods take no human token or session.
     * A thrown dispatch error is a retry. Construction options, when a later
     * store adds them, are server test seams: production has no memory endpoint or flag.
     * enqueue returns only after commit.
     */
    export interface WorkflowWakeInbox {
        enqueue(event: ModuleWakeEvent): Promise<WorkflowWakeEnqueueResult>;
        runNext(projectId: string, dispatch: (event: ModuleWakeEvent) => Promise<WorkflowWakeDispatchResult>): Promise<WorkflowWakeRunNextResult>;
    }
    export function workflowWakeBodyBytes(body: unknown): number;
    export function assertWorkflowWakeBodyLimit(byteLength: number): void;
    /** Wire copy only. Arbitrary body fields are dropped. */
    export function parseWorkflowWakeEvent(body: unknown, byteLength?: number): ModuleWakeEvent;
    export function workflowWakeStableIdentity(event: ModuleWakeEvent): WorkflowWakeStableIdentity;
    export function sameWorkflowWakeIdentity(left: ModuleWakeEvent, right: ModuleWakeEvent): boolean;
}
declare module "_102034_/l1/workflow/wakeInboxPostgres" {
    import type { Pool } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import { type WorkflowWakeInbox } from "_102034_/l1/workflow/wakeContracts";
    export interface PostgresWorkflowWakeInboxOptions {
        projectId: string;
        env?: AppEnv;
        pool?: Pool;
        definition?: ResolvedTableDefinition;
    }
    export function createPostgresWorkflowWakeInbox(options: PostgresWorkflowWakeInboxOptions): WorkflowWakeInbox;
}
declare module "_102034_/l1/workflow/wakeRegistry" {
    import type { WorkflowWakeHandler, WorkflowWakeScope } from "_102034_/l1/workflow/wakeContracts";
    export interface WorkflowWakeRegistryDeps {
        loadCompositionRoot?: (projectId: string, moduleId: string) => Promise<void>;
    }
    export interface WorkflowWakeRegistry {
        register(scope: WorkflowWakeScope, handler: WorkflowWakeHandler): void;
        resolve(scope: WorkflowWakeScope): Promise<WorkflowWakeHandler>;
        clear(): void;
    }
    export function createWorkflowWakeRegistry(deps?: WorkflowWakeRegistryDeps): WorkflowWakeRegistry;
    export function registerWorkflowWakeHandler(scope: WorkflowWakeScope, handler: WorkflowWakeHandler): void;
    export function resolveWorkflowWakeHandler(scope: WorkflowWakeScope): Promise<WorkflowWakeHandler>;
    export function resetWorkflowWakeRegistryForTests(): void;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/workflowWake" {
    import type { FastifyInstance } from 'fastify';
    import { type ProjectsConfig } from "_102034_/l1/server/layer_1_external/config/projectConfig";
    import { type WorkflowWakeInbox, type WorkflowWakeScope } from "_102034_/l1/workflow/wakeContracts";
    import type { WorkflowWakeHandler } from "_102034_/l1/workflow/wakeContracts";
    export interface WorkflowWakeRouteDeps {
        resolveAppId?: () => string;
        readIntegration?: (projectId: string) => {
            token: string;
        };
        readConfig?: () => ProjectsConfig;
        resolveHandler?: (scope: WorkflowWakeScope) => Promise<WorkflowWakeHandler>;
        createInbox?: (projectId: string) => WorkflowWakeInbox;
    }
    /**
     * Service route for one CM wake delivery. Production keeps a single lazy inbox
     * for the configured app and does not open a pool per request. The handler is
     * resolved and not called: 202 means the row was committed, not that the routine ran.
     */
    export function registerWorkflowWakeRoutes(app: FastifyInstance, deps?: WorkflowWakeRouteDeps): void;
}
declare module "_102034_/l1/workflow/activities" {
    import type { OccurrenceRef, TaskOccurrenceSnapshot, WorkflowStepKind } from "_102034_/l1/workflow/contracts";
    import { type StepOwner } from "_102034_/l1/workflow/plan";
    export type WorkflowActivityState = 'future' | 'active' | 'completed';
    /** Identity of an activity is (taskId, stepKey). pass is the current or last visit. */
    export interface WorkflowActivity {
        stepKey: string;
        title: string;
        kind: WorkflowStepKind;
        ownerKind: StepOwner;
        actorRef?: string;
        journeyRef?: string;
        functionRef?: string;
        actorNow: string | null;
        pass: number;
        state: WorkflowActivityState;
        /** Property of the activity. It is not a permission to act or transfer. */
        actionable: boolean;
    }
    export interface WorkflowActivitiesSnapshot {
        ref: OccurrenceRef;
        taskId: string;
        revision: number;
        taskStatus: TaskOccurrenceSnapshot['status'];
        taskTitle: string;
        processTitle: string;
        moduleTitle: string;
        activities: WorkflowActivity[];
    }
    /**
     * Projects one activity per persisted plan step. Does not read a release template,
     * a business record, or any clock, credential, or store.
     */
    export function projectWorkflowActivities(snapshot: TaskOccurrenceSnapshot): WorkflowActivitiesSnapshot;
}
declare module "_102034_/l1/workflow/activitiesStore" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { OccurrenceKey, OccurrenceRef, TaskOccurrenceSnapshot } from "_102034_/l1/workflow/contracts";
    import type { WorkflowActivity } from "_102034_/l1/workflow/activities";
    /**
     * Server-side activity index bound to one project and module.
     * Subject and actorRefs are resolved by the server consumer. This contract has no HTTP principal.
     * There is no production in-memory store and no apply of a previously captured snapshot.
     */
    export interface WorkflowActivityStore {
        readonly projectId: string;
        readonly moduleId: string;
        refresh(ctx: RequestContext, key: OccurrenceKey, loadOccurrence: () => Promise<TaskOccurrenceSnapshot | null>): Promise<WorkflowActivityRefreshResult>;
        list(ctx: RequestContext, query: WorkflowActivityListQuery): Promise<WorkflowActivityListResult>;
    }
    export interface WorkflowActivityRefreshResult {
        state: 'synced' | 'absent';
        occurrence: TaskOccurrenceSnapshot | null;
    }
    /** Person is an MDM id. actorRefs are role references already authorized for that person. */
    export interface WorkflowActivitySubject {
        personMdmId: string;
        actorRefs?: string[];
    }
    export interface WorkflowActivityListQuery {
        subject: WorkflowActivitySubject;
        cursor?: string;
        pageSize?: number;
        includeNonActionable?: boolean;
    }
    /** Identity, titles, status, ref, revision and sync time, plus one activity. */
    export interface WorkflowActivityListItem {
        projectId: string;
        moduleId: string;
        taskId: string;
        ref: OccurrenceRef;
        revision: number;
        syncedAt: string;
        status: TaskOccurrenceSnapshot['status'];
        taskTitle: string;
        processTitle: string;
        moduleTitle: string;
        activity: WorkflowActivity;
    }
    export interface WorkflowActivityListResult {
        items: WorkflowActivityListItem[];
        cursor?: string;
    }
}
declare module "_102034_/l1/workflow/activitiesPostgres" {
    import type { Pool } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { OccurrenceKey } from "_102034_/l1/workflow/contracts";
    import type { WorkflowActivityStore } from "_102034_/l1/workflow/activitiesStore";
    export interface PostgresWorkflowActivityDefinitions {
        tasks: ResolvedTableDefinition;
        activities: ResolvedTableDefinition;
    }
    export interface PostgresWorkflowActivityStoreOptions {
        projectId: string;
        moduleId: string;
        env?: AppEnv;
        pool?: Pool;
        definitions?: PostgresWorkflowActivityDefinitions;
    }
    export function workflowProjectionLockToken(projectId: string, moduleId: string, key: Pick<OccurrenceKey, 'processId' | 'entity' | 'recordId'>): string;
    export function createPostgresWorkflowActivityStore(options: PostgresWorkflowActivityStoreOptions): WorkflowActivityStore;
}
declare module "_102034_/l1/workflow/activitiesSync" {
    import type { WorkflowActivityStore } from "_102034_/l1/workflow/activitiesStore";
    import type { TaskOccurrencePort } from "_102034_/l1/workflow/contracts";
    /**
     * Decorates the canonical task port. The projection is refreshed from a fresh read.
     * A projection failure never rewrites a confirmed open or advance.
     */
    export function withWorkflowActivityProjection(basePort: TaskOccurrencePort, store: WorkflowActivityStore): TaskOccurrencePort;
}
declare module "_102034_/l1/workflow/messagesTask" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { RequestOpenModuleTask, TaskData } from "_102036_/l2/shared/interfaces";
    import type { OccurrenceKey, TaskOccurrenceMessageStatus, TaskOccurrenceOpenCommand, TaskOccurrenceSnapshot } from "_102034_/l1/workflow/contracts";
    /** Server-bound MDM ↔ CM user translation. This codec has no default. */
    export interface MessagesWorkflowIdentities {
        toCmUserId(ctx: RequestContext, mdmId: string): Promise<string>;
        toMdmId(ctx: RequestContext, userId: string): Promise<string>;
    }
    /** MDM id → CM user id through the resolver; identity errors keep the resolver code with a sanitized message. */
    export function toCm(ctx: RequestContext, identities: MessagesWorkflowIdentities, mdmId: string): Promise<string>;
    /** Opening payload. Plan refs stay refs. Person ids go through the resolver. */
    export function encodeOpenModuleTask(ctx: RequestContext, identities: MessagesWorkflowIdentities, command: TaskOccurrenceOpenCommand): Promise<RequestOpenModuleTask>;
    /** Delivery status projected from the wire: state, threadId and orderAt only. */
    export function projectMessage(message: unknown): TaskOccurrenceMessageStatus | undefined;
    /** Canonical task view. Does not keep CM user ids or message bodies. */
    export function decodeTaskSnapshot(ctx: RequestContext, identities: MessagesWorkflowIdentities, task: TaskData, expected: OccurrenceKey, roomThreadId?: string): Promise<TaskOccurrenceSnapshot>;
}
declare module "_102034_/l1/workflow/messagesIdentities" {
    import { type ServerMessagesClient } from "_102034_/l1/server/layer_1_external/collabMessages/client";
    import type { MessagesWorkflowIdentities } from "_102034_/l1/workflow/messagesTask";
    type IdentityClient = Pick<ServerMessagesClient, 'linkModulePerson' | 'resolveModulePeople'>;
    export interface MessagesWorkflowIdentitiesOptions {
        projectId: string;
        /** Test seam. Production builds a server client bound to projectId. */
        client?: IdentityClient;
    }
    export function createMessagesWorkflowIdentities(options: MessagesWorkflowIdentitiesOptions): MessagesWorkflowIdentities;
}
declare module "_102034_/l1/workflow/messagesOccurrence" {
    import { type ServerMessagesClient } from "_102034_/l1/server/layer_1_external/collabMessages/client";
    import type { TaskOccurrencePort } from "_102034_/l1/workflow/contracts";
    import { type MessagesWorkflowIdentities } from "_102034_/l1/workflow/messagesTask";
    type TaskClient = Pick<ServerMessagesClient, 'openModuleTask' | 'getModuleTask' | 'advanceModuleTask'>;
    export interface MessagesTaskOccurrencePortOptions {
        projectId: string;
        moduleId: string;
        asUserId: string;
        identities: MessagesWorkflowIdentities;
        client?: TaskClient;
    }
    export function createMessagesTaskOccurrencePort(options: MessagesTaskOccurrencePortOptions): TaskOccurrencePort;
}
declare module "_102034_/l1/workflow/messagesRuntime" {
    import { type ServerMessagesClient } from "_102034_/l1/server/layer_1_external/collabMessages/client";
    import type { WorkflowActivityStore } from "_102034_/l1/workflow/activitiesStore";
    import type { TaskOccurrencePort } from "_102034_/l1/workflow/contracts";
    /** Methods the production composition calls. Tests may pass the real client. */
    export type RuntimeMessagesClient = Pick<ServerMessagesClient, 'openModuleTask' | 'getModuleTask' | 'advanceModuleTask' | 'linkModulePerson' | 'resolveModulePeople'>;
    export interface RuntimeMessagesTaskPortOptions {
        projectId: string;
        moduleId: string;
        /** Test seam for the real client. There is no memory or stand-in identity. */
        client?: RuntimeMessagesClient;
        /** Server test seam. Production always uses the Postgres projection. */
        projectionStore?: WorkflowActivityStore;
    }
    /** Production task port. projectId and moduleId come from the server bootstrap. */
    export function createRuntimeMessagesTaskPort(options: RuntimeMessagesTaskPortOptions): TaskOccurrencePort;
}
declare module "_102034_/l1/workflow/wakeDispatch" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ModuleWakeEvent } from "_102036_/l2/shared/interfaces";
    import type { TaskOccurrencePort } from "_102034_/l1/workflow/contracts";
    import { type WorkflowWakeDispatchResult, type WorkflowWakeHandler, type WorkflowWakeScope } from "_102034_/l1/workflow/wakeContracts";
    export interface WorkflowWakeDispatcherDeps {
        /** Server test seam. Production builds a fresh routine context on every attempt. */
        createContext?: (event: ModuleWakeEvent) => RequestContext;
        /** Server test seam. Production uses the canonical task port, never the projection. */
        port?: TaskOccurrencePort;
        /** Server test seam. Production resolves the handler registered for the full scope. */
        resolve?: (scope: WorkflowWakeScope) => Promise<WorkflowWakeHandler>;
        /** Server test seam. Production reads the application integration. */
        readIntegration?: (projectId: string) => {
            organizationId: string;
        };
        /** Server test seam. Production uses the company id reserved for this installation. */
        companyId?: () => string | undefined;
        /** Server test seam. Production uses the current clock for wake.until. */
        now?: () => Date;
    }
    export interface WorkflowWakeDispatcher {
        dispatch(event: ModuleWakeEvent): Promise<WorkflowWakeDispatchResult>;
    }
    export function createWorkflowWakeDispatcher(projectId: string, moduleId: string, deps?: WorkflowWakeDispatcherDeps): WorkflowWakeDispatcher;
}
declare module "_102034_/l1/workflow/wakeLoop" {
    import { type AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import { type WorkflowWakeDispatcher } from "_102034_/l1/workflow/wakeDispatch";
    import type { WorkflowWakeInbox } from "_102034_/l1/workflow/wakeContracts";
    export interface WorkflowWakeTimer {
        unref(): void;
    }
    export interface WorkflowWakeInboxLoopDeps {
        /** Server test seam. Production uses the configured client application. */
        resolveProjectId?: () => string;
        /** Server test seam. Production reads the process environment. */
        readEnv?: () => Pick<AppEnv, 'runtimeMode' | 'tickEnabled'>;
        /** Server test seam. Production opens the Postgres inbox lazily. */
        createStore?: (projectId: string) => WorkflowWakeInbox;
        /** Server test seam. Production uses the canonical dispatcher for the event module. */
        createDispatcher?: (projectId: string, moduleId: string) => WorkflowWakeDispatcher;
        intervalMs?: number;
        /** Server test seam. Production uses an unref'd interval. */
        schedule?: (callback: () => void, intervalMs: number) => WorkflowWakeTimer;
        /** Server test seam. Production clears the interval handle. */
        clearTimer?: (timer: WorkflowWakeTimer) => void;
    }
    /**
     * Drains wake events that are already in the inbox. It does not compute a
     * new period, open a task, or replace the CM scheduler.
     * The local running flag only skips an overlapping round in this process.
     * Two processes share the Postgres table and its advisory lock.
     */
    export class WorkflowWakeInboxLoop {
        private timer;
        private started;
        private stopped;
        private running;
        private inflight;
        private store;
        private projectId;
        private readonly resolveProjectId;
        private readonly readEnv;
        private readonly createStore;
        private readonly createDispatcher;
        private readonly intervalMs;
        private readonly schedule;
        private readonly clearTimer;
        constructor(deps?: WorkflowWakeInboxLoopDeps);
        /** Idempotent. Runs one round immediately, then every five seconds. No-op on the memory runtime. */
        start(): Promise<void>;
        /** At most twenty due rows. `empty` ends the round; `busy` and `retry` leave the other rows eligible. */
        runOnce(): Promise<void>;
        /** Drops the timer and waits for the round that is already running. */
        stop(): Promise<void>;
        private drain;
        private inbox;
        private configuredProjectId;
        private dispatch;
        private report;
    }
}
declare module "_102034_/l1/server/layer_2_application/tick/moduleTick" {
    /**
     * The only clock the platform owns: once a minute it calls `onTick(ctx, now)` on every module that
     * exports one, in series, and gets out of the way.
     *
     * There is no alert table, no queue and no cron here on purpose (decision of 17/09/2026): a central
     * scheduler would have to know what every module wants and would go stale the first time a module
     * changed its mind. The module keeps its own occurrences in its own `tdm` table and decides, every
     * minute, whether it owes anything — `evaluateSchedule` next door reads the prose for it.
     *
     * One module's failure never reaches another: each call is isolated, and a tick that is still
     * running skips the next one instead of stacking.
     */
    import { type ModuleTickRegistration } from "_102034_/l1/server/layer_1_external/persistence/registry";
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const MODULE_TICK_INTERVAL_MS = 60000;
    /** Builds the context one module sees on its tick. No request, no session: the caller is the platform. */
    export type TickContextFactory = (moduleId: string) => RequestContext;
    export function createTickContext(moduleId: string): RequestContext;
    /** Calls every handler in series. A handler that throws is logged with its moduleId and the run continues. */
    export function runModuleTick(handlers: readonly ModuleTickRegistration[], createContext: TickContextFactory, now: Date): Promise<void>;
    /**
     * The minute loop. `start()` resolves the handlers once and arms the interval; the timer is
     * `unref`ed so it never holds the process open, as the metrics sampler does.
     */
    export class ModuleTickLoop {
        private readonly createContext;
        private readonly intervalMs;
        /** Seam for the tests; the server always uses the registry. */
        private readonly loadHandlers;
        private timer;
        private handlers;
        private running;
        constructor(createContext?: TickContextFactory, intervalMs?: number, 
        /** Seam for the tests; the server always uses the registry. */
        loadHandlers?: () => Promise<readonly ModuleTickRegistration[]>);
        start(): Promise<number>;
        /** Exposed for the tests and for a future `POST /<module>/tick`; the loop calls it every minute. */
        runOnce(now?: Date): Promise<void>;
        stop(): void;
    }
}
declare module "_102034_/l1/server/layer_1_external/transport/http/startServer" {
    import { type BffAuthOutcome } from "_102034_/l1/server/layer_1_external/auth/bffAuth";
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import { type AuthorityOverride } from "_102034_/l1/server/layer_1_external/auth/authorityOverride";
    import type { ProjectOnboardingConfig } from "_102029_/l2/runtimeConfigTypes";
    import type { FrontendAppRegistration, RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    /** Session JSON projection. The IdP `sub` stays `userId`; this is only the MDM person. */
    export type SessionInfoPerson = {
        mdmId: string;
    };
    export type SessionOnboardingStatus = 'ready' | 'incomplete' | 'pending' | 'unregistered' | 'unavailable';
    export type SessionInfoOnboarding = {
        status: SessionOnboardingStatus;
        entryPath: string;
        moduleBasePath: string;
        requestId?: string;
    };
    export type SessionInfoCompany = {
        mdmId: string;
    };
    /** Entry already checked against the client module. `organizationKey` null means the index cannot be read. */
    export type SessionOnboardingSource = {
        entry: {
            entryPath: string;
            moduleBasePath: string;
        };
        organizationKey: string | null;
        companyMdmId?: string | null;
    };
    type ClientModuleRoutes = Pick<FrontendAppRegistration, 'projectId' | 'appId' | 'basePath' | 'routes'>;
    /**
     * Entry of the configured client module. Throws a readable error for an external URL,
     * a missing module, or a path that is not a route or alias of that module.
     */
    export function resolveClientOnboardingEntry(onboarding: Pick<ProjectOnboardingConfig, 'moduleId' | 'entryPath'>, clientProjectId: string, apps: readonly ClientModuleRoutes[]): {
        entryPath: string;
        moduleBasePath: string;
    };
    export function getContentType(filePath: string): "image/jpeg" | "image/png" | "image/webp" | "image/gif" | "application/pdf" | "image/avif" | "image/svg+xml; charset=utf-8" | "image/x-icon" | "application/json; charset=utf-8" | "text/javascript; charset=utf-8" | "text/css; charset=utf-8" | "text/plain; charset=utf-8" | "text/html; charset=utf-8" | "font/woff2" | "font/woff" | "video/mp4" | "audio/wav" | "audio/mpeg" | "audio/ogg";
    export function buildBootConfig(app: FrontendAppRegistration): Promise<{
        onboarding?: {
            entryPath: string;
            moduleBasePath: string;
        };
        projectId: string;
        clientProjectId: string;
        moduleId: string;
        basePath: string;
        shellMode: import("/_102034_/l1/server/layer_2_controllers/contracts.js").ShellMode;
        device: import("/_102034_/l1/server/layer_2_controllers/contracts.js").DeviceKind;
        languages: string[];
        designSystems: string[];
        routes: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendRouteRegistration[];
        headerEntrypoint: string;
        headerTag: string;
        asideEntrypoint: string;
        asideTag: string;
        pageTitle: string;
        navigation: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendNavigationItem[];
        moduleLinks: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendNavigationItem[];
        layout: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendAppLayout;
        clientShell: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendClientShellConfig;
        appEnv: ProjectMode;
    }>;
    export function buildBootConfigScript(app: FrontendAppRegistration): Promise<string>;
    export function resolveModuleBoot(basePath: string): Promise<{
        status: number;
        body: {
            statusCode: number;
            msg: string;
        };
    } | {
        status: number;
        body: {
            onboarding?: {
                entryPath: string;
                moduleBasePath: string;
            };
            projectId: string;
            clientProjectId: string;
            moduleId: string;
            basePath: string;
            shellMode: import("/_102034_/l1/server/layer_2_controllers/contracts.js").ShellMode;
            device: import("/_102034_/l1/server/layer_2_controllers/contracts.js").DeviceKind;
            languages: string[];
            designSystems: string[];
            routes: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendRouteRegistration[];
            headerEntrypoint: string;
            headerTag: string;
            asideEntrypoint: string;
            asideTag: string;
            pageTitle: string;
            navigation: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendNavigationItem[];
            moduleLinks: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendNavigationItem[];
            layout: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendAppLayout;
            clientShell: import("/_102034_/l1/server/layer_2_controllers/contracts.js").FrontendClientShellConfig;
            appEnv: ProjectMode;
        };
    }>;
    /** Copy the raw query of `url` onto `location`. Empty query stays off the destination. */
    export function withQuery(location: string, url: string): string;
    /**
     * Body of `GET /session/info`. Authorities come from `claimAuthorities` (top-level ∪
     * `active_org.teams[].roles`); the unused `authorities` field is not emitted.
     */
    export function sessionInfoBody(session: BffAuthOutcome, mode: ProjectMode, override: AuthorityOverride | null, person?: SessionInfoPerson | null, gate?: {
        company?: SessionInfoCompany | null;
        onboarding?: SessionInfoOnboarding;
    }): {
        onboarding?: SessionInfoOnboarding;
        company?: SessionInfoCompany;
        sessionSource?: "local-test";
        authenticated: boolean;
        email: string;
        name: unknown;
        picture: unknown;
        userId: string;
        person: SessionInfoPerson;
        allAuthorities: string[];
        realAuthorities: string[];
        overridden: boolean;
        canOverride: boolean;
        appEnv: ProjectMode;
        expiresAt: string;
        enforcement: {
            authentication: boolean;
            actors: boolean;
        };
        reason: "ok" | "missing-token" | "invalid-token";
    };
    /**
     * Same MDM resolution the BFF uses (`applyVerifiedEmailToSession` on the verified e-mail only).
     * A failed read keeps the rest of the session and reports no person — never the IdP sub.
     */
    export function resolveSessionInfoBody(ctx: RequestContext, session: BffAuthOutcome, mode: ProjectMode, override: AuthorityOverride | null, gate?: SessionOnboardingSource | null): Promise<{
        onboarding?: SessionInfoOnboarding;
        company?: SessionInfoCompany;
        sessionSource?: "local-test";
        authenticated: boolean;
        email: string;
        name: unknown;
        picture: unknown;
        userId: string;
        person: SessionInfoPerson;
        allAuthorities: string[];
        realAuthorities: string[];
        overridden: boolean;
        canOverride: boolean;
        appEnv: ProjectMode;
        expiresAt: string;
        enforcement: {
            authentication: boolean;
            actors: boolean;
        };
        reason: "ok" | "missing-token" | "invalid-token";
    }>;
    export function buildHttpServer(): any;
    export function handleHttpRequest(method: string, url: string, body?: unknown, ctx?: RequestContext, headers?: Record<string, string | string[] | undefined>): Promise<import("/_102034_/l1/server/layer_1_external/storage/attachmentHttp.js").AttachmentHttpResult>;
    /** Draft boot applies the draft schema before listen. Production (no COLLAB_DRAFT) only listens. */
    export interface BootStepsInput {
        draft: boolean;
        runMigrations: () => Promise<void>;
        initializeOrganization?: () => Promise<void>;
        /** After migrations and organization bootstrap, before the process accepts traffic. */
        beforeListen?: () => Promise<void>;
        listen: () => Promise<void>;
    }
    export interface ServerWorkflowWakeLoop {
        start(): Promise<void>;
        stop(): Promise<void>;
    }
    export interface ServerWorkflowWakeLifecycleDeps {
        readEnv?: () => {
            runtimeMode: 'memory' | 'postgres';
            tickEnabled: boolean;
        };
        createLoop?: () => ServerWorkflowWakeLoop;
    }
    /** Postgres inbox recovery. `tickEnabled` does not gate it. Memory runtime does not start a loop. */
    export function createServerWorkflowWakeLifecycle(deps?: ServerWorkflowWakeLifecycleDeps): ServerWorkflowWakeLoop;
    export function bootSteps(input: BootStepsInput): Promise<void>;
    /** Registry failure used to be an unhandledRejection: pm2 stayed green, listen never ran.
     *  Exit nonzero so pm2 marks error and the release probe fails with the missing key. */
    export function failFrontendRegistryBoot(error: unknown): never;
}
declare module "_102034_/l1/server/layer_1_external/transport/message/execMessage" {
    import type { BffRequest, RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function execMessage(request: BffRequest, ctx?: RequestContext): Promise<{
        response: import("/_102034_/l1/server/layer_2_controllers/contracts.js").BffResponse;
        statusCode: number;
    }>;
}
declare module "_102034_/l1/server/layer_2_application/repositoryRegistry" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export type RepositoryFactory<T> = (ctx: RequestContext) => T;
    /** Bind a repository port name to the factory that builds its concrete adapter for a request ctx. */
    export function registerRepository<T>(portName: string, factory: RepositoryFactory<T>): void;
    /** Resolve the concrete repository adapter for a port name, bound to the current request ctx. */
    export function resolveRepository<T>(ctx: RequestContext, portName: string): T;
    export function hasRepository(portName: string): boolean;
    /** Test/boot helper: clear all registered factories. */
    export function clearRepositories(): void;
}
declare module "_102034_/l1/server/layer_2_application/schedule/evaluateSchedule" {
    /**
     * The occurrence this schedule owes at `now`, or `null` when it owes nothing.
     *
     * @param schedule prose written by the l4 of the module (`trigger.schedule`).
     * @param now the instant the tick handed the module.
     * @param lastRun when the module last ran this schedule, or `null` if it never did.
     * @returns the occurrence timestamp (≤ `now`) still owed, or `null` when the prose is not a schedule
     *          or the occurrence has already run.
     */
    export function evaluateSchedule(schedule: string, now: Date, lastRun: Date | null): Date | null;
}
declare module "_102034_/l1/server/layer_2_controllers/router" {
    import type { BffHandler } from "_102034_/l1/server/layer_2_controllers/contracts";
    export function createServerRouter(): Promise<Map<string, BffHandler>>;
}
declare module "_102034_/l1/workflow/activitiesRebuild" {
    import { type ServerMessagesClient } from "_102034_/l1/server/layer_1_external/collabMessages/client";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { WorkflowActivityStore } from "_102034_/l1/workflow/activitiesStore";
    import type { OccurrenceKey, TaskOccurrencePort } from "_102034_/l1/workflow/contracts";
    export interface RebuildWorkflowActivityPageInput {
        projectId: string;
        moduleId: string;
        cursor?: string;
        pageSize?: number;
        /** Server test seam. Production uses the project-bound messages client. */
        client?: Pick<ServerMessagesClient, 'listModuleTasks'>;
        /** Server test seam. Production uses the Postgres projection. */
        store?: WorkflowActivityStore;
        /** Canonical task port without the projection decorator. */
        basePort?: TaskOccurrencePort;
    }
    export interface WorkflowActivityRebuildFailure {
        ref: OccurrenceKey | null;
        code: string;
    }
    export interface RebuildWorkflowActivityPageResult {
        cursor?: string;
        counts: {
            listed: number;
            refreshed: number;
            absent: number;
            failed: number;
        };
        failures: WorkflowActivityRebuildFailure[];
    }
    /**
     * Rebuild one page of the derived activity index from the canonical task list.
     * A missing local row is not a reason to skip a task. Confirmed absence removes
     * only that ref. A source error does not.
     */
    export function rebuildWorkflowActivityPage(ctx: RequestContext, input: RebuildWorkflowActivityPageInput): Promise<RebuildWorkflowActivityPageResult>;
}
declare module "_102034_/l1/workflow/engine" {
    import type { IClock, ILogger } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AdvanceOccurrenceResult, OccurrenceKey, OccurrencePort, OccurrenceSnapshot, OpenOccurrenceResult, TaskOccurrenceAdvanceResult, TaskOccurrenceOpenResult, TaskOccurrencePort, TaskOccurrenceSnapshot, WorkflowExecutor, WorkflowOrigin, WorkflowRoomChoice, WorkflowTable, WorkflowWakeRequest } from "_102034_/l1/workflow/contracts";
    import { type WorkflowPlanInput } from "_102034_/l1/workflow/plan";
    export { ownerOf } from "_102034_/l1/workflow/plan";
    export type { StepOwner } from "_102034_/l1/workflow/plan";
    /** Caller fields this engine reads. A request context satisfies this. */
    export interface WorkflowEngineContext {
        clock: IClock;
        log: ILogger;
        sessionContext?: {
            person?: {
                mdmId: string;
            } | null;
        };
    }
    export interface WorkflowAdvance {
        from: string;
        to: string;
        actorNow: string | null;
        note?: string;
    }
    export interface WorkflowEngine {
        open(ctx: WorkflowEngineContext, table: WorkflowTable, key: OccurrenceKey, firstStep: string, actorNow: string | null): Promise<OpenOccurrenceResult>;
        advance(ctx: WorkflowEngineContext, table: WorkflowTable, key: OccurrenceKey, command: WorkflowAdvance): Promise<AdvanceOccurrenceResult>;
        find(ctx: WorkflowEngineContext, key: OccurrenceKey): Promise<OccurrenceSnapshot | null>;
    }
    /** Open input for a task occurrence. The title is the occurrence title, not a plan title. */
    export interface TaskWorkflowOpen {
        key: OccurrenceKey;
        plan: WorkflowPlanInput;
        title: string;
        firstStep: string;
        actorNow: string | null;
        owner: string;
        origin: WorkflowOrigin;
        executor: WorkflowExecutor;
        room: WorkflowRoomChoice;
        message?: {
            content: string;
        };
    }
    /** Advance input. `to: 'end'` is the logical close. The caller supplies commandId and expectedRevision. */
    export interface TaskWorkflowAdvance {
        commandId: string;
        expectedRevision: number;
        from: string;
        to: string;
        actorNow: string | null;
        executor: WorkflowExecutor;
        note?: string;
        wake?: WorkflowWakeRequest;
        message?: {
            content: string;
        };
    }
    export interface TaskWorkflowEngine {
        open(ctx: RequestContext, input: TaskWorkflowOpen): Promise<TaskOccurrenceOpenResult>;
        advance(ctx: RequestContext, key: OccurrenceKey, command: TaskWorkflowAdvance): Promise<TaskOccurrenceAdvanceResult>;
        find(ctx: RequestContext, key: OccurrenceKey): Promise<TaskOccurrenceSnapshot | null>;
    }
    export function createWorkflowEngine(port: TaskOccurrencePort): TaskWorkflowEngine;
    export function createWorkflowEngine(port: OccurrencePort): WorkflowEngine;
}
declare module "_102034_/l1/workflow/memoryOccurrence" {
    import type { OccurrencePort } from "_102034_/l1/workflow/contracts";
    export function createMemoryOccurrencePort(): OccurrencePort;
}
declare module "_102034_/l1/workflow/occurrenceRecordId" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    /** Stable opaque record id. Does not log the seed and does not read telemetry userId or actorId. */
    export function occurrenceRecordId(ctx: RequestContext, processId: string, seed?: string): string;
    /**
     * Per-creation copy. The first newId is the occurrence record; later ids delegate to the parent generator.
     * Only the isolated create call may use this context, because an earlier audit or write would consume that first id.
     */
    export function createOccurrenceContext(ctx: RequestContext, recordId: string): RequestContext;
}
declare module "_102034_/l1/workflow/index" {
    export type { AdvanceOccurrenceCommand, AdvanceOccurrenceResult, OccurrenceContext, OccurrenceHistoryEntry, OccurrenceKey, OccurrencePort, OccurrenceRef, OccurrenceSnapshot, OpenOccurrenceResult, WorkflowStepDef, WorkflowStepKind, WorkflowTable, WorkflowExecutor, WorkflowOrigin, WorkflowRoomChoice, WorkflowWake, WorkflowWakeRequest, TaskOccurrenceMessageStatus, TaskOccurrenceHistoryEntry, TaskOccurrenceSnapshot, TaskOccurrenceOpenCommand, TaskOccurrenceAdvanceCommand, TaskOccurrenceOpenResult, TaskOccurrenceAdvanceResult, TaskOccurrencePort, } from "_102034_/l1/workflow/contracts";
    export { createWorkflowEngine, ownerOf, type StepOwner, type WorkflowAdvance, type WorkflowEngine, type WorkflowEngineContext, type TaskWorkflowEngine, type TaskWorkflowOpen, type TaskWorkflowAdvance, } from "_102034_/l1/workflow/engine";
    export { createMemoryOccurrencePort } from "_102034_/l1/workflow/memoryOccurrence";
    export { createMessagesTaskOccurrencePort, type MessagesTaskOccurrencePortOptions, } from "_102034_/l1/workflow/messagesOccurrence";
    export { createMessagesWorkflowIdentities, type MessagesWorkflowIdentitiesOptions, } from "_102034_/l1/workflow/messagesIdentities";
    export { createRuntimeMessagesTaskPort, type RuntimeMessagesClient, type RuntimeMessagesTaskPortOptions, } from "_102034_/l1/workflow/messagesRuntime";
    export type { MessagesWorkflowIdentities } from "_102034_/l1/workflow/messagesTask";
    export { createOccurrenceContext, occurrenceRecordId } from "_102034_/l1/workflow/occurrenceRecordId";
    export { prepareWorkflowPlan, type WorkflowPlan, type WorkflowPlanInput, type WorkflowPlanStep, type WorkflowPlanStepInput, } from "_102034_/l1/workflow/plan";
    export { projectWorkflowActivities, type WorkflowActivitiesSnapshot, type WorkflowActivity, type WorkflowActivityState, } from "_102034_/l1/workflow/activities";
    export type { WorkflowActivityListItem, WorkflowActivityListQuery, WorkflowActivityListResult, WorkflowActivityRefreshResult, WorkflowActivityStore, WorkflowActivitySubject, } from "_102034_/l1/workflow/activitiesStore";
    export { createPostgresWorkflowActivityStore, type PostgresWorkflowActivityDefinitions, type PostgresWorkflowActivityStoreOptions, } from "_102034_/l1/workflow/activitiesPostgres";
    export { withWorkflowActivityProjection } from "_102034_/l1/workflow/activitiesSync";
    export { rebuildWorkflowActivityPage, type RebuildWorkflowActivityPageInput, type RebuildWorkflowActivityPageResult, type WorkflowActivityRebuildFailure, } from "_102034_/l1/workflow/activitiesRebuild";
    export type { ModuleWakeEvent, ModuleWakeReceipt, WorkflowWakeHandler, WorkflowWakeScope, } from "_102034_/l1/workflow/wakeContracts";
    export { workflowWakeCommandId } from "_102034_/l1/workflow/wakeContracts";
    export { registerWorkflowWakeHandler } from "_102034_/l1/workflow/wakeRegistry";
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102034_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102034_/l2/audit/module.defs" {
    export const skill: {
        readonly moduleId: "audit";
        readonly purpose: "Operational audit module for reading change traceability and lifecycle history. Audit log answers who changed what; status history answers how entity state changed over time.";
        readonly pages: readonly ["home", "audit-log", "status-history"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.audit.currentSection", "ui.audit.refreshTick"];
    };
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
        /** Present only when server onboarding is enabled. Paths belong to the client module, not the page being served. */
        onboarding?: {
            entryPath: string;
            moduleBasePath: string;
        };
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
                /** Id of the tab the bar is showing (`app` or `mod-<basePath>`). */
                activeTab: () => string;
                togglePin: (id: string) => void;
                isPinned: (id: string) => boolean;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102034_/l2/audit/module" {
    import type { MasterFrontendModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.audit.currentSection";
        readonly refreshTick: "ui.audit.refreshTick";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: MasterFrontendModuleFrontendDefinition;
}
declare module "_102034_/l2/audit/shared/contracts/audit-log" {
    export type { AuditLogDetailsParams, AuditLogDetailsResponse, AuditLogLoadParams, AuditLogResponse, } from "_102034_/l1/audit/module";
}
declare module "_102034_/l2/audit/shared/contracts/home" {
    export type { AuditHomeResponse } from "_102034_/l1/audit/module";
}
declare module "_102034_/l2/audit/shared/contracts/status-history" {
    export type { AuditStatusHistoryLoadParams, AuditStatusHistoryResponse, } from "_102034_/l1/audit/module";
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
        requestId?: string;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
            requestId?: string;
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    /** The event the shell listens for to send the user back to the collab-auth login. */
    export const BFF_UNAUTHENTICATED_EVENT = "collab-bff-unauthenticated";
    /** Explicit override (email). Empty string clears it and the session cookie takes over again. */
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102034_/l2/audit/web/shared/auditLog" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditLogLoadParams, AuditLogResponse } from "_102034_/l2/audit/shared/contracts/audit-log";
    export function loadAuditLog(input: AuditLogLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditLogResponse>>;
}
declare module "_102034_/l2/audit/web/shared/auditLogDetails" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditLogDetailsParams, AuditLogDetailsResponse } from "_102034_/l2/audit/shared/contracts/audit-log";
    export function loadAuditLogDetails(input: AuditLogDetailsParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditLogDetailsResponse>>;
}
declare module "_102034_/l2/audit/web/shared/formatters" {
    export function formatInteger(value: number | null | undefined): string;
    export function formatDateTime(value: string | null | undefined): string;
    export function formatJson(value: unknown): string;
}
declare module "_102034_/l2/audit/web/desktop/page11/audit-log" {
    import { LitElement } from 'lit';
    import type { AuditLogDetailsResponse, AuditLogResponse } from "_102034_/l2/audit/shared/contracts/audit-log";
    interface AuditLogFilters {
        module: string;
        entityType: string;
        entityId: string;
        actorId: string;
        actorType: string;
        action: string;
        from: string;
        to: string;
    }
    export class AuditWebDesktopPage11AuditLogPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            data: {
                state: boolean;
            };
            details: {
                state: boolean;
            };
            page: {
                state: boolean;
            };
            filters: {
                state: boolean;
            };
        };
        status: string;
        routeError?: string;
        data?: AuditLogResponse;
        details?: AuditLogDetailsResponse;
        page: number;
        filters: AuditLogFilters;
        createRenderRoot(): this;
        connectedCallback(): void;
        private load;
        private handleFilterSubmit;
        private goToPage;
        private loadDiff;
        private card;
        private renderNamedCountList;
        private renderBody;
        render(): any;
    }
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102034_/l2/audit/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditHomeResponse } from "_102034_/l2/audit/shared/contracts/home";
    export function loadAuditHome(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditHomeResponse>>;
}
declare module "_102034_/l2/audit/web/shared/statusHistory" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditStatusHistoryLoadParams, AuditStatusHistoryResponse } from "_102034_/l2/audit/shared/contracts/status-history";
    export function loadAuditStatusHistory(input: AuditStatusHistoryLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditStatusHistoryResponse>>;
}
declare module "_102034_/l2/audit/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { AuditHomeResponse } from "_102034_/l2/audit/shared/contracts/home";
    import type { AuditLogDetailsResponse, AuditLogResponse } from "_102034_/l2/audit/shared/contracts/audit-log";
    import type { AuditStatusHistoryResponse } from "_102034_/l2/audit/shared/contracts/status-history";
    type AuditSection = 'overview' | 'audit-log' | 'status-history';
    export class AuditWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            homeData: {
                state: boolean;
            };
            auditLogData: {
                state: boolean;
            };
            statusHistoryData: {
                state: boolean;
            };
            auditLogDetails: {
                state: boolean;
            };
        };
        currentSection: AuditSection;
        status: string;
        routeError?: string;
        homeData?: AuditHomeResponse;
        auditLogData?: AuditLogResponse;
        statusHistoryData?: AuditStatusHistoryResponse;
        auditLogDetails?: AuditLogDetailsResponse;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private handleRouteChange;
        private navigateWithinModule;
        private loadCurrentRoute;
        private handleNavClick;
        private handleRefreshClick;
        private handleFilterSubmit;
        private handlePageClick;
        private loadDiff;
        private handleLoadDiff;
        private renderOverview;
        private renderNamedCountList;
        private renderAuditLog;
        private renderStatusHistory;
        render(): any;
    }
}
declare module "_102034_/l2/audit/web/desktop/page11/overview" {
    import { LitElement } from 'lit';
    import type { AuditHomeResponse } from "_102034_/l2/audit/shared/contracts/home";
    export class AuditWebDesktopPage11OverviewPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            homeData: {
                state: boolean;
            };
        };
        status: string;
        routeError?: string;
        homeData?: AuditHomeResponse;
        createRenderRoot(): this;
        connectedCallback(): void;
        private load;
        private card;
        private renderNamedCountList;
        private renderOverview;
        render(): any;
    }
}
declare module "_102034_/l2/audit/web/desktop/page11/status-history" {
    import { LitElement } from 'lit';
    import type { AuditStatusHistoryResponse } from "_102034_/l2/audit/shared/contracts/status-history";
    interface StatusHistoryFilters {
        module: string;
        entityType: string;
        entityId: string;
        actorId: string;
        fromStatus: string;
        toStatus: string;
        reasonCode: string;
        from: string;
        to: string;
    }
    export class AuditWebDesktopPage11StatusHistoryPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            data: {
                state: boolean;
            };
            page: {
                state: boolean;
            };
            filters: {
                state: boolean;
            };
        };
        status: string;
        routeError?: string;
        data?: AuditStatusHistoryResponse;
        page: number;
        filters: StatusHistoryFilters;
        createRenderRoot(): this;
        connectedCallback(): void;
        private load;
        private handleFilterSubmit;
        private goToPage;
        private renderNamedCountList;
        private card;
        private renderBody;
        render(): any;
    }
}
declare module "_102034_/l2/audit/web/routes/audit-log" {
    export { AuditWebDesktopHomePage } from "_102034_/l2/audit/web/desktop/page11/home";
}
declare module "_102034_/l2/audit/web/routes/overview" {
    export { AuditWebDesktopHomePage } from "_102034_/l2/audit/web/desktop/page11/home";
}
declare module "_102034_/l2/audit/web/routes/status-history" {
    export { AuditWebDesktopHomePage } from "_102034_/l2/audit/web/desktop/page11/home";
}
declare module "_102034_/l2/audit/web/shared/auditLog.defs" {
    export const skill = "\n# Audit Log Page\n\n## Purpose\n\nRender the change-traceability page for the audit module, focused on the\n`mdm_audit_log` trail.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.auditLog.load`\n- The routine must return:\n  - overview totals for audit activity\n  - grouped cuts by module, routine, actor and action\n  - a paginated event list\n  - enough data to open event details\n\n## Filters\n\n- `module`\n- `entityType`\n- `entityId`\n- `actorId`\n- `actorType`\n- `action`\n- period / date range\n\n## Page Behavior\n\n- Load only when the current pathname is `/audit/audit-log`\n- Use the left aside as the primary navigation\n- Keep the header free of duplicated page links\n- Render summary cards first and the event table after that\n- Provide access to event detail inspection\n- Reserve a detailed remote-record view when a DynamoDB-backed `diff` exists\n\n## Visual Intent\n\n- Diagnostic and table-heavy layout\n- Emphasis on data changes, actor traceability and routine provenance\n- Neutral colors with explicit highlighting for destructive or exceptional\n  actions\n\n## Conceptual Contract\n\n- This page is about immutable records of create, update, delete and restore\n  operations\n- The user should understand that this trail captures what changed and who\n  caused it\n- This page must not be framed as lifecycle/status analytics\n";
}
declare module "_102034_/l2/audit/web/shared/home.defs" {
    export const skill = "\n# Audit Home Page\n\n## Purpose\n\nRender the overview page for the audit module. This page must explain the audit\narchitecture and summarize the two operational trails: audit log and status\nhistory.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.home.load`\n- The routine must return only what the overview page needs:\n  - environment/runtime summary\n  - recent volume cards for audit log and status history\n  - explanation of the difference between the two trails\n  - recent relevant events\n  - grouped distribution by module, entity type and actor\n\n## Page Behavior\n\n- Detect the active section by the current pathname\n- Treat `/audit`, `/audit/index.html` and `/audit/overview` as overview\n- Use the left aside as the primary navigation\n- Do not duplicate page links in the header\n- Render top cards first, then the conceptual comparison block, then condensed\n  lists/tables\n\n## Visual Intent\n\n- Same shell direction as the monitor module\n- Dense operational cards with neutral diagnostic styling\n- Clear comparison block titled `Audit Log vs Status History`\n- Header reserved for title, current context and refresh/filter actions\n\n## Conceptual Contract\n\n- `audit log` answers who changed what\n- `status history` answers how the entity status changed over time\n- The initial operational sources are `mdm_audit_log` and\n  `mdm_status_history`, but the page narrative must be generic enough for\n  future expansion\n";
}
declare module "_102034_/l2/audit/web/shared/statusHistory.defs" {
    export const skill = "\n# Status History Page\n\n## Purpose\n\nRender the lifecycle-trail page for the audit module, focused on the\n`mdm_status_history` trail.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.statusHistory.load`\n- The routine must return:\n  - overview totals for status transitions\n  - grouped cuts by module, entity type and transition\n  - an ordered transition list\n  - enough information to highlight repeated transition patterns and current\n    status when derivable\n\n## Filters\n\n- `module`\n- `entityType`\n- `entityId`\n- `fromStatus`\n- `toStatus`\n- `actorId`\n- `reasonCode`\n- period / date range\n\n## Page Behavior\n\n- Load only when the current pathname is `/audit/status-history`\n- Use the left aside as the primary navigation\n- Keep the header free of duplicated page links\n- Render summary cards first and the ordered transition table after that\n- Highlight common transitions and status flow bottlenecks when the response\n  provides them\n\n## Visual Intent\n\n- Diagnostic, sequence-oriented layout\n- Emphasis on lifecycle flow, transition frequency and semantic reasons\n- Clear distinction from the diff-oriented audit log page\n\n## Conceptual Contract\n\n- This page is about immutable status transitions with semantic context such as\n  `reason`, `reasonCode` and `metadata`\n- The user should understand that this trail captures how status moved over\n  time, not which fields changed\n- This page must not be framed as raw data-diff inspection\n";
}
declare module "_102034_/l2/monitor/module.defs" {
    export const skill: {
        readonly moduleId: "monitor";
        readonly purpose: "Operational monitoring module for system overview, Postgres diagnostics and DynamoDB diagnostics.";
        readonly pages: readonly ["home", "operations", "postgres", "dynamodb"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.monitor.currentSection", "ui.monitor.refreshTick"];
    };
}
declare module "_102034_/l2/monitor/module" {
    import type { MasterFrontendModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.monitor.currentSection";
        readonly refreshTick: "ui.monitor.refreshTick";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: MasterFrontendModuleFrontendDefinition;
}
declare module "_102034_/l2/monitor/shared/contracts/architecture" {
    export interface MonitorArchitectureResponse {
        generatedAt: string;
        architecture: {
            totalTables: number;
            postgresBackedTables: number;
            dynamoBackedTables: number;
            hotBackupTables: number;
            tables: Array<{
                projectId: string;
                moduleId: string;
                repositoryName: string;
                tableName: string;
                description: string;
                purpose: string;
                storageProfile: string;
                backupHot: boolean;
                writeMode: string;
                dynamoTableName: string | null;
                dynamoPartitionKey: string | null;
                dynamoSortKey: string | null;
                dynamoTtlField: string | null;
                detailsInDynamoOnly: boolean;
                localIndexes: Array<{
                    name: string;
                    unique: boolean;
                    columns: string[];
                }>;
            }>;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/dynamodb" {
    export interface MonitorDynamoResponse {
        generatedAt: string;
        dynamodb: {
            runtimeMode: 'memory' | 'postgres';
            region: string;
            tables: Array<{
                tableName: string;
                description?: string | null;
                moduleId?: string | null;
                repositoryName?: string | null;
                storageProfile?: string | null;
                backupHot?: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate?: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/home" {
    export interface MonitorHomeSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorHomeResponse {
        generatedAt: string;
        system: {
            appEnv: string;
            runtimeMode: 'memory' | 'postgres';
            writeBehindEnabled: boolean;
            awsRegion: string;
        };
        bff: {
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<{
                routine: string;
                statusCode: number;
                statusGroup: string;
                errorCode?: string | null;
                finishedAt: string;
            }>;
        };
        recentSeries: MonitorHomeSeriesPoint[];
        postgres: {
            host: string;
            port: number;
            currentDatabase: string;
            availableDatabases: string[];
            tableCount: number;
            missingTableCount: number;
            activeConnections: number;
            cacheHitRate: number | null;
            pendingOutbox: number;
            replicationFailures: number;
        };
        dynamodb: {
            totalTables: number;
            availableTables: number;
            missingTables: number;
            totalItemCount: number;
            metricsAreApproximate?: boolean;
        };
    }
    export interface MonitorStatisticsSeriesResponse {
        generatedAt: string;
        windowSeconds: number;
        totals: {
            total: number;
            success: number;
            clientError: number;
            serverError: number;
            notFound: number;
        };
        series: MonitorHomeSeriesPoint[];
    }
}
declare module "_102034_/l2/monitor/shared/contracts/postgres" {
    export interface MonitorPostgresResponse {
        generatedAt: string;
        postgres: {
            runtimeMode: 'memory' | 'postgres';
            connection: {
                host: string;
                port: number;
                runtimeDatabase: string;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                description?: string | null;
                moduleId?: string | null;
                repositoryName?: string | null;
                storageProfile?: string | null;
                backupHot?: boolean;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-details-dynamodb" {
    export interface MonitorDynamoTableDetailsResponse {
        generatedAt: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        summary: {
            tableStatus: string | null;
            itemCount: number;
            tableSizeBytes: number;
            billingMode: string | null;
            tableClass: string | null;
            metricsAreApproximate?: boolean;
        };
        keys: {
            partitionKey: string | null;
            sortKey: string | null;
        };
        attributeDefinitions: Array<{
            name: string;
            type: string;
        }>;
        globalSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
        localSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-details-postgres" {
    export interface MonitorPostgresTableDetailsResponse {
        generatedAt: string;
        databaseName: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        metrics: {
            rowCount: number;
            totalSizeBytes: number;
        };
        columns: Array<{
            name: string;
            dataType: string;
            isNullable: boolean;
            defaultValue: string | null;
        }>;
        primaryKey: string[];
        indexes: Array<{
            name: string;
            unique: boolean;
            method: string;
            columns: string[];
        }>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-inspect-dynamodb" {
    export interface MonitorDynamoTableInspectResponse {
        generatedAt: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        columns: Array<{
            name: string;
            type: string;
            filterable: boolean;
        }>;
        pagination: {
            pageSize: number;
            cursor: string | null;
            nextCursor: string | null;
            hasNextPage: boolean;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        metricsAreApproximate?: boolean;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-inspect-postgres" {
    export interface MonitorPostgresTableInspectResponse {
        generatedAt: string;
        databaseName: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        columns: Array<{
            name: string;
            dataType: string;
            isNullable: boolean;
        }>;
        pagination: {
            page: number;
            pageSize: number;
            totalRows: number;
            totalPages: number;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        order: {
            primary: string[];
            fallback: string;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/tests" {
    export type MonitorTestCaseStatus = 'pass' | 'fail' | 'inconclusive' | 'skipped' | 'knownFail' | 'expectedRed' | 'blocked' | 'moduleOnly';
    export interface MonitorTestCaseResult {
        module: string;
        page: string;
        id: string;
        routine: string;
        status: MonitorTestCaseStatus;
        ok: boolean;
        statusCode: number;
        durationMs: number;
        errorCode: string | null;
        errorMessage: string | null;
        reason: string;
        /** Handler stage the producer classified. Present on catalog cases. */
        stage?: string;
        /** Catalog `source` — who wrote the expectation. */
        expectationSource?: string;
        /** Catalog `expectation` text. */
        expectation?: string;
    }
    export interface MonitorTestRunSummary {
        runId: string;
        traceId: string;
        startedAt: string;
        finishedAt: string;
        /** ProjectMode from l5/project.json. */
        appEnv: string;
        appEnvSource?: string;
        serverAppEnv?: string;
        scope: {
            moduleId?: string;
            page?: string;
        };
        total: number;
        passed: number;
        failed: number;
        knownFail: number;
        expectedRed?: number;
        /** Catalog cases reported but not executed (`runner: 'module'`). Absent on a run from an older server. */
        moduleOnly?: number;
        blocked?: number;
        inconclusive: number;
        skipped: number;
        /** True when the scope had no registered suite. A zero-case run is not a pass. */
        untested?: boolean;
        untestedReason?: string;
        cases: MonitorTestCaseResult[];
    }
    export interface MonitorTestPageCase {
        id: string;
        routine: string;
        mutating: boolean;
        expect: {
            ok: boolean;
            errorCode?: string;
            minItems?: number;
            shape?: 'object' | 'array' | 'paginated';
            itemsKey?: string;
        };
    }
    export interface MonitorTestModule {
        moduleId: string;
        projectId: string;
        variantPolicy?: string;
        untestedPages?: Array<{
            page: string;
            reason: string;
        }>;
        pages: Array<{
            page: string;
            variant: string;
            path: string;
            loadError?: string;
            cases: MonitorTestPageCase[];
        }>;
    }
    export interface MonitorTestsListResponse {
        appEnv: string;
        appEnvSource?: string;
        serverAppEnv?: string;
        executionEnabled: boolean;
        modules: MonitorTestModule[];
        recentRuns: MonitorTestRunSummary[];
    }
    export interface MonitorTestsResultsResponse {
        recentRuns: MonitorTestRunSummary[];
    }
}
declare module "_102034_/l2/monitor/web/shared/architecture" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorArchitectureResponse } from "_102034_/l2/monitor/shared/contracts/architecture";
    export function loadMonitorArchitecture(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorArchitectureResponse>>;
}
declare module "_102033_/l2/shared/chartRuntime" {
    import type { ECharts as EChartsInstance } from 'echarts/core';
    export type { ECharts, EChartsCoreOption } from 'echarts/core';
    type EChartsRuntime = {
        init(element: HTMLElement, theme?: string | object, options?: object): EChartsInstance;
    };
    global {
        interface Window {
            echarts?: EChartsRuntime;
            collabEChartsRuntime?: Promise<EChartsRuntime>;
        }
    }
    /** Full local ECharts build shared by Studio and published applications; never uses a CDN. */
    export function loadECharts(): Promise<EChartsRuntime>;
    /**
     * Handlers for ECharts events, by event name (`click`, `legendselectchanged`, `datazoom`, …).
     *
     * ECharts events do NOT reach the DOM: they are emitted on the instance via `chart.on(...)`, so
     * `@chartclick=${…}` in a Lit template is a listener that never fires — and it COMPILES, because any
     * `@name` is a valid Lit binding. A generated page wrote exactly that, which is why the handlers must
     * come through the directive instead.
     */
    export type ChartEvents = Record<string, (params: never) => void>;
    /**
     * Bind an ECharts option to the element this directive sits on.
     *
     * @param option a full EChartsCoreOption. Every chart type and component this runtime registers above is
     *        available — no `echarts.use()` needed at the call site, which is the whole point of the module:
     *        an unregistered piece renders BLANK with no error.
     * @param events optional handlers, e.g. `{ click: (p) => this.selectCategory(p.name) }`. Rebound on every
     *        update, so a closure over fresh state is always the one that runs.
     *
     * The element must have a height (ECharts measures its container; a container of height 0 draws nothing).
     */
    export const chart: any;
}
declare module "_102034_/l2/monitor/web/shared/dynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorDynamoResponse } from "_102034_/l2/monitor/shared/contracts/dynamodb";
    export function loadMonitorDynamodb(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/homeFormatters" {
    export function formatInteger(value: number | null | undefined): string;
    export function formatPercent(value: number | null | undefined): string;
    export function formatBytes(value: number | null | undefined): string;
    export function formatDateTime(value: string | null | undefined): string;
    export function formatTime(value: string | null | undefined): string;
    export function formatMonitorValue(value: unknown): string;
    export function formatStatusLabel(statusGroup: string): string;
}
declare module "_102034_/l2/monitor/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorHomeResponse } from "_102034_/l2/monitor/shared/contracts/home";
    export function loadMonitorHome(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorHomeResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/operations" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorOperationsSummaryRequest, MonitorOperationsSummaryResponse } from "_102034_/l2/monitor/shared/contracts/operations";
    export function loadMonitorOperationsSummary(params: MonitorOperationsSummaryRequest, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorOperationsSummaryResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/postgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorPostgresResponse } from "_102034_/l2/monitor/shared/contracts/postgres";
    export function loadMonitorPostgres(databaseName?: string, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/process" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorProcessResponse } from "_102034_/l2/monitor/shared/contracts/process";
    import type { RuntimeMetricSample, RuntimeMetricsResponse } from "_102034_/l2/monitor/shared/contracts/runtimeMetrics";
    export function loadMonitorProcess(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorProcessResponse>>;
    export const RUNTIME_METRIC_OPTIONS: readonly [{
        readonly key: "rssBytes";
        readonly label: "RSS";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "heapUsedBytes";
        readonly label: "Heap usado";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "heapTotalBytes";
        readonly label: "Heap total";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "heapLimitBytes";
        readonly label: "Limite do heap";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "externalBytes";
        readonly label: "Memória externa";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "systemFreeMemBytes";
        readonly label: "Memória livre do servidor";
        readonly unit: "MB";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "cpuPercent";
        readonly label: "CPU do processo";
        readonly unit: "%";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "eventLoopUtilization";
        readonly label: "Utilização do event loop";
        readonly unit: "%";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "eventLoopDelayP95Ms";
        readonly label: "Atraso do event loop p95";
        readonly unit: "ms";
        readonly value: (sample: RuntimeMetricSample) => number;
    }, {
        readonly key: "systemLoadAvg1m";
        readonly label: "Load average 1m";
        readonly unit: "";
        readonly value: (sample: RuntimeMetricSample) => number;
    }];
    export type RuntimeMetricKey = typeof RUNTIME_METRIC_OPTIONS[number]['key'];
    export interface RuntimeMetricChartPoint {
        timestamp: number;
        value: number;
    }
    export interface RuntimeMetricChartSeries {
        processInstance: string;
        points: RuntimeMetricChartPoint[];
    }
    export interface RuntimeMetricChart {
        series: RuntimeMetricChartSeries[];
        minValue: number;
        maxValue: number;
    }
    export function loadMonitorRuntimeMetrics(input?: {
        minutes?: number;
        limit?: number;
    }, options?: BffClientOptions): Promise<{
        ok: boolean;
        data: RuntimeMetricsResponse | null;
        error: {
            code: string;
            message: string;
        } | null;
    }>;
    export function latestRuntimeMetricSamples(samples: RuntimeMetricSample[]): RuntimeMetricSample[];
    export function averageRuntimeMetric(samples: RuntimeMetricSample[], value: (sample: RuntimeMetricSample) => number): number | null;
    export function buildRuntimeMetricChart(samples: RuntimeMetricSample[], key: RuntimeMetricKey): RuntimeMetricChart;
}
declare module "_102034_/l2/monitor/web/shared/series" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorStatisticsSeriesResponse } from "_102034_/l2/monitor/shared/contracts/home";
    export function loadMonitorSeries(windowSeconds?: number, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorStatisticsSeriesResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/abend" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorAbendResponse, MonitorClientErrorsResponse } from "_102034_/l2/monitor/shared/contracts/abend";
    export function loadMonitorAbend(params: {
        module?: string;
        limit?: number;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorAbendResponse>>;
    export function loadMonitorClientErrors(params: {
        limit?: number;
        sinceHours?: number;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorClientErrorsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/trace" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorTraceResponse } from "_102034_/l2/monitor/shared/contracts/trace";
    export interface MonitorTraceLoadParams {
        requestId?: string;
        traceId?: string;
    }
    export function loadMonitorTrace(params: MonitorTraceLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorTraceResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tests" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorTestRunSummary, MonitorTestsListResponse, MonitorTestsResultsResponse } from "_102034_/l2/monitor/shared/contracts/tests";
    export function loadMonitorTestsList(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorTestsListResponse>>;
    export function runMonitorTests(params: {
        moduleId?: string;
        page?: string;
        skipMutating?: boolean;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorTestRunSummary>>;
    export function loadMonitorTestsResults(params: {
        moduleId?: string;
        page?: string;
        runId?: string;
        limit?: number;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorTestsResultsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableDetailsDynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorDynamoTableDetailsResponse } from "_102034_/l2/monitor/shared/contracts/table-details-dynamodb";
    export function loadMonitorDynamoTableDetails(input: {
        tableName: string;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoTableDetailsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableDetailsPostgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorPostgresTableDetailsResponse } from "_102034_/l2/monitor/shared/contracts/table-details-postgres";
    export function loadMonitorPostgresTableDetails(input: {
        databaseName?: string;
        tableName: string;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresTableDetailsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableInspectDynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorDynamoTableInspectResponse } from "_102034_/l2/monitor/shared/contracts/table-inspect-dynamodb";
    export function loadMonitorDynamoTableInspect(input: {
        tableName: string;
        cursor?: string;
        filters?: Record<string, string>;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoTableInspectResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableInspectPostgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { MonitorPostgresTableInspectResponse } from "_102034_/l2/monitor/shared/contracts/table-inspect-postgres";
    export function loadMonitorPostgresTableInspect(input: {
        databaseName?: string;
        tableName: string;
        page?: number;
        filters?: Record<string, string>;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresTableInspectResponse>>;
}
declare module "_102034_/l2/monitor/web/desktop/page11/home" {
    import { LitElement, type PropertyValues } from 'lit';
    import { type RuntimeMetricKey } from "_102034_/l2/monitor/web/shared/process";
    import type { MonitorArchitectureResponse } from "_102034_/l2/monitor/shared/contracts/architecture";
    import type { MonitorDynamoResponse } from "_102034_/l2/monitor/shared/contracts/dynamodb";
    import type { MonitorHomeResponse, MonitorHomeSeriesPoint, MonitorStatisticsSeriesResponse } from "_102034_/l2/monitor/shared/contracts/home";
    import type { MonitorOperationsSummaryResponse, MonitorOperationsWindow } from "_102034_/l2/monitor/shared/contracts/operations";
    import type { MonitorPostgresResponse } from "_102034_/l2/monitor/shared/contracts/postgres";
    import type { MonitorProcessResponse } from "_102034_/l2/monitor/shared/contracts/process";
    import type { RuntimeMetricsResponse } from "_102034_/l2/monitor/shared/contracts/runtimeMetrics";
    import type { MonitorAbendResponse, MonitorClientErrorsResponse } from "_102034_/l2/monitor/shared/contracts/abend";
    import type { MonitorTraceResponse } from "_102034_/l2/monitor/shared/contracts/trace";
    import type { MonitorTestsListResponse } from "_102034_/l2/monitor/shared/contracts/tests";
    import type { MonitorDynamoTableDetailsResponse } from "_102034_/l2/monitor/shared/contracts/table-details-dynamodb";
    import type { MonitorPostgresTableDetailsResponse } from "_102034_/l2/monitor/shared/contracts/table-details-postgres";
    import type { MonitorDynamoTableInspectResponse } from "_102034_/l2/monitor/shared/contracts/table-inspect-dynamodb";
    import type { MonitorPostgresTableInspectResponse } from "_102034_/l2/monitor/shared/contracts/table-inspect-postgres";
    /** The shape `/session/info` answers with (see the runtime's startServer). */
    interface MonitorSessionInfo {
        authenticated: boolean;
        email: string | null;
        userId: string | null;
        allAuthorities: string[];
        realAuthorities: string[];
        overridden: boolean;
        canOverride: boolean;
        appEnv: string;
        expiresAt: string | null;
        enforcement: {
            authentication: boolean;
            actors: boolean;
        };
        /** From the publish manifest, when the builder starts writing one. */
        deploy?: {
            commit?: string;
            builtAt?: string;
            builtBy?: string;
        } | null;
    }
    type MonitorSection = 'overview' | 'operations' | 'architecture' | 'postgres' | 'dynamodb' | 'process' | 'abend' | 'trace' | 'tests';
    type MonitorRoute = {
        section: 'overview';
        kind: 'section';
    } | {
        section: 'operations';
        kind: 'section';
        window?: MonitorOperationsWindow;
        module?: string;
    } | {
        section: 'architecture';
        kind: 'section';
    } | {
        section: 'postgres';
        kind: 'section';
        databaseName?: string;
    } | {
        section: 'dynamodb';
        kind: 'section';
    } | {
        section: 'process';
        kind: 'section';
    } | {
        section: 'abend';
        kind: 'section';
        module?: string;
    } | {
        section: 'trace';
        kind: 'section';
        requestId?: string;
        traceId?: string;
    } | {
        section: 'tests';
        kind: 'section';
    } | {
        section: 'postgres';
        kind: 'inspect' | 'details';
        tableName: string;
        databaseName?: string;
        page?: number;
        filters: Record<string, string>;
    } | {
        section: 'dynamodb';
        kind: 'inspect' | 'details';
        tableName: string;
        cursor?: string;
        cursorStack: string[];
        filters: Record<string, string>;
    };
    export class MonitorWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            currentRoute: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            homeData: {
                state: boolean;
            };
            operationsData: {
                state: boolean;
            };
            copiedOperationsSummary: {
                state: boolean;
            };
            homeSeries: {
                state: boolean;
            };
            seriesMeta: {
                state: boolean;
            };
            architectureData: {
                state: boolean;
            };
            postgresData: {
                state: boolean;
            };
            dynamodbData: {
                state: boolean;
            };
            selectedDatabaseName: {
                state: boolean;
            };
            postgresInspectData: {
                state: boolean;
            };
            postgresDetailsData: {
                state: boolean;
            };
            dynamoInspectData: {
                state: boolean;
            };
            dynamoDetailsData: {
                state: boolean;
            };
            abendData: {
                state: boolean;
            };
            clientErrorsData: {
                state: boolean;
            };
            copiedAbendId: {
                state: boolean;
            };
            processData: {
                state: boolean;
            };
            runtimeMetricsData: {
                state: boolean;
            };
            selectedRuntimeMetric: {
                state: boolean;
            };
            traceData: {
                state: boolean;
            };
            traceSearchInput: {
                state: boolean;
            };
            testsData: {
                state: boolean;
            };
            testsRunning: {
                state: boolean;
            };
            copiedTestsRun: {
                state: boolean;
            };
            sessionInfo: {
                state: boolean;
            };
            overrideDraft: {
                state: boolean;
            };
        };
        /** `/session/info`: who is logged in, the project mode, and which authorities the session acts with. */
        sessionInfo: MonitorSessionInfo | null;
        overrideDraft: string;
        currentSection: MonitorSection;
        currentRoute: MonitorRoute;
        status: string;
        routeError?: string;
        homeData?: MonitorHomeResponse;
        operationsData?: MonitorOperationsSummaryResponse;
        copiedOperationsSummary?: boolean;
        homeSeries?: MonitorHomeSeriesPoint[];
        seriesMeta?: MonitorStatisticsSeriesResponse;
        architectureData?: MonitorArchitectureResponse;
        postgresData?: MonitorPostgresResponse;
        dynamodbData?: MonitorDynamoResponse;
        selectedDatabaseName?: string;
        postgresInspectData?: MonitorPostgresTableInspectResponse;
        postgresDetailsData?: MonitorPostgresTableDetailsResponse;
        dynamoInspectData?: MonitorDynamoTableInspectResponse;
        dynamoDetailsData?: MonitorDynamoTableDetailsResponse;
        abendData?: MonitorAbendResponse;
        clientErrorsData?: MonitorClientErrorsResponse;
        copiedAbendId?: string;
        processData?: MonitorProcessResponse;
        runtimeMetricsData?: RuntimeMetricsResponse;
        selectedRuntimeMetric: RuntimeMetricKey;
        traceData?: MonitorTraceResponse;
        traceSearchInput: string;
        testsData?: MonitorTestsListResponse;
        testsRunning: boolean;
        copiedTestsRun?: boolean;
        private overviewPollTimer;
        private runtimeMetricsChart?;
        private runtimeMetricsChartHost?;
        private runtimeMetricsChartResizeObserver?;
        private runtimeMetricsChartGeneration;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        protected updated(changedProperties: PropertyValues<this>): void;
        private readonly handleLocationChange;
        private readonly handleVisibilityChange;
        private loadRouteFromLocation;
        private navigate;
        private startOverviewPolling;
        private stopOverviewPolling;
        private refreshOverviewSeries;
        private toBlockingError;
        private routeErrorMessage;
        private loadActiveRoute;
        private renderRouteError;
        private refreshCurrentSection;
        private handleNavClick;
        private handleDatabaseChange;
        private handlePostgresInspectFilters;
        private handleDynamoInspectFilters;
        private renderBreadcrumb;
        private renderStorageProfile;
        private severityClass;
        private copyOperationsSummary;
        private handleOperationsFilters;
        private renderOperations;
        /**
         * Who am I, where am I, and what am I acting as — the first thing to know before reading any number
         * below it. The data comes from `/session/info` (the claims live in an httpOnly cookie, so the page
         * cannot read them itself), and the authority selector only appears where the server allows it:
         * `development`/`presentation`. The REAL authorities stay visible next to the override, so a
         * presentation demo is never mistaken for the real user's access.
         */
        private renderSessionCard;
        /** The last test run, in one line: it is the fastest read on whether the module still works. */
        private renderLastTestRun;
        /** Producer names, not a shortened label. Untested is never a green empty run. */
        private renderRunCounts;
        private testRunTone;
        private loadSessionInfo;
        private applyAuthorityOverride;
        /**
         * PRUNED on 2026-08-19 to what is acted upon: the session (who/where/deploy), the last test run, the
         * state of the stores, what ran and what failed. The four top counters were zero-or-noise next to the
         * routine list, the "Postgres runtime target" block was infrastructure trivia, and the live series chart
         * was decorative — the numbers that matter are in the sections that own them.
         */
        private renderOverview;
        private renderPostgresTableLinks;
        private renderDynamoTableLinks;
        private renderArchitecture;
        private renderPostgres;
        private renderDynamodb;
        private renderPostgresInspect;
        private renderPostgresDetails;
        private renderDynamoInspect;
        private renderDynamoDetails;
        private handleTraceSearch;
        private handleRuntimeMetricSelection;
        private releaseRuntimeMetricsChart;
        private disposeRuntimeMetricsChart;
        private syncRuntimeMetricsChart;
        private renderRuntimeMetricsChart;
        private renderProcess;
        private renderTrace;
        /** LLM-friendly plain-text block for one abend entry (paste-ready). */
        private buildAbendClipboardText;
        private copyAbendEntry;
        /** LLM-friendly plain-text block for one frontend error entry. */
        private buildClientErrorClipboardText;
        private copyClientErrorEntry;
        private renderClientErrors;
        private renderAbend;
        private handleRunTests;
        private renderTestStatusBadge;
        private truncateTestText;
        private copyLastTestRun;
        private renderTests;
        private renderMetricCard;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/abend" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorAbendPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/architecture" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorArchitecturePage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102034_/l2/monitor/web/desktop/page11/aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102029_/l2/contracts/bootstrap";
    export class MonitorWebDesktopAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/dynamodb" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorDynamodbPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/header" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102029_/l2/contracts/bootstrap";
    export class MonitorWebDesktopHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/operations" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorOperationsPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/overview" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorOverviewPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/postgres" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorPostgresPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/process" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorProcessPage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/routes/releases" {
    import { LitElement } from 'lit';
    interface ReleaseItem {
        id: string;
        active: boolean;
        createdAt: string;
    }
    interface LogsTail {
        app: string;
        file: string;
        stream: 'out' | 'error';
        updatedAt: string | null;
        available: Array<{
            app: string;
            file: string;
            updatedAt: string | null;
        }>;
        lines: string[];
    }
    export class MonitorWebDesktopReleasesPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            busy: {
                state: boolean;
            };
            active: {
                state: boolean;
            };
            releases: {
                state: boolean;
            };
            logStream: {
                state: boolean;
            };
            logApp: {
                state: boolean;
            };
            logFile: {
                state: boolean;
            };
            logTargets: {
                state: boolean;
            };
            logLines: {
                state: boolean;
            };
        };
        status: string;
        busy: boolean;
        active: string | null;
        releases: ReleaseItem[];
        logStream: 'out' | 'error';
        logApp: string;
        logFile: string;
        logTargets: LogsTail['available'];
        logLines: string[];
        constructor();
        createRenderRoot(): this;
        connectedCallback(): void;
        private loadReleases;
        private loadLogs;
        private changeLogApp;
        private activate;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/releases" {
    import { MonitorWebDesktopReleasesPage } from "_102034_/l2/monitor/web/routes/releases";
    export class MonitorReleasesPage extends MonitorWebDesktopReleasesPage {
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/trace" {
    import { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
    export class MonitorTracePage extends MonitorWebDesktopHomePage {
        connectedCallback(): void;
    }
}
declare module "_102034_/l2/monitor/web/routes/abend" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/architecture" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/config" {
    import { LitElement } from 'lit';
    export class MonitorWebDesktopConfigPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            json: {
                state: boolean;
            };
            busy: {
                state: boolean;
            };
        };
        status: string;
        json: string;
        busy: boolean;
        createRenderRoot(): this;
        connectedCallback(): void;
        private loadConfig;
        private copyJson;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/routes/dynamodb-table" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/dynamodb" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/messagesLogsState" {
    import type { MonitorLogApp, MonitorLogEntry, MonitorLogPage, MonitorLogStream } from "_102034_/l2/monitor/shared/contracts/logs";
    export type MessagesLogsPhase = 'loading' | 'loading-more' | 'error' | 'empty' | 'limited' | 'source-changed' | 'result';
    export interface MessagesLogsQuery {
        app: MonitorLogApp;
        stream: MonitorLogStream;
        /** ISO UTC with an explicit zone, or empty when the time filter is off. */
        startAt: string;
        text: string;
    }
    export interface MessagesLogsState {
        generation: number;
        mounted: boolean;
        phase: MessagesLogsPhase;
        query: MessagesLogsQuery;
        entries: MonitorLogEntry[];
        nextCursor: string | null;
        hasMore: boolean;
        limited: boolean;
        file: string;
        errorMessage: string;
        pendingCursor: string | null;
    }
    /** Start at fixed when a screen is created: one hour before `now`, whole seconds, ISO UTC. */
    export function messagesLogsInitialStartAt(now: Date): string;
    export function createMessagesLogsState(now?: Date): MessagesLogsState;
    /** New mount. In-flight responses from the previous mount no longer match. */
    export function connectMessagesLogs(state: MessagesLogsState): MessagesLogsState;
    export function disconnectMessagesLogs(state: MessagesLogsState): MessagesLogsState;
    export function isCurrentMessagesLogs(state: MessagesLogsState, generation: number): boolean;
    export function beginMessagesLogsQuery(state: MessagesLogsState, query: MessagesLogsQuery): MessagesLogsState;
    export function applyMessagesLogsPage(state: MessagesLogsState, generation: number, page: MonitorLogPage): MessagesLogsState;
    export function failMessagesLogsQuery(state: MessagesLogsState, generation: number, message: string): MessagesLogsState;
    export function markMessagesLogsSourceChanged(state: MessagesLogsState, generation: number): MessagesLogsState;
    export function beginMessagesLogsLoadMore(state: MessagesLogsState): MessagesLogsState;
    export function applyMessagesLogsOlderPage(state: MessagesLogsState, generation: number, requestedCursor: string, page: MonitorLogPage): MessagesLogsState;
    export function failMessagesLogsLoadMore(state: MessagesLogsState, generation: number, message: string): MessagesLogsState;
    /** datetime-local components are the browser's local wall clock. Empty means no time filter. */
    export function startAtLocalToIso(value: string): {
        ok: true;
        iso: string;
    } | {
        ok: false;
        error: string;
    };
    /** `YYYY-MM-DDTHH:mm:ss` in the browser's local zone, for a datetime-local field. */
    export function startAtIsoToLocal(iso: string): string;
    /** Zone name and the offset of this instant. Empty when `iso` is not a time. */
    export function messagesLogsStartAtContext(iso: string): string;
    /** One displayed line block: the UTC timestamp (when the source had one) and the message. Copy uses the same text. */
    export function messagesLogsEntryLine(entry: MonitorLogEntry): string;
    export function messagesLogsBody(state: MessagesLogsState): string;
    export const messagesLogsCopyLabelsEn: {
        readonly processApi: "API";
        readonly processWorker: "Worker";
        readonly outputStandard: "Standard output";
        readonly outputError: "Error output";
        readonly startAtLocal: "Start at";
        readonly startAtUtc: "Start at (UTC)";
        readonly messageContains: "Message contains";
    };
    export type MessagesLogsCopyLabels = {
        [K in keyof typeof messagesLogsCopyLabelsEn]: string;
    };
    export function messagesLogsCopyText(state: MessagesLogsState, labels?: MessagesLogsCopyLabels): string;
    export function messagesLogsCanCopy(state: MessagesLogsState): boolean;
    export function messagesLogsCanLoadMore(state: MessagesLogsState): boolean;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102034_/l2/monitor/web/routes/messagesText" {
    import type { MessagesLogsCopyLabels } from "_102034_/l2/monitor/web/routes/messagesLogsState";
    /** User-facing strings for the Collab Messages log panel. Default language is `en`. */
    export interface MessagesPageText {
        startAt: string;
        startAtHelp: string;
        invalidStartAt: string;
        logSource: string;
        apiStandardOutput: string;
        apiErrorOutput: string;
        workerStandardOutput: string;
        workerErrorOutput: string;
        copied: string;
        copyFailed: string;
        processApi: string;
        processWorker: string;
        outputStandard: string;
        outputError: string;
        startAtUtc: string;
        messageContains: string;
    }
    export function messagesPageText(): MessagesPageText;
    export function messagesPageCopyLabels(text: MessagesPageText): MessagesLogsCopyLabels;
}
declare module "_102034_/l2/monitor/web/routes/messages" {
    import { LitElement } from 'lit';
    import type { MonitorMessagesStatusResponse } from "_102034_/l2/monitor/shared/contracts/messages";
    import { type MessagesLogsState } from "_102034_/l2/monitor/web/routes/messagesLogsState";
    export class MonitorWebDesktopMessagesPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            busy: {
                state: boolean;
            };
            payload: {
                state: boolean;
            };
            logs: {
                state: boolean;
            };
            draftStartAt: {
                state: boolean;
            };
            draftText: {
                state: boolean;
            };
            startAtError: {
                state: boolean;
            };
            copyNotice: {
                state: boolean;
            };
        };
        status: string;
        busy: boolean;
        payload: MonitorMessagesStatusResponse | null;
        logs: MessagesLogsState;
        /** Same instant as `logs.query.startAt`, fixed when this screen is created. */
        draftStartAt: string;
        draftText: string;
        startAtError: string;
        copyNotice: string;
        private static sourceSeq;
        private readonly sourceGroup;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private reload;
        private loadStatus;
        private selectLogs;
        private applyFilters;
        private clearFilters;
        private onFilterKeydown;
        private loadOlder;
        private logScroll;
        private restoreLogScroll;
        private copyLogs;
        private fetchLogs;
        private storageError;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/routes/operations" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/overview" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/postgres-table" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/postgres" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/process" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/tests" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/routes/trace" {
    export { MonitorWebDesktopHomePage } from "_102034_/l2/monitor/web/desktop/page11/home";
}
declare module "_102034_/l2/monitor/web/shared/dynamodb.defs" {
    export const skill = "\n# Monitor DynamoDB Page\n\n## Purpose\n\nRender the DynamoDB diagnostics page for the monitor module.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.dynamodb.load`\n- The routine must return:\n  - region\n  - summary of available/missing tables\n  - table status, item count and size\n\n## Page Behavior\n\n- Load only when the current pathname is `/monitor/dynamodb`\n- Render summary cards first\n- Render a table with per-table status and storage information\n\n## Layout Intent\n\n- Compact operational table\n- Highlight missing or unavailable tables clearly\n";
}
declare module "_102034_/l2/monitor/web/shared/home.defs" {
    export const skill = "\n# Monitor Home Page\n\n## Purpose\n\nRender the operational home page for the monitor module using a single\naggregated BFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.home.load`\n- The routine must return only what the overview page needs:\n  - system/runtime summary\n  - BFF overview counts\n  - by-routine ranking\n  - recent failures\n  - recent execution series\n  - condensed Postgres and DynamoDB status cards\n\n## Page Behavior\n\n- Detect the active section by the current pathname\n- Treat `/monitor`, `/monitor/index.html` and `/monitor/overview` as overview\n- Render a header with refresh status and a manual refresh button\n- Show dense operational cards first\n- Show ranked routine activity and recent failures\n- Keep the page compatible with the master shell aside/header\n\n## Shared Files\n\n- `web/shared/home.ts` owns the BFF call\n- `web/shared/homeFormatters.ts` owns reusable formatting helpers\n\n## Layout Intent\n\n- Fast scan for operations\n- Dense but readable dashboard\n- Neutral colors with explicit severity accents\n- Tailwind-first styling in light DOM\n";
}
declare module "_102034_/l2/monitor/web/shared/postgres.defs" {
    export const skill = "\n# Monitor Postgres Page\n\n## Purpose\n\nRender a focused Postgres diagnostics page for the monitor module.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.postgres.load`\n- The routine must return:\n  - database activity summary\n  - cache hit ratio\n  - waiting locks\n  - queue and cache counts\n  - known application tables with row counts and total size\n\n## Page Behavior\n\n- Load only when the current pathname is `/monitor/postgres`\n- Render top-level health cards\n- Render queue/cache cards\n- Render a table of known Postgres tables\n\n## Layout Intent\n\n- Diagnostic, table-heavy layout\n- Emphasis on operational bottlenecks and storage footprint\n";
}
declare module "_102034_/l2/shared/bff-client" {
    export function execBff<TData = unknown>(routine: string, params: unknown): Promise<{
        ok: boolean;
        data: TData | null;
        error: {
            code: string;
            message: string;
            details?: unknown;
        } | null;
    }>;
}
declare module "_102034_/l4/ontology/ddm.defs" {
    export const ddm: {
        readonly schemaVersion: "2026-09-17-ddm-ontology-v1";
        readonly family: "ddm";
        readonly title: "Derived data of a module";
        readonly description: "What is recalculated from transactional and master data: a metric, a summary, an aggregate, a series in time. It has no writer, no state and no business key of its own.";
        readonly record: {
            readonly fields: {
                readonly "<window>": {
                    readonly type: "timestamp";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "The start of the window this row summarises — the time column of the series (the `time_bucket` of the aggregate). Present whenever the summary is over time.";
                };
                readonly "<groupKey>": {
                    readonly type: "string";
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "One key per dimension the summary is grouped by: the id of a master record, the id of a row of a tdm table, or a code. Indexed, because every read filters by it.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly description: "The JSONB document, and where every measure lives. A column exists because something filters, sorts or deduplicates by it; a summary is filtered by its window and its groups, never by its numbers, so a measure is never a column.";
                    readonly fields: {
                        readonly "<measure>": {
                            readonly type: "number";
                            readonly required: true;
                            readonly derived: true;
                            readonly description: "One key per number: a count, a sum, an average, a maximum. Always derived — nobody ever writes one.";
                        };
                    };
                };
            };
        };
        readonly recommendations: readonly ["Nobody writes a `ddm` row: every field is `derived`. If a person can type it, the entity is `tdm`.", "No lifecycle and no transition: a summary does not change state, it is recalculated.", "No unique key per row: the window plus the group keys already identify the row, and the recalculation rewrites it.", "Name the source: a `ddm` entity summarises rows of a named `tdm` table (or of the master records), and its description says which one and over which window.", "The window and the group keys are the columns, and every one of them is indexed. Every measure lives inside `details`: nothing filters by a number, and a column with no index is refused.", "`storage.kind: 'timeSeries'` when the rows are a series in time and are stored as a hypertable; `relational` for a plain rollup table refreshed as a whole.", "A value that follows from ONE row of a `tdm` table — a status implied by its own dates, the total of its own embedded lines, or of lines linked to it by FK — is not a `ddm` entity: it is a field of that row marked `derived`."];
        readonly capabilities: {
            readonly "aggregate.byWindow": {
                readonly source: "table";
                readonly sentence: "Summarises the rows of a transactional table by time window and by group · a Timescale continuous aggregate (time_bucket + GROUP BY) declared as a statement of viewDefinitions in the persistence of the module and applied after the tables are created · every dashboard and every counter by period · it runs only where the timescaledb extension is available: the bootstrap warns and skips the statement otherwise, and the in-memory runtime of the preview has none of it";
                readonly platform: "partial";
                readonly evidence: "l1/monitor/persistence.ts:91-117 (the living example); l1/server/layer_1_external/persistence/schemaBootstrap.ts:342-358 (applyViewDefinitions), :340 (the skip pattern), :158-172 (the extension check); registry.ts:511-524 (viewDefinitions are read from the module persistence)";
            };
            readonly "store.timeSeries": {
                readonly source: "table";
                readonly sentence: "Keeps the rows as a series chunked by time, so a window is read without touching the whole table · timescale.hypertable of the TableDefinition, turned into create_hypertable(table, timeColumn, chunk_time_interval) · a series read by period · non-fatal: when the extension is missing the table stays an ordinary one and only a warning is written";
                readonly platform: "partial";
                readonly evidence: "persistence/contracts.ts:50-55 (declaration); schemaBootstrap.ts:281-297 (create_hypertable, the failure kept non-fatal); l1/monitor/persistence.ts:81-87 (the living example)";
            };
            readonly "read.window": {
                readonly source: "table";
                readonly sentence: "Reads the summary for a period and a group · findMany({ where, orderBy, limit, offset }) over the window column and the group keys, both indexed · the screen that shows the metric";
                readonly platform: "ready";
                readonly evidence: "l1/server/layer_1_external/data/moduleDataRuntime.ts:78, :19-30";
            };
            readonly refresh: {
                readonly source: "table";
                readonly sentence: "Keeps the summary up to date as the source rows arrive · add_continuous_aggregate_policy, declared as one more statement of the same view definition (start_offset, end_offset, schedule_interval) · the platform, on its own · Timescale only, and nothing outside the platform's own monitor has ever declared one";
                readonly platform: "partial";
                readonly evidence: "l1/monitor/persistence.ts:111-114; schemaBootstrap.ts:342-358 (the statement is executed at bootstrap, never after)";
            };
            readonly rebuild: {
                readonly source: "table";
                readonly sentence: "Recomputes the whole summary from the source rows · the schema rebuild drops the continuous aggregates and the views it owns and recreates them from the declaration · a migration or a publish · there is no routine a module can call to rebuild one series on demand";
                readonly platform: "partial";
                readonly evidence: "schemaBootstrap.ts:204-230 (the owned views and aggregates are dropped), :342-358 (recreated); no refresh entry point in layer_2_controllers";
            };
            readonly resample: {
                readonly source: "table";
                readonly sentence: "Reads the same series at another granularity, minute to hour to day · a second aggregate declared the same way, over the first one · a screen that zooms out · there is no granularity parameter at read time: each granularity is a table of its own";
                readonly platform: "partial";
                readonly evidence: "moduleDataRuntime.ts:19-30 offers where, ilike, orderBy, limit and offset, and no bucket; the only mechanism is the one of aggregate.byWindow (l1/monitor/persistence.ts:94-110), declared a second time at the other granularity";
            };
            readonly retain: {
                readonly source: "table";
                readonly sentence: "Drops the rows older than the period that matters, so the series does not grow forever · add_retention_policy as a statement of the view definition · the platform, on its own · the retentionDays field of the TableDefinition is declared and read by NOBODY, so the declarative path does not exist; only the raw statement works, and only with Timescale";
                readonly platform: "partial";
                readonly evidence: "l1/monitor/persistence.ts:115 (the living example); persistence/contracts.ts:83 (retentionDays, with no reader anywhere in mls-102034)";
            };
            readonly backfill: {
                readonly source: "table";
                readonly sentence: "Fills the summary for a period that is already past · the continuous aggregate is created WITH NO DATA and filled by its policy from start_offset onwards; a period older than that window is never computed · whoever turns the metric on after the fact";
                readonly platform: "missing";
                readonly evidence: "l1/monitor/persistence.ts:110 (WITH NO DATA), :112 (start_offset '3 minutes'); no backfill or refresh_continuous_aggregate call anywhere in mls-102034";
            };
            readonly "read.mdmRecord": {
                readonly source: "platform";
                readonly sentence: "Reads the master record a group key points at, to label the line of the summary · ctx.mdm.entity.get({ mdmId }), and collection.getMany to hydrate a whole chart at once · the screen that shows the metric by customer, by professional or by product";
                readonly platform: "ready";
                readonly evidence: "l1/mdm/layer_3_usecases/mdmFacade.ts:237-243 (facade), :794 (MdmCollection); mdmImplementation.md §10";
            };
        };
        readonly storage: {
            readonly engine: "Either a Postgres table written by a recalculation, or — the way the platform does it — a materialized view declared in viewDefinitions of the module persistence and created by the schema bootstrap.";
            readonly hypertable: "timescale.hypertable of the TableDefinition names the time column and the chunk interval; without the extension the table is created as an ordinary one.";
            readonly view: "A ViewDefinition is { moduleId, viewName, statements[] }; the statements run in order after every table and hypertable exists, and a failing one only warns.";
            readonly purpose: "There is no TablePurpose for derived data today: the persistence contract offers mdm, cadastro, transacao, controle, fila and cache (contracts.ts:4-11).";
        };
        readonly knownDivergences: {
            readonly "id-and-version-do-not-exist-on-a-view": "The module ontology gives every table `id` and `version` by derivation. A summary materialised as a continuous aggregate has neither — `monitor_bff_execution_agg_minute` carries the bucket, the group keys and the counts, and nothing else. A `ddm` entity is declarable today; the engine that would make the two agree is another task.";
            readonly "measures-are-columns-on-a-view": "In a materialised aggregate the measures really ARE columns of the view: monitor_bff_execution_agg_minute carries totalCount, successCount and the rest (l1/monitor/persistence.ts:98-108). The module ontology keeps a column only where there is an index, so a ddm entity declares its measures inside details; the two shapes meet the day the engine materialises a ddm from this declaration.";
            readonly "retention-days-is-dead": "TableDefinition.retentionDays is declared in the persistence contract and read by no code; retention exists only as a raw add_retention_policy statement.";
            readonly "no-generator-emits-view-definitions": "viewDefinitions is read from any module's persistence entry point, and the only module that ships one is the platform's own monitor. No generated module declares an aggregate yet.";
            readonly "timescale-is-optional": "Every capability of this family that depends on Timescale is skipped with a warning when the extension is absent, and the in-memory runtime of the preview has no aggregate at all — a derived entity simply has no rows there.";
            readonly "no-derived-purpose": "A derived table is declared today with the same TablePurpose as a transactional one, so nothing downstream can tell them apart by the persistence declaration alone; the family of this ontology is what says it.";
        };
    };
    export default ddm;
}
declare module "_102034_/l4/ontology/mdm.defs" {
    export const mdm: {
        readonly schemaVersion: "2026-09-15-mdm-ontology-v2";
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "mdmId; stable through promotion and merge.";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                    readonly writePrecondition: true;
                    readonly description: "Bumped by the engine on every write; optimistic concurrency.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly groups: readonly ["identification", "base", "<subtype>", "general", "<moduleId>"];
                    readonly description: "The JSONB document, as a map of groups (see groups).";
                };
            };
            readonly displayField: "identification.name";
        };
        readonly groups: {
            readonly identification: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "Also columns of the index table; that is what makes them filterable and sortable. A field earns a column only when something has to filter or sort by it.";
                readonly fields: {
                    readonly subtype: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Person", "Company", "ContactChannel", "Animal", "Product", "Service", "Location", "BankAccount", "Document", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
                        readonly description: "Which subtype this record is; it decides which subtype branch the document carries.";
                    };
                    readonly name: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 200;
                        readonly description: "How a human recognises the record. The only text filter there is.";
                    };
                    readonly status: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Active", "Inactive", "Merged", "Blocked"];
                    };
                    readonly docType: {
                        readonly type: "enum";
                        readonly indexed: true;
                        readonly values: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
                    };
                    readonly docId: {
                        readonly type: "string";
                        readonly indexed: true;
                        readonly description: "The document number itself. Unique with docType by design; the unique index does not exist yet, see knownDivergences.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly default: "US";
                        readonly description: "ISO 3166-1 alpha-2. Says which country the document and the legal rules belong to.";
                    };
                    readonly tags: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Module roles, as <moduleId>.<Entity>. Written by attachRole; this is how a module says the record is one of its own. A column with no index.";
                    };
                    readonly mergedInto: {
                        readonly type: "string";
                        readonly derived: true;
                        readonly description: "On the loser of a merge, the mdmId of the winner. A column with no index.";
                    };
                    readonly createdAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                    readonly updatedAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                };
            };
            readonly base: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "What every record has, whatever its subtype, and which nothing filters by.";
                readonly fields: {
                    readonly moduleTypes: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly derived: true;
                        readonly description: "The module roles again, kept for the engine and duplicating tags. Not a field for a reader; read tags.";
                    };
                    readonly aliases: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly description: "Other names the same subject answers to: trade name, maiden name, nickname.";
                    };
                    readonly addresses: {
                        readonly type: "object";
                        readonly of: "Address";
                        readonly collection: true;
                        readonly required: true;
                    };
                    readonly contacts: {
                        readonly type: "object";
                        readonly of: "ContactSummary";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Summary of the ContactChannel records linked by HasContact. A contact is a record, never a string on this one.";
                    };
                    readonly relationshipRefs: {
                        readonly type: "object";
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "The compact keys the engine recomputes on every link and unlink. The key set is relationships[].compactKeys — it is not repeated here, and it is never written by hand.";
                    };
                    readonly notes: {
                        readonly type: "string";
                        readonly maxLength: 1000;
                    };
                };
            };
            readonly general: {
                readonly type: "object";
                readonly owner: "organization";
                readonly open: true;
                readonly description: "Fields promoted by the organization when more than one module needed them; the schema lives in the project registry, so a module reads this branch and does not declare it.";
            };
            readonly "<moduleId>": {
                readonly type: "object";
                readonly owner: "module";
                readonly open: true;
                readonly description: "One key per module id — Record<moduleId, object>. Only that module writes it (MDM_FOREIGN_NAMESPACE otherwise); other modules see the key by name. Never identity, document, contact or login. Example: \"agendaClinica\": { \"prontuario\": \"PR-000123\" } — its schema is the module's own ontology (Paciente.defs.ts).";
            };
        };
        readonly types: {
            readonly Address: {
                readonly type: {
                    readonly type: "enum";
                    readonly required: true;
                    readonly values: readonly ["Residential", "Commercial", "Billing", "Delivery", "Other"];
                };
                readonly label: {
                    readonly type: "string";
                    readonly description: "Short human label for this address. Examples: home, headquarters, warehouse, branch";
                };
                readonly line1: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Primary address line: street and number, PO Box, or rural route. Examples: US \"123 Main St\"; Brazil \"Rua das Flores 100\"; Japan \"1-2-3 Shinjuku\".";
                };
                readonly line2: {
                    readonly type: "string";
                    readonly description: "Secondary line: apartment, suite, floor, unit, building. Examples: US \"Apt 4B\"; Brazil \"Apto 42\"; Japan \"Shinjuku-ku\".";
                };
                readonly line3: {
                    readonly type: "string";
                    readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan). Examples: Brazil \"Jardim Paulista\"; Japan \"Tokyo\".";
                };
                readonly city: {
                    readonly type: "string";
                };
                readonly stateOrProvince: {
                    readonly type: "string";
                    readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                };
                readonly postalCode: {
                    readonly type: "string";
                    readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                };
                readonly countryCode: {
                    readonly type: "string";
                    readonly required: true;
                    readonly maxLength: 2;
                    readonly pattern: "^[A-Z]{2}$";
                    readonly default: "US";
                    readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                };
                readonly formatted: {
                    readonly type: "string";
                    readonly derived: true;
                    readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                };
                readonly geolocation: {
                    readonly type: "object";
                    readonly of: "GeoPoint";
                };
                readonly isPrimary: {
                    readonly type: "boolean";
                    readonly required: true;
                };
            };
            readonly GeoPoint: {
                readonly lat: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -90;
                    readonly max: 90;
                };
                readonly lng: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -180;
                    readonly max: 180;
                };
            };
            readonly PrivacyConsent: {
                readonly consentedAt: {
                    readonly type: "timestamp";
                    readonly required: true;
                };
                readonly consentVersion: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Version of the privacy policy accepted.";
                };
                readonly channel: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "How consent was obtained. Examples: web-signup, paper-form, whatsapp, verbal";
                };
                readonly revokedAt: {
                    readonly type: "timestamp";
                };
                readonly notes: {
                    readonly type: "string";
                };
            };
            readonly ContactSummary: {
                readonly mdmId: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                };
                readonly title: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Human-readable label for this contact in the context of the parent entity. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                };
            };
        };
        readonly subtypes: {
            readonly Person: {
                readonly description: "Natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly gender: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "NonBinary", "NotDisclosed"];
                    };
                    readonly nationality: {
                        readonly type: "string";
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string";
                        readonly maxLength: 120;
                    };
                    readonly photoUrl: {
                        readonly type: "string";
                    };
                    readonly privacyConsent: {
                        readonly type: "object";
                        readonly of: "PrivacyConsent";
                        readonly description: "Required for residents of Brazil (LGPD) and the EU (GDPR).";
                    };
                };
                readonly capabilities: readonly ["locate.byLogin", "locate.users", "invite.login", "register.self", "accessRequest.read", "accessRequest.resolve", "export.personalData", "anonymize"];
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Corporations, LLCs, nonprofits, government entities — and the internal structures of any of them.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["LegalEntity", "Branch", "Franchise", "BusinessUnit", "Group", "Team", "Department", "InternalOrg"];
                        readonly description: "Tells a legal entity apart from an internal structure.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Official registered name.";
                    };
                    readonly tradeName: {
                        readonly type: "string";
                        readonly description: "DBA name. Also goes into aliases, so the text filter finds it.";
                    };
                    readonly legalType: {
                        readonly type: "enum";
                        readonly values: readonly ["Corporation", "LLC", "SoleProp", "Partnership", "Nonprofit", "Government", "Other"];
                    };
                    readonly parentCompanyId: {
                        readonly type: "record";
                        readonly to: readonly ["Company"];
                        readonly description: "Parent in an organizational tree. The link itself is BelongsToGroup, PartOfUnit or SubsidiaryOf.";
                    };
                    readonly externalCode: {
                        readonly type: "string";
                        readonly description: "ERP, HR or legacy code used by the consuming modules.";
                    };
                    readonly foundingDate: {
                        readonly type: "date";
                    };
                    readonly taxRegime: {
                        readonly type: "string";
                        readonly description: "Country-specific tax class: S-Corp and C-Corp in the US, Simples Nacional in Brazil.";
                    };
                    readonly industryCode: {
                        readonly type: "string";
                        readonly description: "NAICS in the US, CNAE in Brazil, or the local equivalent.";
                    };
                    readonly website: {
                        readonly type: "string";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly ContactChannel: {
                readonly description: "A phone, e-mail or social handle as a record of its own, so it can be traced, verified and shared.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Phone", "Email", "WhatsApp", "Instagram", "LinkedIn", "X", "Other"];
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The contact itself, stored unmasked.";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
            readonly Animal: {
                readonly description: "Pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string";
                    };
                    readonly breed: {
                        readonly type: "string";
                    };
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly sex: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "Unknown"];
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly microchip: {
                        readonly type: "string";
                    };
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Breed registry, USDA tag, or official animal id.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly Product: {
                readonly description: "An inventory or catalog item that can be bought, stocked, sold or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string";
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "enum";
                        readonly values: readonly ["Physical", "Digital", "Bundle", "Consumable", "Other"];
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string";
                        readonly description: "unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly description: "True when stock is tracked by location.";
                    };
                };
            };
            readonly Service: {
                readonly description: "A reusable service or offering that can be sold, scheduled, taught or assigned to a place. Courses are services too.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string";
                    };
                    readonly serviceKind: {
                        readonly type: "enum";
                        readonly values: readonly ["Service", "Course", "Cohort", "Subscription", "AppointmentType"];
                        readonly description: "Cohort is a concrete instance of a course.";
                    };
                    readonly serviceType: {
                        readonly type: "enum";
                        readonly values: readonly ["Course", "Consulting", "Maintenance", "Appointment", "Subscription", "Other"];
                    };
                    readonly parentServiceId: {
                        readonly type: "record";
                        readonly to: readonly ["Service"];
                        readonly description: "The base service, when this one is a cohort or a derived offering.";
                    };
                    readonly durationMinutes: {
                        readonly type: "number";
                    };
                    readonly deliveryMode: {
                        readonly type: "enum";
                        readonly values: readonly ["Onsite", "Remote", "Hybrid", "Other"];
                    };
                };
            };
            readonly Location: {
                readonly description: "A physical place used for stock or for delivering a service: room, warehouse, campus, store, branch, shelf.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Room", "Warehouse", "Building", "Campus", "Store", "Office", "Shelf", "Other"];
                    };
                    readonly locationCode: {
                        readonly type: "string";
                    };
                    readonly parentLocationId: {
                        readonly type: "record";
                        readonly to: readonly ["Location"];
                        readonly description: "The larger place this one belongs to.";
                    };
                    readonly capacity: {
                        readonly type: "number";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Routing data only. Balances and transactions belong to the finance module, never here.";
                readonly fields: {
                    readonly bankName: {
                        readonly type: "string";
                    };
                    readonly bankRoutingNumber: {
                        readonly type: "string";
                        readonly description: "ABA routing number in the US; use swift for international.";
                    };
                    readonly accountNumber: {
                        readonly type: "string";
                    };
                    readonly accountType: {
                        readonly type: "enum";
                        readonly values: readonly ["Checking", "Savings", "MoneyMarket", "Payment", "Other"];
                    };
                    readonly swift: {
                        readonly type: "string";
                        readonly description: "BIC/SWIFT, for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string";
                    };
                    readonly pixKey: {
                        readonly type: "string";
                    };
                    readonly pixKeyType: {
                        readonly type: "enum";
                        readonly values: readonly ["CPF", "CNPJ", "Phone", "Email", "RandomKey"];
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                        readonly description: "Verified by micro-deposit, open banking or manual review.";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "An indexed reference to an external file. The file itself never lives in the MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The module that created this record.";
                    };
                    readonly docCategory: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Contract", "Certificate", "IdDocument", "Invoice", "Receipt", "Report", "Photo", "Other"];
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "S3 bucket, or its equivalent, holding the file.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Path inside the bucket. Never rewritten after creation.";
                    };
                    readonly fileName: {
                        readonly type: "string";
                        readonly required: true;
                    };
                    readonly mimeType: {
                        readonly type: "string";
                    };
                    readonly fileSizeKb: {
                        readonly type: "number";
                    };
                    readonly issuedAt: {
                        readonly type: "date";
                    };
                    readonly expiresAt: {
                        readonly type: "date";
                    };
                    readonly issuer: {
                        readonly type: "string";
                        readonly description: "Name of the issuing authority, as free text. Not an mdmId.";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly AssetGeneric: {
                readonly description: "The fallback asset, for what does not fit vehicle, property or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string";
                        readonly description: "furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly manufacturer: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string";
                    };
                    readonly vin: {
                        readonly type: "string";
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly year: {
                        readonly type: "integer";
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly fuelType: {
                        readonly type: "enum";
                        readonly values: readonly ["Gasoline", "Diesel", "Electric", "Hybrid", "Flex", "Other"];
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Real estate: residential, commercial, rural or industrial.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Deed number, cadastral reference, or the local equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                    readonly propertyType: {
                        readonly type: "enum";
                        readonly values: readonly ["Residential", "Commercial", "Rural", "UrbanLot", "Industrial", "Other"];
                    };
                    readonly areaSqft: {
                        readonly type: "number";
                        readonly description: "Area in square feet; the primary unit in the US.";
                    };
                    readonly areaM2: {
                        readonly type: "number";
                        readonly description: "Area in square meters, outside the US.";
                    };
                    readonly taxParcelId: {
                        readonly type: "string";
                        readonly description: "Tax parcel or assessor id in the US, or the local equivalent.";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly acquisitionDate: {
                        readonly type: "date";
                    };
                };
            };
        };
        readonly relationships: readonly [{
            readonly type: "Owns";
            readonly title: "Owns";
            readonly description: "A person or a company owns an asset · metadata: since, ownershipPct";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["ownedAssets"];
                readonly to: readonly ["owners"];
            };
        }, {
            readonly type: "Employs";
            readonly title: "Employs";
            readonly description: "A company employs a person · metadata: role, department, startDate";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["employee", "contractor", "intern"];
            readonly compactKeys: {
                readonly from: readonly ["employees"];
                readonly to: readonly ["employers"];
            };
        }, {
            readonly type: "OffersProduct";
            readonly title: "Offers product";
            readonly description: "A company puts a product in its catalog · metadata: since, supplierSku";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredProducts"];
                readonly to: readonly ["productSuppliers"];
            };
        }, {
            readonly type: "OffersService";
            readonly title: "Offers service";
            readonly description: "A company or a person offers a service · metadata: since, priceTable";
            readonly from: readonly ["Company", "Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredServices"];
                readonly to: readonly ["serviceProviders"];
            };
        }, {
            readonly type: "StocksAt";
            readonly title: "Stocks at";
            readonly description: "A product or a piece of equipment is stocked at a place · metadata: quantity, unit, minLevel";
            readonly from: readonly ["Product", "AssetEquipment"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["stockLocations"];
                readonly to: readonly ["stockedItems"];
            };
        }, {
            readonly type: "Teaches";
            readonly title: "Teaches";
            readonly description: "A person teaches a service or a course · metadata: role, since";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["primary-instructor", "assistant-instructor", "substitute"];
            readonly compactKeys: {
                readonly from: readonly ["taughtServices"];
                readonly to: readonly ["instructors"];
            };
        }, {
            readonly type: "HappensAt";
            readonly title: "Happens at";
            readonly description: "A service is delivered at a place · metadata: scheduleLabel, weekday";
            readonly from: readonly ["Service"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["serviceLocations"];
                readonly to: readonly ["scheduledServices"];
            };
        }, {
            readonly type: "FranchiseOf";
            readonly title: "Franchise of";
            readonly description: "A company operates as a franchise of another · metadata: contractId, territory";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["franchisors"];
                readonly to: readonly ["franchisees"];
            };
        }, {
            readonly type: "BelongsToGroup";
            readonly title: "Belongs to group";
            readonly description: "A company belongs to an economic group · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["subsidiary-brand"];
            readonly compactKeys: {
                readonly from: readonly ["groupParents"];
                readonly to: readonly ["groupMembers"];
            };
        }, {
            readonly type: "PartOfUnit";
            readonly title: "Part of unit";
            readonly description: "An internal structure belongs to a larger one · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["department", "team", "branch-unit"];
            readonly compactKeys: {
                readonly from: readonly ["unitParents"];
                readonly to: readonly ["unitChildren"];
            };
        }, {
            readonly type: "ManagedBy";
            readonly title: "Managed by";
            readonly description: "A person runs a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["manager", "coordinator"];
            readonly compactKeys: {
                readonly from: readonly ["managedOrganizations"];
                readonly to: readonly ["managers"];
            };
        }, {
            readonly type: "ReportsTo";
            readonly title: "Reports to";
            readonly description: "A person reports to another person · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["direct-report", "manager"];
            readonly compactKeys: {
                readonly from: readonly ["reportManagers"];
                readonly to: readonly ["reports"];
            };
        }, {
            readonly type: "AssignedTo";
            readonly title: "Assigned to";
            readonly description: "A person is assigned to a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["member", "assistant", "instructor"];
            readonly compactKeys: {
                readonly from: readonly ["assignments"];
                readonly to: readonly ["assignees"];
            };
        }, {
            readonly type: "Attends";
            readonly title: "Attends";
            readonly description: "A person attends a service or a course · metadata: attendanceStatus";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["enrolled", "completed"];
            readonly compactKeys: {
                readonly from: readonly ["attendedServices"];
                readonly to: readonly ["attendees"];
            };
        }, {
            readonly type: "SuppliesProduct";
            readonly title: "Supplies product";
            readonly description: "A company supplies a product · metadata: leadTimeDays, catalogCode";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliedProducts"];
                readonly to: readonly ["productVendors"];
            };
        }, {
            readonly type: "PartnersWith";
            readonly title: "Partners with";
            readonly description: "A person is a partner in a company · metadata: equityPct, role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["managing-partner", "silent-partner"];
            readonly compactKeys: {
                readonly from: readonly ["partners"];
                readonly to: readonly ["partners"];
            };
        }, {
            readonly type: "Family";
            readonly title: "Family";
            readonly description: "Kinship between two people, read the same way from either side · metadata: degree. An emergency contact is this link with role emergency";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: true;
            readonly roles: readonly ["spouse", "child", "parent", "sibling", "emergency"];
            readonly compactKeys: {
                readonly from: readonly ["family"];
                readonly to: readonly ["family"];
            };
        }, {
            readonly type: "GuardianOf";
            readonly title: "Guardian of";
            readonly description: "A person answers for another person or for an animal · metadata: since, guardianType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person", "Animal"];
            readonly bidirectional: false;
            readonly roles: readonly ["parent", "guardian", "owner", "foster"];
            readonly compactKeys: {
                readonly from: readonly ["pets"];
                readonly to: readonly ["guardians"];
            };
        }, {
            readonly type: "CustomerOf";
            readonly title: "Customer of";
            readonly description: "A person or a company buys from a company · metadata: since, segment";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliers"];
                readonly to: readonly ["customers"];
            };
        }, {
            readonly type: "SupplierOf";
            readonly title: "Supplier of";
            readonly description: "A company supplies another company · metadata: category, contractMdmId";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["customers"];
                readonly to: readonly ["suppliers"];
            };
        }, {
            readonly type: "MemberOf";
            readonly title: "Member of";
            readonly description: "A person is a member of a company or an association · metadata: role, membershipType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["board-member", "honorary"];
            readonly compactKeys: {
                readonly from: readonly ["memberships"];
                readonly to: readonly ["members"];
            };
        }, {
            readonly type: "HoldsAccount";
            readonly title: "Holds account";
            readonly description: "A person or a company holds a bank account · metadata: isPrimary, since";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["BankAccount"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["bankAccounts"];
                readonly to: readonly ["accountHolders"];
            };
        }, {
            readonly type: "SubsidiaryOf";
            readonly title: "Subsidiary of";
            readonly description: "A company is a subsidiary of another · metadata: equityPct, type";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["wholly-owned", "affiliate"];
            readonly compactKeys: {
                readonly from: readonly ["parentCompanies"];
                readonly to: readonly ["subsidiaries"];
            };
        }, {
            readonly type: "LocatedAt";
            readonly title: "Located at";
            readonly description: "A person or a company sits at a property · metadata: locationType";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetProperty"];
            readonly bidirectional: false;
            readonly roles: readonly ["headquarters", "branch", "warehouse"];
            readonly compactKeys: {
                readonly from: readonly ["locations"];
                readonly to: readonly ["locatedEntities"];
            };
        }, {
            readonly type: "Signed";
            readonly title: "Signed";
            readonly description: "A person or a company signed a document · metadata: role";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Document"];
            readonly bidirectional: false;
            readonly roles: readonly ["contractor", "client", "witness", "notary"];
            readonly compactKeys: {
                readonly from: readonly ["documents"];
                readonly to: readonly ["signedBy"];
            };
        }, {
            readonly type: "HasContact";
            readonly title: "Has contact";
            readonly description: "Any record owns a contact channel; this is what fills base.contacts · metadata: isPrimary";
            readonly from: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
            readonly to: readonly ["ContactChannel"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["contacts"];
                readonly to: readonly ["contactOwners"];
            };
        }];
        readonly capabilities: {
            readonly "read.byId": "Reads one record, or a handful at once, when the id is already known · get, getMany and hydrateMany over the index plus the document store, O(1) each · any screen that already holds the mdmId, and every list that has to fill in the records it points at · platform: ready";
            readonly "locate.byName": "Finds records whose name contains the typed text, anywhere in the string · listByType narrows by subtype and status in the index table and then matches the name in memory; aliases are not consulted and there is no default page size · anyone looking a record up · platform: partial";
            readonly "locate.byDocument": "Finds the single record that holds a national document (CPF, CNPJ, SSN, EIN) · findByDocument loads the index and filters in JS · whoever registers, to deduplicate before creating · platform: partial";
            readonly "locate.byContact": "Finds the record that owns a phone, WhatsApp handle or e-mail · findByContact loads every ContactChannel record · whoever answers an inbound call or message · platform: partial";
            readonly "locate.byLogin": "Finds the person behind a login e-mail · mdm_tag row with namespace login, partial unique index on (namespace, tag, module) · the session resolver · platform: ready";
            readonly "locate.users": "Lists people who already have a platform login · ctx.mdm.identity.listUsers({ name?, status?, roleTag?, roleTagMode?, pageSize?, cursor? }) filters a folded literal name, status Active by default or Inactive, Merged, Blocked or all, and one role tag with or without that tag; pages of 1 to 100, default 20, ordered by mdmId in UTF-8 byte order and continued by nextCursor, which is navigation and not a snapshot · the MDM is the one shared by the organization and the VM, with no project filter · ctx.mdm.identity.getLoginEmail(mdmId) reads the login of one person · platform: ready, proved in memory and on PostgreSQL";
            readonly "locate.byTag": "Finds every record carrying a given label — which is how a secondary key works here · mdm.tag.findByTag, over the index idx_mdm_tag_lookup on (entityType, tag, module); the `namespace` column keeps one key space apart from another, and the login e-mail of locate.byLogin is nothing but the namespace 'login' · a module that has to find a record by a code of its own, such as a chart or a badge number · platform: ready";
            readonly "locate.semantic": "Finds a record through a misspelling, a phonetic match or half a name · would need a trigram or tsvector index, or embeddings; searchVector is TEXT compared literally · reception, when the spelling is uncertain · platform: missing";
            readonly "locate.byDocumentField": "Filters or sorts by something that lives only in the document, such as birth month, city or any module field · would need that field promoted to an index column, or a GIN index on details; for a key the module itself controls, locate.byTag already answers without any of that · marketing and reporting · platform: missing";
            readonly "register.createOrAttach": "Creates the record when it does not exist and, either way, marks it with the module role · locate.byDocument, create when absent, then attachRole writes details[moduleId], the tag, the audit row and the recomputed compact refs · whoever registers · platform: ready";
            readonly "register.asProspect": "Records an interested party who has no document yet, and promotes it later · prospect.create with promotionSource and ttlExpiresAt, then promoteToEntity keeping the same mdmId · reception and the public site · platform: ready";
            readonly "edit.platformFields": "Changes the name, document, addresses, consent and the other fields the platform owns · entity.update; touching an identification field also rewrites the index row · whoever maintains the record · platform: partial";
            readonly "edit.moduleNamespace": "Changes only details[moduleId], which is what this module knows about the record · attachRole or update carrying the module key; any other module key is refused · the module itself · platform: ready";
            readonly inactivate: "Takes the record out of use without deleting it · status Active to Inactive, and reactivate undoes it · whoever maintains the record · platform: partial";
            readonly merge: "Joins two records that are the same subject, the loser pointing at the winner · mergeEntity sets status Merged and mergedInto, but the facade neither exports nor routes it · an administrator · platform: missing";
            readonly delete: "Removes the record physically, and is refused while an active relationship exists · entity.delete, error MDM_DELETE_BLOCKED_BY_RELATIONSHIPS · an administrator · platform: ready";
            readonly link: "Creates a versioned relationship, with a role, between two permanent records · link(from, to, type, role); the engine recomputes the compact keys on both sides · whoever maintains the record · platform: ready";
            readonly unlink: "Closes a relationship while keeping its history · unlink sets status Inactive; the row is never deleted · whoever maintains the record · platform: ready";
            readonly "link.contact": "Adds a phone, WhatsApp handle or e-mail that belongs to this record · create a ContactChannel record and link it with HasContact; the engine fills relationshipRefs.contacts · whoever maintains the record · platform: ready";
            readonly listLinks: "Shows the related records, with their validity and role · relationship.list and relatedOfMany · the record screen · platform: ready";
            readonly "attach.document": "Stores a photo, a scan or a signed document against the record, by category · upload to S3 or local disk, a row in mdm_attachment, presigned GET · whoever maintains the record · platform: partial";
            readonly comment: "Leaves a note on the record, with one level of reply and a 15-minute edit window · mdm_comment anchored by entityType, entityId and module · whoever maintains the record · platform: ready";
            readonly tag: "Marks the record with free labels inside the module namespace · mdm_tag, unique on (entityType, entityId, tag, module) · whoever maintains the record · platform: ready";
            readonly "sequence.next": "Issues the next number of a counter, such as a record or order number · mdm_number_sequence with SELECT … FOR UPDATE, key {module}.{entityType}.{scope} · the module, on create · platform: ready";
            readonly "config.kv": "Keeps a small piece of JSON configuration that more than one module reads · mdm.kv.get and mdm.kv.put over mdm_kv, a shared table keyed by one `key` column — no per-record scope, no history and no module column · a module that needs a setting the others also read · platform: ready";
            readonly "statusHistory.read": "Shows when the record changed status and who changed it · mdm_status_history · the record screen · platform: partial";
            readonly audit: "Says who changed what, and when · mdm_audit_log, insert only · an administrator · platform: partial";
            readonly "invite.login": "Gives the person a login so they can see their own data · identity.invite writes the mdm_tag login row and calls collab-auth · whoever maintains the record · platform: ready";
            readonly "register.self": "Links the signed-in account to one Person, or opens an access request when the e-mail already belongs to candidate contacts · POST /session/register reads the e-mail and the name from the resolved session, never from the body, and does not send an invite · the signed-in account · platform: ready";
            readonly "accessRequest.read": "Reads the requester's own request by id, or the organization's follow-up list of reserved candidate tokens · GET /session/registration/request?id= and GET /session/registration/requests; the list exists only while alpha authorities are on in this round · the requester for their own id, and the organization follow-up while alpha is on · platform: ready";
            readonly "accessRequest.resolve": "Resolves one pending request by requestId, expectedVersion and either a reserved candidate token or create-new with no target · POST /session/registration/resolve accepts no e-mail, mdmId, name or organizationKey, sends no invite, and exists only while alpha authorities are on in this round · the organization follow-up while alpha is on · platform: ready";
            readonly "export.personalData": "Hands the subject their own data on request (LGPD art. 18, GDPR art. 15) · would need the document, the links and the attachments in a single export · an administrator · platform: missing";
            readonly anonymize: "Erases the personal data while keeping the record for statistics · would pseudonymize the identification keeping the mdmId · an administrator · platform: missing";
        };
        readonly rules: {
            readonly "rule-person-ssn-unique-for-us": "Two permanent people in the US must not share the same SSN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-person-privacy-consent-required-br-eu": "A person living in Brazil or the EU without a valid privacy consent is forced to Inactive · engine · platform: ready";
            readonly "rule-company-ein-unique-for-us": "Two permanent companies in the US must not share the same EIN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-company-legal-name-required": "A company record is refused without a legalName · engine · platform: ready";
            readonly "rule-contact-value-unique-per-type": "Two contact channels must not share the same contactType and value · engine · platform: partial";
            readonly "rule-bank-account-routing-required-for-us": "A US bank account is refused without a bankRoutingNumber · engine · platform: ready";
            readonly "rule-bank-account-holder-via-relationship": "Who holds a bank account is the HoldsAccount link, never a field of the account · engine · platform: ready";
            readonly "rule-document-parties-via-relationships": "Who signed a document is the Signed link, never a field of the document · engine · platform: ready";
            readonly "rule-document-path-immutable": "Once stored, the storage key of a document is never rewritten · engine · platform: ready";
            readonly "rule-foreign-namespace-refused": "A caller carrying a moduleId may write the platform keys, general and its own key; any other module key is refused with MDM_FOREIGN_NAMESPACE · engine · platform: ready";
            readonly "rule-delete-blocked-by-relationships": "A physical delete is refused while an active relationship exists · engine · platform: ready";
            readonly "rule-document-shape-validated": "Addresses, consent, general and the module namespace are validated on write against the schema derived from this ontology · engine · platform: missing, nothing validates the document today";
            readonly "rule-identity-never-in-namespace": "Identity, document, contact and login are platform layers; a module never redeclares them inside details[moduleId] · engine · platform: partial";
        };
        readonly statuses: readonly ["Active", "Inactive", "Merged", "Blocked"];
        readonly docTypes: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
        readonly storage: {
            readonly indexTable: "mdm_documents_entities_index";
            readonly prospectIndexTable: "mdm_documents_prospects_index";
            readonly documentTable: "mdm_documents";
            readonly documentColumn: "details";
            readonly indexedColumns: readonly ["subtype", "name", "status", "docType", "docId", "countryCode", "createdAt", "updatedAt"];
            readonly reservedKeys: readonly ["identification", "base", "general", "<subtype>", "<moduleId>"];
        };
        readonly knownDivergences: {
            readonly "grouped-document": "The branches of this file are the target. The engine writes and reads a FLAT document today, so identification, base and the subtype branch are all one level.";
            readonly "contacts-written-from-input": "base.contacts is declared derived from HasContact and the engine still writes it raw from the input, duplicating relationshipRefs.contacts.";
            readonly "module-types-duplicates-tags": "base.moduleTypes and identification.tags carry the same module roles. tags is the one with a column; moduleTypes is kept for the engine and should disappear.";
            readonly "doc-unique-missing": "UNIQUE(docType, docId) is promised in defs/ontology.ts and absent from persistence.ts, so the two uniqueness rules are only partly enforced.";
            readonly "privacy-consent-value": "PrivacyConsent (data) and PrivacyConsentValue (interface) declare different fields; the same is true of Address and ContactSummary.";
            readonly "compact-relationship-refs-count": "CompactRelationshipRefs has 22 keys in the data and 48 in the interface; the interface is the real one.";
            readonly "search-vector-type": "searchVector is documented as tsvector and created as TEXT, compared literally, which is why locate.semantic is missing.";
            readonly "relationship-documents-table": "Table mdm_relationship_documents is cited and does not exist.";
            readonly "service-defs-case": "The JSON service definitions use PascalCase where the columns are camelCase.";
            readonly "platform-detail-keys-copy": "The two lists in mdmFacade.ts and integration.ts are gone. One classifier, l1/mdm/defs/platformDetailKeys.ts, keeps catalog names apart from engine-compat extras. mdmId is the flat record id (record.fields.id), not a catalog field and not a module namespace.";
            readonly "prospect-lifecycle-fields": "promotionSource, promotedTo and ttlExpiresAt are the three ProspectLifecycleFields of the current engine and prospect index. They belong to that contract, not to a module namespace and not to a common editable form field. They are not universal inputs of every entity.";
            readonly "emergency-contact-type": "There is no EmergencyContactOf type; a Family link with role emergency carries that meaning.";
            readonly "subtype-enum-narrowed": "identification.subtype is declared here with the 13 values; the engine narrows it per subtype, so a Person record only ever carries \"Person\".";
            readonly "index-only-columns": "The index table also has searchVector and dynamoPk, which are engine internals and no field of the document; one of the 9 indexes is on dynamoPk, which is why indexedColumns lists 8.";
            readonly "registration-draft": "register.self and the organization bootstrap may store a Person while the name or the country is still unknown, and a Company while the legal name is still unknown. The engine marks that case with registrationDraft. That marker is not a form field and is not written into the module namespace. A normal create still requires the name, the country and, for a company, the legal name.";
        };
    };
    export default mdm;
}
declare module "_102034_/l4/ontology/platform.defs" {
    export const mdmPlatformCatalog: {
        readonly catalogVersion: "2026-09-11-mdm-platform-v1";
        readonly layers: readonly [{
            readonly layer: "identification";
            readonly owner: "platform";
            readonly where: "index columns";
            readonly fields: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "countryCode", "tags"];
            readonly note: "docType/docId is the legal document, UNIQUE among permanent records. Never a login.";
        }, {
            readonly layer: "base";
            readonly owner: "platform";
            readonly where: "typed keys of the subtype in the document";
            readonly fields: readonly ["contacts[]", "addresses[]", "aliases[]", "relationshipRefs", "subtype-specific fields"];
            readonly note: "Never redeclared by a module.";
        }, {
            readonly layer: "general";
            readonly owner: "organization";
            readonly where: "document key general";
            readonly fields: readonly ["promoted fields"];
            readonly note: "A field that more than one module needed; promoted by the organization; schema in the solution registry.";
        }, {
            readonly layer: "module";
            readonly owner: "the module";
            readonly where: "document key <moduleId>";
            readonly fields: readonly ["namespace fields only"];
            readonly note: "Only what nobody else needs. Never identity, document, contact, login.";
        }];
        readonly visibility: {
            readonly rule: "keys open, content closed";
            readonly read: "identification + base + general + details[ctx.moduleId] + namespaces[] (names of the other module keys, no content)";
            readonly unrestricted: "no moduleId or moduleId === 'organization' reads the full document";
            readonly write: "platform keys + general + details[ctx.moduleId]; any other module key → MDM_FOREIGN_NAMESPACE (400)";
        };
        readonly identity: {
            readonly who: "JWT: sub, email, authorities <moduleId>:<actorId>";
            readonly whereThePersonExists: "record tags/moduleTypes <moduleId>.<EntityId> and details[<moduleId>]";
            readonly login: {
                readonly storage: "mdm_tag row";
                readonly row: {
                    readonly entityType: "MdmEntity";
                    readonly entityId: "<mdmId>";
                    readonly namespace: "login";
                    readonly tag: "<login e-mail>";
                    readonly module: "organization";
                };
                readonly lookup: "ctx.mdm.identity.findByLogin(email) — indexed mdm_tag (namespace=login)";
                readonly invariant: "one login e-mail → one record; one record → at most one login row";
                readonly services: readonly ["findByLogin(email) → mdmId | null", "setLogin(mdmId, email) — uniqueness MDM_LOGIN_TAKEN; one Person → at most one login row", "invite({ mdmId, email, moduleId, actorId }) → { token, expiresAt } — writes login row, asks collab-auth by API key", "session.person: { mdmId, email, name } on RequestSessionContext when a login row exists"];
                readonly pending: readonly ["collab-auth emits <module>:<actor> as active_org.teams[].roles (auth.ts:157), not as top-level authorities/roles that bffAuth.ts:38-45 reads"];
            };
            readonly otherIdentifiers: "one mdm_tag row per identifier, one namespace each (external system id, badge, card)";
            readonly neverInModule: readonly ["login", "document", "contact"];
        };
        readonly roles: {
            readonly meaning: "kind: mdm in a module ontology = a role of that module over a level-1 subtype";
            readonly tag: "<moduleId>.<EntityId>";
            readonly createOrAttach: readonly ["findByDocument(docType, docId) or findByContact(type, value)", "create({ details }) when absent — dedups by document, returns alreadyExists", "attachRole(mdmId, role, namespace?)"];
            readonly ontologyRules: readonly ["fields[] holds namespace fields only", "storage.idField is the MDM id and stays outside fields[]", "displayField is a level-1 field or a namespace field", "no lifecycleStates, no transitions — activity is the MDM status"];
            readonly actorsAreNotRoles: "a profile (receptionist, manager) becomes a Person record only when the business records something about that person";
        };
        readonly services: readonly [{
            readonly service: "tags";
            readonly table: "mdm_tag";
            readonly rows: "many per record";
            readonly indexes: readonly ["(entityType, tag, module)", "(entityType, namespace, module)", "(module, tag)", "unique (entityType, entityId, tag, module)", "unique (namespace, tag, module) WHERE namespace='login'"];
            readonly operations: readonly ["mdm.tag.add", "mdm.tag.remove", "mdm.tag.findByEntity", "mdm.tag.findByTag"];
            readonly useFor: readonly ["secondary identifiers (login, external ids)", "module markers with a value"];
            readonly notFor: readonly ["role tags — those live in record tags[] via attachRole"];
        }, {
            readonly service: "relationships";
            readonly table: "mdm_relationship";
            readonly rows: "typed, versioned, validFrom/validTo, status";
            readonly operations: readonly ["mdm.relationship.create", "mdm.relationship.list", "mdm.relationship.update", "facade link / unlink / relatedOfMany"];
            readonly catalog: "RelationshipCatalog in ontology.ts (26 types)";
            readonly compactRefs: "relationshipRefs.<key>[] on the record for fast reads";
            readonly useFor: readonly ["a fact about two master records (responsible for, customer of, supplies)"];
            readonly notFor: readonly ["a module join entity between two master records"];
        }, {
            readonly service: "prospects";
            readonly table: "mdm_prospect_index";
            readonly rows: "transient records, duplicates allowed, TTL";
            readonly operations: readonly ["mdm.prospect.create", "mdm.prospect.get", "mdm.prospect.list", "mdm.prospect.update", "mdm.prospect.promoteToEntity"];
            readonly useFor: readonly ["leads and unqualified records before deduplication"];
        }, {
            readonly service: "comments";
            readonly operations: readonly ["mdm.comment.add", "mdm.comment.edit", "mdm.comment.remove", "mdm.comment.findByEntity"];
            readonly useFor: readonly ["notes on a master record"];
            readonly notFor: readonly ["a module Comment entity about a master record"];
        }, {
            readonly service: "attachments";
            readonly operations: readonly ["mdm.attachment.attach", "mdm.attachment.detach", "mdm.attachment.findByEntity"];
            readonly storage: "S3-backed";
            readonly useFor: readonly ["files of a master record (photos, documents)"];
            readonly notFor: readonly ["a module Photo/File entity about a master record"];
        }, {
            readonly service: "audit";
            readonly tables: readonly ["mdm audit log (every MDM write, via runMonitoredWrite)", "status history"];
            readonly operations: readonly ["audit.home.load", "audit.auditLog.load", "audit.auditLog.details", "audit.statusHistory.load"];
            readonly rule: "modules never create their own audit, log or history entities for master records";
            readonly pending: readonly ["audit of module-table writes is a platform decision, not a module entity"];
        }, {
            readonly service: "statusHistory";
            readonly operations: readonly ["mdm.statusHistory.findByEntity", "mdm.statusHistory.findLatest"];
            readonly useFor: readonly ["when a master record changed status, by whom"];
        }, {
            readonly service: "numberSequence";
            readonly operations: readonly ["mdm.numberSequence.next"];
            readonly useFor: readonly ["sequential business numbers (order number, invoice number)"];
            readonly notFor: readonly ["a module counter table"];
        }, {
            readonly service: "kv";
            readonly operations: readonly ["mdm.kv.get", "mdm.kv.put"];
            readonly useFor: readonly ["small organization-wide settings"];
            readonly notFor: readonly ["business entities"];
        }];
        readonly lookups: readonly [{
            readonly lookup: "get / getMany / hydrateMany by mdmId";
            readonly cost: "O(1) per id";
        }, {
            readonly lookup: "listByType(subtype, …)";
            readonly cost: "indexed";
        }, {
            readonly lookup: "findTagsByTag(entityType, tag, module)";
            readonly cost: "indexed — use for identifiers looked up per request";
        }, {
            readonly lookup: "findByDocument(docType, docId)";
            readonly cost: "full scan today — not for a per-request path";
        }, {
            readonly lookup: "findByContact(type, value)";
            readonly cost: "full scan today — not for a per-request path";
        }];
        readonly invariants: readonly ["a master record is never deleted: inactivate / reactivate; delete is soft (status, mergedInto)", "one legal document → one permanent record; dedup on create; merge keeps mergedInto", "a module writes only its namespace (and general when promoted)", "writes are versioned (version / expectedVersion)", "countryCode comes from the organization (ctx.organization.countryCode), never from UI language", "dependency is always module → MDM; the MDM knows no module"];
        readonly events: readonly [{
            readonly eventId: "mdmCreated";
            readonly on: "MdmEntity.create";
        }, {
            readonly eventId: "mdmUpdated";
            readonly on: "MdmEntity.update";
        }, {
            readonly eventId: "mdmInactivated";
            readonly on: "MdmEntity.inactivate";
        }, {
            readonly eventId: "loginGranted";
            readonly on: "login.granted";
        }, {
            readonly eventId: "inviteAccepted";
            readonly on: "invite.accepted";
        }];
    };
    export type MdmPlatformCatalogType = typeof mdmPlatformCatalog;
    export default mdmPlatformCatalog;
}
declare module "_102034_/l4/ontology/tdm.defs" {
    export const tdm: {
        readonly schemaVersion: "2026-09-17-tdm-ontology-v1";
        readonly family: "tdm";
        readonly title: "Transactional data of a module";
        readonly description: "The movement, the event, the operation of one module: an appointment, an order, a payment, a stock move. The module writes it and owns it; no other module reads it by name.";
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "The row id, written by the engine. Every foreign key that points at this table points at it.";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                    readonly description: "Optimistic concurrency counter of the row. Declared on every table; see knownDivergences for what the engine does with it today.";
                };
                readonly "<column>": {
                    readonly type: "string";
                    readonly indexed: true;
                    readonly description: "One key per column the module declares. A field is a column ONLY when something filters, sorts, deduplicates or searches by it: the foreign keys, the lifecycle status, the dates and the values a list really orders by. A column with no index does not belong here.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly description: "The JSONB document with everything else: free text, amounts that are only displayed, nested objects and the collections embedded by composition. Nothing filters by what is inside it.";
                };
            };
        };
        readonly recommendations: readonly ["`id` and `version` are written for you: never ask for them and never redeclare them.", "A field is a column only when something filters, sorts, deduplicates or searches by it. Everything else goes inside `details`, as a tree, however deep the business needs.", "Every foreign key is a column of `type: record` and is indexed — a key nobody can filter by is not a key.", "What belongs to the master record — name, document, contact, address — is never copied into a column here. The column carries the id of the record, and `read.mdmRecord` reads the rest.", "A number a person quotes (an order number, a ticket number, a receipt number) comes from `sequence.next` over `mdm_number_sequence`. Never a counter of your own, and never a column that stores the last number issued.", "A lifecycle is an indexed `status` column whose `values` cover the declared states; moving between them is the capability `transition`.", "Uniqueness is enforced on columns, through `uniqueKeys` — the engine turns it into a UNIQUE index.", "A value recalculated from OTHER rows (a total of the day, an average, a position in a ranking) is not a column of this table: it is a `ddm` entity. A value that follows from this same row (a status implied by its own dates, a total of its own embedded lines) or from rows linked to it by FK (the sum of its payments, whether an open order points at it) is a field of this row marked `derived`."];
        readonly capabilities: {
            readonly "read.byId": {
                readonly source: "table";
                readonly sentence: "Reads one row when the id is already known · findOne({ where: { id } }) on the repository of the table · any screen that already holds the id";
                readonly platform: "ready";
                readonly evidence: "l1/server/layer_1_external/data/moduleDataRuntime.ts:77";
            };
            readonly "locate.byColumn": {
                readonly source: "table";
                readonly sentence: "Lists rows filtered by equality on indexed columns, ordered and paged · findMany({ where, orderBy, limit, offset }); the page is 20 by default and is cut at 200, and the envelope declares the size actually used · any list screen";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:19-30 (input), :78 (findMany), :33-35 and :48-52 (page)";
            };
            readonly "locate.byText": {
                readonly source: "table";
                readonly sentence: "Finds rows whose column contains the typed text, anywhere in the string · findMany({ ilike }), one case-insensitive substring per column, ILIKE in Postgres · a search box over a list · no index serves a leading wildcard, so it reads the table";
                readonly platform: "partial";
                readonly evidence: "moduleDataRuntime.ts:21-22";
            };
            readonly count: {
                readonly source: "table";
                readonly sentence: "Counts the rows a filter matches, ignoring the page · count(), the same WHERE as findMany · a total on a list header or a badge";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:79-80";
            };
            readonly listByForeignKey: {
                readonly source: "table";
                readonly sentence: "Lists the rows that point at one record, or at many records at once · findMany({ where: { <fk> } }), and findManyByValues({ field, values }) to fill a whole list without one query per line · a record screen showing its movements";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:78, :81-85";
            };
            readonly create: {
                readonly source: "table";
                readonly sentence: "Writes a new row · insert({ record }); upsert when the same key may arrive twice · whoever performs the operation";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:86-87";
            };
            readonly update: {
                readonly source: "table";
                readonly sentence: "Changes part of a row · update({ where, patch }), the patch written as it comes · whoever maintains the movement";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:88";
            };
            readonly delete: {
                readonly source: "table";
                readonly sentence: "Removes the row physically · delete({ where }) · an administrator · nothing blocks it: unlike the master record, a module table has no relationship check before a delete";
                readonly platform: "ready";
                readonly evidence: "moduleDataRuntime.ts:89; compare mdm.capabilities.delete (MDM_DELETE_BLOCKED_BY_RELATIONSHIPS)";
            };
            readonly transition: {
                readonly source: "table";
                readonly sentence: "Moves the row from one lifecycle state to the next · an update of the indexed status column; the engine has no transition primitive, so the rule that guards it lives in the module · whoever the transition names";
                readonly platform: "partial";
                readonly evidence: "moduleDataRuntime.ts:88; no transition or state machine anywhere in l1/server/layer_1_external/data";
            };
            readonly uniqueKey: {
                readonly source: "table";
                readonly sentence: "Refuses a second row with the same key · a UNIQUE index of the module TableDefinition, partial (`where`) when the rule only applies to part of the rows · the engine, on write";
                readonly platform: "ready";
                readonly evidence: "l1/server/layer_1_external/persistence/contracts.ts:35-42; schemaBootstrap.ts:153";
            };
            readonly transaction: {
                readonly source: "table";
                readonly sentence: "Writes several rows all or nothing · runInTransaction over the module data runtime · whoever writes more than one table in one operation · a real transaction against Postgres; in the in-memory runtime of the preview it only calls the callback, so nothing is rolled back there";
                readonly platform: "partial";
                readonly evidence: "moduleDataRuntime.ts:577-585 (postgres) against :538-540 (memory)";
            };
            readonly "read.mdmRecord": {
                readonly source: "platform";
                readonly sentence: "Reads the master record a column of this table points at · ctx.mdm.entity.get({ mdmId }), and collection.getMany to hydrate a whole list at once · every screen that shows the name of the customer, the professional or the product behind a movement";
                readonly platform: "ready";
                readonly evidence: "l1/mdm/layer_3_usecases/mdmFacade.ts:237-243 (facade), :794 (MdmCollection); mdmImplementation.md §10";
            };
            readonly "sequence.next": {
                readonly source: "platform";
                readonly sentence: "Issues the next number of a counter, such as an order or a receipt number · mdm_number_sequence with SELECT … FOR UPDATE, key {module}.{entityType}.{scope} · the module, on create · the routine mdm.numberSequence.next is routed and works, but the facade a module usecase holds does not expose it, so today it is reached over the BFF";
                readonly platform: "partial";
                readonly evidence: "l1/mdm/layer_3_usecases/numberSequenceUsecases.ts:39-60; layer_2_controllers/router.ts:66; absent from MdmFacade (mdmFacade.ts:237-243)";
            };
            readonly "attach.document": {
                readonly source: "platform";
                readonly sentence: "Stores a photo, a scan or a signed file against this row, by category · mdm_attachment anchored by entityType and entityId, which are free text, so the row of a module table can be the anchor; upload to S3 or local disk with a presigned GET · whoever maintains the movement · the table has no module column and no generated module uses it yet";
                readonly platform: "partial";
                readonly evidence: "persistence.ts:536-556 (entityType TEXT); mdmFacade.ts:973-999 (facade attachment); mdmImplementation.md §6";
            };
            readonly comment: {
                readonly source: "platform";
                readonly sentence: "Leaves a note on this row, with one level of reply and a 15-minute edit window · mdm_comment anchored by entityType, entityId and module · whoever maintains the movement · routed as mdm.comment.*, and not on the facade, so a usecase reaches it over the BFF";
                readonly platform: "partial";
                readonly evidence: "persistence.ts:493-511; layer_2_controllers/router.ts:59-62; absent from MdmFacade (mdmFacade.ts:237-243)";
            };
            readonly tag: {
                readonly source: "platform";
                readonly sentence: "Marks this row with free labels inside the module namespace, and finds every row carrying one · mdm_tag, UNIQUE (entityType, entityId, tag, module), index (entityType, tag, module) · a module that needs a secondary key of its own · routed as mdm.tag.*, and not on the facade";
                readonly platform: "partial";
                readonly evidence: "persistence.ts:446-465; layer_2_controllers/router.ts:70-73; absent from MdmFacade (mdmFacade.ts:237-243)";
            };
            readonly "statusHistory.read": {
                readonly source: "platform";
                readonly sentence: "Shows when this row changed status and who changed it · mdm_status_history, read by mdm.statusHistory.findByEntity · the record screen · nothing writes a row for a module table: the history is written only by the MDM record service, so the read comes back empty until the module writes it itself";
                readonly platform: "missing";
                readonly evidence: "persistence.ts:404-423 (table); StatusHistoryService (core/DataRecordService.ts:272) is called only from l1/mdm (DataRecordService.ts:540, internal/entityPersistence.ts:400, :475, :541), never from the module data runtime; mdmImplementation.md §6";
            };
            readonly audit: {
                readonly source: "platform";
                readonly sentence: "Says who changed what, and when · mdm_audit_log, insert only · an administrator · a write to a module table goes through the module data runtime, which writes no audit row; only MDM writes are audited";
                readonly platform: "missing";
                readonly evidence: "AuditLogService (core/DataRecordService.ts:158) is called only from l1/mdm usecases (numberSequenceUsecases.ts:108, identityUsecases.ts:189, internal/relationshipPersistence.ts:82, and the record service itself); no audit reference anywhere in moduleDataRuntime.ts; mdmImplementation.md §6";
            };
        };
        readonly storage: {
            readonly engine: "One Postgres table per entity, declared as a TableDefinition in the persistence file of the module and created by the schema bootstrap (l1/server/layer_1_external/persistence/schemaBootstrap.ts).";
            readonly tableName: "The physical name is namespaced by project and module — mls<projectId>_<module>_<entity>; the logical name, the one a repository is asked for, is the entity in lowercase (registry.ts:405-420).";
            readonly details: "details is a JSONB column of the same row. Nothing filters by what is inside it; a field that has to be filtered is promoted to a column of its own.";
            readonly indexes: "indexes[] of the TableDefinition, unique and partial (where) supported; the primary key is id.";
            readonly purpose: "TablePurpose 'transacao' is the one that names this family in the persistence contract (contracts.ts:4-11).";
        };
        readonly knownDivergences: {
            readonly "version-never-bumped": "version is declared on every row and NO write path increments it: update writes the patch as it comes (moduleDataRuntime.ts:88). Optimistic concurrency on a module table is the target, not today's behaviour.";
            readonly "no-audit-for-module-tables": "mdm_audit_log is written only by the MDM record service; a write through the module data runtime leaves no trace.";
            readonly "no-status-history-for-module-tables": "mdm_status_history is written only by the MDM record service, so a lifecycle of a module table has no history unless the module writes one of its own.";
            readonly "ilike-is-a-scan": "locate.byText uses ILIKE with a leading wildcard, which no B-tree index serves; there is no trigram index on a module table.";
            readonly "memory-transaction-is-a-noop": "runInTransaction in the in-memory runtime just calls the callback, so a preview never rolls anything back (moduleDataRuntime.ts:538-540).";
            readonly "platform-services-not-on-the-facade": "sequence.next, comment and tag are routed and are absent from MdmFacade, which is what a module usecase holds; attach.document is the only one of the four the facade exposes.";
        };
    };
    export default tdm;
}

declare module "_102034_/l1/audit/module" {
    export interface AuditNamedCount {
        label: string;
        count: number;
    }
    export interface AuditLogEventRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: string;
        actorId: string;
        actorType: string;
        module: string;
        routine: string;
        createdAt: string;
        hasRemoteDiff: boolean;
    }
    export interface AuditStatusEventRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: string;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface AuditHomeResponse {
        generatedAt: string;
        system: {
            appEnv: string;
            runtimeMode: 'memory' | 'postgres';
            writeBehindEnabled: boolean;
            awsRegion: string;
        };
        summary: {
            auditLog: {
                total: number;
                last24h: number;
                uniqueModules: number;
                uniqueActors: number;
            };
            statusHistory: {
                total: number;
                last24h: number;
                uniqueEntities: number;
                uniqueTransitions: number;
            };
        };
        explanation: {
            auditLog: string;
            statusHistory: string;
        };
        distribution: {
            byModule: AuditNamedCount[];
            byEntityType: AuditNamedCount[];
            byActorId: AuditNamedCount[];
        };
        recentEvents: {
            auditLog: AuditLogEventRecord[];
            statusHistory: AuditStatusEventRecord[];
        };
    }
    export interface AuditLogLoadParams {
        module?: string;
        entityType?: string;
        entityId?: string;
        actorId?: string;
        actorType?: string;
        action?: string;
        from?: string;
        to?: string;
        page?: number;
        pageSize?: number;
    }
    export interface AuditLogDetailsParams {
        id: string;
    }
    export interface AuditLogDetailsResponse {
        generatedAt: string;
        event: (AuditLogEventRecord & {
            diff: unknown[] | null;
        }) | null;
    }
    export interface AuditLogResponse {
        generatedAt: string;
        filters: Required<AuditLogLoadParams>;
        summary: {
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
            uniqueModules: number;
            uniqueActors: number;
            createCount: number;
            updateCount: number;
            deleteCount: number;
            restoreCount: number;
        };
        groups: {
            byModule: AuditNamedCount[];
            byRoutine: AuditNamedCount[];
            byActorId: AuditNamedCount[];
            byAction: AuditNamedCount[];
        };
        events: AuditLogEventRecord[];
    }
    export interface AuditStatusHistoryLoadParams {
        module?: string;
        entityType?: string;
        entityId?: string;
        fromStatus?: string;
        toStatus?: string;
        actorId?: string;
        reasonCode?: string;
        from?: string;
        to?: string;
        page?: number;
        pageSize?: number;
    }
    export interface AuditStatusHistoryResponse {
        generatedAt: string;
        filters: Required<AuditStatusHistoryLoadParams>;
        summary: {
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
            uniqueModules: number;
            uniqueEntities: number;
            uniqueTransitions: number;
        };
        groups: {
            byModule: AuditNamedCount[];
            byEntityType: AuditNamedCount[];
            byTransition: AuditNamedCount[];
            currentStatuses: AuditNamedCount[];
        };
        events: AuditStatusEventRecord[];
    }
}
declare module "_102034_/l1/audit/layer_2_controllers/auditHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const auditHomeLoadHandler: BffHandler;
    export const auditAuditLogLoadHandler: BffHandler;
    export const auditAuditLogDetailsHandler: BffHandler;
    export const auditStatusHistoryLoadHandler: BffHandler;
}
declare module "_102034_/l1/audit/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createAuditRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/audit/layer_3_usecases/auditUsecases.test" { }
declare module "_102034_/l1/audit/layer_3_usecases/auditUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { AuditHomeResponse, AuditLogDetailsParams, AuditLogDetailsResponse, AuditLogLoadParams, AuditLogResponse, AuditStatusHistoryLoadParams, AuditStatusHistoryResponse } from '_102034_/l1/audit/module';
    export function loadAuditHome(ctx: RequestContext): Promise<AuditHomeResponse>;
    export function loadAuditLog(ctx: RequestContext, input?: AuditLogLoadParams): Promise<AuditLogResponse>;
    export function loadAuditLogDetails(ctx: RequestContext, input: AuditLogDetailsParams): Promise<AuditLogDetailsResponse>;
    export function loadAuditStatusHistory(ctx: RequestContext, input?: AuditStatusHistoryLoadParams): Promise<AuditStatusHistoryResponse>;
}
declare module "_102034_/l1/mdm/integration.test" { }
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls mdm.promoteProspect(prospectMdmId)
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/integration" {
    import type { MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CompactRelationshipRefs, CompanyKind, MdmDetailRecord, MdmEntityIndexRecord, MdmModuleNamespaceValue, MdmProspectIndexRecord, MdmRelationshipRecord, ServiceKind } from '_102034_/l1/mdm/module';
    export type MdmSubtypeRef = MdmSubtype;
    export type { CompanyKind, ServiceKind };
    export interface MdmRef {
        mdmId: string;
        subtype: MdmSubtypeRef;
        name: string;
    }
    export interface MdmLookupResult extends MdmRef {
        status: MdmStatus | string;
        countryCode?: string | null;
        docType?: string | null;
        docId?: string | null;
        companyKind?: CompanyKind | null;
        serviceKind?: ServiceKind | null;
        parentCompanyId?: string | null;
        parentServiceId?: string | null;
        relationshipRefs?: CompactRelationshipRefs;
        moduleNamespaces?: Record<string, MdmModuleNamespaceValue>;
    }
    export interface MdmRelationshipSummary {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        status: MdmRelationshipRecord['status'];
        role?: string | null;
    }
    export interface MdmSearchFilter {
        subtype?: MdmSubtypeRef;
        status?: string;
        countryCode?: string;
        companyKind?: CompanyKind;
        serviceKind?: ServiceKind;
        docType?: string;
        docId?: string;
        query?: string;
        limit?: number;
    }
    export interface MdmIntegrationContract {
        getByMdmId(input: {
            mdmId: string;
        }): Promise<MdmLookupResult | null>;
        search(input: MdmSearchFilter): Promise<MdmLookupResult[]>;
        listRelationships(input: {
            mdmId: string;
            type?: RelationshipType;
            scope?: 'entity' | 'prospect' | 'all';
        }): Promise<MdmRelationshipSummary[]>;
        resolveCourseHierarchy(input: {
            mdmId: string;
        }): Promise<{
            current: MdmLookupResult | null;
            parentCourse: MdmLookupResult | null;
            cohorts: MdmLookupResult[];
        }>;
        resolveOrganizationTree(input: {
            mdmId: string;
        }): Promise<{
            current: MdmLookupResult | null;
            parent: MdmLookupResult | null;
            children: MdmLookupResult[];
        }>;
    }
    export type MdmRecordSummary = MdmEntityIndexRecord | MdmProspectIndexRecord;
    export function toMdmLookupResult(detail: MdmDetailRecord, summary?: Partial<MdmRecordSummary>): MdmLookupResult;
    export function toMdmRelationshipSummary(relationship: MdmRelationshipRecord): MdmRelationshipSummary;
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;
    export type MdmDetailInput = DistributiveOmit<MdmDetailRecord, 'mdmId'> & {
        mdmId?: string;
    };
    export interface MdmDocumentInput {
        mdmId: string;
        version: number;
        details: MdmDetailInput;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import('/_102034_/l1/server/layer_1_external/data/runtime.js').IDataRuntime): import('/_102034_/l1/server/layer_1_external/data/runtime.js').ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102034_/l1/mdm/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/mdm/tableNames" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export function getMdmTableNames(appEnv: AppEnv['appEnv']): {
        documents: string;
        documentsEntitiesIndex: string;
        documentsProspectsIndex: string;
        kv: string;
        relationship: string;
        prospectRelationship: string;
        auditLog: string;
        tag: string;
        comment: string;
        attachment: string;
        numberSequence: string;
        outbox: string;
        replicationFailures: string;
        monitoringWrite: string;
        errorLog: string;
        statusHistory: string;
    };
}
declare module "_102034_/l1/mdm/defs/rules" {
    /**
     * MDM — Master Data Model
     * Business rules for all MDM entities and workflows.
     *
     * Schema per rule:
     *   kind               → "domain" | "policy" | "platform" | "validation"
     *   description        → what the rule enforces, in plain English
     *   scope              → entity names, capability names, or "global"
     *   entities           → MDM entity subtypes directly affected (optional)
     *   acceptanceCriteria → verifiable conditions that confirm the rule is met
     */
    export const MdmRules: {
        readonly rule_mdm_single_id_space: {
            readonly kind: "platform";
            readonly description: "Every entity in the MDM — regardless of subtype — shares a single mdmId space. Any module may store an mdmId as a foreign key without knowing the subtype.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["mdmId is a UUID generated at creation and never changed.", "No module-specific ID scheme is allowed to replace or shadow mdmId.", "On prospect promotion, the mdmId is preserved — no new ID is generated unless a merge conflict is resolved."];
        };
        readonly rule_mdm_default_country_us: {
            readonly kind: "platform";
            readonly description: "The default country for all MDM entities is the United States (US). Country-specific validation (document formats, tax regimes, privacy consent) is applied based on the countryCode field.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["countryCode defaults to \"US\" when not explicitly provided.", "Document type validation (SSN, EIN, CPF, CNPJ, etc.) is gated on countryCode.", "Privacy consent is required only when countryCode is \"BR\" (LGPD) or an EU member state (GDPR)."];
        };
        readonly rule_mdm_dependency_direction: {
            readonly kind: "platform";
            readonly description: "MDM has no knowledge of any consuming module. Dependency is always unidirectional: module → MDM. Module-specific data is stored in extension tables owned by the module, not in MDM.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["No MDM entity, rule, or service may import or reference a non-MDM module.", "Module extensions use a dedicated table (e.g. CrmMdmExt) with mdmId as FK.", "MDM write operations never trigger module-specific side effects."];
        };
        readonly rule_mdm_read_from_dynamo: {
            readonly kind: "platform";
            readonly description: "Full entity data is read from the operational document store exposed by the backend runtime. In the current architecture, PostgreSQL local cache is the operational read source and DynamoDB remains the remote recovery/replication source of truth.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["BFF handlers that return entity details fetch the MDM document record, not only the Postgres index row.", "Postgres index fields are used for filtering, searching, joining, and deduplication.", "The operational runtime may serve details from mdm_cache, as long as the full document shape is preserved.", "DynamoDB remains the remote backup and restore source for rebuilding local tables when needed."];
        };
        readonly rule_mdm_version_optimistic_concurrency: {
            readonly kind: "platform";
            readonly description: "DynamoDB writes use optimistic concurrency via the version field. A write is rejected if the version in the store differs from the version read by the caller.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["Every write increments version by 1.", "Write operations include a condition expression: version = expectedVersion.", "On conflict, the caller receives a ConcurrencyConflict error and must re-fetch before retrying."];
        };
        readonly rule_entity_dedup_by_doc_id: {
            readonly kind: "domain";
            readonly description: "In MdmEntity, the combination of (docType, docId) must be unique. Attempting to create a new entity with an existing (docType, docId) pair returns the existing mdmId instead of creating a duplicate.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person", "Company"];
            readonly acceptanceCriteria: readonly ["PostgreSQL enforces UNIQUE(docType, docId) on MdmEntity.", "The creation service checks for an existing match before inserting.", "When a match is found, the existing mdmId is returned with a 200 (not a 201).", "The caller is informed that the returned record already existed."];
        };
        readonly rule_prospect_no_dedup_constraint: {
            readonly kind: "domain";
            readonly description: "MdmProspect does not enforce uniqueness on (docType, docId). The same document number may appear multiple times as separate prospects. Deduplication is resolved at promotion time.";
            readonly scope: readonly ["MdmProspect"];
            readonly acceptanceCriteria: readonly ["No UNIQUE constraint on (docType, docId) in MdmProspect.", "Duplicate prospects with the same docId are allowed and flagged during promotion.", "The promotion workflow presents duplicate candidates to the operator for manual resolution."];
        };
        readonly rule_merge_preserves_mdm_id: {
            readonly kind: "domain";
            readonly description: "When two entities are merged, one mdmId is designated as the winner. The loser record is set to status Merged with mergedInto pointing to the winner. The loser mdmId is never deleted — it remains as a tombstone for backward compatibility.";
            readonly scope: readonly ["MdmEntity"];
            readonly acceptanceCriteria: readonly ["Merged records have status \"Merged\" and a non-null mergedInto field.", "All foreign key references to the loser mdmId continue to resolve (tombstone is permanent).", "A lookup by the loser mdmId returns the tombstone record with a redirect to the winner mdmId.", "No hard deletion of merged records."];
        };
        readonly rule_prospect_promotion_workflow: {
            readonly kind: "domain";
            readonly description: "A prospect is promoted to a permanent entity via an explicit promotion call. The workflow checks for duplicates in MdmEntity and either promotes directly or flags for operator review.";
            readonly scope: readonly ["MdmProspect", "MdmEntity", "cap_promote_prospect"];
            readonly acceptanceCriteria: readonly ["Promotion is triggered by an explicit mdm.promoteProspect(prospectMdmId) call.", "If no MdmEntity match is found: the DynamoDB document is unchanged; the PostgreSQL row is moved from MdmProspect to MdmEntity; the same mdmId is used.", "If a match is found: prospect status is set to PendingMerge; an operator review task is created.", "After promotion, the calling module updates its extension table to point to the final mdmId.", "MdmProspectRelationship rows referencing the promoted entity are migrated to MdmRelationship."];
        };
        readonly rule_prospect_ttl_expiry: {
            readonly kind: "policy";
            readonly description: "Prospects with a ttlExpiresAt timestamp are automatically expired when the TTL is reached without promotion. Expired prospects are not deleted — they are set to status Expired.";
            readonly scope: readonly ["MdmProspect"];
            readonly acceptanceCriteria: readonly ["A background job checks for prospects where ttlExpiresAt < now() and status is New or InProgress.", "Qualifying prospects are set to status Expired.", "Expired prospects are retained for audit purposes and can be manually reactivated.", "Null ttlExpiresAt means no expiry — the prospect remains until explicitly promoted or discarded."];
        };
        readonly rule_person_ssn_unique_for_us: {
            readonly kind: "validation";
            readonly description: "For persons with countryCode \"US\", the SSN (docType: SSN) must be unique in MdmEntity. SSN is treated as the primary deduplication key for US individuals.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person"];
            readonly acceptanceCriteria: readonly ["If docType is SSN and countryCode is US, the UNIQUE(docType, docId) constraint in Postgres applies.", "SSN is stored as digits only, no dashes.", "SSN is never returned in list responses — only in single-entity reads with explicit field projection."];
        };
        readonly rule_person_privacy_consent_required_br_eu: {
            readonly kind: "policy";
            readonly description: "For persons with countryCode in Brazil (BR) or any EU member state, a PrivacyConsent record must be present in the entity document before the record is set to status Active.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Person"];
            readonly acceptanceCriteria: readonly ["Creation of a Person with countryCode BR or an EU code without privacyConsent results in status Inactive.", "The entity is set to Active only after privacyConsent.consentedAt is recorded.", "Revocation (privacyConsent.revokedAt set) triggers a status change to Inactive."];
        };
        readonly rule_company_ein_unique_for_us: {
            readonly kind: "validation";
            readonly description: "For companies with countryCode \"US\", the EIN (docType: EIN) must be unique in MdmEntity.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Company"];
            readonly acceptanceCriteria: readonly ["If docType is EIN and countryCode is US, the UNIQUE(docType, docId) constraint applies.", "EIN is stored as digits only, no dashes."];
        };
        readonly rule_company_legal_name_required: {
            readonly kind: "validation";
            readonly description: "Every Company entity must have a non-empty legalName in its detail document.";
            readonly scope: readonly ["MdmEntity", "MdmProspect"];
            readonly entities: readonly ["Company"];
            readonly acceptanceCriteria: readonly ["Creation or update of a Company without legalName is rejected with a validation error.", "tradeName is optional; legalName is not."];
        };
        readonly rule_bank_account_holder_via_relationship: {
            readonly kind: "domain";
            readonly description: "The holder of a BankAccount is not stored as a field inside the BankAccount document. The ownership relationship is expressed via a HoldsAccount relationship in MdmRelationship.";
            readonly scope: readonly ["MdmRelationship"];
            readonly entities: readonly ["BankAccount"];
            readonly acceptanceCriteria: readonly ["No \"holderId\" or \"ownerMdmId\" field exists in BankAccountDetail.", "To find the holder of an account, query MdmRelationship where toId = bankAccountMdmId and type = HoldsAccount.", "A BankAccount may have multiple holders (joint accounts) — each represented as a separate HoldsAccount relationship."];
        };
        readonly rule_bank_account_routing_required_for_us: {
            readonly kind: "validation";
            readonly description: "For BankAccount entities used in US domestic transfers, bankRoutingNumber is required.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["BankAccount"];
            readonly acceptanceCriteria: readonly ["If a BankAccount is associated with a US-based holder (countryCode US) and accountType is Checking or Savings, bankRoutingNumber must be present.", "International accounts (IBAN/SWIFT) are exempt from this requirement."];
        };
        readonly rule_document_parties_via_relationships: {
            readonly kind: "domain";
            readonly description: "Parties involved in a Document (signatories, issuees, subjects) are not stored as an array inside the Document detail. They are represented as Signed or HasContact relationships in MdmRelationship.";
            readonly scope: readonly ["MdmRelationship"];
            readonly entities: readonly ["Document"];
            readonly acceptanceCriteria: readonly ["No parties[] or signatories[] field exists in DocumentDetail.", "To find all parties of a document, query MdmRelationship where toId = documentMdmId and type = Signed.", "The role field in MdmRelationship carries the party role: contractor, client, witness, notary."];
        };
        readonly rule_document_path_immutable: {
            readonly kind: "policy";
            readonly description: "The storageBucket and storagePath fields of a Document are immutable after creation. Files must never be moved or renamed in storage without creating a new Document entity.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["Document"];
            readonly acceptanceCriteria: readonly ["Update operations that attempt to change storageBucket or storagePath are rejected with a validation error.", "To update a file, a new Document entity must be created with the new path.", "The old Document entity is set to status Inactive, not deleted."];
        };
        readonly rule_contact_value_unique_per_type: {
            readonly kind: "validation";
            readonly description: "Within MdmEntity, the combination of (contactType, value) must be unique. The same phone number or email address cannot belong to two different ContactChannel entities.";
            readonly scope: readonly ["MdmEntity"];
            readonly entities: readonly ["ContactChannel"];
            readonly acceptanceCriteria: readonly ["Attempting to create a ContactChannel with an existing (contactType, value) pair returns the existing mdmId.", "Uniqueness is enforced at the service layer before the DynamoDB write.", "MdmProspect does not enforce this constraint — duplicates are resolved on promotion."];
        };
        readonly rule_relationship_valid_period: {
            readonly kind: "domain";
            readonly description: "All relationships must have a validFrom date. validTo is optional and null means currently active. Historical relationships are retained — not deleted when they end.";
            readonly scope: readonly ["MdmRelationship", "MdmProspectRelationship"];
            readonly acceptanceCriteria: readonly ["validFrom is required on creation.", "When a relationship ends, validTo is set — the row is not deleted.", "Queries for active relationships must filter by validTo IS NULL OR validTo >= today.", "Multiple non-overlapping relationship periods between the same two entities are allowed (e.g. rehire)."];
        };
        readonly rule_relationship_bidirectional_query: {
            readonly kind: "platform";
            readonly description: "For bidirectional relationships (isBidirectional: true), only one row is stored in the database. Querying \"all relationships of entity X\" must check both fromId and toId columns.";
            readonly scope: readonly ["MdmRelationship", "MdmProspectRelationship"];
            readonly acceptanceCriteria: readonly ["isBidirectional = true relationships are stored as a single row with fromId being the creator.", "The relationship query service returns the relationship when X appears in either fromId or toId.", "No duplicate rows are created for bidirectional relationships."];
        };
        readonly rule_async_worker_idempotency: {
            readonly kind: "platform";
            readonly description: "The background worker that processes write-behind events to DynamoDB and other remote stores must be idempotent. Re-processing the same outbox event must not create duplicate remote state or corrupt data.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["The worker processes durable outbox events generated by the local write transaction.", "Remote writes are idempotent for the same aggregateId and version or equivalent event payload.", "Worker failures and retries do not cause duplicate remote rows or data corruption.", "Successfully replicated outbox rows are deleted from mdm_outbox as the normal completion path.", "Failed outbox rows remain in mdm_outbox with retry metadata and the last error message for operator visibility."];
        };
        readonly rule_sync_fields_written_atomically: {
            readonly kind: "platform";
            readonly description: "SYNC fields (mdmId, subtype, name, status, docType, docId, mergedInto, dynamoPk) must be written atomically to the local PostgreSQL operational tables in the same request as the local document write. Remote DynamoDB replication is performed asynchronously via write-behind.";
            readonly scope: readonly ["global"];
            readonly acceptanceCriteria: readonly ["The entity write service writes the local document, index rows, and outbox event in the same local transaction.", "If the local transaction fails, no partial local state is committed.", "If remote replication succeeds, the corresponding outbox row is removed from mdm_outbox.", "If remote replication fails, the outbox retains the pending event for retry or operator intervention.", "The system must never have a state where a committed local document exists without its required local SYNC index row."];
        };
    };
    export type MdmRuleId = keyof typeof MdmRules;
}
declare module "_102034_/l1/mdm/layer_1_external/data/runtimeFactory" {
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export function getSharedDataRuntime(): IDataRuntime;
    export function resetSharedDataRuntime(): void;
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAttachmentRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmAttachmentRecord } from '_102034_/l1/mdm/module';
    export class MdmAttachmentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmAttachmentRecord): Promise<void>;
        get(id: string): Promise<MdmAttachmentRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAuditLogRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmAuditLogDocumentRecord } from '_102034_/l1/mdm/module';
    export class MdmAuditLogRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmAuditLogDocumentRecord): Promise<void>;
        get(id: string): Promise<MdmAuditLogDocumentRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmCommentRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmCommentRecord } from '_102034_/l1/mdm/module';
    export class MdmCommentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmCommentRecord): Promise<void>;
        get(id: string): Promise<MdmCommentRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmDocumentRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmDocumentRecord } from '_102034_/l1/mdm/module';
    export class MdmDocumentRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        get(mdmId: string): Promise<MdmDocumentRecord | null>;
        put(record: MdmDocumentRecord): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmNumberSequenceRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmNumberSequenceRecord } from '_102034_/l1/mdm/module';
    export class MdmNumberSequenceRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmNumberSequenceRecord): Promise<void>;
        get(id: string): Promise<MdmNumberSequenceRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmRelationshipRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmRelationshipDocumentRecord } from '_102034_/l1/mdm/module';
    export class MdmRelationshipRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        private getTableName;
        put(record: MdmRelationshipDocumentRecord): Promise<void>;
        delete(id: string, scope: 'entity' | 'prospect'): Promise<void>;
        listAll(scope: 'entity' | 'prospect'): Promise<MdmRelationshipDocumentRecord[]>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmTagRemoteRuntimeDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmTagRecord } from '_102034_/l1/mdm/module';
    export class MdmTagRemoteRuntimeDynamo {
        private readonly env;
        private readonly client;
        constructor(env: AppEnv);
        put(record: MdmTagRecord): Promise<void>;
        get(id: string): Promise<MdmTagRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient" {
    import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export function createDynamoDocumentClient(env: AppEnv): DynamoDBDocumentClient;
}
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.test" { }
declare module "_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory" {
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export function createMemoryDataRuntime(): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/pg" {
    export { getSharedPgPool, queryRows, withPgTransaction, } from '_102034_/l1/server/layer_1_external/data/postgres/pg';
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export function createPostgresDataRuntime(env: AppEnv): IDataRuntime;
}
declare module "_102034_/l1/mdm/layer_1_external/queue/RestoreFromDynamoUsecase" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MdmDocumentRecord, MdmRelationshipDocumentRecord } from '_102034_/l1/mdm/module';
    export class RestoreFromDynamoUsecase {
        private readonly env;
        private readonly runtime;
        private readonly remoteRuntime;
        private readonly remoteRelationshipRuntime;
        constructor(env?: AppEnv);
        restoreDocument(document: MdmDocumentRecord): Promise<void>;
        restoreById(mdmId: string): Promise<void>;
        restoreRelationship(relationship: MdmRelationshipDocumentRecord): Promise<void>;
        restoreAllRelationships(): Promise<number>;
    }
}
declare module "_102034_/l1/mdm/layer_1_external/queue/WriteBehindWorker" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export class WriteBehindWorker {
        private readonly env;
        private readonly runtime;
        private readonly remoteAuditRuntime;
        private readonly remoteRuntime;
        private readonly remoteRelationshipRuntime;
        private readonly remoteTagRuntime;
        private readonly remoteCommentRuntime;
        private readonly remoteAttachmentRuntime;
        private readonly remoteNumberSequenceRuntime;
        constructor(env?: AppEnv);
        private static readonly MAX_ATTEMPT_COUNT;
        runOnce(limit?: number): Promise<{
            processed: number;
            failed: number;
        }>;
        private handleRegistryTablePayload;
    }
}
declare module "_102034_/l1/mdm/layer_2_controllers/attachmentHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const attachmentAttachHandler: BffHandler;
    export const attachmentDetachHandler: BffHandler;
    export const attachmentFindByEntityHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/commentHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const commentAddHandler: BffHandler;
    export const commentEditHandler: BffHandler;
    export const commentRemoveHandler: BffHandler;
    export const commentFindByEntityHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/entityHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const entityCreateHandler: BffHandler;
    export const entityGetHandler: BffHandler;
    export const entityListHandler: BffHandler;
    export const entityUpdateHandler: BffHandler;
    export const entityMergeHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/kvHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const kvGetHandler: BffHandler;
    export const kvPutHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/numberSequenceHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const numberSequenceNextHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/prospectHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const prospectCreateHandler: BffHandler;
    export const prospectGetHandler: BffHandler;
    export const prospectListHandler: BffHandler;
    export const prospectUpdateHandler: BffHandler;
    export const prospectPromoteHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/relationshipHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const relationshipCreateHandler: BffHandler;
    export const relationshipListHandler: BffHandler;
    export const relationshipUpdateHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createMdmRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/mdm/layer_2_controllers/searchHandler" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const searchHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/statusHistoryHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const statusHistoryFindByEntityHandler: BffHandler;
    export const statusHistoryFindLatestHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_2_controllers/tagHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const tagAddHandler: BffHandler;
    export const tagRemoveHandler: BffHandler;
    export const tagFindByEntityHandler: BffHandler;
    export const tagFindByTagHandler: BffHandler;
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams } from '_102034_/l1/mdm/module';
    export function attachFile(ctx: RequestContext, params: AttachFileParams): Promise<any>;
    export function detachFile(ctx: RequestContext, params: DetachFileParams): Promise<any>;
    export function findAttachmentsByEntity(ctx: RequestContext, params: FindAttachmentsByEntityParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/commentUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/commentUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { AddCommentParams, EditCommentParams, FindCommentsByEntityParams, RemoveCommentParams } from '_102034_/l1/mdm/module';
    export function addComment(ctx: RequestContext, params: AddCommentParams): Promise<any>;
    export function editComment(ctx: RequestContext, params: EditCommentParams): Promise<any>;
    export function removeComment(ctx: RequestContext, params: RemoveCommentParams): Promise<any>;
    export function findCommentsByEntity(ctx: RequestContext, params: FindCommentsByEntityParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/kvUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/kvUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { GetMdmKvParams, MdmKvRecord, PutMdmKvParams } from '_102034_/l1/mdm/module';
    export function getMdmKv(ctx: RequestContext, params: GetMdmKvParams): Promise<MdmKvRecord | null>;
    export function putMdmKv(ctx: RequestContext, params: PutMdmKvParams): Promise<MdmKvRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmSupport" {
    import type { MdmProspectStatus, MdmStatus, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CreateRecordParams, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, MdmRelationshipRecord } from '_102034_/l1/mdm/module';
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    type RelationshipScope = 'entity' | 'prospect';
    export function refreshRelationshipRefs(ctx: RequestContext, relationshipScope: RelationshipScope, mdmIds: string[], enqueueDocumentWrite: (document: {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }) => Promise<void>): Promise<void>;
    export function normalizeCountryCode(countryCode?: string | null): string;
    export function normalizeDocumentId(docId?: string | null): string | null;
    export function normalizeContactValue(value?: string | null): string | null;
    export function isProtectedPrivacyCountry(countryCode: string): boolean;
    export function normalizeDetailInput(input: CreateRecordParams['detail'], ctx: RequestContext, mdmId: string): MdmDetailRecord;
    export function applyPatchToDetail(currentDetail: MdmDetailRecord, patch: Partial<MdmDetailRecord>, ctx: RequestContext): MdmDetailRecord;
    export function normalizeStatus(detail: MdmDetailRecord): MdmStatus | MdmProspectStatus;
    export function validateDetail(detail: MdmDetailRecord): void;
    export function toDocumentRecord(detail: MdmDetailRecord, version: number): {
        mdmId: any;
        version: number;
        details: MdmDetailRecord;
    };
    export function buildEntityIndex(detail: MdmDetailRecord): MdmEntityIndexRecord;
    export function buildProspectIndex(detail: MdmDetailRecord): MdmProspectIndexRecord;
    export function normalizeEntityStatus(detail: MdmDetailRecord): MdmStatus;
    export function normalizeProspectStatus(detail: MdmDetailRecord): MdmProspectStatus;
    export function buildSearchVector(detail: MdmDetailRecord): string;
    export function relationshipIsBidirectional(type: RelationshipType): boolean;
    export function migrateProspectRelationships(ctx: RequestContext, prospectMdmId: string): Promise<{
        affectedIds: string[];
        migratedRelationships: MdmRelationshipRecord[];
    }>;
    export function buildRelationshipSearchText(relationship: MdmRelationshipRecord): string;
}
declare module "_102034_/l1/mdm/layer_3_usecases/numberSequenceUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/numberSequenceUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { NumberSequenceNextParams } from '_102034_/l1/mdm/module';
    export function nextSequence(ctx: RequestContext, params: NumberSequenceNextParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/postgresDynamo.integration.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/recordUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/recordUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { CreateRecordParams, ListRecordsParams, MergeEntityParams, MdmDocumentRecord, MdmRelationshipDocumentRecord, PromoteProspectParams, RecordDetailResponse, UpdateRecordParams } from '_102034_/l1/mdm/module';
    export function enqueueWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], document: MdmDocumentRecord): Promise<void>;
    export function enqueueRelationshipWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], relationship: MdmRelationshipDocumentRecord): Promise<void>;
    export function createEntity(ctx: RequestContext, params: CreateRecordParams): Promise<{
        alreadyExists: boolean;
        mdmId: any;
        version?: undefined;
    } | {
        alreadyExists: boolean;
        mdmId: any;
        version: number;
    }>;
    export function createProspect(ctx: RequestContext, params: CreateRecordParams): Promise<{
        mdmId: any;
        version: number;
    }>;
    export function getEntity(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function getProspect(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function listEntities(ctx: RequestContext, params: ListRecordsParams): Promise<any>;
    export function listProspects(ctx: RequestContext, params: ListRecordsParams): Promise<any>;
    export function updateEntity(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: any;
        version: any;
        status: any;
    }>;
    export function updateProspect(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: any;
        version: any;
        status: any;
    }>;
    export function promoteProspect(ctx: RequestContext, params: PromoteProspectParams): Promise<any>;
    export function mergeEntity(ctx: RequestContext, params: MergeEntityParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/relationshipUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/relationshipUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { CreateRelationshipParams, ListRelationshipsParams, SearchParams, UpdateRelationshipParams } from '_102034_/l1/mdm/module';
    export function createRelationship(ctx: RequestContext, params: CreateRelationshipParams): Promise<any>;
    export function listRelationships(ctx: RequestContext, params: ListRelationshipsParams): Promise<any[]>;
    export function updateRelationship(ctx: RequestContext, params: UpdateRelationshipParams): Promise<any>;
    export function runSearch(ctx: RequestContext, params: SearchParams): Promise<{
        records: any[];
        relationships: any;
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/statusHistoryUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/statusHistoryUsecases" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { FindLatestStatusByEntityParams, FindStatusHistoryByEntityParams } from '_102034_/l1/mdm/module';
    export function findStatusHistoryByEntity(ctx: RequestContext, params: FindStatusHistoryByEntityParams): Promise<any>;
    export function findLatestStatusByEntity(ctx: RequestContext, params: FindLatestStatusByEntityParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/tagUsecases.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/tagUsecases" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { AddTagParams, FindTagsByEntityParams, FindTagsByTagParams, RemoveTagParams } from '_102034_/l1/mdm/module';
    export function addTag(ctx: RequestContext, params: AddTagParams): Promise<any>;
    export function removeTag(ctx: RequestContext, params: RemoveTagParams): Promise<any>;
    export function findTagsByEntity(ctx: RequestContext, params: FindTagsByEntityParams): Promise<any>;
    export function findTagsByTag(ctx: RequestContext, params: FindTagsByTagParams): Promise<any>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService.test" { }
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from '_102034_/l1/mdm/module';
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/mdmEntityDefs" {
    import type { EntityDef, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord } from '_102034_/l1/mdm/module';
    export const mdmEntityDef: EntityDef<MdmDetailRecord, MdmEntityIndexRecord>;
    export const mdmProspectDef: EntityDef<MdmDetailRecord, MdmProspectIndexRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from '_102034_/l1/mdm/module';
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_4_entities/MdmDocumentEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { MdmDetailRecord, MdmDocumentRecord } from '_102034_/l1/mdm/module';
    export class MdmDocumentEntity {
        static get(ctx: RequestContext, mdmId: string): Promise<MdmDocumentRecord>;
        static parseDetails(document: MdmDocumentRecord): MdmDetailRecord;
        static create(ctx: RequestContext, record: MdmDocumentRecord): Promise<void>;
        static replace(ctx: RequestContext, record: MdmDocumentRecord, expectedVersion: number): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_4_entities/MdmRecordEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { MdmEntityIndexRecord, MdmProspectIndexRecord } from '_102034_/l1/mdm/module';
    export class MdmRecordEntity {
        static getEntityIndex(ctx: RequestContext, mdmId: string): Promise<MdmEntityIndexRecord>;
        static getProspectIndex(ctx: RequestContext, mdmId: string): Promise<MdmProspectIndexRecord>;
        static findEntityByDocument(ctx: RequestContext, docType?: string | null, docId?: string | null): Promise<MdmEntityIndexRecord | null>;
        static findEntityByContact(ctx: RequestContext, contactType?: string | null, value?: string | null): Promise<MdmEntityIndexRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_4_entities/MdmRelationshipEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { MdmRelationshipRecord } from '_102034_/l1/mdm/module';
    export class MdmRelationshipEntity {
        static findOne(ctx: RequestContext, id: string): Promise<{
            scope: 'entity' | 'prospect';
            relationship: MdmRelationshipRecord;
        }>;
    }
}
declare module "_102034_/l1/mdm/plugin/index" {
    export const mdmPlugin: {
        module: string;
    };
}
declare module "_102034_/l1/monitor/module" {
    export type MonitorStatusGroup = 'success' | 'client_error' | 'server_error' | 'not_found';
    export interface MonitorBffExecutionLogRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    /** Continuous aggregate — no id or updatedAt, maintained by TimescaleDB. */
    export interface MonitorBffExecutionAggregateMinuteRecord {
        bucketStart: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        totalCount: number;
        successCount: number;
        clientErrorCount: number;
        serverErrorCount: number;
        notFoundCount: number;
        totalDurationMs: number;
    }
    export interface MonitorClientTelemetryEventRecord {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        module: string;
        routine: string;
        eventType: string;
        label?: string | null;
        durationMs?: number | null;
        metadata?: unknown;
        recordedAt: string;
        receivedAt: string;
    }
    export interface MonitorSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorExecutionEvent {
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        pageName: string;
        command: string;
        source: 'http' | 'message' | 'test';
        statusCode: number;
        statusGroup: MonitorStatusGroup;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
}
declare module "_102034_/l1/monitor/persistence" {
    import type { TableDefinition, ViewDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
    export const viewDefinitions: ViewDefinition[];
}
declare module "_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore.test" { }
declare module "_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore" {
    import type { MonitorExecutionEvent, MonitorSeriesPoint } from '_102034_/l1/monitor/module';
    export class BffExecutionSeriesStore {
        private readonly maxWindowSeconds;
        private readonly buckets;
        constructor(maxWindowSeconds?: number);
        record(event: MonitorExecutionEvent): void;
        getSeries(input?: {
            windowSeconds?: number;
            routine?: string;
            source?: 'http' | 'message' | 'test';
        }): MonitorSeriesPoint[];
        reset(): void;
        private trim;
        private listRecentTimestamps;
        private incrementDetailPoint;
    }
    export function getSharedBffExecutionSeriesStore(): BffExecutionSeriesStore;
    export function resetSharedBffExecutionSeriesStore(): void;
}
declare module "_102034_/l1/monitor/layer_1_external/data/persistence/MonitorPersistenceMetadata" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export interface MonitorTableMetadata {
        projectId: string;
        moduleId: string;
        repositoryName: string;
        tableName: string;
        description: string;
        purpose: string;
        storageProfile: string;
        backupHot: boolean;
        writeMode: string;
        dynamoTableName: string | null;
        dynamoPartitionKey: string | null;
        dynamoSortKey: string | null;
        dynamoTtlField: string | null;
        localIndexes: Array<{
            name: string;
            unique: boolean;
            columns: string[];
        }>;
        detailsInDynamoOnly: boolean;
    }
    export class MonitorPersistenceMetadata {
        private readonly env;
        constructor(env: AppEnv);
        listAll(): Promise<MonitorTableMetadata[]>;
        listPostgresTables(): Promise<any>;
        listDynamoTables(): Promise<any>;
        findByPostgresTableName(tableName: string): Promise<MonitorTableMetadata | null>;
        findByDynamoTableName(tableName: string): Promise<MonitorTableMetadata | null>;
    }
}
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres.test" { }
declare module "_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres" {
    import { type AttributeValue } from '@aws-sdk/client-dynamodb';
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { MonitorBffExecutionLogRecord, MonitorExecutionEvent } from '_102034_/l1/monitor/module';
    type MonitorPostgresColumn = {
        name: string;
        dataType: string;
        isNullable: boolean;
        defaultValue: string | null;
    };
    type MonitorPostgresIndex = {
        name: string;
        unique: boolean;
        method: string;
        columns: string[];
    };
    type MonitorDynamoKey = Record<string, AttributeValue>;
    export function normalizeStringList(value: unknown): string[];
    export function isSafeMonitorIdentifier(value: string): boolean;
    export function normalizeInspectFilters(input: unknown): Record<string, string>;
    export function normalizeDynamoKey(key: MonitorDynamoKey | undefined): string | null;
    export function decodeDynamoKey(cursor?: string | null): MonitorDynamoKey | undefined;
    export function parseRoutineParts(routine: string): {
        module: string;
        pageName: string;
        command: string;
    };
    export function getStatusGroup(statusCode: number): "success" | "client_error" | "server_error" | "not_found";
    export class MonitorRuntimePostgres {
        private readonly env;
        private readonly metadata;
        constructor(env?: AppEnv);
        recordExecution(event: MonitorExecutionEvent): Promise<void>;
        static isMissingMonitorStorageError(error: unknown): boolean;
        listKnownPostgresTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
        }>>;
        private listAvailableDatabases;
        private getKnownPostgresTableNames;
        private getKnownDynamoTableNames;
        private getTableNameByRepositoryName;
        private assertKnownPostgresTable;
        private assertKnownDynamoTable;
        private getPoolForDatabase;
        private listPostgresColumns;
        private getPostgresPrimaryKey;
        private listPostgresIndexes;
        private getPostgresTableMetrics;
        listKnownPostgresTablesDetailed(databaseName?: string): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            rowCount: number | null;
            totalSizeBytes: number | null;
        }>>;
        getPostgresTableDetails(input: {
            databaseName?: string;
            tableName: string;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            metrics: {
                rowCount: number;
                totalSizeBytes: number;
            };
            columns: MonitorPostgresColumn[];
            primaryKey: string[];
            indexes: MonitorPostgresIndex[];
        }>;
        inspectPostgresTable(input: {
            databaseName?: string;
            tableName: string;
            page?: number;
            filters?: unknown;
        }): Promise<{
            databaseName: string;
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<Pick<MonitorPostgresColumn, 'name' | 'dataType' | 'isNullable'>>;
            pagination: {
                page: number;
                pageSize: number;
                totalRows: number;
                totalPages: number;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            order: {
                primary: string[];
                fallback: string;
            };
        }>;
        listKnownDynamoTables(): Promise<Array<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            itemCount: number | null;
            tableStatus: string | null;
            tableSizeBytes: number | null;
            metricsAreApproximate: boolean;
        }>>;
        getPostgresSnapshot(input?: {
            databaseName?: string;
        }): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            connection: {
                host: string;
                port: number;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                activeConnectionsByState: Record<string, number>;
                maxConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        }>;
        getDynamoSnapshot(): Promise<{
            runtimeMode: AppEnv['runtimeMode'];
            region: string;
            tables: Array<{
                tableName: string;
                description: string | null;
                moduleId: string | null;
                repositoryName: string | null;
                storageProfile: string | null;
                backupHot: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        }>;
        getDynamoTableDetails(input: {
            tableName: string;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            summary: {
                tableStatus: string | null;
                itemCount: number;
                tableSizeBytes: number;
                billingMode: string | null;
                tableClass: string | null;
                metricsAreApproximate: boolean;
            };
            keys: {
                partitionKey: string | null;
                sortKey: string | null;
            };
            attributeDefinitions: Array<{
                name: string;
                type: string;
            }>;
            globalSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
            localSecondaryIndexes: Array<{
                name: string;
                projectionType: string | null;
                keys: string[];
            }>;
        }>;
        inspectDynamoTable(input: {
            tableName: string;
            cursor?: string;
            filters?: unknown;
        }): Promise<{
            tableName: string;
            description: string | null;
            moduleId: string | null;
            repositoryName: string | null;
            storageProfile: string | null;
            backupHot: boolean;
            exists: boolean;
            columns: Array<{
                name: string;
                type: string;
                filterable: boolean;
            }>;
            pagination: {
                pageSize: number;
                cursor: string | null;
                nextCursor: string | null;
                hasNextPage: boolean;
            };
            filters: Record<string, string>;
            rows: Array<Record<string, unknown>>;
            metricsAreApproximate: boolean;
        }>;
        getSnapshotData(): Promise<{
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<Pick<MonitorBffExecutionLogRecord, 'routine' | 'statusCode' | 'statusGroup' | 'errorCode' | 'finishedAt'>>;
        }>;
        recordTelemetry(events: Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            module: string;
            routine: string;
            eventType: string;
            label: string;
            durationMs: number | null;
            metadata: Record<string, unknown> | null;
            recordedAt: string;
            receivedAt: string;
        }>): Promise<void>;
        loadRequestTrace(input: {
            requestId?: string;
            traceId?: string;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            ok: boolean;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
        loadAbends(input: {
            module?: string;
            limit?: number;
        }): Promise<Array<{
            id: string;
            requestId: string;
            traceId: string;
            userId: string;
            routine: string;
            module: string;
            statusCode: number;
            statusGroup: string;
            durationMs: number;
            errorCode: string | null;
            errorStack: string | null;
            startedAt: string;
            finishedAt: string;
        }>>;
    }
}
declare module "_102034_/l1/monitor/layer_2_controllers/abendHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const monitorAbendLoadHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/monitorGetStatistics" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const monitorGetStatisticsSnapshotHandler: BffHandler;
    export const monitorGetStatisticsSeriesHandler: BffHandler;
    export const monitorHomeLoadHandler: BffHandler;
    export const monitorPostgresLoadHandler: BffHandler;
    export const monitorDynamodbLoadHandler: BffHandler;
    export const monitorArchitectureLoadHandler: BffHandler;
    export const monitorPostgresTableInspectHandler: BffHandler;
    export const monitorPostgresTableDetailsHandler: BffHandler;
    export const monitorDynamodbTableInspectHandler: BffHandler;
    export const monitorDynamodbTableDetailsHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/processHealthHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const monitorProcessLoadHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/releaseHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const monitorReleasesListHandler: BffHandler;
    export const monitorReleasesActivateHandler: BffHandler;
    export const monitorLogsTailHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_2_controllers/router" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createMonitorRouter(): Map<string, BffHandler>;
}
declare module "_102034_/l1/monitor/layer_2_controllers/traceHandlers" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const monitorRequestTraceLoadHandler: BffHandler;
}
declare module "_102034_/l1/monitor/layer_3_usecases/abendUsecases" {
    import type { MonitorAbendResponse } from '_102034_/l2/monitor/shared/contracts/abend';
    export function loadAbends(input: {
        module?: string;
        limit?: number;
    }): Promise<MonitorAbendResponse>;
}
declare module "_102034_/l1/monitor/layer_3_usecases/processHealthUsecases" {
    import type { MonitorProcessResponse } from '_102034_/l2/monitor/shared/contracts/process';
    export function loadProcessHealth(): MonitorProcessResponse;
}
declare module "_102034_/l1/monitor/layer_3_usecases/statisticsUsecases" {
    export function getStatisticsSnapshot(): Promise<{
        generatedAt: string;
        storage: {
            postgres: {
                runtimeMode: any;
                tables: any;
            };
            dynamodb: {
                region: any;
                tables: any;
            };
        };
        counts: {
            postgresIndexes: {
                mdmEntityIndex: number;
                mdmProspectIndex: number;
                mdmRelationship: number;
                mdmProspectRelationship: number;
                monitorBffExecutionLog: number;
                monitorBffExecutionAggMinute: number;
            };
        };
        bff: any;
    }>;
    export function getStatisticsSeries(input?: {
        windowSeconds?: number;
        routine?: string;
        source?: 'http' | 'message' | 'test';
    }): Promise<{
        generatedAt: string;
        windowSeconds: number;
        totals: MonitorSeriesPoint;
        series: any;
    }>;
    export function loadMonitorHome(): Promise<{
        generatedAt: string;
        system: {
            appEnv: any;
            runtimeMode: any;
            writeBehindEnabled: any;
            awsRegion: any;
        };
        bff: any;
        recentSeries: any;
        postgres: {
            host: any;
            port: any;
            currentDatabase: any;
            availableDatabases: any;
            tableCount: any;
            missingTableCount: any;
            activeConnections: any;
            cacheHitRate: any;
            pendingOutbox: any;
            replicationFailures: any;
        };
        dynamodb: any;
    }>;
    export function loadMonitorPostgres(input?: {
        databaseName?: string;
    }): Promise<{
        generatedAt: string;
        postgres: any;
    }>;
    export function loadMonitorDynamodb(): Promise<{
        generatedAt: string;
        dynamodb: any;
    }>;
    export function loadMonitorArchitecture(): Promise<{
        generatedAt: string;
        architecture: {
            totalTables: any;
            postgresBackedTables: any;
            dynamoBackedTables: any;
            hotBackupTables: any;
            tables: any;
        };
    }>;
    export function loadMonitorPostgresTableInspect(input: {
        databaseName?: string;
        tableName: string;
        page?: number;
        filters?: Record<string, string>;
    }): Promise<any>;
    export function loadMonitorPostgresTableDetails(input: {
        databaseName?: string;
        tableName: string;
    }): Promise<any>;
    export function loadMonitorDynamoTableInspect(input: {
        tableName: string;
        cursor?: string;
        filters?: Record<string, string>;
    }): Promise<any>;
    export function loadMonitorDynamoTableDetails(input: {
        tableName: string;
    }): Promise<any>;
}
declare module "_102034_/l1/monitor/layer_3_usecases/traceUsecases" {
    import type { MonitorTraceResponse } from '_102034_/l2/monitor/shared/contracts/trace';
    export function loadRequestTrace(input: {
        requestId?: string;
        traceId?: string;
    }): Promise<MonitorTraceResponse>;
}
declare module "_102034_/l1/monitor/layer_4_entities/MonitorExecutionEntity" {
    import type { MonitorExecutionEvent } from '_102034_/l1/monitor/module';
    export class MonitorExecutionEntity {
        static record(event: MonitorExecutionEvent): Promise<void>;
    }
}
declare module "_102034_/l1/scripts/db" {
    export function getSqlDirPaths(): Promise<string[]>;
    export function listSqlFiles(): Promise<string[]>;
    export function readSqlFile(fileName: string): Promise<string>;
    export function getPgPool(): Promise<any>;
}
declare module "_102034_/l1/scripts/dbDelete" {
    export function dbDelete(inputEnv?: string, confirmation?: string): Promise<void>;
}
declare module "_102034_/l1/scripts/dbInit" {
    export function dbInit(inputEnv?: string): Promise<void>;
}
declare module "_102034_/l1/scripts/ensureDynamoTable" {
    export function ensureDynamoTable(): Promise<void>;
}
declare module "_102034_/l1/scripts/envCli" {
    export type CliAppEnv = 'development' | 'staging' | 'production';
    export function parseCliAppEnv(value: string | undefined): CliAppEnv;
    export function setCliAppEnv(value: string | undefined): CliAppEnv;
}
declare module "_102034_/l1/scripts/migrate" {
    export function runMigrations(): Promise<void>;
}
declare module "_102034_/l1/scripts/resetLocalDb" {
    export function resetLocalDb(): Promise<void>;
}
declare module "_102034_/l1/scripts/restoreFromDynamo" { }
declare module "_102034_/l1/scripts/runWriteBehindWorker" { }
declare module "_102034_/l1/scripts/setupServer" {
    export function setupServer(): Promise<void>;
}
declare module "_102034_/l1/server/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory" {
    export interface ICacheRuntime {
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue): Promise<void>;
    }
    export class CacheRuntimeMemory implements ICacheRuntime {
        private readonly values;
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue): Promise<void>;
    }
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: Array<{
            id: string;
            label: string;
            href: string;
            description?: string;
        }>;
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function getPublicationTarget(targetName?: string): {
        assetBaseUrl: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
        name: string;
    };
    export function resolvePublicationDistPath(targetName: string, relativePath?: string): string;
    export function resolveActivePublicationDistPath(relativePath?: string): string;
    export function toPublishedAssetUrl(relativePath: string, targetName?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { ResolvedTableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
    }
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmDocumentInput, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from '_102034_/l1/mdm/module';
    import type { IFindManyInput, IModuleDataRuntime } from '_102034_/l1/server/layer_1_external/data/moduleDataRuntime';
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentInput;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102034_/l1/server/layer_1_external/frontend/appRegistry" {
    import type { FrontendAppRegistration } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function getFrontendAppRegistrations(): Promise<FrontendAppRegistration[]>;
    export function getFrontendAppByBasePath(urlPath: string): Promise<FrontendAppRegistration>;
    export function getAppPublicRootDir(app: FrontendAppRegistration): string;
}
declare module "_102034_/l1/server/layer_1_external/id/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_1_external/observability/ConsoleLogger" {
    import type { ILogger } from '_102034_/l1/server/layer_2_controllers/contracts';
    export class ConsoleLogger implements ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        dynamoResolvedTableName: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102034_/l1/server/layer_1_external/persistence/dynamoAdmin" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    import type { ResolvedTableDefinition, SchemaSnapshot } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export function ensureRegisteredDynamoTables(env: AppEnv): Promise<void>;
    export function deleteRegisteredDynamoTables(env: AppEnv): Promise<void>;
    export function writeSchemaSnapshotLog(env: AppEnv, snapshot: SchemaSnapshot): Promise<void>;
    export function deleteDynamoItem(env: AppEnv, definition: ResolvedTableDefinition, key: Record<string, unknown>): Promise<void>;
    export function putDynamoItem(env: AppEnv, definition: ResolvedTableDefinition, item: Record<string, unknown>): Promise<void>;
    export function scanAllDynamoItems(env: AppEnv, definition: ResolvedTableDefinition): Promise<Array<Record<string, unknown>>>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry.test" { }
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/restoreFromDynamo" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export class RegistryRestoreFromDynamoUsecase {
        private readonly env;
        constructor(env?: AppEnv);
        restoreTable(repositoryNameOrTableName: string): Promise<number>;
    }
}
declare module "_102034_/l1/server/layer_1_external/persistence/schemaBootstrap" {
    import type { AppEnv } from '_102034_/l1/server/layer_1_external/config/env';
    export function bootstrapSchema(env: AppEnv, input?: {
        ensureDynamo?: boolean;
        recordSnapshotLog?: boolean;
    }): Promise<{
        snapshotId: string;
        postgresTableCount: number;
        dynamoTableCount: number;
    }>;
}
declare module "_102034_/l1/server/layer_1_external/platform/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/transport/http/execBff.test" { }
declare module "_102034_/l1/server/layer_1_external/transport/http/startServer" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function buildHttpServer(): any;
    export function handleHttpRequest(method: string, url: string, body?: unknown, ctx?: RequestContext): Promise<{
        statusCode: number;
        body: string;
        headers: {
            location: string;
            'content-type'?: undefined;
        };
    } | {
        statusCode: number;
        body: NonSharedBuffer;
        headers: {
            'content-type': string;
            location?: undefined;
        };
    } | {
        statusCode: any;
        body: any;
        headers?: undefined;
    }>;
}
declare module "_102034_/l1/server/layer_1_external/transport/message/execMessage" {
    import type { BffRequest, RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function execMessage(request: BffRequest, ctx?: RequestContext): Promise<any>;
}
declare module "_102034_/l1/server/layer_2_application/repositoryRegistry" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export type RepositoryFactory<T> = (ctx: RequestContext) => T;
    /** Bind a repository port name to the factory that builds its concrete adapter for a request ctx. */
    export function registerRepository<T>(portName: string, factory: RepositoryFactory<T>): void;
    /** Resolve the concrete repository adapter for a port name, bound to the current request ctx. */
    export function resolveRepository<T>(ctx: RequestContext, portName: string): T;
    export function hasRepository(portName: string): boolean;
    /** Test/boot helper: clear all registered factories. */
    export function clearRepositories(): void;
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            userId?: string;
            authToken?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRegionName = 'header' | 'aside' | 'content';
    export interface FrontendDynamicRegionConfig {
        renderer: FrontendRegionRendererRegistration;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface FrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, FrontendDynamicRegionConfig>;
    }
    export interface FrontendClientShellConfig {
        mode: ShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: FrontendShellRegionProfiles;
            aside?: FrontendShellRegionProfiles;
        };
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestContext {
        data: IDataRuntime;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        requestMeta?: {
            requestId?: string;
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ControllerRoute {
        key: string;
        handler: BffHandler;
    }
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
        clientShell?: FrontendClientShellConfig;
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102034_/l1/server/layer_2_controllers/execBff" {
    import { type BffRequest, type BffResponse, type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createRequestContext(dataRuntime?: any): RequestContext;
    export function createDefaultRequestContext(): RequestContext;
    export function execBff(request: BffRequest, ctx?: RequestContext): Promise<{
        response: BffResponse;
        statusCode: number;
    }>;
}
declare module "_102034_/l1/server/layer_2_controllers/moduleRegistry" {
    import { type BffHandler, type ModuleBffRegistration, type RoutineResolution } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function getModuleBffRegistrations(): ModuleBffRegistration[];
    export function resolveRoutineResolution(routine: string): RoutineResolution;
    export function loadModuleRouter(registration: ModuleBffRegistration): Promise<Map<string, BffHandler>>;
    export function resetModuleRouterCache(): void;
}
declare module "_102034_/l1/server/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createServerRouter(): Promise<Map<string, BffHandler>>;
}
declare module "_102034_/l2/audit/module.defs" {
    export const skill: {
        readonly moduleId: "audit";
        readonly purpose: "Operational audit module for reading change traceability and lifecycle history. Audit log answers who changed what; status history answers how entity state changed over time.";
        readonly pages: readonly ["home", "audit-log", "status-history"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.audit.currentSection", "ui.audit.refreshTick"];
    };
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: MasterFrontendNavigationItem[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: MasterFrontendNavigationItem[];
        moduleLinks?: MasterFrontendNavigationItem[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102034_/l2/audit/module" {
    import type { MasterFrontendModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.audit.currentSection";
        readonly refreshTick: "ui.audit.refreshTick";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: MasterFrontendModuleFrontendDefinition;
}
declare module "_102034_/l2/audit/shared/contracts/audit-log" {
    export type { AuditLogDetailsParams, AuditLogDetailsResponse, AuditLogLoadParams, AuditLogResponse, } from '_102034_/l1/audit/module';
}
declare module "_102034_/l2/audit/shared/contracts/home" {
    export type { AuditHomeResponse } from '_102034_/l1/audit/module';
}
declare module "_102034_/l2/audit/shared/contracts/status-history" {
    export type { AuditStatusHistoryLoadParams, AuditStatusHistoryResponse, } from '_102034_/l1/audit/module';
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102034_/l2/audit/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { AuditHomeResponse } from '_102034_/l2/audit/shared/contracts/home';
    import type { AuditLogDetailsResponse, AuditLogResponse } from '_102034_/l2/audit/shared/contracts/audit-log';
    import type { AuditStatusHistoryResponse } from '_102034_/l2/audit/shared/contracts/status-history';
    type AuditSection = 'overview' | 'audit-log' | 'status-history';
    export class AuditWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            homeData: {
                state: boolean;
            };
            auditLogData: {
                state: boolean;
            };
            statusHistoryData: {
                state: boolean;
            };
            auditLogDetails: {
                state: boolean;
            };
        };
        currentSection: AuditSection;
        status: string;
        routeError?: string;
        homeData?: AuditHomeResponse;
        auditLogData?: AuditLogResponse;
        statusHistoryData?: AuditStatusHistoryResponse;
        auditLogDetails?: AuditLogDetailsResponse;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handlePopState;
        private handleRouteChange;
        private navigateWithinModule;
        private loadCurrentRoute;
        private handleNavClick;
        private handleRefreshClick;
        private handleFilterSubmit;
        private handlePageClick;
        private loadDiff;
        private handleLoadDiff;
        private renderOverview;
        private renderNamedCountList;
        private renderAuditLog;
        private renderStatusHistory;
        render(): any;
    }
}
declare module "_102034_/l2/audit/web/routes/audit-log" {
    export { AuditWebDesktopHomePage } from '_102034_/l2/audit/web/desktop/page11/home';
}
declare module "_102034_/l2/audit/web/routes/overview" {
    export { AuditWebDesktopHomePage } from '_102034_/l2/audit/web/desktop/page11/home';
}
declare module "_102034_/l2/audit/web/routes/status-history" {
    export { AuditWebDesktopHomePage } from '_102034_/l2/audit/web/desktop/page11/home';
}
declare module "_102034_/l2/audit/web/shared/auditLog.defs" {
    export const skill = "\n# Audit Log Page\n\n## Purpose\n\nRender the change-traceability page for the audit module, focused on the\n`mdm_audit_log` trail.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.auditLog.load`\n- The routine must return:\n  - overview totals for audit activity\n  - grouped cuts by module, routine, actor and action\n  - a paginated event list\n  - enough data to open event details\n\n## Filters\n\n- `module`\n- `entityType`\n- `entityId`\n- `actorId`\n- `actorType`\n- `action`\n- period / date range\n\n## Page Behavior\n\n- Load only when the current pathname is `/audit/audit-log`\n- Use the left aside as the primary navigation\n- Keep the header free of duplicated page links\n- Render summary cards first and the event table after that\n- Provide access to event detail inspection\n- Reserve a detailed remote-record view when a DynamoDB-backed `diff` exists\n\n## Visual Intent\n\n- Diagnostic and table-heavy layout\n- Emphasis on data changes, actor traceability and routine provenance\n- Neutral colors with explicit highlighting for destructive or exceptional\n  actions\n\n## Conceptual Contract\n\n- This page is about immutable records of create, update, delete and restore\n  operations\n- The user should understand that this trail captures what changed and who\n  caused it\n- This page must not be framed as lifecycle/status analytics\n";
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102034_/l2/audit/web/shared/auditLog" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditLogLoadParams } from '_102034_/l2/audit/shared/contracts/audit-log';
    export function loadAuditLog(input: AuditLogLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditLogResponse>>;
}
declare module "_102034_/l2/audit/web/shared/auditLogDetails" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditLogDetailsParams } from '_102034_/l2/audit/shared/contracts/audit-log';
    export function loadAuditLogDetails(input: AuditLogDetailsParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditLogDetailsResponse>>;
}
declare module "_102034_/l2/audit/web/shared/formatters" {
    export function formatInteger(value: number | null | undefined): string;
    export function formatDateTime(value: string | null | undefined): string;
    export function formatJson(value: unknown): string;
}
declare module "_102034_/l2/audit/web/shared/home.defs" {
    export const skill = "\n# Audit Home Page\n\n## Purpose\n\nRender the overview page for the audit module. This page must explain the audit\narchitecture and summarize the two operational trails: audit log and status\nhistory.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.home.load`\n- The routine must return only what the overview page needs:\n  - environment/runtime summary\n  - recent volume cards for audit log and status history\n  - explanation of the difference between the two trails\n  - recent relevant events\n  - grouped distribution by module, entity type and actor\n\n## Page Behavior\n\n- Detect the active section by the current pathname\n- Treat `/audit`, `/audit/index.html` and `/audit/overview` as overview\n- Use the left aside as the primary navigation\n- Do not duplicate page links in the header\n- Render top cards first, then the conceptual comparison block, then condensed\n  lists/tables\n\n## Visual Intent\n\n- Same shell direction as the monitor module\n- Dense operational cards with neutral diagnostic styling\n- Clear comparison block titled `Audit Log vs Status History`\n- Header reserved for title, current context and refresh/filter actions\n\n## Conceptual Contract\n\n- `audit log` answers who changed what\n- `status history` answers how the entity status changed over time\n- The initial operational sources are `mdm_audit_log` and\n  `mdm_status_history`, but the page narrative must be generic enough for\n  future expansion\n";
}
declare module "_102034_/l2/audit/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadAuditHome(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditHomeResponse>>;
}
declare module "_102034_/l2/audit/web/shared/statusHistory.defs" {
    export const skill = "\n# Status History Page\n\n## Purpose\n\nRender the lifecycle-trail page for the audit module, focused on the\n`mdm_status_history` trail.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `audit.statusHistory.load`\n- The routine must return:\n  - overview totals for status transitions\n  - grouped cuts by module, entity type and transition\n  - an ordered transition list\n  - enough information to highlight repeated transition patterns and current\n    status when derivable\n\n## Filters\n\n- `module`\n- `entityType`\n- `entityId`\n- `fromStatus`\n- `toStatus`\n- `actorId`\n- `reasonCode`\n- period / date range\n\n## Page Behavior\n\n- Load only when the current pathname is `/audit/status-history`\n- Use the left aside as the primary navigation\n- Keep the header free of duplicated page links\n- Render summary cards first and the ordered transition table after that\n- Highlight common transitions and status flow bottlenecks when the response\n  provides them\n\n## Visual Intent\n\n- Diagnostic, sequence-oriented layout\n- Emphasis on lifecycle flow, transition frequency and semantic reasons\n- Clear distinction from the diff-oriented audit log page\n\n## Conceptual Contract\n\n- This page is about immutable status transitions with semantic context such as\n  `reason`, `reasonCode` and `metadata`\n- The user should understand that this trail captures how status moved over\n  time, not which fields changed\n- This page must not be framed as raw data-diff inspection\n";
}
declare module "_102034_/l2/audit/web/shared/statusHistory" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { AuditStatusHistoryLoadParams } from '_102034_/l2/audit/shared/contracts/status-history';
    export function loadAuditStatusHistory(input: AuditStatusHistoryLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<AuditStatusHistoryResponse>>;
}
declare module "_102034_/l2/monitor/module.defs" {
    export const skill: {
        readonly moduleId: "monitor";
        readonly purpose: "Operational monitoring module for system overview, Postgres diagnostics and DynamoDB diagnostics.";
        readonly pages: readonly ["home", "postgres", "dynamodb"];
        readonly genome: {
            readonly page11: "desktop-standard";
            readonly page21: "mobile-standard";
        };
        readonly states: readonly ["ui.monitor.currentSection", "ui.monitor.refreshTick"];
    };
}
declare module "_102034_/l2/monitor/module" {
    import type { MasterFrontendModuleFrontendDefinition } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: {
        readonly page11: {
            readonly device: "desktop";
            readonly layout: "standard";
        };
        readonly page21: {
            readonly device: "mobile";
            readonly layout: "standard";
        };
    };
    export const moduleStates: {
        readonly currentSection: "ui.monitor.currentSection";
        readonly refreshTick: "ui.monitor.refreshTick";
    };
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: MasterFrontendModuleFrontendDefinition;
}
declare module "_102034_/l2/monitor/shared/contracts/abend" {
    export interface MonitorAbendEntry {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        statusCode: number;
        statusGroup: string;
        durationMs: number;
        errorCode: string | null;
        errorStack: string | null;
        startedAt: string;
        finishedAt: string;
    }
    export interface MonitorAbendResponse {
        entries: MonitorAbendEntry[];
        totalCount: number;
        generatedAt: string;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/architecture" {
    export interface MonitorArchitectureResponse {
        generatedAt: string;
        architecture: {
            totalTables: number;
            postgresBackedTables: number;
            dynamoBackedTables: number;
            hotBackupTables: number;
            tables: Array<{
                projectId: string;
                moduleId: string;
                repositoryName: string;
                tableName: string;
                description: string;
                purpose: string;
                storageProfile: string;
                backupHot: boolean;
                writeMode: string;
                dynamoTableName: string | null;
                dynamoPartitionKey: string | null;
                dynamoSortKey: string | null;
                dynamoTtlField: string | null;
                detailsInDynamoOnly: boolean;
                localIndexes: Array<{
                    name: string;
                    unique: boolean;
                    columns: string[];
                }>;
            }>;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/dynamodb" {
    export interface MonitorDynamoResponse {
        generatedAt: string;
        dynamodb: {
            runtimeMode: 'memory' | 'postgres';
            region: string;
            tables: Array<{
                tableName: string;
                description?: string | null;
                moduleId?: string | null;
                repositoryName?: string | null;
                storageProfile?: string | null;
                backupHot?: boolean;
                exists: boolean;
                itemCount: number | null;
                tableStatus: string | null;
                tableSizeBytes: number | null;
                metricsAreApproximate?: boolean;
            }>;
            summary: {
                totalTables: number;
                availableTables: number;
                missingTables: number;
                totalItemCount: number;
                metricsAreApproximate: boolean;
            };
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/home" {
    export interface MonitorHomeSeriesPoint {
        timestamp: string;
        total: number;
        success: number;
        clientError: number;
        serverError: number;
        notFound: number;
    }
    export interface MonitorHomeResponse {
        generatedAt: string;
        system: {
            appEnv: string;
            runtimeMode: 'memory' | 'postgres';
            writeBehindEnabled: boolean;
            awsRegion: string;
        };
        bff: {
            byRoutine: Array<{
                routine: string;
                totalCount: number;
                lastFinishedAt: string;
                avgDurationMs: number;
            }>;
            byStatusGroup: Array<{
                statusGroup: string;
                totalCount: number;
            }>;
            overview: {
                totalExecutions: number;
                successCount: number;
                clientErrorCount: number;
                serverErrorCount: number;
                notFoundCount: number;
            };
            recentFailures: Array<{
                routine: string;
                statusCode: number;
                statusGroup: string;
                errorCode?: string | null;
                finishedAt: string;
            }>;
        };
        recentSeries: MonitorHomeSeriesPoint[];
        postgres: {
            host: string;
            port: number;
            currentDatabase: string;
            availableDatabases: string[];
            tableCount: number;
            missingTableCount: number;
            activeConnections: number;
            cacheHitRate: number | null;
            pendingOutbox: number;
            replicationFailures: number;
        };
        dynamodb: {
            totalTables: number;
            availableTables: number;
            missingTables: number;
            totalItemCount: number;
            metricsAreApproximate?: boolean;
        };
    }
    export interface MonitorStatisticsSeriesResponse {
        generatedAt: string;
        windowSeconds: number;
        totals: {
            total: number;
            success: number;
            clientError: number;
            serverError: number;
            notFound: number;
        };
        series: MonitorHomeSeriesPoint[];
    }
}
declare module "_102034_/l2/monitor/shared/contracts/postgres" {
    export interface MonitorPostgresResponse {
        generatedAt: string;
        postgres: {
            runtimeMode: 'memory' | 'postgres';
            connection: {
                host: string;
                port: number;
                currentDatabase: string;
                availableDatabases: string[];
            };
            database: {
                name: string;
                activeConnections: number;
                waitingLocks: number;
                cacheHitRate: number | null;
                commitCount: number;
                rollbackCount: number;
                deadlockCount: number;
            };
            queue: {
                pendingOutbox: number;
                processedOutbox: number;
                replicationFailures: number;
                cacheEntries: number;
            };
            tables: Array<{
                tableName: string;
                description?: string | null;
                moduleId?: string | null;
                repositoryName?: string | null;
                storageProfile?: string | null;
                backupHot?: boolean;
                exists: boolean;
                rowCount: number | null;
                totalSizeBytes: number | null;
            }>;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/process" {
    export interface MonitorProcessResponse {
        generatedAt: string;
        memory: {
            heapUsedMb: number;
            heapTotalMb: number;
            rssMb: number;
            externalMb: number;
            heapUsedPercent: number;
        };
        system: {
            freememMb: number;
            totalMemMb: number;
            freeMemPercent: number;
            cpuCount: number;
            loadAvg1m: number;
            loadAvg5m: number;
            loadAvg15m: number;
        };
        process: {
            uptimeSeconds: number;
            nodeVersion: string;
            pid: number;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-details-dynamodb" {
    export interface MonitorDynamoTableDetailsResponse {
        generatedAt: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        summary: {
            tableStatus: string | null;
            itemCount: number;
            tableSizeBytes: number;
            billingMode: string | null;
            tableClass: string | null;
            metricsAreApproximate?: boolean;
        };
        keys: {
            partitionKey: string | null;
            sortKey: string | null;
        };
        attributeDefinitions: Array<{
            name: string;
            type: string;
        }>;
        globalSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
        localSecondaryIndexes: Array<{
            name: string;
            projectionType: string | null;
            keys: string[];
        }>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-details-postgres" {
    export interface MonitorPostgresTableDetailsResponse {
        generatedAt: string;
        databaseName: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        metrics: {
            rowCount: number;
            totalSizeBytes: number;
        };
        columns: Array<{
            name: string;
            dataType: string;
            isNullable: boolean;
            defaultValue: string | null;
        }>;
        primaryKey: string[];
        indexes: Array<{
            name: string;
            unique: boolean;
            method: string;
            columns: string[];
        }>;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-inspect-dynamodb" {
    export interface MonitorDynamoTableInspectResponse {
        generatedAt: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        columns: Array<{
            name: string;
            type: string;
            filterable: boolean;
        }>;
        pagination: {
            pageSize: number;
            cursor: string | null;
            nextCursor: string | null;
            hasNextPage: boolean;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        metricsAreApproximate?: boolean;
    }
}
declare module "_102034_/l2/monitor/shared/contracts/table-inspect-postgres" {
    export interface MonitorPostgresTableInspectResponse {
        generatedAt: string;
        databaseName: string;
        tableName: string;
        description?: string | null;
        moduleId?: string | null;
        repositoryName?: string | null;
        storageProfile?: string | null;
        backupHot?: boolean;
        exists: boolean;
        columns: Array<{
            name: string;
            dataType: string;
            isNullable: boolean;
        }>;
        pagination: {
            page: number;
            pageSize: number;
            totalRows: number;
            totalPages: number;
        };
        filters: Record<string, string>;
        rows: Array<Record<string, unknown>>;
        order: {
            primary: string[];
            fallback: string;
        };
    }
}
declare module "_102034_/l2/monitor/shared/contracts/trace" {
    export interface MonitorTraceEntry {
        id: string;
        requestId: string;
        traceId: string;
        userId: string;
        routine: string;
        module: string;
        statusCode: number;
        statusGroup: string;
        ok: boolean;
        durationMs: number;
        errorCode?: string | null;
        errorStack?: string | null;
        startedAt: string;
        finishedAt: string;
    }
    export interface MonitorTraceResponse {
        requestId: string | null;
        traceId: string | null;
        entries: MonitorTraceEntry[];
        totalCount: number;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102029_/l2/contracts/bootstrap";
    export class MonitorWebDesktopAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/header" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102029_/l2/contracts/bootstrap";
    export class MonitorWebDesktopHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/desktop/page11/home" {
    import { LitElement } from 'lit';
    import type { MonitorArchitectureResponse } from '_102034_/l2/monitor/shared/contracts/architecture';
    import type { MonitorDynamoResponse } from '_102034_/l2/monitor/shared/contracts/dynamodb';
    import type { MonitorHomeResponse, MonitorHomeSeriesPoint, MonitorStatisticsSeriesResponse } from '_102034_/l2/monitor/shared/contracts/home';
    import type { MonitorPostgresResponse } from '_102034_/l2/monitor/shared/contracts/postgres';
    import type { MonitorProcessResponse } from '_102034_/l2/monitor/shared/contracts/process';
    import type { MonitorAbendResponse } from '_102034_/l2/monitor/shared/contracts/abend';
    import type { MonitorTraceResponse } from '_102034_/l2/monitor/shared/contracts/trace';
    import type { MonitorDynamoTableDetailsResponse } from '_102034_/l2/monitor/shared/contracts/table-details-dynamodb';
    import type { MonitorPostgresTableDetailsResponse } from '_102034_/l2/monitor/shared/contracts/table-details-postgres';
    import type { MonitorDynamoTableInspectResponse } from '_102034_/l2/monitor/shared/contracts/table-inspect-dynamodb';
    import type { MonitorPostgresTableInspectResponse } from '_102034_/l2/monitor/shared/contracts/table-inspect-postgres';
    type MonitorSection = 'overview' | 'architecture' | 'postgres' | 'dynamodb' | 'process' | 'abend' | 'trace';
    type MonitorRoute = {
        section: 'overview';
        kind: 'section';
    } | {
        section: 'architecture';
        kind: 'section';
    } | {
        section: 'postgres';
        kind: 'section';
        databaseName?: string;
    } | {
        section: 'dynamodb';
        kind: 'section';
    } | {
        section: 'process';
        kind: 'section';
    } | {
        section: 'abend';
        kind: 'section';
        module?: string;
    } | {
        section: 'trace';
        kind: 'section';
        requestId?: string;
        traceId?: string;
    } | {
        section: 'postgres';
        kind: 'inspect' | 'details';
        tableName: string;
        databaseName?: string;
        page?: number;
        filters: Record<string, string>;
    } | {
        section: 'dynamodb';
        kind: 'inspect' | 'details';
        tableName: string;
        cursor?: string;
        cursorStack: string[];
        filters: Record<string, string>;
    };
    export class MonitorWebDesktopHomePage extends LitElement {
        static properties: {
            currentSection: {
                state: boolean;
            };
            currentRoute: {
                state: boolean;
            };
            status: {
                state: boolean;
            };
            routeError: {
                state: boolean;
            };
            homeData: {
                state: boolean;
            };
            homeSeries: {
                state: boolean;
            };
            seriesMeta: {
                state: boolean;
            };
            architectureData: {
                state: boolean;
            };
            postgresData: {
                state: boolean;
            };
            dynamodbData: {
                state: boolean;
            };
            selectedDatabaseName: {
                state: boolean;
            };
            postgresInspectData: {
                state: boolean;
            };
            postgresDetailsData: {
                state: boolean;
            };
            dynamoInspectData: {
                state: boolean;
            };
            dynamoDetailsData: {
                state: boolean;
            };
            abendData: {
                state: boolean;
            };
            processData: {
                state: boolean;
            };
            traceData: {
                state: boolean;
            };
            traceSearchInput: {
                state: boolean;
            };
        };
        currentSection: MonitorSection;
        currentRoute: MonitorRoute;
        status: string;
        routeError?: string;
        homeData?: MonitorHomeResponse;
        homeSeries?: MonitorHomeSeriesPoint[];
        seriesMeta?: MonitorStatisticsSeriesResponse;
        architectureData?: MonitorArchitectureResponse;
        postgresData?: MonitorPostgresResponse;
        dynamodbData?: MonitorDynamoResponse;
        selectedDatabaseName?: string;
        postgresInspectData?: MonitorPostgresTableInspectResponse;
        postgresDetailsData?: MonitorPostgresTableDetailsResponse;
        dynamoInspectData?: MonitorDynamoTableInspectResponse;
        dynamoDetailsData?: MonitorDynamoTableDetailsResponse;
        abendData?: MonitorAbendResponse;
        processData?: MonitorProcessResponse;
        traceData?: MonitorTraceResponse;
        traceSearchInput: string;
        private overviewPollTimer;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private readonly handleVisibilityChange;
        private loadRouteFromLocation;
        private navigate;
        private startOverviewPolling;
        private stopOverviewPolling;
        private refreshOverviewSeries;
        private toBlockingError;
        private routeErrorMessage;
        private loadActiveRoute;
        private renderRouteError;
        private refreshCurrentSection;
        private handleNavClick;
        private handleDatabaseChange;
        private handlePostgresInspectFilters;
        private handleDynamoInspectFilters;
        private renderBreadcrumb;
        private renderStorageProfile;
        private renderOverviewChart;
        private renderOverview;
        private renderPostgresTableLinks;
        private renderDynamoTableLinks;
        private renderArchitecture;
        private renderPostgres;
        private renderDynamodb;
        private renderPostgresInspect;
        private renderPostgresDetails;
        private renderDynamoInspect;
        private renderDynamoDetails;
        private handleTraceSearch;
        private renderProcess;
        private renderTrace;
        private renderAbend;
        private renderMetricCard;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/routes/abend" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/architecture" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/dynamodb-table" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/dynamodb" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/overview" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/postgres-table" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/postgres" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/process" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/routes/releases" {
    import { LitElement } from 'lit';
    interface ReleaseItem {
        id: string;
        active: boolean;
        createdAt: string;
    }
    export class MonitorWebDesktopReleasesPage extends LitElement {
        static properties: {
            status: {
                state: boolean;
            };
            busy: {
                state: boolean;
            };
            active: {
                state: boolean;
            };
            releases: {
                state: boolean;
            };
            logStream: {
                state: boolean;
            };
            logLines: {
                state: boolean;
            };
        };
        status: string;
        busy: boolean;
        active: string | null;
        releases: ReleaseItem[];
        logStream: 'out' | 'error';
        logLines: string[];
        constructor();
        createRenderRoot(): this;
        connectedCallback(): void;
        private loadReleases;
        private loadLogs;
        private activate;
        render(): any;
    }
}
declare module "_102034_/l2/monitor/web/routes/trace" {
    export { MonitorWebDesktopHomePage } from '_102034_/l2/monitor/web/desktop/page11/home';
}
declare module "_102034_/l2/monitor/web/shared/abend" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorAbend(params: {
        module?: string;
        limit?: number;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorAbendResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/architecture" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorArchitecture(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorArchitectureResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/dynamodb.defs" {
    export const skill = "\n# Monitor DynamoDB Page\n\n## Purpose\n\nRender the DynamoDB diagnostics page for the monitor module.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.dynamodb.load`\n- The routine must return:\n  - region\n  - summary of available/missing tables\n  - table status, item count and size\n\n## Page Behavior\n\n- Load only when the current pathname is `/monitor/dynamodb`\n- Render summary cards first\n- Render a table with per-table status and storage information\n\n## Layout Intent\n\n- Compact operational table\n- Highlight missing or unavailable tables clearly\n";
}
declare module "_102034_/l2/monitor/web/shared/dynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorDynamodb(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/home.defs" {
    export const skill = "\n# Monitor Home Page\n\n## Purpose\n\nRender the operational home page for the monitor module using a single\naggregated BFF request.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.home.load`\n- The routine must return only what the overview page needs:\n  - system/runtime summary\n  - BFF overview counts\n  - by-routine ranking\n  - recent failures\n  - recent execution series\n  - condensed Postgres and DynamoDB status cards\n\n## Page Behavior\n\n- Detect the active section by the current pathname\n- Treat `/monitor`, `/monitor/index.html` and `/monitor/overview` as overview\n- Render a header with refresh status and a manual refresh button\n- Show dense operational cards first\n- Show ranked routine activity and recent failures\n- Keep the page compatible with the master shell aside/header\n\n## Shared Files\n\n- `web/shared/home.ts` owns the BFF call\n- `web/shared/homeFormatters.ts` owns reusable formatting helpers\n\n## Layout Intent\n\n- Fast scan for operations\n- Dense but readable dashboard\n- Neutral colors with explicit severity accents\n- Tailwind-first styling in light DOM\n";
}
declare module "_102034_/l2/monitor/web/shared/home" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorHome(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorHomeResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/homeFormatters" {
    export function formatInteger(value: number | null | undefined): string;
    export function formatPercent(value: number | null | undefined): string;
    export function formatBytes(value: number | null | undefined): string;
    export function formatDateTime(value: string | null | undefined): string;
    export function formatTime(value: string | null | undefined): string;
    export function formatMonitorValue(value: unknown): string;
    export function formatStatusLabel(statusGroup: string): string;
}
declare module "_102034_/l2/monitor/web/shared/postgres.defs" {
    export const skill = "\n# Monitor Postgres Page\n\n## Purpose\n\nRender a focused Postgres diagnostics page for the monitor module.\n\n## Target Genome\n\n- Device: desktop\n- Layout: standard\n- Folder: `web/desktop/page11/`\n\n## Main Routine\n\n- Use `monitor.postgres.load`\n- The routine must return:\n  - database activity summary\n  - cache hit ratio\n  - waiting locks\n  - queue and cache counts\n  - known application tables with row counts and total size\n\n## Page Behavior\n\n- Load only when the current pathname is `/monitor/postgres`\n- Render top-level health cards\n- Render queue/cache cards\n- Render a table of known Postgres tables\n\n## Layout Intent\n\n- Diagnostic, table-heavy layout\n- Emphasis on operational bottlenecks and storage footprint\n";
}
declare module "_102034_/l2/monitor/web/shared/postgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorPostgres(databaseName?: string, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/process" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorProcess(options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorProcessResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/series" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorSeries(windowSeconds?: number, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorStatisticsSeriesResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableDetailsDynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorDynamoTableDetails(input: {
        tableName: string;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoTableDetailsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableDetailsPostgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorPostgresTableDetails(input: {
        databaseName?: string;
        tableName: string;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresTableDetailsResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableInspectDynamodb" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorDynamoTableInspect(input: {
        tableName: string;
        cursor?: string;
        filters?: Record<string, string>;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorDynamoTableInspectResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/tableInspectPostgres" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export function loadMonitorPostgresTableInspect(input: {
        databaseName?: string;
        tableName: string;
        page?: number;
        filters?: Record<string, string>;
    }, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorPostgresTableInspectResponse>>;
}
declare module "_102034_/l2/monitor/web/shared/trace" {
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    export interface MonitorTraceLoadParams {
        requestId?: string;
        traceId?: string;
    }
    export function loadMonitorTrace(params: MonitorTraceLoadParams, options?: BffClientOptions): Promise<import("/_102029_/l2/bffClient.js").BffClientResponse<MonitorTraceResponse>>;
}
declare module "_102034_/l2/shared/bff-client" {
    export function execBff<TData = unknown>(routine: string, params: unknown): Promise<{
        ok: boolean;
        data: TData | null;
        error: {
            code: string;
            message: string;
            details?: unknown;
        } | null;
    }>;
}

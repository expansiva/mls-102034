const STORAGE_CONFIG_BY_ENV = {
    development: {
        dynamoTableMdm: 'mdm_documents',
        dynamoTableMdmRelationship: 'mdm_relationship',
        dynamoTableMdmProspectRelationship: 'mdm_prospect_relationship',
        dynamoTableMdmAuditLog: 'mdm_audit_log',
        dynamoTableMdmTag: 'mdm_tag',
        dynamoTableMdmComment: 'mdm_comment',
        dynamoTableMdmAttachment: 'mdm_attachment',
        dynamoTableMdmNumberSequence: 'mdm_number_sequence',
    },
    staging: {
        dynamoTableMdm: 'mdm_documents_test',
        dynamoTableMdmRelationship: 'mdm_relationship_test',
        dynamoTableMdmProspectRelationship: 'mdm_prospect_relationship_test',
        dynamoTableMdmAuditLog: 'mdm_audit_log_test',
        dynamoTableMdmTag: 'mdm_tag_test',
        dynamoTableMdmComment: 'mdm_comment_test',
        dynamoTableMdmAttachment: 'mdm_attachment_test',
        dynamoTableMdmNumberSequence: 'mdm_number_sequence_test',
    },
    production: {
        dynamoTableMdm: 'mdm_documents',
        dynamoTableMdmRelationship: 'mdm_relationship',
        dynamoTableMdmProspectRelationship: 'mdm_prospect_relationship',
        dynamoTableMdmAuditLog: 'mdm_audit_log',
        dynamoTableMdmTag: 'mdm_tag',
        dynamoTableMdmComment: 'mdm_comment',
        dynamoTableMdmAttachment: 'mdm_attachment',
        dynamoTableMdmNumberSequence: 'mdm_number_sequence',
    },
};
export function getStorageConfig(appEnv) {
    return STORAGE_CONFIG_BY_ENV[appEnv];
}

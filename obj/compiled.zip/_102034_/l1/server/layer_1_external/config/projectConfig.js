/// <mls fileReference="_102034_/l1/server/layer_1_external/config/projectConfig.ts" enhancement="_blank" />
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
let cachedConfig = null;
function normalizeProjectType(project) {
    if (project.type) {
        return project.type;
    }
    switch (project.role) {
        case 'frontend_base':
            return 'master frontend';
        case 'server_core':
            return 'master backend';
        case 'client_project':
            return 'client';
        default:
            return 'lib';
    }
}
function validateProjectsConfig(config) {
    const projects = Object.entries(config.projects);
    const clients = projects.filter(([, project]) => project.type === 'client');
    const masterFrontends = projects.filter(([, project]) => project.type === 'master frontend');
    const masterBackends = projects.filter(([, project]) => project.type === 'master backend');
    if (clients.length !== 1) {
        throw new Error(`Workspace must declare exactly 1 project of type "client". Found ${clients.length}.`);
    }
    if (masterFrontends.length === 0) {
        throw new Error('Workspace must declare at least 1 project of type "master frontend".');
    }
    if (masterBackends.length === 0) {
        throw new Error('Workspace must declare at least 1 project of type "master backend".');
    }
    if (!config.projects[config.defaultProjectId]) {
        throw new Error(`defaultProjectId "${config.defaultProjectId}" is not declared in projects/config.json.`);
    }
    if (!config.publication?.targets || Object.keys(config.publication.targets).length === 0) {
        throw new Error('projects/config.json must declare at least one publication target.');
    }
    if (!config.publication.targets[config.publication.defaultTarget]) {
        throw new Error(`publication.defaultTarget "${config.publication.defaultTarget}" is not declared in projects/config.json.`);
    }
}
function normalizeAssetBaseUrl(assetBaseUrl) {
    if (!assetBaseUrl) {
        return '';
    }
    return assetBaseUrl.replace(/\/+$/u, '');
}
function getDefaultPublicationConfig() {
    return {
        defaultTarget: 'local',
        targets: {
            local: {
                assetBaseUrl: '',
                serveStaticFromServer: true,
                minify: false,
                sourcemap: true,
            },
            cdncloudflare: {
                assetBaseUrl: 'https://cdn.example.com',
                serveStaticFromServer: false,
                minify: true,
                sourcemap: false,
            },
        },
    };
}
function normalizeProjectsConfig(config) {
    const normalizedProjects = Object.fromEntries(Object.entries(config.projects).map(([projectId, project]) => [
        projectId,
        {
            ...project,
            type: normalizeProjectType(project),
        },
    ]));
    const normalizedConfig = {
        ...config,
        projects: normalizedProjects,
        publication: {
            ...getDefaultPublicationConfig(),
            ...config.publication,
            targets: Object.fromEntries(Object.entries({
                ...getDefaultPublicationConfig().targets,
                ...(config.publication?.targets ?? {}),
            }).map(([targetName, targetConfig]) => [
                targetName,
                {
                    ...targetConfig,
                    assetBaseUrl: normalizeAssetBaseUrl(targetConfig.assetBaseUrl),
                },
            ])),
        },
    };
    validateProjectsConfig(normalizedConfig);
    return normalizedConfig;
}
function getProjectsDir() {
    const cwdProjectsConfig = resolve(process.cwd(), 'config.json');
    if (existsSync(cwdProjectsConfig)) {
        return resolve(process.cwd());
    }
    const nestedProjectsConfig = resolve(process.cwd(), 'projects', 'config.json');
    if (existsSync(nestedProjectsConfig)) {
        return resolve(process.cwd(), 'projects');
    }
    return resolve(process.cwd());
}
export function readProjectsConfig() {
    if (cachedConfig) {
        return cachedConfig;
    }
    const configPath = resolve(getProjectsDir(), 'config.json');
    if (!existsSync(configPath)) {
        throw new Error(`projects/config.json not found at ${configPath}`);
    }
    cachedConfig = normalizeProjectsConfig(JSON.parse(readFileSync(configPath, 'utf8')));
    return cachedConfig;
}
export function resetProjectsConfigCache() {
    cachedConfig = null;
}
export function resolveProjectsPath(relativePath) {
    return resolve(getProjectsDir(), relativePath);
}
export function resolveProjectDistPath(relativePath) {
    const normalized = relativePath.replace(/^\.\//u, '');
    const match = normalized.match(/^_(\d+)_\/(.*)$/u);
    if (!match) {
        return resolve(getProjectsDir(), 'dist', 'local', normalized);
    }
    const [, projectId, rest] = match;
    return resolve(getProjectsDir(), 'dist', 'local', `_${projectId}_`, rest);
}
export function getPublicationTarget(targetName) {
    const config = readProjectsConfig();
    const resolvedTargetName = targetName ?? config.publication.defaultTarget;
    const target = config.publication.targets[resolvedTargetName];
    if (!target) {
        throw new Error(`Unknown publication target "${resolvedTargetName}".`);
    }
    return {
        name: resolvedTargetName,
        ...target,
        assetBaseUrl: normalizeAssetBaseUrl(target.assetBaseUrl),
    };
}
export function resolvePublicationDistPath(targetName, relativePath = '.') {
    const normalized = relativePath.replace(/^\.\//u, '');
    if (!normalized || normalized === '.') {
        return resolve(getProjectsDir(), 'dist', targetName);
    }
    return resolve(getProjectsDir(), 'dist', targetName, normalized);
}
export function resolveActivePublicationDistPath(relativePath = '.') {
    return resolvePublicationDistPath(getPublicationTarget().name, relativePath);
}
export function toPublishedAssetUrl(relativePath, targetName) {
    const normalizedPath = relativePath.startsWith('/') ? relativePath : `/${relativePath.replace(/^\.\//u, '')}`;
    const target = getPublicationTarget(targetName);
    return target.assetBaseUrl ? `${target.assetBaseUrl}${normalizedPath}` : normalizedPath;
}
export function resolveProjectModuleImportUrl(relativePath) {
    return pathToFileURL(resolveProjectDistPath(relativePath)).href;
}

/// <mls fileReference="_102034_/l1/server/layer_1_external/frontend/appRegistry.ts" enhancement="_blank" />
import { dirname } from 'node:path';
import { getPublicationTarget, readProjectsConfig, resolveActivePublicationDistPath, resolveProjectDistPath, resolveProjectModuleImportUrl, toPublishedAssetUrl, } from '/_102034_/l1/server/layer_1_external/config/projectConfig.js';
const moduleDefinitionCache = new Map();
let cachedAppsPromise = null;
function toPublicImportPath(importPath) {
    const normalized = importPath.startsWith('./') ? `/${importPath.slice(2)}` : importPath;
    return toPublishedAssetUrl(normalized);
}
function createDefaultLayout() {
    return {
        regions: {
            desktop: {
                header: true,
                aside: true,
                content: true,
            },
            mobile: {
                header: true,
                aside: true,
                content: true,
            },
        },
        asideMode: {
            desktop: 'inline',
            mobile: 'drawer',
        },
    };
}
function mergeLayoutPreferences(preferences) {
    const defaults = createDefaultLayout();
    return {
        regions: {
            desktop: {
                ...defaults.regions.desktop,
                ...(preferences?.layout?.regions?.desktop ?? {}),
            },
            mobile: {
                ...defaults.regions.mobile,
                ...(preferences?.layout?.regions?.mobile ?? {}),
            },
        },
        asideMode: {
            ...defaults.asideMode,
            ...(preferences?.layout?.asideMode ?? {}),
        },
    };
}
function normalizeRendererConfig(renderer) {
    if (!renderer?.entrypoint || !renderer.tag) {
        return undefined;
    }
    return {
        entrypoint: toPublicImportPath(renderer.entrypoint),
        tag: renderer.tag,
    };
}
function normalizeRoutes(routes) {
    return (routes ?? []).map((route) => ({
        ...route,
        entrypoint: toPublicImportPath(route.entrypoint),
    }));
}
async function loadModuleDefinition(projectId, moduleId) {
    const cacheKey = `${projectId}:${moduleId}`;
    const cached = moduleDefinitionCache.get(cacheKey);
    if (cached) {
        return cached;
    }
    const pending = (async () => {
        try {
            const moduleUrl = resolveProjectModuleImportUrl(`./_${projectId}_/l2/${moduleId}/module.js`);
            const mod = await import(moduleUrl);
            if (!mod.moduleFrontendDefinition?.routes?.length) {
                return undefined;
            }
            return {
                ...mod.moduleFrontendDefinition,
                routes: normalizeRoutes(mod.moduleFrontendDefinition.routes),
                headerRenderer: normalizeRendererConfig(mod.moduleFrontendDefinition.headerRenderer),
                asideRenderer: normalizeRendererConfig(mod.moduleFrontendDefinition.asideRenderer),
                device: mod.moduleFrontendDefinition.device ?? 'desktop',
                navigation: mod.moduleFrontendDefinition.navigation ?? [],
            };
        }
        catch {
            return undefined;
        }
    })();
    moduleDefinitionCache.set(cacheKey, pending);
    return pending;
}
async function loadModuleShellPreferences(projectId, moduleId) {
    try {
        const moduleUrl = resolveProjectModuleImportUrl(`./_${projectId}_/l2/${moduleId}/module.js`);
        const mod = await import(moduleUrl);
        return mod.moduleShellPreferences;
    }
    catch {
        return undefined;
    }
}
function collectRoutePatterns(routes) {
    return [...new Set(routes.flatMap((route) => [route.path, ...(route.aliases ?? [])]))];
}
async function getConfiguredFrontendApps() {
    const config = readProjectsConfig();
    const publicationTarget = getPublicationTarget();
    const sharedAssetRoots = publicationTarget.serveStaticFromServer
        ? Object.keys(config.projects).map((projectId) => resolveActivePublicationDistPath(`./_${projectId}_/l2`))
        : Object.keys(config.projects).map((projectId) => resolveProjectDistPath(`./_${projectId}_/l2`));
    const configuredProjects = Object.entries(config.projects);
    const maybeApps = await Promise.all(configuredProjects.flatMap(([projectId, project]) => (project.modules ?? []).map(async (moduleConfig) => {
        const [moduleDefinition, modulePreferences] = await Promise.all([
            loadModuleDefinition(projectId, moduleConfig.moduleId),
            loadModuleShellPreferences(projectId, moduleConfig.moduleId),
        ]);
        if (!moduleDefinition) {
            return null;
        }
        const app = {
            projectId,
            appId: moduleConfig.moduleId,
            basePath: moduleConfig.basePath,
            indexHtmlPath: resolveActivePublicationDistPath(config.shellTemplates[moduleConfig.shellMode]),
            assetRoots: sharedAssetRoots,
            routePatterns: collectRoutePatterns(moduleDefinition.routes),
            shellMode: moduleConfig.shellMode,
            routes: moduleDefinition.routes,
            headerRenderer: moduleDefinition.headerRenderer,
            asideRenderer: moduleDefinition.asideRenderer,
            layout: mergeLayoutPreferences(modulePreferences),
            device: moduleDefinition.device ?? 'desktop',
            pageTitle: moduleDefinition.pageTitle ?? moduleConfig.moduleId,
            navigation: moduleDefinition.navigation ?? [],
        };
        return app;
    })));
    const apps = maybeApps.filter((app) => app !== null);
    return apps.map((app) => ({
        ...app,
        moduleLinks: apps
            .filter((candidate) => candidate.basePath !== app.basePath)
            .map((candidate) => ({
            id: candidate.appId,
            label: candidate.pageTitle ?? candidate.appId,
            href: candidate.basePath,
            description: `Open ${candidate.pageTitle ?? candidate.appId}`,
        })),
    }));
}
export async function getFrontendAppRegistrations() {
    if (!cachedAppsPromise) {
        cachedAppsPromise = getConfiguredFrontendApps();
    }
    return cachedAppsPromise;
}
export async function getFrontendAppByBasePath(urlPath) {
    const apps = await getFrontendAppRegistrations();
    return apps.find((app) => urlPath === app.basePath || urlPath.startsWith(`${app.basePath}/`));
}
export function getAppPublicRootDir(app) {
    return dirname(app.indexHtmlPath);
}

export class ConsoleLogger {
    info(message, data) {
        console.info(message, data ?? '');
    }
    error(message, data) {
        console.error(message, data ?? '');
    }
}

/// <mls fileReference="_102034_/l1/server/layer_1_external/persistence/dynamoAdmin.ts" enhancement="_blank" />
import { CreateTableCommand, DeleteTableCommand, DescribeTableCommand, DynamoDBClient, waitUntilTableExists, waitUntilTableNotExists, } from '@aws-sdk/client-dynamodb';
import { DeleteCommand, PutCommand, ScanCommand } from '@aws-sdk/lib-dynamodb';
import { createDynamoDocumentClient } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient.js';
import { loadResolvedDynamoTableDefinitions } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
function createDynamoClient(env) {
    return new DynamoDBClient({
        region: env.awsRegion,
        credentials: env.awsAccessKeyId && env.awsSecretAccessKey
            ? {
                accessKeyId: env.awsAccessKeyId,
                secretAccessKey: env.awsSecretAccessKey,
                sessionToken: env.awsSessionToken,
            }
            : undefined,
    });
}
async function ensureDynamoTableDefinition(client, definition) {
    if (!definition.dynamoResolvedTableName || !definition.dynamo) {
        return;
    }
    try {
        await client.send(new DescribeTableCommand({
            TableName: definition.dynamoResolvedTableName,
        }));
        return;
    }
    catch (error) {
        const errorName = typeof error === 'object' && error !== null && 'name' in error
            ? String(error.name)
            : '';
        const errorType = typeof error === 'object' && error !== null && '__type' in error
            ? String(error.__type)
            : '';
        if (errorName !== 'ResourceNotFoundException' &&
            !errorType.includes('ResourceNotFoundException')) {
            throw error;
        }
    }
    const attributeDefinitions = [
        {
            AttributeName: definition.dynamo.partitionKey,
            AttributeType: 'S',
        },
    ];
    const keySchema = [
        {
            AttributeName: definition.dynamo.partitionKey,
            KeyType: 'HASH',
        },
    ];
    if (definition.dynamo.sortKey) {
        attributeDefinitions.push({
            AttributeName: definition.dynamo.sortKey,
            AttributeType: 'S',
        });
        keySchema.push({
            AttributeName: definition.dynamo.sortKey,
            KeyType: 'RANGE',
        });
    }
    await client.send(new CreateTableCommand({
        TableName: definition.dynamoResolvedTableName,
        AttributeDefinitions: attributeDefinitions,
        KeySchema: keySchema,
        BillingMode: 'PAY_PER_REQUEST',
    }));
    await waitUntilTableExists({
        client,
        maxWaitTime: 60,
    }, {
        TableName: definition.dynamoResolvedTableName,
    });
}
export async function ensureRegisteredDynamoTables(env) {
    const client = createDynamoClient(env);
    const definitions = await loadResolvedDynamoTableDefinitions(env);
    for (const definition of definitions) {
        await ensureDynamoTableDefinition(client, definition);
    }
}
export async function deleteRegisteredDynamoTables(env) {
    const client = createDynamoClient(env);
    const definitions = await loadResolvedDynamoTableDefinitions(env);
    for (const definition of definitions) {
        if (!definition.dynamoResolvedTableName) {
            continue;
        }
        try {
            await client.send(new DeleteTableCommand({ TableName: definition.dynamoResolvedTableName }));
            await waitUntilTableNotExists({
                client,
                maxWaitTime: 60,
            }, {
                TableName: definition.dynamoResolvedTableName,
            });
        }
        catch (error) {
            const errorName = typeof error === 'object' && error !== null && 'name' in error
                ? String(error.name)
                : '';
            const errorType = typeof error === 'object' && error !== null && '__type' in error
                ? String(error.__type)
                : '';
            if (errorName !== 'ResourceNotFoundException' &&
                !errorType.includes('ResourceNotFoundException')) {
                throw error;
            }
        }
    }
}
export async function writeSchemaSnapshotLog(env, snapshot) {
    const definitions = await loadResolvedDynamoTableDefinitions(env);
    const snapshotDefinition = definitions.find((definition) => definition.repositoryName === 'schemaSnapshotLog');
    if (!snapshotDefinition?.dynamoResolvedTableName) {
        return;
    }
    const client = createDynamoDocumentClient(env);
    await client.send(new PutCommand({
        TableName: snapshotDefinition.dynamoResolvedTableName,
        Item: {
            snapshotId: snapshot.id,
            hash: snapshot.hash,
            appliedAt: snapshot.appliedAt,
            tables: snapshot.tables,
        },
    }));
}
export async function deleteDynamoItem(env, definition, key) {
    if (!definition.dynamoResolvedTableName) {
        return;
    }
    const client = createDynamoDocumentClient(env);
    await client.send(new DeleteCommand({
        TableName: definition.dynamoResolvedTableName,
        Key: key,
    }));
}
export async function putDynamoItem(env, definition, item) {
    if (!definition.dynamoResolvedTableName) {
        return;
    }
    const client = createDynamoDocumentClient(env);
    await client.send(new PutCommand({
        TableName: definition.dynamoResolvedTableName,
        Item: item,
    }));
}
export async function scanAllDynamoItems(env, definition) {
    if (!definition.dynamoResolvedTableName) {
        return [];
    }
    const client = createDynamoDocumentClient(env);
    const items = [];
    let exclusiveStartKey;
    do {
        const response = await client.send(new ScanCommand({
            TableName: definition.dynamoResolvedTableName,
            ExclusiveStartKey: exclusiveStartKey,
        }));
        items.push(...(response.Items ?? []));
        exclusiveStartKey = response.LastEvaluatedKey;
    } while (exclusiveStartKey);
    return items;
}

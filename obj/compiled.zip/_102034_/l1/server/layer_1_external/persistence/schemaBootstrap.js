import { getSharedPgPool } from '/_102034_/l1/server/layer_1_external/data/postgres/pg.js';
import { usesPostgres } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { buildSchemaSnapshot, loadResolvedTableDefinitions, loadViewDefinitions, } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { ensureRegisteredDynamoTables, writeSchemaSnapshotLog, } from '/_102034_/l1/server/layer_1_external/persistence/dynamoAdmin.js';
function quoteIdentifier(identifier) {
    return `"${identifier.replaceAll('"', '""')}"`;
}
function renderIndexColumn(column) {
    if (typeof column === 'string') {
        return quoteIdentifier(column);
    }
    return `${quoteIdentifier(column.name)} ${(column.direction ?? 'asc').toUpperCase()}`;
}
function buildCreateTableSql(definition) {
    const columnsSql = definition.columns.map((column) => {
        const notNullSql = column.nullable ? '' : ' NOT NULL';
        const defaultSql = column.defaultSql ? ` DEFAULT ${column.defaultSql}` : '';
        return `${quoteIdentifier(column.name)} ${column.postgresType}${notNullSql}${defaultSql}`;
    });
    const primaryKeySql = definition.primaryKey.length > 0
        ? `, PRIMARY KEY (${definition.primaryKey.map((column) => quoteIdentifier(column)).join(', ')})`
        : '';
    const unloggedSql = definition.postgres?.unlogged ? 'UNLOGGED ' : '';
    return `CREATE ${unloggedSql}TABLE ${quoteIdentifier(definition.tableName)} (${columnsSql.join(', ')}${primaryKeySql})`;
}
function buildCreateIndexSql(definition) {
    return (definition.indexes ?? []).map((index) => `CREATE ${index.unique ? 'UNIQUE ' : ''}INDEX ${quoteIdentifier(index.name)}
     ON ${quoteIdentifier(definition.tableName)} (${index.columns.map((column) => renderIndexColumn(column)).join(', ')})`);
}
async function ensureTimescaleAvailable(pool) {
    const existing = await pool.query("SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'timescaledb') AS exists");
    if (existing.rows[0]?.exists) {
        return true;
    }
    try {
        await pool.query('CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE');
        return true;
    }
    catch {
        console.warn('[bootstrapSchema] TimescaleDB extension not available — hypertables will be created as regular tables');
        return false;
    }
}
async function rebuildPostgresSchema(env, definitions, snapshotId) {
    const pool = getSharedPgPool(env);
    const hasTimescale = definitions.some((d) => d.timescale?.hypertable);
    const timescaleAvailable = hasTimescale ? await ensureTimescaleAvailable(pool) : false;
    await pool.query('DROP SCHEMA IF EXISTS public CASCADE');
    await pool.query('CREATE SCHEMA public');
    const orderedDefinitions = [...definitions]
        .filter((definition) => usesPostgres(definition))
        .sort((left, right) => {
        if (left.tableName === '_schema_migrations') {
            return -1;
        }
        if (right.tableName === '_schema_migrations') {
            return 1;
        }
        return left.tableName.localeCompare(right.tableName);
    });
    for (const definition of orderedDefinitions) {
        await pool.query(buildCreateTableSql(definition));
    }
    for (const definition of orderedDefinitions) {
        for (const indexSql of buildCreateIndexSql(definition)) {
            await pool.query(indexSql);
        }
    }
    if (timescaleAvailable) {
        for (const definition of orderedDefinitions.filter((d) => d.timescale?.hypertable)) {
            const { timeColumn, chunkTimeInterval } = definition.timescale.hypertable;
            const intervalPart = chunkTimeInterval ? `, chunk_time_interval => INTERVAL '${chunkTimeInterval}'` : '';
            await pool.query(`SELECT create_hypertable($1, $2, if_not_exists => TRUE${intervalPart})`, [definition.tableName, timeColumn]);
        }
    }
    await pool.query('INSERT INTO "_schema_migrations" ("id") VALUES ($1)', [snapshotId]);
    return timescaleAvailable;
}
async function applyViewDefinitions(pool, input) {
    const viewDefs = await loadViewDefinitions();
    for (const view of viewDefs) {
        for (const statement of view.statements) {
            if (!input.timescaleAvailable && statement.includes('timescaledb')) {
                console.warn(`[bootstrapSchema] Skipped TimescaleDB view statement for ${view.viewName}`);
                continue;
            }
            await pool.query(statement);
        }
    }
}
export async function bootstrapSchema(env, input) {
    if (env.runtimeMode === 'memory') {
        console.info('[bootstrapSchema] Skipped — memory mode');
        return { snapshotId: 'memory', postgresTableCount: 0, dynamoTableCount: 0 };
    }
    const definitions = await loadResolvedTableDefinitions(env);
    const snapshot = await buildSchemaSnapshot(env);
    const timescaleAvailable = await rebuildPostgresSchema(env, definitions, snapshot.id);
    const pool = getSharedPgPool(env);
    await applyViewDefinitions(pool, { timescaleAvailable });
    let dynamoTableCount = 0;
    if (input?.ensureDynamo !== false) {
        await ensureRegisteredDynamoTables(env);
        dynamoTableCount = definitions.filter((definition) => definition.dynamoResolvedTableName).length;
    }
    if (input?.recordSnapshotLog) {
        await writeSchemaSnapshotLog(env, snapshot);
    }
    return {
        snapshotId: snapshot.id,
        postgresTableCount: definitions.filter((definition) => usesPostgres(definition)).length,
        dynamoTableCount,
    };
}

import { getSharedPgPool } from '/_102034_/l1/server/layer_1_external/data/postgres/pg.js';
import { usesPostgres } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { buildSchemaSnapshot, loadResolvedTableDefinitions } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { ensureRegisteredDynamoTables, writeSchemaSnapshotLog, } from '/_102034_/l1/server/layer_1_external/persistence/dynamoAdmin.js';
function quoteIdentifier(identifier) {
    return `"${identifier.replaceAll('"', '""')}"`;
}
function renderIndexColumn(column) {
    if (typeof column === 'string') {
        return quoteIdentifier(column);
    }
    return `${quoteIdentifier(column.name)} ${(column.direction ?? 'asc').toUpperCase()}`;
}
function buildCreateTableSql(definition) {
    const columnsSql = definition.columns.map((column) => {
        const notNullSql = column.nullable ? '' : ' NOT NULL';
        const defaultSql = column.defaultSql ? ` DEFAULT ${column.defaultSql}` : '';
        return `${quoteIdentifier(column.name)} ${column.postgresType}${notNullSql}${defaultSql}`;
    });
    const primaryKeySql = definition.primaryKey.length > 0
        ? `, PRIMARY KEY (${definition.primaryKey.map((column) => quoteIdentifier(column)).join(', ')})`
        : '';
    const unloggedSql = definition.postgres?.unlogged ? 'UNLOGGED ' : '';
    return `CREATE ${unloggedSql}TABLE ${quoteIdentifier(definition.tableName)} (${columnsSql.join(', ')}${primaryKeySql})`;
}
function buildCreateIndexSql(definition) {
    return (definition.indexes ?? []).map((index) => `CREATE ${index.unique ? 'UNIQUE ' : ''}INDEX ${quoteIdentifier(index.name)}
     ON ${quoteIdentifier(definition.tableName)} (${index.columns.map((column) => renderIndexColumn(column)).join(', ')})`);
}
async function rebuildPostgresSchema(env, definitions, snapshotId) {
    const pool = getSharedPgPool(env);
    await pool.query('DROP SCHEMA IF EXISTS public CASCADE');
    await pool.query('CREATE SCHEMA public');
    const orderedDefinitions = [...definitions]
        .filter((definition) => usesPostgres(definition))
        .sort((left, right) => {
        if (left.tableName === '_schema_migrations') {
            return -1;
        }
        if (right.tableName === '_schema_migrations') {
            return 1;
        }
        return left.tableName.localeCompare(right.tableName);
    });
    for (const definition of orderedDefinitions) {
        await pool.query(buildCreateTableSql(definition));
    }
    for (const definition of orderedDefinitions) {
        for (const indexSql of buildCreateIndexSql(definition)) {
            await pool.query(indexSql);
        }
    }
    await pool.query('INSERT INTO "_schema_migrations" ("id") VALUES ($1)', [snapshotId]);
}
export async function bootstrapSchema(env, input) {
    const definitions = await loadResolvedTableDefinitions(env);
    const snapshot = await buildSchemaSnapshot(env);
    await rebuildPostgresSchema(env, definitions, snapshot.id);
    let dynamoTableCount = 0;
    if (input?.ensureDynamo !== false) {
        await ensureRegisteredDynamoTables(env);
        dynamoTableCount = definitions.filter((definition) => definition.dynamoResolvedTableName).length;
    }
    if (input?.recordSnapshotLog) {
        await writeSchemaSnapshotLog(env, snapshot);
    }
    return {
        snapshotId: snapshot.id,
        postgresTableCount: definitions.filter((definition) => usesPostgres(definition)).length,
        dynamoTableCount,
    };
}

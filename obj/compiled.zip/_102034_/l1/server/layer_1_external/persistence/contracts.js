export function resolveRepositoryName(definition) {
    return definition.repositoryName ?? definition.tableName;
}
export function resolveDynamoTableName(definition, env) {
    if (!definition.dynamo) {
        return null;
    }
    return (definition.dynamo.tableNameByEnv?.[env.appEnv] ??
        definition.dynamo.tableName ??
        null);
}
export function resolvePostgresTableName(definition, env) {
    return definition.tableNameByEnv?.[env.appEnv] ?? definition.tableName;
}
export function usesPostgres(definition) {
    return definition.storageProfile !== 'dynamoOnly';
}
export function usesDynamo(definition) {
    return (definition.storageProfile === 'dynamoOnly' ||
        definition.storageProfile === 'postgresHotBackup' ||
        definition.storageProfile === 'dynamoWithPostgresIndex');
}
export function requiresWriteBehind(definition) {
    return definition.writeMode === 'writeBehind' && definition.storageProfile === 'postgresHotBackup';
}

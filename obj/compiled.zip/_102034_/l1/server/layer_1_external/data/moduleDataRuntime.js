import { getSharedPgPool, queryRows, withPgTransaction } from '/_102034_/l1/server/layer_1_external/data/postgres/pg.js';
import { createRuntimeUuid } from '/_102029_/l2/webCrypto.js';
import { requiresWriteBehind, usesPostgres, } from '/_102034_/l1/server/layer_1_external/persistence/contracts.js';
import { findResolvedTableDefinition, loadResolvedTableDefinitions, } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
function quoteIdentifier(identifier) {
    return `"${identifier.replaceAll('"', '""')}"`;
}
function buildWhereClause(where, startIndex = 1) {
    const entries = Object.entries(where ?? {}).filter(([, value]) => value !== undefined);
    if (entries.length === 0) {
        return {
            sql: '',
            params: [],
        };
    }
    const params = [];
    return {
        sql: `WHERE ${entries
            .map(([key, value]) => {
            if (value === null) {
                return `${quoteIdentifier(key)} IS NULL`;
            }
            params.push(value);
            return `${quoteIdentifier(key)} = $${startIndex + params.length - 1}`;
        })
            .join(' AND ')}`,
        params,
    };
}
function matchesWhere(record, where) {
    if (!where) {
        return true;
    }
    return Object.entries(where).every(([key, value]) => {
        if (value === undefined) {
            return true;
        }
        return record[key] === value;
    });
}
function compareValues(left, right) {
    if (typeof left === 'number' && typeof right === 'number') {
        return left - right;
    }
    return String(left ?? '').localeCompare(String(right ?? ''));
}
function getPrimaryKey(definition, record) {
    return Object.fromEntries(definition.primaryKey.map((key) => [key, record[key]]));
}
function serializeAggregateId(key) {
    return Object.entries(key)
        .map(([field, value]) => `${field}=${String(value ?? '')}`)
        .join('|');
}
async function insertRegistryOutboxRecord(executor, env, definition, payload) {
    const outboxDefinition = await findResolvedTableDefinition('mdmOutbox', env);
    const nowIso = new Date().toISOString();
    await executor.query(`INSERT INTO ${quoteIdentifier(outboxDefinition.tableName)}
     ("id", "aggregateType", "aggregateId", "eventType", "payload", "attemptCount", "processedAt", "lastError", "createdAt", "updatedAt", "topic")
     VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7, $8, $9, $10, $11)`, [
        createRuntimeUuid(),
        'RegistryTable',
        `${definition.tableName}:${serializeAggregateId(payload.key)}`,
        payload.operation === 'delete' ? 'DeleteRegistryTableRecord' : 'UpsertRegistryTableRecord',
        JSON.stringify(payload),
        0,
        null,
        null,
        nowIso,
        nowIso,
        `registry.${definition.repositoryName}.write-behind`,
    ]);
}
class MemoryTableRepository {
    constructor(definition, records) {
        this.definition = definition;
        this.records = records;
    }
    async findOne(input) {
        const record = this.records.find((entry) => matchesWhere(entry, input.where));
        return record ? { ...record } : null;
    }
    async findMany(input) {
        const rows = this.records.filter((entry) => matchesWhere(entry, input?.where));
        if (input?.orderBy) {
            const { field, direction } = input.orderBy;
            rows.sort((left, right) => {
                const result = compareValues(left[String(field)], right[String(field)]);
                return direction === 'asc' ? result : -result;
            });
        }
        const limited = input?.limit ? rows.slice(0, input.limit) : rows;
        return limited.map((entry) => ({ ...entry }));
    }
    async findManyByValues(input) {
        const values = new Set(input.values);
        const rows = this.records.filter((entry) => values.has(entry[String(input.field)]));
        const limited = input.limit ? rows.slice(0, input.limit) : rows;
        return limited.map((entry) => ({ ...entry }));
    }
    async insert(input) {
        this.records.push({ ...input.record });
    }
    async upsert(input) {
        const key = getPrimaryKey(this.definition, input.record);
        const index = this.records.findIndex((entry) => matchesWhere(entry, key));
        if (index >= 0) {
            this.records[index] = { ...input.record };
            return;
        }
        this.records.push({ ...input.record });
    }
    async update(input) {
        const record = this.records.find((entry) => matchesWhere(entry, input.where));
        if (!record) {
            throw new AppError('NOT_FOUND', 'Record not found', 404, input.where);
        }
        Object.assign(record, input.patch);
    }
    async delete(input) {
        const next = this.records.filter((entry) => !matchesWhere(entry, input.where));
        this.records.length = 0;
        this.records.push(...next);
    }
}
class PostgresTableRepository {
    constructor(definition, env, executor) {
        this.definition = definition;
        this.env = env;
        this.executor = executor;
    }
    async findOne(input) {
        const where = buildWhereClause(input.where);
        const rows = await queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.definition.tableName)} ${where.sql} LIMIT 1`, where.params);
        return rows[0] ?? null;
    }
    async findMany(input) {
        const where = buildWhereClause(input?.where);
        const orderSql = input?.orderBy
            ? `ORDER BY ${quoteIdentifier(String(input.orderBy.field))} ${input.orderBy.direction.toUpperCase()}`
            : '';
        const limitSql = input?.limit ? `LIMIT ${input.limit}` : '';
        return queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.definition.tableName)} ${where.sql} ${orderSql} ${limitSql}`.trim(), where.params);
    }
    async findManyByValues(input) {
        if (input.values.length === 0) {
            return [];
        }
        const limitSql = input.limit ? `LIMIT ${input.limit}` : '';
        return queryRows(this.executor, `SELECT * FROM ${quoteIdentifier(this.definition.tableName)}
       WHERE ${quoteIdentifier(String(input.field))} = ANY($1)
       ${limitSql}`.trim(), [input.values]);
    }
    async insert(input) {
        await this.executeMutation(input.record, async (executor) => {
            const entries = Object.entries(input.record);
            const columns = entries.map(([key]) => quoteIdentifier(key));
            const placeholders = entries.map((_, index) => `$${index + 1}`);
            await executor.query(`INSERT INTO ${quoteIdentifier(this.definition.tableName)} (${columns.join(', ')})
         VALUES (${placeholders.join(', ')})`, entries.map(([, value]) => value));
        });
    }
    async upsert(input) {
        await this.executeMutation(input.record, async (executor) => {
            const entries = Object.entries(input.record);
            const columns = entries.map(([key]) => quoteIdentifier(key));
            const placeholders = entries.map((_, index) => `$${index + 1}`);
            const updateSql = entries
                .filter(([key]) => !this.definition.primaryKey.includes(key))
                .map(([key]) => `${quoteIdentifier(key)} = EXCLUDED.${quoteIdentifier(key)}`)
                .join(', ');
            await executor.query(`INSERT INTO ${quoteIdentifier(this.definition.tableName)} (${columns.join(', ')})
         VALUES (${placeholders.join(', ')})
         ON CONFLICT (${this.definition.primaryKey.map((key) => quoteIdentifier(key)).join(', ')})
         DO UPDATE SET ${updateSql}`, entries.map(([, value]) => value));
        });
    }
    async update(input) {
        await this.executeMutation(undefined, async (executor) => {
            const patchEntries = Object.entries(input.patch).filter(([, value]) => value !== undefined);
            if (patchEntries.length === 0) {
                return;
            }
            const where = buildWhereClause(input.where, patchEntries.length + 1);
            const setSql = patchEntries
                .map(([key], index) => `${quoteIdentifier(key)} = $${index + 1}`)
                .join(', ');
            await executor.query(`UPDATE ${quoteIdentifier(this.definition.tableName)} SET ${setSql} ${where.sql}`.trim(), [...patchEntries.map(([, value]) => value), ...where.params]);
            if (requiresWriteBehind(this.definition)) {
                const rows = await queryRows(executor, `SELECT * FROM ${quoteIdentifier(this.definition.tableName)} ${where.sql} LIMIT 1`, where.params);
                const row = rows[0];
                if (row) {
                    await insertRegistryOutboxRecord(executor, this.env, this.definition, {
                        tableName: this.definition.tableName,
                        repositoryName: this.definition.repositoryName,
                        operation: 'upsert',
                        key: getPrimaryKey(this.definition, row),
                        item: row,
                    });
                }
            }
        });
    }
    async delete(input) {
        await this.executeMutation(undefined, async (executor) => {
            const where = buildWhereClause(input.where);
            const rowsToDelete = requiresWriteBehind(this.definition)
                ? await queryRows(executor, `SELECT * FROM ${quoteIdentifier(this.definition.tableName)} ${where.sql}`, where.params)
                : [];
            await executor.query(`DELETE FROM ${quoteIdentifier(this.definition.tableName)} ${where.sql}`.trim(), where.params);
            for (const row of rowsToDelete) {
                await insertRegistryOutboxRecord(executor, this.env, this.definition, {
                    tableName: this.definition.tableName,
                    repositoryName: this.definition.repositoryName,
                    operation: 'delete',
                    key: getPrimaryKey(this.definition, row),
                });
            }
        });
    }
    async executeMutation(record, operation) {
        if (!requiresWriteBehind(this.definition)) {
            await operation(this.executor);
            return;
        }
        if ('release' in this.executor) {
            await operation(this.executor);
            if (record) {
                await insertRegistryOutboxRecord(this.executor, this.env, this.definition, {
                    tableName: this.definition.tableName,
                    repositoryName: this.definition.repositoryName,
                    operation: 'upsert',
                    key: getPrimaryKey(this.definition, record),
                    item: record,
                });
            }
            return;
        }
        await withPgTransaction(this.executor, async (client) => {
            await operation(client);
            if (record) {
                await insertRegistryOutboxRecord(client, this.env, this.definition, {
                    tableName: this.definition.tableName,
                    repositoryName: this.definition.repositoryName,
                    operation: 'upsert',
                    key: getPrimaryKey(this.definition, record),
                    item: record,
                });
            }
        });
    }
}
class MemoryModuleDataRuntime {
    constructor(env) {
        this.env = env;
        this.store = new Map();
    }
    async getTable(repositoryNameOrTableName) {
        const definition = await findResolvedTableDefinition(repositoryNameOrTableName, this.env);
        if (!usesPostgres(definition)) {
            throw new AppError('PERSISTENCE_TABLE_UNAVAILABLE', 'Dynamo-only tables are not available in memory runtime', 400, { repositoryNameOrTableName });
        }
        if (!this.store.has(definition.repositoryName)) {
            this.store.set(definition.repositoryName, []);
        }
        return new MemoryTableRepository(definition, this.store.get(definition.repositoryName));
    }
    async listTables() {
        return loadResolvedTableDefinitions(this.env);
    }
    async runInTransaction(callback) {
        return callback(this);
    }
}
class PostgresModuleDataRuntime {
    constructor(env, executor = getSharedPgPool(env)) {
        this.env = env;
        this.executor = executor;
        this.repositoryCache = new Map();
    }
    async getTable(repositoryNameOrTableName) {
        const definition = await findResolvedTableDefinition(repositoryNameOrTableName, this.env);
        if (!usesPostgres(definition)) {
            throw new AppError('PERSISTENCE_TABLE_UNAVAILABLE', 'Requested repository does not have a local PostgreSQL table', 400, { repositoryNameOrTableName });
        }
        const cacheKey = definition.repositoryName;
        const cached = this.repositoryCache.get(cacheKey);
        if (cached) {
            return cached;
        }
        const repository = new PostgresTableRepository(definition, this.env, this.executor);
        this.repositoryCache.set(cacheKey, repository);
        return repository;
    }
    async listTables() {
        return loadResolvedTableDefinitions(this.env);
    }
    async runInTransaction(callback) {
        if ('release' in this.executor) {
            return callback(this);
        }
        return withPgTransaction(this.executor, async (client) => callback(new PostgresModuleDataRuntime(this.env, client)));
    }
}
export function createMemoryModuleDataRuntime(env) {
    return new MemoryModuleDataRuntime(env);
}
export function createPostgresModuleDataRuntime(env, executor = getSharedPgPool(env)) {
    return new PostgresModuleDataRuntime(env, executor);
}

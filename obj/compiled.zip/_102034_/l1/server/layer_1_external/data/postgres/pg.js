/// <mls fileReference="_102034_/l1/server/layer_1_external/data/postgres/pg.ts" enhancement="_blank" />
import { Pool } from 'pg';
let sharedPool = null;
export function getSharedPgPool(env) {
    if (!sharedPool) {
        sharedPool = new Pool({
            host: env.pgHost,
            port: env.pgPort,
            database: env.pgDatabase,
            user: env.pgUser,
            password: env.pgPassword,
        });
    }
    return sharedPool;
}
export async function withPgTransaction(pool, callback) {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await callback(client);
        await client.query('COMMIT');
        return result;
    }
    catch (error) {
        await client.query('ROLLBACK');
        throw error;
    }
    finally {
        client.release();
    }
}
export async function queryRows(client, sql, params = []) {
    const result = await client.query(sql, params);
    return result.rows;
}

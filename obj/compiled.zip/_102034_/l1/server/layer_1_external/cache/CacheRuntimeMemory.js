export class CacheRuntimeMemory {
    constructor() {
        this.values = new Map();
    }
    async get(key) {
        return this.values.get(key) ?? null;
    }
    async set(key, value) {
        this.values.set(key, value);
    }
}

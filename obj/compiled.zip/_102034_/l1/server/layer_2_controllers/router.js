import { getModuleBffRegistrations, loadModuleRouter } from '/_102034_/l1/server/layer_2_controllers/moduleRegistry.js';
export async function createServerRouter() {
    const mergedRouter = new Map();
    for (const registration of getModuleBffRegistrations()) {
        const router = await loadModuleRouter(registration);
        for (const [routine, handler] of router.entries()) {
            mergedRouter.set(routine, handler);
        }
    }
    return mergedRouter;
}

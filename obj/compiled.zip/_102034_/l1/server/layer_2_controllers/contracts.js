export class AppError extends Error {
    constructor(code, message, statusCode = 400, details) {
        super(message);
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
    }
}
export function ok(data) {
    return {
        ok: true,
        data,
        error: null,
    };
}
export function fail(error) {
    return {
        ok: false,
        data: null,
        error: {
            code: error.code,
            message: error.message,
            details: error.details,
        },
    };
}

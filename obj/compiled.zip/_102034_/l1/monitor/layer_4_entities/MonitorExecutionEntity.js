import { MonitorRuntimePostgres } from '/_102034_/l1/monitor/layer_1_external/data/postgres/MonitorRuntimePostgres.js';
import { getSharedBffExecutionSeriesStore } from '/_102034_/l1/monitor/layer_1_external/cache/BffExecutionSeriesStore.js';
export class MonitorExecutionEntity {
    static async record(event) {
        getSharedBffExecutionSeriesStore().record(event);
        try {
            await new MonitorRuntimePostgres().recordExecution(event);
        }
        catch (error) {
            if (MonitorRuntimePostgres.isMissingMonitorStorageError(error)) {
                return;
            }
            throw error;
        }
    }
}

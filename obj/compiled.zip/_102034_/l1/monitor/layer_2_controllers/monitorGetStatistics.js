/// <mls fileReference="_102034_/l1/monitor/layer_2_controllers/monitorGetStatistics.ts" enhancement="_blank" />
import { AppError, ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getStatisticsSeries, getStatisticsSnapshot, loadMonitorArchitecture, loadMonitorDynamoTableDetails, loadMonitorDynamoTableInspect, loadMonitorDynamodb, loadMonitorHome, loadMonitorPostgresTableDetails, loadMonitorPostgresTableInspect, loadMonitorPostgres, } from '/_102034_/l1/monitor/layer_3_usecases/statisticsUsecases.js';
function parseWindowSeconds(value) {
    if (value === undefined) {
        return 100;
    }
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed <= 0) {
        throw new AppError('VALIDATION_ERROR', 'windowSeconds must be a positive integer', 400);
    }
    return Math.min(parsed, 100);
}
function parseOptionalDatabaseName(value) {
    if (value === undefined || value === null || value === '') {
        return undefined;
    }
    if (typeof value !== 'string') {
        throw new AppError('VALIDATION_ERROR', 'databaseName must be a string', 400);
    }
    return value;
}
function parseRequiredTableName(value) {
    if (typeof value !== 'string' || value.trim().length === 0) {
        throw new AppError('VALIDATION_ERROR', 'tableName must be a non-empty string', 400);
    }
    return value.trim();
}
function parsePage(value) {
    if (value === undefined || value === null || value === '') {
        return undefined;
    }
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed <= 0) {
        throw new AppError('VALIDATION_ERROR', 'page must be a positive integer', 400);
    }
    return parsed;
}
function parseOptionalCursor(value) {
    if (value === undefined || value === null || value === '') {
        return undefined;
    }
    if (typeof value !== 'string') {
        throw new AppError('VALIDATION_ERROR', 'cursor must be a string', 400);
    }
    return value;
}
function parseFilters(value) {
    if (value === undefined || value === null) {
        return undefined;
    }
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new AppError('VALIDATION_ERROR', 'filters must be an object', 400);
    }
    const invalidEntry = Object.entries(value).find(([, entry]) => entry !== undefined && typeof entry !== 'string');
    if (invalidEntry) {
        throw new AppError('VALIDATION_ERROR', 'filters must contain only string values', 400);
    }
    return Object.fromEntries(Object.entries(value)
        .filter(([, entry]) => typeof entry === 'string' && entry.trim().length > 0)
        .map(([key, entry]) => [key, entry.trim()]));
}
export const monitorGetStatisticsSnapshotHandler = async () => {
    return ok(await getStatisticsSnapshot());
};
export const monitorGetStatisticsSeriesHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await getStatisticsSeries({
        windowSeconds: parseWindowSeconds(params.windowSeconds),
        routine: typeof params.routine === 'string' ? params.routine : undefined,
        source: params.source === 'http' || params.source === 'message' || params.source === 'test'
            ? params.source
            : undefined,
    }));
};
export const monitorHomeLoadHandler = async () => ok(await loadMonitorHome());
export const monitorPostgresLoadHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await loadMonitorPostgres({
        databaseName: parseOptionalDatabaseName(params.databaseName),
    }));
};
export const monitorDynamodbLoadHandler = async () => ok(await loadMonitorDynamodb());
export const monitorArchitectureLoadHandler = async () => ok(await loadMonitorArchitecture());
export const monitorPostgresTableInspectHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await loadMonitorPostgresTableInspect({
        databaseName: parseOptionalDatabaseName(params.databaseName),
        tableName: parseRequiredTableName(params.tableName),
        page: parsePage(params.page),
        filters: parseFilters(params.filters),
    }));
};
export const monitorPostgresTableDetailsHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await loadMonitorPostgresTableDetails({
        databaseName: parseOptionalDatabaseName(params.databaseName),
        tableName: parseRequiredTableName(params.tableName),
    }));
};
export const monitorDynamodbTableInspectHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await loadMonitorDynamoTableInspect({
        tableName: parseRequiredTableName(params.tableName),
        cursor: parseOptionalCursor(params.cursor),
        filters: parseFilters(params.filters),
    }));
};
export const monitorDynamodbTableDetailsHandler = async ({ request }) => {
    const params = (request.params ?? {});
    return ok(await loadMonitorDynamoTableDetails({
        tableName: parseRequiredTableName(params.tableName),
    }));
};

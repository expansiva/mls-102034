import { loadResolvedDynamoTableDefinitions, loadResolvedPostgresTableDefinitions, loadResolvedTableDefinitions, } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
export class MonitorPersistenceMetadata {
    constructor(env) {
        this.env = env;
    }
    async listAll() {
        const definitions = await loadResolvedTableDefinitions(this.env);
        return definitions.map((definition) => ({
            projectId: definition.projectId,
            moduleId: definition.moduleId,
            repositoryName: definition.repositoryName,
            tableName: definition.tableName,
            description: definition.description,
            purpose: definition.purpose,
            storageProfile: definition.storageProfile,
            backupHot: definition.backupHot,
            writeMode: definition.writeMode,
            dynamoTableName: definition.dynamoResolvedTableName,
            dynamoPartitionKey: definition.dynamo?.partitionKey ?? null,
            dynamoSortKey: definition.dynamo?.sortKey ?? null,
            dynamoTtlField: definition.dynamo?.ttlField ?? null,
            localIndexes: (definition.indexes ?? []).map((index) => ({
                name: index.name,
                unique: index.unique === true,
                columns: index.columns.map((column) => typeof column === 'string'
                    ? column
                    : `${column.name}${column.direction ? ` ${column.direction}` : ''}`),
            })),
            detailsInDynamoOnly: definition.storageProfile === 'dynamoWithPostgresIndex',
        }));
    }
    async listPostgresTables() {
        return loadResolvedPostgresTableDefinitions(this.env);
    }
    async listDynamoTables() {
        return loadResolvedDynamoTableDefinitions(this.env);
    }
    async findByPostgresTableName(tableName) {
        const items = await this.listAll();
        return items.find((item) => item.tableName === tableName) ?? null;
    }
    async findByDynamoTableName(tableName) {
        const items = await this.listAll();
        return items.find((item) => item.dynamoTableName === tableName) ?? null;
    }
}

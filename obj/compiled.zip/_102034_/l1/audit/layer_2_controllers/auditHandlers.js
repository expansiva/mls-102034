/// <mls fileReference="_102034_/l1/audit/layer_2_controllers/auditHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { loadAuditHome, loadAuditLog, loadAuditLogDetails, loadAuditStatusHistory, } from '/_102034_/l1/audit/layer_3_usecases/auditUsecases.js';
export const auditHomeLoadHandler = async ({ ctx }) => ok(await loadAuditHome(ctx));
export const auditAuditLogLoadHandler = async ({ ctx, request }) => ok(await loadAuditLog(ctx, request.params));
export const auditAuditLogDetailsHandler = async ({ ctx, request }) => ok(await loadAuditLogDetails(ctx, request.params));
export const auditStatusHistoryLoadHandler = async ({ ctx, request }) => ok(await loadAuditStatusHistory(ctx, request.params));

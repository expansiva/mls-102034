import { auditAuditLogDetailsHandler, auditAuditLogLoadHandler, auditHomeLoadHandler, auditStatusHistoryLoadHandler, } from '/_102034_/l1/audit/layer_2_controllers/auditHandlers.js';
export function createAuditRouter() {
    return new Map([
        ['audit.home.load', auditHomeLoadHandler],
        ['audit.auditLog.load', auditAuditLogLoadHandler],
        ['audit.auditLog.details', auditAuditLogDetailsHandler],
        ['audit.statusHistory.load', auditStatusHistoryLoadHandler],
    ]);
}

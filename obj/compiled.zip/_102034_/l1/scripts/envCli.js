export function parseCliAppEnv(value) {
    switch ((value ?? '').toLowerCase()) {
        case 'dev':
        case 'development':
            return 'development';
        case 'staging':
        case 'stage':
            return 'staging';
        case 'prod':
        case 'production':
            return 'production';
        default:
            throw new Error('Environment argument must be one of: dev, staging, prod');
    }
}
export function setCliAppEnv(value) {
    const appEnv = parseCliAppEnv(value);
    process.env.APP_ENV = appEnv;
    return appEnv;
}

export async function findStatusHistoryByEntity(ctx, params) {
    return ctx.data.mdmStatusHistory.findMany({
        where: {
            entityType: params.entityType,
            entityId: params.entityId,
        },
        orderBy: {
            field: 'createdAt',
            direction: 'desc',
        },
        limit: params.limit ?? 100,
    });
}
export async function findLatestStatusByEntity(ctx, params) {
    const rows = await findStatusHistoryByEntity(ctx, {
        entityType: params.entityType,
        entityId: params.entityId,
        limit: 1,
    });
    return rows[0] ?? null;
}

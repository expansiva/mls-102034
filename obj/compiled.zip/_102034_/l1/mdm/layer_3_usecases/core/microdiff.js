const richTypes = {
    Date: true,
    RegExp: true,
    String: true,
    Number: true,
};
export function microdiff(obj, newObj, stack = []) {
    const diffs = [];
    const isObjArray = Array.isArray(obj);
    for (const key in obj) {
        const objKey = obj[key];
        const path = isObjArray ? Number(key) : key;
        if (!(key in newObj)) {
            diffs.push({
                type: 'REMOVE',
                path: [path],
                oldValue: objKey,
            });
            continue;
        }
        const newObjKey = newObj[key];
        const areCompatibleObjects = typeof objKey === 'object' &&
            typeof newObjKey === 'object' &&
            Array.isArray(objKey) === Array.isArray(newObjKey);
        if (objKey &&
            newObjKey &&
            areCompatibleObjects &&
            !richTypes[Object.getPrototypeOf(objKey)?.constructor?.name ?? ''] &&
            !stack.includes(objKey)) {
            const nestedDiffs = microdiff(objKey, newObjKey, stack.concat([objKey])).map((difference) => ({
                ...difference,
                path: [path, ...difference.path],
            }));
            diffs.push(...nestedDiffs);
            continue;
        }
        const isEquivalentNaN = Number.isNaN(objKey) && Number.isNaN(newObjKey);
        const isEquivalentRichType = areCompatibleObjects &&
            (Number.isNaN(objKey)
                ? String(objKey) === String(newObjKey)
                : Number(objKey) === Number(newObjKey));
        if (objKey !== newObjKey && !isEquivalentNaN && !isEquivalentRichType) {
            diffs.push({
                type: 'CHANGE',
                path: [path],
                oldValue: objKey,
                value: newObjKey,
            });
        }
    }
    const isNewObjArray = Array.isArray(newObj);
    for (const key in newObj) {
        if (!(key in obj)) {
            diffs.push({
                type: 'CREATE',
                path: [isNewObjArray ? Number(key) : key],
                value: newObj[key],
            });
        }
    }
    return diffs;
}

/// <mls fileReference="_102034_/l1/mdm/layer_3_usecases/core/DataRecordService.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { findResolvedTableDefinition } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { microdiff } from '/_102034_/l1/mdm/layer_3_usecases/core/microdiff.js';
import { moduleConfig } from '/_102034_/l1/mdm/module.js';
function normalizeActor(ctx, actor) {
    return {
        actorId: actor?.actorId ?? ctx.requestMeta?.userId ?? 'system',
        actorType: actor?.actorType ?? (ctx.requestMeta?.userId ? 'user' : 'system'),
        source: actor?.source ?? ctx.requestMeta?.source ?? 'system',
    };
}
function diffEntries(before, after) {
    if (!before || !after) {
        return null;
    }
    return microdiff(before, after);
}
function buildAuditOutbox(ctx, record) {
    const nowIso = ctx.clock.nowIso();
    return {
        id: ctx.idGenerator.newId(),
        topic: 'mdm.audit.write-behind',
        aggregateType: 'MdmAuditLog',
        aggregateId: record.id,
        eventType: 'UpsertAuditLog',
        payload: record,
        attemptCount: 0,
        processedAt: null,
        lastError: null,
        createdAt: nowIso,
        updatedAt: nowIso,
    };
}
async function buildRegistryWriteBehindOutbox(ctx, repositoryName, item) {
    const definition = await findResolvedTableDefinition(repositoryName, readAppEnv());
    const key = Object.fromEntries(definition.primaryKey.map((field) => [field, item[field]]));
    const nowIso = ctx.clock.nowIso();
    return {
        id: ctx.idGenerator.newId(),
        topic: `registry.${definition.repositoryName}.write-behind`,
        aggregateType: 'RegistryTable',
        aggregateId: `${definition.tableName}:${definition.primaryKey.map((field) => `${field}=${String(item[field] ?? '')}`).join('|')}`,
        eventType: 'UpsertRegistryTableRecord',
        payload: {
            tableName: definition.tableName,
            repositoryName: definition.repositoryName,
            operation: 'upsert',
            key,
            item,
        },
        attemptCount: 0,
        processedAt: null,
        lastError: null,
        createdAt: nowIso,
        updatedAt: nowIso,
    };
}
export class AuditLogService {
    static async record(ctx, runtime, input) {
        const actor = normalizeActor(ctx, input.actor);
        const createdAt = input.createdAt ?? ctx.clock.nowIso();
        const indexRecord = {
            id: ctx.idGenerator.newId(),
            entityType: input.entityType,
            entityId: input.entityId,
            action: input.action,
            actorId: actor.actorId,
            actorType: actor.actorType,
            module: input.module,
            routine: input.routine,
            createdAt,
        };
        const documentRecord = {
            ...indexRecord,
            diff: diffEntries(input.before ?? null, input.after ?? null),
        };
        await runtime.mdmAuditLog.insert({ record: indexRecord });
        if (moduleConfig.persistence.writeMode === 'writeBehind') {
            await runtime.mdmOutbox.insert({
                record: buildAuditOutbox(ctx, documentRecord),
            });
        }
        return indexRecord;
    }
}
export class MonitoringWriteService {
    static async record(ctx, runtime, input) {
        const actor = normalizeActor(ctx, input);
        const record = {
            id: ctx.idGenerator.newId(),
            entityType: input.entityType,
            entityId: input.entityId ?? null,
            module: input.module,
            routine: input.routine,
            action: input.action,
            success: input.success,
            durationMs: input.durationMs,
            startedAt: input.startedAt,
            finishedAt: input.finishedAt,
            actorType: actor.actorType,
            source: actor.source,
            errorCode: input.errorCode ?? null,
        };
        await runtime.mdmMonitoringWrite.insert({ record });
    }
}
export class ErrorLogService {
    static async record(ctx, runtime, input) {
        const error = input.error;
        const record = {
            id: ctx.idGenerator.newId(),
            entityType: input.entityType ?? null,
            entityId: input.entityId ?? null,
            module: input.module,
            routine: input.routine,
            action: input.action,
            errorCode: error instanceof AppError ? error.code : 'INTERNAL_ERROR',
            message: error instanceof Error ? error.message : String(error),
            details: error instanceof AppError && error.details && typeof error.details === 'object'
                ? error.details
                : null,
            stack: error instanceof Error ? (error.stack ?? null) : null,
            createdAt: ctx.clock.nowIso(),
        };
        await runtime.mdmErrorLog.insert({ record });
        if (moduleConfig.persistence.writeMode === 'writeBehind') {
            await runtime.mdmOutbox.insert({
                record: await buildRegistryWriteBehindOutbox(ctx, 'mdmErrorLog', record),
            });
        }
    }
}
export class StatusHistoryService {
    static async record(ctx, runtime, input) {
        const actor = normalizeActor(ctx, input.actor);
        const record = {
            id: ctx.idGenerator.newId(),
            entityType: input.entityType,
            entityId: input.entityId,
            fromStatus: input.fromStatus ?? null,
            toStatus: input.toStatus,
            reason: input.reason ?? null,
            reasonCode: input.reasonCode ?? null,
            actorId: actor.actorId,
            actorType: actor.actorType,
            module: input.module,
            routine: input.routine,
            metadata: input.metadata ?? null,
            createdAt: ctx.clock.nowIso(),
        };
        await runtime.mdmStatusHistory.insert({ record });
        if (moduleConfig.persistence.writeMode === 'writeBehind') {
            await runtime.mdmOutbox.insert({
                record: await buildRegistryWriteBehindOutbox(ctx, 'mdmStatusHistory', record),
            });
        }
    }
}
async function recordFailure(ctx, meta, startedAtMs, error) {
    const finishedAt = ctx.clock.nowIso();
    try {
        await ErrorLogService.record(ctx, ctx.data, {
            ...meta,
            error,
        });
    }
    catch (loggingError) {
        ctx.log.error('Error log recording failed', {
            cause: loggingError instanceof Error ? loggingError.message : String(loggingError),
            originalError: error instanceof Error ? error.message : String(error),
            routine: meta.routine,
        });
    }
    try {
        await MonitoringWriteService.record(ctx, ctx.data, {
            ...meta,
            success: false,
            startedAt: new Date(startedAtMs).toISOString(),
            finishedAt,
            durationMs: Math.max(0, Date.now() - startedAtMs),
            errorCode: error instanceof AppError ? error.code : 'INTERNAL_ERROR',
        });
    }
    catch (monitoringError) {
        ctx.log.error('Monitoring write failure recording failed', {
            cause: monitoringError instanceof Error ? monitoringError.message : String(monitoringError),
            routine: meta.routine,
        });
    }
}
export async function runMonitoredWrite(ctx, meta, callback) {
    const startedAtMs = Date.now();
    try {
        const result = await callback();
        try {
            await MonitoringWriteService.record(ctx, ctx.data, {
                ...meta,
                success: true,
                startedAt: new Date(startedAtMs).toISOString(),
                finishedAt: ctx.clock.nowIso(),
                durationMs: Math.max(0, Date.now() - startedAtMs),
                errorCode: null,
            });
        }
        catch (error) {
            await ErrorLogService.record(ctx, ctx.data, {
                ...meta,
                action: meta.action,
                error,
            });
        }
        return result;
    }
    catch (error) {
        await recordFailure(ctx, meta, startedAtMs, error);
        throw error;
    }
}
export class DataRecordService {
    static async create(ctx, def, input) {
        const after = input.after;
        const entityId = def.getId(after);
        const meta = {
            entityType: def.entityType,
            entityId,
            module: input.meta.module,
            routine: input.meta.routine,
            action: 'create',
            actorId: input.meta.actorId,
            actorType: input.meta.actorType,
            source: input.meta.source,
        };
        return runMonitoredWrite(ctx, meta, async () => {
            const index = def.buildIndex(after);
            const document = def.toDocument(after, 1);
            await ctx.data.runInTransaction(async (runtime) => {
                await runtime.mdmDocument.put({ record: document });
                await def.getIndexRuntime(runtime).insert({ record: index });
                await AuditLogService.record(ctx, runtime, {
                    entityType: def.entityType,
                    entityId,
                    action: 'create',
                    module: input.meta.module,
                    routine: input.meta.routine,
                    before: null,
                    after: def.getAuditSnapshot(after, index),
                    actor: input.meta,
                });
                if (input.afterPersist) {
                    await input.afterPersist(runtime, {
                        after,
                        document,
                    });
                }
            });
            return {
                version: 1,
                after,
                index,
            };
        });
    }
    static async update(ctx, def, input) {
        const beforeDetail = input.before.details;
        const after = input.after
            ?? (input.patch && input.applyPatch
                ? input.applyPatch(beforeDetail, input.patch, ctx)
                : null);
        if (!after) {
            throw new AppError('INVALID_UPDATE_INPUT', 'update requires after or patch+applyPatch', 400);
        }
        const entityId = input.id;
        const meta = {
            entityType: def.entityType,
            entityId,
            module: input.meta.module,
            routine: input.meta.routine,
            action: 'update',
            actorId: input.meta.actorId,
            actorType: input.meta.actorType,
            source: input.meta.source,
        };
        return runMonitoredWrite(ctx, meta, async () => {
            const index = def.buildIndex(after);
            const document = def.toDocument(after, input.before.version + 1);
            const beforeSnapshot = def.getAuditSnapshot(beforeDetail, def.buildIndex(beforeDetail));
            const afterSnapshot = def.getAuditSnapshot(after, index);
            await ctx.data.runInTransaction(async (runtime) => {
                await runtime.mdmDocument.put({
                    record: document,
                    expectedVersion: input.expectedVersion,
                });
                await def.getIndexRuntime(runtime).update({
                    where: { mdmId: entityId },
                    patch: index,
                });
                await AuditLogService.record(ctx, runtime, {
                    entityType: def.entityType,
                    entityId,
                    action: 'update',
                    module: input.meta.module,
                    routine: input.meta.routine,
                    before: beforeSnapshot,
                    after: afterSnapshot,
                    actor: input.meta,
                });
                if (input.afterPersist) {
                    await input.afterPersist(runtime, {
                        before: input.before,
                        after,
                        document,
                    });
                }
            });
            return {
                version: document.version,
                after,
                index,
            };
        });
    }
    static async transitionStatus(ctx, def, input) {
        const entityId = def.getId(input.after);
        const meta = {
            entityType: def.entityType,
            entityId,
            module: input.meta.module,
            routine: input.meta.routine,
            action: 'transitionStatus',
            actorId: input.meta.actorId,
            actorType: input.meta.actorType,
            source: input.meta.source,
        };
        return runMonitoredWrite(ctx, meta, async () => {
            const index = def.buildIndex(input.after);
            const document = def.toDocument(input.after, input.before.version + 1);
            const beforeSnapshot = def.getAuditSnapshot(input.before.details, def.buildIndex(input.before.details));
            const afterSnapshot = def.getAuditSnapshot(input.after, index);
            await ctx.data.runInTransaction(async (runtime) => {
                await runtime.mdmDocument.put({
                    record: document,
                    expectedVersion: input.expectedVersion,
                });
                await def.getIndexRuntime(runtime).update({
                    where: { mdmId: entityId },
                    patch: index,
                });
                await StatusHistoryService.record(ctx, runtime, {
                    entityType: def.entityType,
                    entityId,
                    fromStatus: input.fromStatus ?? null,
                    toStatus: input.toStatus,
                    reason: input.reason ?? null,
                    reasonCode: input.reasonCode ?? null,
                    module: input.meta.module,
                    routine: input.meta.routine,
                    actor: input.meta,
                    metadata: input.metadata ?? null,
                });
                await AuditLogService.record(ctx, runtime, {
                    entityType: def.entityType,
                    entityId,
                    action: 'transitionStatus',
                    module: input.meta.module,
                    routine: input.meta.routine,
                    before: beforeSnapshot,
                    after: afterSnapshot,
                    actor: input.meta,
                });
                if (input.afterPersist) {
                    await input.afterPersist(runtime, {
                        before: input.before,
                        after: input.after,
                        document,
                    });
                }
            });
            return {
                version: document.version,
                after: input.after,
                index,
            };
        });
    }
}

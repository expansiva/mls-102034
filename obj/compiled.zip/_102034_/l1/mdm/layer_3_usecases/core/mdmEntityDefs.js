import { buildEntityIndex, buildProspectIndex, toDocumentRecord } from '/_102034_/l1/mdm/layer_3_usecases/mdmSupport.js';
function getAuditSnapshot(detail, index) {
    return {
        index,
        details: detail,
    };
}
export const mdmEntityDef = {
    entityType: 'MdmEntity',
    moduleName: 'mdm',
    getIndexRuntime(runtime) {
        return runtime.mdmEntityIndex;
    },
    buildIndex(detail) {
        return buildEntityIndex(detail);
    },
    toDocument(detail, version) {
        return toDocumentRecord(detail, version);
    },
    getId(detail) {
        return detail.mdmId;
    },
    getAuditSnapshot(detail, index) {
        return getAuditSnapshot(detail, index);
    },
};
export const mdmProspectDef = {
    entityType: 'MdmProspect',
    moduleName: 'mdm',
    getIndexRuntime(runtime) {
        return runtime.mdmProspectIndex;
    },
    buildIndex(detail) {
        return buildProspectIndex(detail);
    },
    toDocument(detail, version) {
        return toDocumentRecord(detail, version);
    },
    getId(detail) {
        return detail.mdmId;
    },
    getAuditSnapshot(detail, index) {
        return getAuditSnapshot(detail, index);
    },
};

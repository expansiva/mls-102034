export const moduleConfig = {
    moduleId: 'mdm',
    persistence: {
        idStrategy: 'uuidv7',
        localStore: 'postgres',
        remoteStore: 'dynamodb',
        writeMode: 'writeBehind',
        remoteSourceOfTruth: true,
        restoreLocalFromRemote: true,
    },
};

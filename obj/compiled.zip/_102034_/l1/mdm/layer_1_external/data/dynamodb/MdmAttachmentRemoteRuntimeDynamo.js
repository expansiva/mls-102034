import { GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { createDynamoDocumentClient } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient.js';
export class MdmAttachmentRemoteRuntimeDynamo {
    constructor(env) {
        this.env = env;
        this.client = createDynamoDocumentClient(env);
    }
    async put(record) {
        await this.client.send(new PutCommand({
            TableName: this.env.dynamoTableMdmAttachment,
            Item: record,
        }));
    }
    async get(id) {
        const result = await this.client.send(new GetCommand({
            TableName: this.env.dynamoTableMdmAttachment,
            Key: { id },
        }));
        return result.Item ?? null;
    }
}

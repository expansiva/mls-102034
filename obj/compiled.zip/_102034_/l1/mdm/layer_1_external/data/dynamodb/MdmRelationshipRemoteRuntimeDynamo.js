import { DeleteCommand, PutCommand, ScanCommand, } from '@aws-sdk/lib-dynamodb';
import { createDynamoDocumentClient } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient.js';
export class MdmRelationshipRemoteRuntimeDynamo {
    constructor(env) {
        this.env = env;
        this.client = createDynamoDocumentClient(env);
    }
    getTableName(scope) {
        return scope === 'prospect'
            ? this.env.dynamoTableMdmProspectRelationship
            : this.env.dynamoTableMdmRelationship;
    }
    async put(record) {
        await this.client.send(new PutCommand({
            TableName: this.getTableName(record.scope),
            Item: record,
        }));
    }
    async delete(id, scope) {
        await this.client.send(new DeleteCommand({
            TableName: this.getTableName(scope),
            Key: { id },
        }));
    }
    async listAll(scope) {
        const records = [];
        let exclusiveStartKey;
        do {
            const result = await this.client.send(new ScanCommand({
                TableName: this.getTableName(scope),
                ExclusiveStartKey: exclusiveStartKey,
            }));
            records.push(...(result.Items ?? []));
            exclusiveStartKey = result.LastEvaluatedKey;
        } while (exclusiveStartKey);
        return records;
    }
}

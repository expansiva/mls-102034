/// <mls fileReference="_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmDocumentRemoteRuntimeDynamo.ts" enhancement="_blank" />
import { GetCommand, PutCommand, } from '@aws-sdk/lib-dynamodb';
import { createDynamoDocumentClient } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient.js';
export class MdmDocumentRemoteRuntimeDynamo {
    constructor(env) {
        this.env = env;
        this.client = createDynamoDocumentClient(env);
    }
    async get(mdmId) {
        const result = await this.client.send(new GetCommand({
            TableName: this.env.dynamoTableMdm,
            Key: { mdmId },
        }));
        return result.Item ?? null;
    }
    async put(record) {
        await this.client.send(new PutCommand({
            TableName: this.env.dynamoTableMdm,
            Item: record,
        }));
    }
}

import { GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { createDynamoDocumentClient } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/dynamoClient.js';
export class MdmAuditLogRemoteRuntimeDynamo {
    constructor(env) {
        this.env = env;
        this.client = createDynamoDocumentClient(env);
    }
    async put(record) {
        await this.client.send(new PutCommand({
            TableName: this.env.dynamoTableMdmAuditLog,
            Item: record,
        }));
    }
    async get(id) {
        const result = await this.client.send(new GetCommand({
            TableName: this.env.dynamoTableMdmAuditLog,
            Key: { id },
        }));
        const item = result.Item;
        if (!item) {
            return null;
        }
        return item;
    }
}

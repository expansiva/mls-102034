/// <mls fileReference="_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.ts" enhancement="_blank" />
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { createMemoryModuleDataRuntime } from '/_102034_/l1/server/layer_1_external/data/moduleDataRuntime.js';
function matchesWhere(record, where) {
    if (!where) {
        return true;
    }
    return Object.entries(where).every(([key, value]) => {
        if (value === undefined) {
            return true;
        }
        return record[key] === value;
    });
}
class TableRuntimeMemory {
    constructor() {
        this.records = [];
    }
    async findOne(input) {
        const record = this.records.find((current) => matchesWhere(current, input.where));
        return record ? { ...record } : null;
    }
    async findMany(input) {
        const records = this.records.filter((record) => matchesWhere(record, input?.where));
        if (input?.orderBy) {
            const { field, direction } = input.orderBy;
            records.sort((left, right) => {
                const leftValue = String(left[String(field)] ?? '');
                const rightValue = String(right[String(field)] ?? '');
                if (leftValue === rightValue) {
                    return 0;
                }
                return direction === 'asc'
                    ? leftValue.localeCompare(rightValue)
                    : rightValue.localeCompare(leftValue);
            });
        }
        const result = input?.limit ? records.slice(0, input.limit) : records;
        return result.map((record) => ({ ...record }));
    }
    async findManyByValues(input) {
        const valueSet = new Set(input.values);
        const records = this.records.filter((record) => valueSet.has(record[String(input.field)]));
        const result = input.limit ? records.slice(0, input.limit) : records;
        return result.map((record) => ({ ...record }));
    }
    async insert(input) {
        this.records.push({ ...input.record });
    }
    async update(input) {
        const record = this.records.find((current) => matchesWhere(current, input.where));
        if (!record) {
            throw new AppError('NOT_FOUND', 'Record not found', 404, input.where);
        }
        Object.assign(record, input.patch);
    }
    async delete(input) {
        const filtered = this.records.filter((record) => !matchesWhere(record, input.where));
        this.records.length = 0;
        this.records.push(...filtered);
    }
}
class DocumentRuntimeMemory {
    constructor() {
        this.records = new Map();
    }
    async get(input) {
        const record = this.records.get(input.mdmId);
        return record ? { ...record } : null;
    }
    async getMany(input) {
        return input.mdmIds
            .map((mdmId) => this.records.get(mdmId))
            .filter((record) => record !== undefined)
            .map((record) => ({ ...record }));
    }
    async put(input) {
        const currentRecord = this.records.get(input.record.mdmId);
        if (input.expectedVersion !== undefined && input.expectedVersion !== null) {
            if (!currentRecord || currentRecord.version !== input.expectedVersion) {
                throw new AppError('CONCURRENCY_CONFLICT', 'Version mismatch', 409, {
                    expectedVersion: input.expectedVersion,
                    currentVersion: currentRecord?.version ?? null,
                });
            }
        }
        if (currentRecord && input.expectedVersion === undefined) {
            throw new AppError('DOCUMENT_EXISTS', 'Document already exists', 409, {
                mdmId: input.record.mdmId,
            });
        }
        this.records.set(input.record.mdmId, { ...input.record });
    }
    async delete(input) {
        this.records.delete(input.mdmId);
    }
}
class QueueRuntimeMemory {
    constructor() {
        this.records = [];
    }
    async publish(input) {
        this.records.push({ ...input });
    }
    async list(input) {
        return input?.topic
            ? this.records.filter((record) => record.topic === input.topic)
            : [...this.records];
    }
}
export function createMemoryDataRuntime() {
    const env = readAppEnv();
    const runtime = {
        mode: 'memory',
        mdmDocument: new DocumentRuntimeMemory(),
        mdmEntityIndex: new TableRuntimeMemory(),
        mdmProspectIndex: new TableRuntimeMemory(),
        mdmRelationship: new TableRuntimeMemory(),
        mdmProspectRelationship: new TableRuntimeMemory(),
        mdmAuditLog: new TableRuntimeMemory(),
        mdmComment: new TableRuntimeMemory(),
        mdmAttachment: new TableRuntimeMemory(),
        mdmNumberSequence: new TableRuntimeMemory(),
        mdmMonitoringWrite: new TableRuntimeMemory(),
        mdmErrorLog: new TableRuntimeMemory(),
        mdmStatusHistory: new TableRuntimeMemory(),
        mdmTag: new TableRuntimeMemory(),
        mdmOutbox: new TableRuntimeMemory(),
        pgQueue: new QueueRuntimeMemory(),
        moduleData: createMemoryModuleDataRuntime(env),
        async runInTransaction(callback) {
            return callback(runtime);
        },
    };
    return runtime;
}

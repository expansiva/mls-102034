import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { deleteDynamoItem, putDynamoItem } from '/_102034_/l1/server/layer_1_external/persistence/dynamoAdmin.js';
import { findResolvedTableDefinition } from '/_102034_/l1/server/layer_1_external/persistence/registry.js';
import { createPostgresDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres.js';
import { MdmAuditLogRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAuditLogRemoteRuntimeDynamo.js';
import { MdmAttachmentRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmAttachmentRemoteRuntimeDynamo.js';
import { MdmCommentRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmCommentRemoteRuntimeDynamo.js';
import { MdmDocumentRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmDocumentRemoteRuntimeDynamo.js';
import { MdmNumberSequenceRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmNumberSequenceRemoteRuntimeDynamo.js';
import { MdmRelationshipRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmRelationshipRemoteRuntimeDynamo.js';
import { MdmTagRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmTagRemoteRuntimeDynamo.js';
function isLegacyPendingMergeOutbox(payload) {
    if (payload.topic !== 'mdm.pending-merge') {
        return false;
    }
    if (payload.aggregateType !== 'MdmDocument') {
        return false;
    }
    const candidate = payload.payload;
    return !candidate || typeof candidate.mdmId !== 'string' || candidate.mdmId.trim().length === 0;
}
export class WriteBehindWorker {
    constructor(env = readAppEnv()) {
        this.env = env;
        this.runtime = createPostgresDataRuntime(env);
        this.remoteAuditRuntime = new MdmAuditLogRemoteRuntimeDynamo(env);
        this.remoteRuntime = new MdmDocumentRemoteRuntimeDynamo(env);
        this.remoteRelationshipRuntime = new MdmRelationshipRemoteRuntimeDynamo(env);
        this.remoteTagRuntime = new MdmTagRemoteRuntimeDynamo(env);
        this.remoteCommentRuntime = new MdmCommentRemoteRuntimeDynamo(env);
        this.remoteAttachmentRuntime = new MdmAttachmentRemoteRuntimeDynamo(env);
        this.remoteNumberSequenceRuntime = new MdmNumberSequenceRemoteRuntimeDynamo(env);
    }
    async runOnce(limit = 50) {
        const queueItems = (await this.runtime.mdmOutbox.findMany({
            where: {
                processedAt: null,
            },
            orderBy: {
                field: 'createdAt',
                direction: 'asc',
            },
            limit,
        })).filter((item) => item.attemptCount < WriteBehindWorker.MAX_ATTEMPT_COUNT);
        let processed = 0;
        let failed = 0;
        for (const payload of queueItems) {
            try {
                if (isLegacyPendingMergeOutbox(payload)) {
                    // Legacy queue messages were written into mdm_outbox with the wrong
                    // aggregate type and no document key. They are not write-behind jobs.
                }
                else if (payload.aggregateType === 'MdmDocument') {
                    await this.remoteRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmAuditLog') {
                    await this.remoteAuditRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmTag') {
                    await this.remoteTagRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmComment') {
                    await this.remoteCommentRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmAttachment') {
                    await this.remoteAttachmentRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmNumberSequence') {
                    await this.remoteNumberSequenceRuntime.put(payload.payload);
                }
                else if (payload.aggregateType === 'MdmRelationship') {
                    if (payload.eventType === 'DeleteRelationship') {
                        const relationshipPayload = payload.payload;
                        await this.remoteRelationshipRuntime.delete(payload.aggregateId, relationshipPayload.scope);
                    }
                    else {
                        await this.remoteRelationshipRuntime.put(payload.payload);
                    }
                }
                else if (payload.aggregateType === 'RegistryTable') {
                    await this.handleRegistryTablePayload(payload.payload);
                }
                await this.runtime.runInTransaction(async (trx) => {
                    await trx.mdmOutbox.delete({
                        where: { id: payload.id },
                    });
                });
                processed += 1;
            }
            catch (error) {
                failed += 1;
                await this.runtime.runInTransaction(async (trx) => {
                    await trx.mdmOutbox.update({
                        where: { id: payload.id },
                        patch: {
                            attemptCount: payload.attemptCount + 1,
                            lastError: error instanceof Error ? error.message : String(error),
                            updatedAt: new Date().toISOString(),
                        },
                    });
                });
            }
        }
        return { processed, failed };
    }
    async handleRegistryTablePayload(payload) {
        const definition = await findResolvedTableDefinition(payload.repositoryName, this.env);
        if (!definition.dynamoResolvedTableName) {
            return;
        }
        if (payload.operation === 'delete') {
            await deleteDynamoItem(this.env, definition, payload.key);
            return;
        }
        await putDynamoItem(this.env, definition, payload.item ?? payload.key);
    }
}
WriteBehindWorker.MAX_ATTEMPT_COUNT = 100;

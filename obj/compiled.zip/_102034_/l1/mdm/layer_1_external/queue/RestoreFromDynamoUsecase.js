import { readAppEnv } from '/_102034_/l1/server/layer_1_external/config/env.js';
import { createPostgresDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/postgres/MdmDataRuntimePostgres.js';
import { MdmDocumentRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmDocumentRemoteRuntimeDynamo.js';
import { MdmRelationshipRemoteRuntimeDynamo } from '/_102034_/l1/mdm/layer_1_external/data/dynamodb/MdmRelationshipRemoteRuntimeDynamo.js';
import { buildEntityIndex, buildProspectIndex } from '/_102034_/l1/mdm/layer_3_usecases/mdmSupport.js';
import { MdmDocumentEntity } from '/_102034_/l1/mdm/layer_4_entities/MdmDocumentEntity.js';
export class RestoreFromDynamoUsecase {
    constructor(env = readAppEnv()) {
        this.env = env;
        this.runtime = createPostgresDataRuntime(env);
        this.remoteRuntime = new MdmDocumentRemoteRuntimeDynamo(env);
        this.remoteRelationshipRuntime = new MdmRelationshipRemoteRuntimeDynamo(env);
    }
    async restoreDocument(document) {
        const details = MdmDocumentEntity.parseDetails(document);
        await this.runtime.runInTransaction(async (trx) => {
            await trx.mdmDocument.put({ record: document });
            if (details.status === 'New' ||
                details.status === 'InProgress' ||
                details.status === 'PendingMerge' ||
                details.status === 'Promoted' ||
                details.status === 'Expired' ||
                details.status === 'Discarded') {
                await trx.mdmProspectIndex.delete({ where: { mdmId: details.mdmId } });
                await trx.mdmProspectIndex.insert({ record: buildProspectIndex(details) });
                return;
            }
            await trx.mdmEntityIndex.delete({ where: { mdmId: details.mdmId } });
            await trx.mdmEntityIndex.insert({ record: buildEntityIndex(details) });
        });
    }
    async restoreById(mdmId) {
        const document = await this.remoteRuntime.get(mdmId);
        if (!document) {
            throw new Error(`Document ${mdmId} not found in DynamoDB`);
        }
        await this.restoreDocument(document);
    }
    async restoreRelationship(relationship) {
        await this.runtime.runInTransaction(async (trx) => {
            const targetRuntime = relationship.scope === 'entity'
                ? trx.mdmRelationship
                : trx.mdmProspectRelationship;
            await targetRuntime.delete({ where: { id: relationship.id } });
            await targetRuntime.insert({
                record: {
                    id: relationship.id,
                    fromId: relationship.fromId,
                    toId: relationship.toId,
                    type: relationship.type,
                    role: relationship.role ?? null,
                    metadata: relationship.metadata ?? {},
                    isBidirectional: relationship.isBidirectional,
                    validFrom: relationship.validFrom,
                    validTo: relationship.validTo ?? null,
                    status: relationship.status,
                    createdAt: relationship.createdAt,
                    updatedAt: relationship.updatedAt,
                },
            });
        });
    }
    async restoreAllRelationships() {
        const entityRelationships = await this.remoteRelationshipRuntime.listAll('entity');
        const prospectRelationships = await this.remoteRelationshipRuntime.listAll('prospect');
        const relationships = [...entityRelationships, ...prospectRelationships];
        for (const relationship of relationships) {
            await this.restoreRelationship(relationship);
        }
        return relationships.length;
    }
}

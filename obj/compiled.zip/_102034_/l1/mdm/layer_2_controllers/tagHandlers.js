/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/tagHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { addTag, findTagsByEntity, findTagsByTag, removeTag, } from '/_102034_/l1/mdm/layer_3_usecases/tagUsecases.js';
export const tagAddHandler = async ({ ctx, request }) => ok(await addTag(ctx, request.params));
export const tagRemoveHandler = async ({ ctx, request }) => ok(await removeTag(ctx, request.params));
export const tagFindByEntityHandler = async ({ ctx, request }) => ok(await findTagsByEntity(ctx, request.params));
export const tagFindByTagHandler = async ({ ctx, request }) => ok(await findTagsByTag(ctx, request.params));

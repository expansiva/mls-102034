/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/commentHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { addComment, editComment, findCommentsByEntity, removeComment, } from '/_102034_/l1/mdm/layer_3_usecases/commentUsecases.js';
export const commentAddHandler = async ({ ctx, request }) => ok(await addComment(ctx, request.params));
export const commentEditHandler = async ({ ctx, request }) => ok(await editComment(ctx, request.params));
export const commentRemoveHandler = async ({ ctx, request }) => ok(await removeComment(ctx, request.params));
export const commentFindByEntityHandler = async ({ ctx, request }) => ok(await findCommentsByEntity(ctx, request.params));

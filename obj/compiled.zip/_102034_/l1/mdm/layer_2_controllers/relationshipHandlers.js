/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/relationshipHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { createRelationship, listRelationships, updateRelationship, } from '/_102034_/l1/mdm/layer_3_usecases/relationshipUsecases.js';
export const relationshipCreateHandler = async ({ ctx, request }) => ok(await createRelationship(ctx, request.params));
export const relationshipListHandler = async ({ ctx, request }) => ok(await listRelationships(ctx, request.params ?? {}));
export const relationshipUpdateHandler = async ({ ctx, request }) => ok(await updateRelationship(ctx, request.params));

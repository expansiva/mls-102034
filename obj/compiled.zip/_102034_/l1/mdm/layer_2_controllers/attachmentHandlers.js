/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/attachmentHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { attachFile, detachFile, findAttachmentsByEntity, } from '/_102034_/l1/mdm/layer_3_usecases/attachmentUsecases.js';
export const attachmentAttachHandler = async ({ ctx, request }) => ok(await attachFile(ctx, request.params));
export const attachmentDetachHandler = async ({ ctx, request }) => ok(await detachFile(ctx, request.params));
export const attachmentFindByEntityHandler = async ({ ctx, request }) => ok(await findAttachmentsByEntity(ctx, request.params));

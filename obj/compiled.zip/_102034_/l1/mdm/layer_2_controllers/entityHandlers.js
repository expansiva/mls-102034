/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/entityHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { createEntity, getEntity, listEntities, mergeEntity, updateEntity, } from '/_102034_/l1/mdm/layer_3_usecases/recordUsecases.js';
export const entityCreateHandler = async ({ ctx, request }) => ok(await createEntity(ctx, request.params));
export const entityGetHandler = async ({ ctx, request }) => ok(await getEntity(ctx, String(request.params.mdmId)));
export const entityListHandler = async ({ ctx, request }) => ok(await listEntities(ctx, request.params ?? {}));
export const entityUpdateHandler = async ({ ctx, request }) => ok(await updateEntity(ctx, request.params));
export const entityMergeHandler = async ({ ctx, request }) => ok(await mergeEntity(ctx, request.params));

/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/prospectHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { createProspect, getProspect, listProspects, promoteProspect, updateProspect, } from '/_102034_/l1/mdm/layer_3_usecases/recordUsecases.js';
export const prospectCreateHandler = async ({ ctx, request }) => ok(await createProspect(ctx, request.params));
export const prospectGetHandler = async ({ ctx, request }) => ok(await getProspect(ctx, String(request.params.mdmId)));
export const prospectListHandler = async ({ ctx, request }) => ok(await listProspects(ctx, request.params ?? {}));
export const prospectUpdateHandler = async ({ ctx, request }) => ok(await updateProspect(ctx, request.params));
export const prospectPromoteHandler = async ({ ctx, request }) => ok(await promoteProspect(ctx, request.params));

/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/statusHistoryHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { findLatestStatusByEntity, findStatusHistoryByEntity, } from '/_102034_/l1/mdm/layer_3_usecases/statusHistoryUsecases.js';
export const statusHistoryFindByEntityHandler = async ({ ctx, request }) => ok(await findStatusHistoryByEntity(ctx, request.params));
export const statusHistoryFindLatestHandler = async ({ ctx, request }) => ok(await findLatestStatusByEntity(ctx, request.params));

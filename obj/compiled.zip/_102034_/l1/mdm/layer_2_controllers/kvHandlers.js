/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/kvHandlers.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getMdmKv, putMdmKv } from '/_102034_/l1/mdm/layer_3_usecases/kvUsecases.js';
export const kvGetHandler = async ({ ctx, request }) => ok(await getMdmKv(ctx, request.params));
export const kvPutHandler = async ({ ctx, request }) => ok(await putMdmKv(ctx, request.params));

/// <mls fileReference="_102034_/l1/mdm/layer_2_controllers/searchHandler.ts" enhancement="_blank" />
import { ok } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { runSearch } from '/_102034_/l1/mdm/layer_3_usecases/relationshipUsecases.js';
export const searchHandler = async ({ ctx, request }) => ok(await runSearch(ctx, request.params ?? {}));

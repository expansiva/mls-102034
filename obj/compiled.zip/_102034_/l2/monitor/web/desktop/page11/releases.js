/// <mls fileReference="_102034_/l2/monitor/web/desktop/page11/releases.ts" enhancement="_102033_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// Modernized standalone page for the monitor "releases" route. Releases is already a
// self-contained component; here it just gets a convention tag so the aura preview resolves it.
import { customElement } from 'lit/decorators.js';
import { MonitorWebDesktopReleasesPage } from '/_102034_/l2/monitor/web/routes/releases.js';
let MonitorReleasesPage = class MonitorReleasesPage extends MonitorWebDesktopReleasesPage {
};
MonitorReleasesPage = __decorate([
    customElement('monitor--web--desktop--page11--releases-102034')
], MonitorReleasesPage);
export { MonitorReleasesPage };

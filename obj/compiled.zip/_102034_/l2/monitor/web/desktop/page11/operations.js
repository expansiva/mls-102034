var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102034_/l2/monitor/web/desktop/page11/operations.ts" enhancement="_102033_/l2/enhancementAura"/>
import { customElement } from 'lit/decorators.js';
import { MonitorWebDesktopHomePage } from '/_102034_/l2/monitor/web/desktop/page11/home.js';
let MonitorOperationsPage = class MonitorOperationsPage extends MonitorWebDesktopHomePage {
    connectedCallback() {
        if (!this.getAttribute('data-route'))
            this.setAttribute('data-route', '/monitor/operacao');
        super.connectedCallback();
    }
};
MonitorOperationsPage = __decorate([
    customElement('monitor--web--desktop--page11--operations-102034')
], MonitorOperationsPage);
export { MonitorOperationsPage };

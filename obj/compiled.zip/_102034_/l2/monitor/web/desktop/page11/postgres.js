/// <mls fileReference="_102034_/l2/monitor/web/desktop/page11/postgres.ts" enhancement="_102033_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// Modernized standalone page for the monitor "postgres" route (Opção A). Reuses all of the
// monitor home logic by extending it and fixing the initial route (no shell/URL needed).
import { customElement } from 'lit/decorators.js';
import { MonitorWebDesktopHomePage } from '/_102034_/l2/monitor/web/desktop/page11/home.js';
let MonitorPostgresPage = class MonitorPostgresPage extends MonitorWebDesktopHomePage {
    connectedCallback() {
        if (!this.getAttribute('data-route'))
            this.setAttribute('data-route', '/monitor/postgres');
        super.connectedCallback();
    }
};
MonitorPostgresPage = __decorate([
    customElement('monitor--web--desktop--page11--postgres-102034')
], MonitorPostgresPage);
export { MonitorPostgresPage };

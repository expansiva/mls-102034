import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorPostgresTableDetails(input, options) {
    return execBff('monitor.postgresTable.details', input, options);
}
//# sourceMappingURL=tableDetailsPostgres.js.map
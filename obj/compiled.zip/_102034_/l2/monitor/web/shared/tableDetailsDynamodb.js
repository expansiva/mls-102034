import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorDynamoTableDetails(input, options) {
    return execBff('monitor.dynamodbTable.details', input, options);
}
//# sourceMappingURL=tableDetailsDynamodb.js.map
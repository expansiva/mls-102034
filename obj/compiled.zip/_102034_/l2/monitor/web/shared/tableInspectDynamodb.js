import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorDynamoTableInspect(input, options) {
    return execBff('monitor.dynamodbTable.inspect', input, options);
}
//# sourceMappingURL=tableInspectDynamodb.js.map
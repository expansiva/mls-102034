import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorAbend(params, options) {
    return execBff('monitor.abend.load', params, options);
}
export async function loadMonitorClientErrors(params, options) {
    return execBff('monitor.clientErrors.load', params, options);
}
//# sourceMappingURL=abend.js.map
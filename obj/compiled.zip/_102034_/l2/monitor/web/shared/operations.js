import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadMonitorOperationsSummary(params, options) {
    return execBff('monitor.operations.summary', params, options);
}

import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorArchitecture(options) {
    return execBff('monitor.architecture.load', {}, options);
}
//# sourceMappingURL=architecture.js.map
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorTrace(params, options) {
    return execBff('monitor.requestTrace.load', params, options);
}
//# sourceMappingURL=trace.js.map
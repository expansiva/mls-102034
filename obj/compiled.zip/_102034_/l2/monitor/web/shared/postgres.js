import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorPostgres(databaseName, options) {
    return execBff('monitor.postgres.load', {
        databaseName,
    }, options);
}
//# sourceMappingURL=postgres.js.map
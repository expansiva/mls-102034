import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorSeries(windowSeconds = 100, options) {
    return execBff('monitor.monitorGetStatistics.getSeries', {
        windowSeconds,
    }, options);
}
//# sourceMappingURL=series.js.map
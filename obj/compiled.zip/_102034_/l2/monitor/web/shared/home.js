import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadMonitorHome(options) {
    return execBff('monitor.home.load', {}, options);
}
//# sourceMappingURL=home.js.map
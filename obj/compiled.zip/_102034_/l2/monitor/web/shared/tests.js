import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadMonitorTestsList(options) {
    return execBff('monitor.tests.list', {}, options);
}
export async function runMonitorTests(params, options) {
    return execBff('monitor.tests.run', params, options);
}
export async function loadMonitorTestsResults(params, options) {
    return execBff('monitor.tests.results', params, options);
}

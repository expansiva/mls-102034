import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadMonitorDynamodb(options) {
    return execBff('monitor.dynamodb.load', {}, options);
}

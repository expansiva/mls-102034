import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadMonitorPostgresTableInspect(input, options) {
    return execBff('monitor.postgresTable.inspect', input, options);
}

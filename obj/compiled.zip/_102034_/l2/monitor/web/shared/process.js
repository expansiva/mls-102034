import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadMonitorProcess(options) {
    return execBff('monitor.process.load', {}, options);
}

/// <mls fileReference="_102034_/l2/monitor/web/routes/dynamodb.ts" enhancement="_blank" />
export { MonitorWebDesktopHomePage } from '../desktop/page11/home.js';
//# sourceMappingURL=dynamodb.js.map
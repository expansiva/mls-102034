/// <mls fileReference="_102034_/l2/monitor/web/routes/messagesText.ts" enhancement="_blank" />
import { getMessageKey } from '/_102029_/l2/collabLitElement.js';
const en = {
    startAt: 'Start at (local time)',
    startAtHelp: 'Browser time zone',
    invalidStartAt: 'Enter a valid local date and time.',
    logSource: 'Log source',
    apiStandardOutput: 'API · Standard output',
    apiErrorOutput: 'API · Error output',
    workerStandardOutput: 'Worker · Standard output',
    workerErrorOutput: 'Worker · Error output',
    copied: 'Copied',
    copyFailed: 'Copy failed (clipboard unavailable)',
    processApi: 'API',
    processWorker: 'Worker',
    outputStandard: 'Standard output',
    outputError: 'Error output',
    startAtUtc: 'Start at (UTC)',
    messageContains: 'Message contains',
};
const catalog = { en };
export function messagesPageText() {
    const key = getMessageKey(catalog);
    return catalog[key] ?? en;
}
export function messagesPageCopyLabels(text) {
    return {
        processApi: text.processApi,
        processWorker: text.processWorker,
        outputStandard: text.outputStandard,
        outputError: text.outputError,
        startAtLocal: text.startAt,
        startAtUtc: text.startAtUtc,
        messageContains: text.messageContains,
    };
}

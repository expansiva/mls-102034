const defaultQuery = () => ({
    app: 'msg',
    stream: 'error',
    startAt: '',
    text: '',
});
export function createMessagesLogsState() {
    return {
        generation: 0,
        mounted: false,
        phase: 'loading',
        query: defaultQuery(),
        entries: [],
        nextCursor: null,
        hasMore: false,
        limited: false,
        file: '',
        errorMessage: '',
        pendingCursor: null,
    };
}
/** New mount. In-flight responses from the previous mount no longer match. */
export function connectMessagesLogs(state) {
    return {
        ...createMessagesLogsState(),
        generation: state.generation + 1,
        mounted: true,
        query: state.query,
    };
}
export function disconnectMessagesLogs(state) {
    return {
        ...state,
        mounted: false,
        generation: state.generation + 1,
        pendingCursor: null,
    };
}
export function isCurrentMessagesLogs(state, generation) {
    return state.mounted && state.generation === generation;
}
export function beginMessagesLogsQuery(state, query) {
    return {
        ...state,
        generation: state.generation + 1,
        phase: 'loading',
        query,
        entries: [],
        nextCursor: null,
        hasMore: false,
        limited: false,
        file: '',
        errorMessage: '',
        pendingCursor: null,
    };
}
function phaseFor(entries, hasMore, limited) {
    if (limited)
        return 'limited';
    if (entries.length === 0)
        return 'empty';
    if (!hasMore)
        return 'result';
    return 'result';
}
export function applyMessagesLogsPage(state, generation, page) {
    if (!isCurrentMessagesLogs(state, generation) || state.phase !== 'loading')
        return state;
    return {
        ...state,
        phase: phaseFor(page.entries, page.hasMore, page.limited),
        entries: page.entries,
        nextCursor: page.nextCursor,
        hasMore: page.hasMore,
        limited: page.limited,
        file: page.file,
        errorMessage: '',
        pendingCursor: null,
    };
}
export function failMessagesLogsQuery(state, generation, message) {
    if (!isCurrentMessagesLogs(state, generation) || state.phase !== 'loading')
        return state;
    return {
        ...state,
        phase: 'error',
        entries: [],
        nextCursor: null,
        hasMore: false,
        limited: false,
        file: '',
        errorMessage: message,
        pendingCursor: null,
    };
}
export function markMessagesLogsSourceChanged(state, generation) {
    if (!isCurrentMessagesLogs(state, generation))
        return state;
    if (state.phase !== 'loading' && state.phase !== 'loading-more')
        return state;
    return {
        ...state,
        phase: 'source-changed',
        entries: [],
        nextCursor: null,
        hasMore: false,
        limited: false,
        errorMessage: 'Log source changed. Refresh to load the current file.',
        pendingCursor: null,
    };
}
export function beginMessagesLogsLoadMore(state) {
    if (!state.mounted || !state.hasMore || !state.nextCursor || state.pendingCursor)
        return state;
    if (state.phase === 'loading' || state.phase === 'loading-more' || state.phase === 'source-changed')
        return state;
    return {
        ...state,
        phase: 'loading-more',
        pendingCursor: state.nextCursor,
        errorMessage: '',
    };
}
export function applyMessagesLogsOlderPage(state, generation, requestedCursor, page) {
    if (!isCurrentMessagesLogs(state, generation))
        return state;
    if (state.phase !== 'loading-more' || state.pendingCursor !== requestedCursor)
        return state;
    const seen = new Set(state.entries.map((entry) => entry.id));
    const older = page.entries.filter((entry) => !seen.has(entry.id));
    const entries = [...older, ...state.entries];
    return {
        ...state,
        phase: phaseFor(entries, page.hasMore, page.limited),
        entries,
        nextCursor: page.nextCursor,
        hasMore: page.hasMore,
        limited: page.limited,
        file: page.file || state.file,
        errorMessage: '',
        pendingCursor: null,
    };
}
export function failMessagesLogsLoadMore(state, generation, message) {
    if (!isCurrentMessagesLogs(state, generation))
        return state;
    if (state.phase !== 'loading-more')
        return state;
    const entries = state.entries;
    return {
        ...state,
        phase: entries.length === 0 ? 'error' : (state.limited ? 'limited' : 'result'),
        errorMessage: message,
        pendingCursor: null,
    };
}
const LOCAL_DATE_TIME = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
/** datetime-local value is a UTC wall clock. Empty means no time filter. */
export function startAtLocalToIso(value) {
    const trimmed = value.trim();
    if (!trimmed)
        return { ok: true, iso: '' };
    const match = LOCAL_DATE_TIME.exec(trimmed);
    if (!match)
        return { ok: false, error: 'Enter a valid UTC date and time.' };
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const hour = Number(match[4]);
    const minute = Number(match[5]);
    const second = Number(match[6] ?? '0');
    if (month < 1 || month > 12 || hour > 23 || minute > 59 || second > 59) {
        return { ok: false, error: 'Enter a valid UTC date and time.' };
    }
    const utc = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
    if (utc.getUTCFullYear() !== year
        || utc.getUTCMonth() !== month - 1
        || utc.getUTCDate() !== day) {
        return { ok: false, error: 'Enter a valid UTC date and time.' };
    }
    const iso = utc.toISOString().replace('.000Z', 'Z');
    return { ok: true, iso };
}
/** One displayed line block: the UTC timestamp (when the source had one) and the message. Copy uses the same text. */
export function messagesLogsEntryLine(entry) {
    return entry.timestamp ? `${entry.timestamp} ${entry.text}` : entry.text;
}
export function messagesLogsBody(state) {
    return state.entries.map(messagesLogsEntryLine).join('\n');
}
export function messagesLogsCopyText(state) {
    if (state.phase === 'loading' || state.entries.length === 0)
        return '';
    const process = state.query.app === 'msg' ? 'API' : 'Worker';
    const output = state.query.stream === 'out' ? 'Standard output' : 'Error output';
    const lines = [`Process: ${process}`, `Output: ${output}`];
    if (state.query.startAt)
        lines.push(`Start at (UTC): ${state.query.startAt}`);
    if (state.query.text)
        lines.push(`Message contains: ${state.query.text}`);
    const body = messagesLogsBody(state);
    return `${lines.join('\n')}\n\n${body}`;
}
export function messagesLogsCanCopy(state) {
    return messagesLogsCopyText(state).length > 0;
}
export function messagesLogsCanLoadMore(state) {
    return state.mounted
        && state.phase !== 'loading'
        && state.phase !== 'loading-more'
        && state.phase !== 'source-changed'
        && state.hasMore
        && !!state.nextCursor
        && !state.pendingCursor;
}

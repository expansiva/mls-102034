/// <mls fileReference="_102034_/l2/monitor/web/routes/postgres-table.ts" enhancement="_blank" />
export { MonitorWebDesktopHomePage } from '../desktop/page11/home.js';
//# sourceMappingURL=postgres-table.js.map
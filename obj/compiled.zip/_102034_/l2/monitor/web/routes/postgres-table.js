/// <mls fileReference="_102034_/l2/monitor/web/routes/postgres-table.ts" enhancement="_blank" />
export { MonitorWebDesktopHomePage } from '/_102034_/l2/monitor/web/desktop/page11/home.js';

/// <mls fileReference="_102034_/l2/monitor/web/routes/dynamodb-table.ts" enhancement="_blank" />
export { MonitorWebDesktopHomePage } from '../desktop/page11/home.js';
//# sourceMappingURL=dynamodb-table.js.map
/// <mls fileReference="_102034_/l2/monitor/web/routes/process.ts" enhancement="_blank" />
export { MonitorWebDesktopHomePage } from '../desktop/page11/home.js';
//# sourceMappingURL=process.js.map
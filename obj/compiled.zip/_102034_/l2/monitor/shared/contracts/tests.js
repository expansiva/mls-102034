/// <mls fileReference="_102034_/l2/monitor/shared/contracts/tests.ts" enhancement="_blank" />
// Frontend view of the monitor Tests API (l1/monitor/layer_3_usecases/testsUsecases.ts). Kept as a
// standalone contract so the render layer does not import backend code.
export {};

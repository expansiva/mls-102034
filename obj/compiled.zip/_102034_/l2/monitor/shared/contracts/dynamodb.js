export {};
//# sourceMappingURL=dynamodb.js.map
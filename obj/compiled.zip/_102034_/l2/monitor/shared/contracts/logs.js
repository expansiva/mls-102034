/// <mls fileReference="_102034_/l2/monitor/shared/contracts/logs.ts" enhancement="_blank" />
export {};

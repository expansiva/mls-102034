export {};
//# sourceMappingURL=table-details-postgres.js.map
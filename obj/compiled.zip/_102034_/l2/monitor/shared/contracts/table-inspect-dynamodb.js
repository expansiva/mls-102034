export {};
//# sourceMappingURL=table-inspect-dynamodb.js.map
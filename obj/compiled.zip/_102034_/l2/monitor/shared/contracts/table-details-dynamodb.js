export {};
//# sourceMappingURL=table-details-dynamodb.js.map
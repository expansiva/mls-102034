export {};
//# sourceMappingURL=table-inspect-postgres.js.map
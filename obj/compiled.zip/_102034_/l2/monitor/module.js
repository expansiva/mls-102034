export const moduleGenome = {
    page11: {
        device: 'desktop',
        layout: 'standard',
    },
    page21: {
        device: 'mobile',
        layout: 'standard',
    },
};
export const moduleStates = {
    currentSection: 'ui.monitor.currentSection',
    refreshTick: 'ui.monitor.refreshTick',
};
export const moduleShellPreferences = {
    layout: {
        asideMode: {
            desktop: 'inline',
            mobile: 'fullscreen',
        },
    },
};
export const moduleFrontendDefinition = {
    pageTitle: 'monitor',
    device: 'desktop',
    navigation: [
        { id: 'overview', label: 'Overview', href: '/monitor', description: 'System status and endpoint activity' },
        { id: 'operations', label: 'Operacao', href: '/monitor/operacao', description: '24h operational summary for support' },
        { id: 'process', label: 'Process', href: '/monitor/process', description: 'Node.js runtime health — memory, uptime, load' },
        { id: 'architecture', label: 'Architecture', href: '/monitor/architecture', description: 'Module topology and storage design' },
        { id: 'postgres', label: 'Postgres', href: '/monitor/postgres', description: 'Tables, cache and queue status' },
        { id: 'dynamodb', label: 'DynamoDB', href: '/monitor/dynamodb', description: 'Tables and storage status' },
        { id: 'abend', label: 'Abends', href: '/monitor/abend', description: 'Failed BFF executions with error details' },
        { id: 'trace', label: 'Trace', href: '/monitor/trace', description: 'Correlate requests by requestId or traceId' },
        { id: 'tests', label: 'Tests', href: '/monitor/tests', description: 'Generated BFF test cases — view runs and execute (dev only)' },
        { id: 'releases', label: 'Releases', href: '/monitor/releases', description: 'Deploy/rollback releases and view pm2 logs (admin)' },
        { id: 'config', label: 'Config', href: '/monitor/config', description: 'Composed workspace config.json (read-only inspect)' },
    ],
    headerRenderer: {
        entrypoint: '/_102034_/l2/monitor/web/desktop/page11/header.js',
        tag: 'monitor-web-desktop-header',
    },
    asideRenderer: {
        entrypoint: '/_102034_/l2/monitor/web/desktop/page11/aside.js',
        tag: 'monitor-web-desktop-aside',
    },
    routes: [
        {
            path: '/monitor',
            aliases: ['/monitor/index.html', '/monitor/overview'],
            entrypoint: '/_102034_/l2/monitor/web/routes/overview.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Overview',
        },
        {
            path: '/monitor/architecture',
            entrypoint: '/_102034_/l2/monitor/web/routes/architecture.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Architecture',
        },
        {
            path: '/monitor/operacao',
            aliases: ['/monitor/operations'],
            entrypoint: '/_102034_/l2/monitor/web/routes/operations.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Operacao',
        },
        {
            path: '/monitor/postgres',
            entrypoint: '/_102034_/l2/monitor/web/routes/postgres.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Postgres',
        },
        {
            path: '/monitor/dynamodb',
            entrypoint: '/_102034_/l2/monitor/web/routes/dynamodb.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'DynamoDB',
        },
        {
            path: '/monitor/postgres/tables',
            entrypoint: '/_102034_/l2/monitor/web/routes/postgres-table.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Postgres table',
            matchMode: 'prefix',
        },
        {
            path: '/monitor/dynamodb/tables',
            entrypoint: '/_102034_/l2/monitor/web/routes/dynamodb-table.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'DynamoDB table',
            matchMode: 'prefix',
        },
        {
            path: '/monitor/process',
            entrypoint: '/_102034_/l2/monitor/web/routes/process.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Process',
        },
        {
            path: '/monitor/abend',
            entrypoint: '/_102034_/l2/monitor/web/routes/abend.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Abends',
        },
        {
            path: '/monitor/trace',
            entrypoint: '/_102034_/l2/monitor/web/routes/trace.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Trace',
        },
        {
            path: '/monitor/tests',
            entrypoint: '/_102034_/l2/monitor/web/routes/tests.js',
            tag: 'monitor-web-desktop-home-page',
            title: 'Tests',
        },
        {
            path: '/monitor/releases',
            entrypoint: '/_102034_/l2/monitor/web/routes/releases.js',
            tag: 'monitor-web-desktop-releases-page',
            title: 'Releases',
        },
        {
            path: '/monitor/config',
            entrypoint: '/_102034_/l2/monitor/web/routes/config.js',
            tag: 'monitor-web-desktop-config-page',
            title: 'Config',
        },
    ],
};

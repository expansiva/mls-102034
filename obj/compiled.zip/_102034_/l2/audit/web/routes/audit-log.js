/// <mls fileReference="_102034_/l2/audit/web/routes/audit-log.ts" enhancement="_blank" />
export { AuditWebDesktopHomePage } from '../desktop/page11/home.js';
//# sourceMappingURL=audit-log.js.map
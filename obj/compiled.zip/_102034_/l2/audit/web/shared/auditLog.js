import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadAuditLog(input, options) {
    return execBff('audit.auditLog.load', input, options);
}

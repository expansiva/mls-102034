import { execBff } from '/_102029_/l2/bffClient.js';
export async function loadAuditStatusHistory(input, options) {
    return execBff('audit.statusHistory.load', input, options);
}

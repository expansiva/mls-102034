import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadAuditHome(options) {
    return execBff('audit.home.load', {}, options);
}
//# sourceMappingURL=home.js.map
/// <mls fileReference="_102034_/l2/audit/web/shared/formatters.ts" enhancement="_blank" />
export function formatInteger(value) {
    return new Intl.NumberFormat('pt-BR').format(value ?? 0);
}
export function formatDateTime(value) {
    if (!value) {
        return 'n/a';
    }
    return new Date(value).toLocaleString('pt-BR');
}
export function formatJson(value) {
    if (value === null || value === undefined) {
        return 'null';
    }
    return JSON.stringify(value, null, 2);
}
//# sourceMappingURL=formatters.js.map
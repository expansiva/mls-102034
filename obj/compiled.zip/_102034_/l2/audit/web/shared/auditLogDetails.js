import { execBff } from '../../../../../_102029_/l2/bffClient.js';
export async function loadAuditLogDetails(input, options) {
    return execBff('audit.auditLog.details', input, options);
}
//# sourceMappingURL=auditLogDetails.js.map